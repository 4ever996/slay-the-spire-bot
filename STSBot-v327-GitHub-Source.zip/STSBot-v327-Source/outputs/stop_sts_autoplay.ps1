[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $PSScriptRoot
$WorkDir = Join-Path $PackageRoot "work"
$CommDir = Join-Path $WorkDir "sts-comm"

function Stop-RecordedProcess(
    [string]$RecordName,
    [string]$ExpectedMarker,
    [string]$Label
) {
    $recordPath = Join-Path $CommDir $RecordName
    if (!(Test-Path -LiteralPath $recordPath -PathType Leaf)) { return $false }
    try {
        $record = Get-Content -LiteralPath $recordPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $process = Get-CimInstance Win32_Process -Filter "ProcessId = $([int]$record.Pid)" -ErrorAction SilentlyContinue
        if ($process -and [string]$process.CommandLine -like "*$ExpectedMarker*") {
            Stop-Process -Id ([int]$record.Pid) -Force -ErrorAction Stop
            Write-Host "Stopped $Label (PID $($record.Pid))."
            Remove-Item -LiteralPath $recordPath -Force -ErrorAction SilentlyContinue
            return $true
        }
        Write-Host "Skipped stale $Label process record."
        Remove-Item -LiteralPath $recordPath -Force -ErrorAction SilentlyContinue
    } catch {
        Write-Warning "Could not stop $Label safely: $($_.Exception.Message)"
    }
    return $false
}

$BotScript = Join-Path $WorkDir "sts_file_bot.py"
$DashboardScript = Join-Path $WorkDir "sts_dashboard.py"
$BridgeScript = Join-Path $WorkDir "sts_comm_bridge.py"

[void](Stop-RecordedProcess "bot_process.json" $BotScript "autoplay bot")
[void](Stop-RecordedProcess "game_process.json" "ModTheSpire.jar" "Slay the Spire")

try {
    $bridgeProcesses = @(
        Get-CimInstance Win32_Process -ErrorAction Stop |
            Where-Object {
                $_.Name -match "^python(w)?\.exe$" -and
                [string]$_.CommandLine -like "*$BridgeScript*"
            }
    )
    foreach ($bridge in $bridgeProcesses) {
        Stop-Process -Id $bridge.ProcessId -Force -ErrorAction SilentlyContinue
        Write-Host "Stopped communication bridge (PID $($bridge.ProcessId))."
    }
} catch {
    Write-Warning "Could not inspect the communication bridge process."
}

[void](Stop-RecordedProcess "dashboard_process.json" $DashboardScript "live dashboard")

Write-Host "Autoplay processes for this package are stopped."
