﻿[CmdletBinding()]
param(
    [string]$GameDir = "",

    [string]$PythonPath = "",

    [ValidateRange(-1, 20)]
    [int]$Ascension = -1,

    [ValidateRange(0, 100)]
    [int]$MaxRuns = 0,

    [ValidateRange(1, 4)]
    [int]$ReviewLossMinAct = 2,

    [ValidateRange(0, 100)]
    [int]$InitialQualifyingLosses = 0,

    [ValidateSet("Auto", "Loop", "Count")]
    [string]$TestMode = "Auto",

    [ValidateRange(1, 999)]
    [int]$TestRuns = 3,

    [switch]$NoLaunchDialog,

    [switch]$CheckOnly,

    [switch]$SkipModInstall
)

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $PSScriptRoot
$WorkDir = Join-Path $PackageRoot "work"
$CommDir = Join-Path $WorkDir "sts-comm"
$BridgeScript = Join-Path $WorkDir "sts_comm_bridge.py"
$BotScript = Join-Path $WorkDir "sts_file_bot.py"
$DashboardScript = Join-Path $WorkDir "sts_dashboard.py"
$LaunchDialogScript = Join-Path $WorkDir "sts_launch_dialog.py"
$CommunicationConfigDir = Join-Path $env:LOCALAPPDATA "ModTheSpire\CommunicationMod"
$CommunicationConfig = Join-Path $CommunicationConfigDir "config.properties"
$TrainingStatePath = Join-Path $CommDir "training_a4_a20.json"
$PortableConfigPath = Join-Path $PackageRoot "portable_config.json"
$BundledModDir = Join-Path $PackageRoot "runtime\mods"

function Test-SlayTheSpireDirectory([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    return (
        (Test-Path -LiteralPath (Join-Path $Path "desktop-1.0.jar") -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $Path "jre\bin\java.exe") -PathType Leaf)
    )
}

function Get-SteamLibraryRoots {
    $roots = @()
    $registryKeys = @(
        "HKCU:\Software\Valve\Steam",
        "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam",
        "HKLM:\SOFTWARE\Valve\Steam"
    )
    foreach ($key in $registryKeys) {
        if (!(Test-Path -LiteralPath $key)) { continue }
        try {
            $properties = Get-ItemProperty -LiteralPath $key
            foreach ($name in @("SteamPath", "InstallPath")) {
                $value = [string]$properties.$name
                if (![string]::IsNullOrWhiteSpace($value)) {
                    $roots += $value.Replace("/", "\")
                }
            }
        } catch {}
    }

    foreach ($steamRoot in @($roots)) {
        $libraryFile = Join-Path $steamRoot "steamapps\libraryfolders.vdf"
        if (!(Test-Path -LiteralPath $libraryFile -PathType Leaf)) { continue }
        try {
            $libraryText = Get-Content -LiteralPath $libraryFile -Raw -Encoding UTF8
            foreach ($match in [regex]::Matches($libraryText, '"path"\s+"([^"]+)"')) {
                $roots += $match.Groups[1].Value.Replace('\\', '\')
            }
        } catch {}
    }

    foreach ($drive in Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue) {
        $roots += (Join-Path $drive.Root "SteamLibrary")
        $roots += (Join-Path $drive.Root "Steam")
        $roots += (Join-Path $drive.Root "Program Files (x86)\Steam")
        $roots += (Join-Path $drive.Root "Program Files\Steam")
    }

    return @(
        $roots |
            Where-Object { ![string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object {
                try { [System.IO.Path]::GetFullPath($_) } catch { $_ }
            } |
            Select-Object -Unique
    )
}

function Find-SlayTheSpireDirectory {
    $candidates = @()
    if (![string]::IsNullOrWhiteSpace($env:STS_GAME_DIR)) {
        $candidates += $env:STS_GAME_DIR
    }
    if (Test-Path -LiteralPath $PortableConfigPath -PathType Leaf) {
        try {
            $savedConfig = Get-Content -LiteralPath $PortableConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($savedConfig.GameDir) { $candidates += [string]$savedConfig.GameDir }
        } catch {}
    }
    foreach ($root in Get-SteamLibraryRoots) {
        $candidates += (Join-Path $root "steamapps\common\SlayTheSpire")
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-SlayTheSpireDirectory $candidate) {
            return [System.IO.Path]::GetFullPath($candidate)
        }
    }
    return $null
}

function Select-SlayTheSpireDirectory {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select the SlayTheSpire game folder (the folder containing desktop-1.0.jar)."
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }
    return $dialog.SelectedPath
}

function Resolve-BotPython([string]$RequestedPath) {
    $candidates = @()
    if (![string]::IsNullOrWhiteSpace($RequestedPath)) { $candidates += $RequestedPath }
    if (![string]::IsNullOrWhiteSpace($env:STS_BOT_PYTHON)) { $candidates += $env:STS_BOT_PYTHON }
    $candidates += (Join-Path $PackageRoot "runtime\python\python.exe")
    $candidates += (Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe")
    $pythonRoot = Join-Path $env:LOCALAPPDATA "Programs\Python"
    if (Test-Path -LiteralPath $pythonRoot -PathType Container) {
        $candidates += @(
            Get-ChildItem -LiteralPath $pythonRoot -Directory -Filter "Python*" -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                ForEach-Object { Join-Path $_.FullName "python.exe" }
        )
    }
    foreach ($commandName in @("python.exe", "python3.exe")) {
        try {
            $command = Get-Command $commandName -ErrorAction Stop
            if ($command.Source) { $candidates += $command.Source }
        } catch {}
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [System.IO.Path]::GetFullPath($candidate)
        }
    }
    return $null
}

function Install-BundledFile([string]$Source, [string]$Destination) {
    if (!(Test-Path -LiteralPath $Source -PathType Leaf)) { return }
    $copyRequired = !(Test-Path -LiteralPath $Destination -PathType Leaf)
    if (!$copyRequired) {
        $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Source).Hash
        $destinationHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Destination).Hash
        $copyRequired = $sourceHash -ne $destinationHash
    }
    if (!$copyRequired) {
        Write-Host "Mod ready: $Destination"
        return
    }
    $destinationParent = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Force -Path $destinationParent | Out-Null
    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        $backup = "$Destination.autoplay_backup"
        if (!(Test-Path -LiteralPath $backup -PathType Leaf)) {
            Copy-Item -LiteralPath $Destination -Destination $backup -Force
            Write-Host "Backed up existing mod: $backup"
        }
    }
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    Write-Host "Installed bundled mod: $Destination"
}

$Python = Resolve-BotPython $PythonPath
if (!$Python) {
    throw "Python runtime not found. Re-extract the complete portable package or pass -PythonPath."
}

if (![string]::IsNullOrWhiteSpace($GameDir)) {
    $GameDir = [System.IO.Path]::GetFullPath($GameDir)
} else {
    $GameDir = Find-SlayTheSpireDirectory
}
if (!(Test-SlayTheSpireDirectory $GameDir)) {
    $selectedGameDir = Select-SlayTheSpireDirectory
    if (!(Test-SlayTheSpireDirectory $selectedGameDir)) {
        throw "A valid SlayTheSpire game directory was not selected."
    }
    $GameDir = [System.IO.Path]::GetFullPath($selectedGameDir)
}

$Java = Join-Path $GameDir "jre\bin\java.exe"

@{
    GameDir = $GameDir
    Updated = (Get-Date).ToString("o")
} | ConvertTo-Json | Set-Content -LiteralPath $PortableConfigPath -Encoding UTF8

if (!$SkipModInstall -and (Test-Path -LiteralPath $BundledModDir -PathType Container)) {
    Install-BundledFile (Join-Path $BundledModDir "ModTheSpire.jar") (Join-Path $GameDir "ModTheSpire.jar")
    Install-BundledFile (Join-Path $BundledModDir "BaseMod.jar") (Join-Path $GameDir "mods\BaseMod.jar")
    Install-BundledFile (Join-Path $BundledModDir "CommunicationMod.jar") (Join-Path $GameDir "mods\CommunicationMod.jar")
}

$requiredPaths = @(
    $GameDir,
    $Python,
    $Java,
    $BridgeScript,
    $BotScript,
    $DashboardScript,
    $LaunchDialogScript,
    (Join-Path $GameDir "ModTheSpire.jar"),
    (Join-Path $GameDir "mods\BaseMod.jar"),
    (Join-Path $GameDir "mods\CommunicationMod.jar")
)
foreach ($requiredPath in $requiredPaths) {
    if (!(Test-Path -LiteralPath $requiredPath)) {
        throw "Required runtime file not found: $requiredPath"
    }
}
if ($Python -match "\s" -or $BridgeScript -match "\s") {
    throw "CommunicationMod cannot parse paths containing spaces. Extract the package to a simple path such as D:\STSBot."
}

New-Item -ItemType Directory -Force -Path $CommDir | Out-Null

if ($CheckOnly) {
    & $Python $LaunchDialogScript --validate 1 count 1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Bundled Python could not load the launch dialog module." }
    & $Python $BotScript --help | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Bundled Python could not load the bot modules." }
    Write-Host "Portable package check passed."
    Write-Host "  Package: $PackageRoot"
    Write-Host "  Game:    $GameDir"
    Write-Host "  Python:  $Python"
    Write-Host "  Mods:    ModTheSpire, BaseMod, CommunicationMod"
    exit 0
}

if ($Ascension -lt 0 -and (Test-Path -LiteralPath $TrainingStatePath)) {
    try {
        $trainingState = Get-Content -LiteralPath $TrainingStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $Ascension = [int]$trainingState.CurrentAscension
    } catch {
        Write-Warning "Could not read training state from $TrainingStatePath; using Ascension 8."
    }
}
if ($Ascension -lt 0) { $Ascension = 8 }

$showLaunchDialog = (
    !$NoLaunchDialog -and
    $TestMode -eq "Auto" -and
    !$PSBoundParameters.ContainsKey("MaxRuns")
)
if ($showLaunchDialog) {
    $dialogJson = & $Python $LaunchDialogScript `
        --default-ascension $Ascension --default-runs $TestRuns
    if ($LASTEXITCODE -eq 2) {
        Write-Host "Bot launch cancelled."
        exit 0
    }
    if ($LASTEXITCODE -ne 0 -or !$dialogJson) {
        throw "Bot launch dialog failed with exit code $LASTEXITCODE."
    }
    try {
        $selection = ($dialogJson | Out-String) | ConvertFrom-Json
        $Ascension = [int]$selection.ascension
        $TestMode = [string]$selection.mode
        $TestRuns = [int]$selection.runs
    } catch {
        throw "Bot launch dialog returned invalid settings: $dialogJson"
    }
}

$MaxTotalRuns = 0
$ContinueAfterVictory = $false
switch ($TestMode) {
    "Loop" {
        $MaxRuns = 0
        $ContinueAfterVictory = $true
        $targetDescription = "loop continuously until manually stopped"
    }
    "Count" {
        $MaxRuns = 0
        $MaxTotalRuns = $TestRuns
        $ContinueAfterVictory = $true
        $targetDescription = "stop after exactly $TestRuns completed runs"
    }
    default {
        if ($MaxRuns -le 0) { $MaxRuns = 3 }
        $targetDescription = "stop after $MaxRuns losses reaching Act $ReviewLossMinAct+"
    }
}

New-Item -ItemType Directory -Force -Path $CommDir | Out-Null
New-Item -ItemType Directory -Force -Path $CommunicationConfigDir | Out-Null

function Convert-ToJavaPropertyValue([string]$Value) {
    return $Value.Replace("\", "\\").Replace(":", "\:").Replace("=", "\=")
}

# CommunicationMod launches the bridge from its SpireConfig file. Rewrite the
# config on every launch so the package containing this launcher is always used.
if ((Test-Path -LiteralPath $CommunicationConfig) -and !(Test-Path -LiteralPath "$CommunicationConfig.autoplay_backup")) {
    Copy-Item -LiteralPath $CommunicationConfig -Destination "$CommunicationConfig.autoplay_backup" -Force
}
$bridgeCommand = "$Python $BridgeScript"
$configLines = @(
    "# Autogenerated by start_sts_autoplay.ps1",
    "command=$(Convert-ToJavaPropertyValue $bridgeCommand)",
    "runAtGameStart=true",
    "maxInitializationTimeout=30",
    "verbose=true"
)
[System.IO.File]::WriteAllLines(
    $CommunicationConfig,
    $configLines,
    [System.Text.UTF8Encoding]::new($false)
)

# The game inherits this environment variable and passes it to the bridge.
# This guarantees that state and command files are written beside this package.
$env:STS_COMM_DIR = $CommDir
Write-Host "CommunicationMod bridge configured:"
Write-Host "  Config: $CommunicationConfig"
Write-Host "  Bridge: $BridgeScript"
Write-Host "  Comm:   $CommDir"
Write-Host "  Target: Ironclad Ascension $Ascension, $targetDescription"

$existingGame = @()
try {
    $existingGame = @(Get-CimInstance Win32_Process -ErrorAction Stop |
        Where-Object {
            $_.ExecutablePath -like "$GameDir\jre\bin\java*.exe" -and
            $_.CommandLine -match "(desktop-1\.0|ModTheSpire)\.jar"
        })
} catch {
    $existingGame = @(Get-Process java -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -eq $Java })
}
if ($existingGame) {
    Write-Host "Slay the Spire is already running. Close it before starting autoplay."
    $existingGame | Select-Object ProcessId, CommandLine | Format-Table -AutoSize
    exit 2
}

$botProcessFile = Join-Path $CommDir "bot_process.json"
if (Test-Path -LiteralPath $botProcessFile) {
    try {
        $oldBot = Get-Content -LiteralPath $botProcessFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $oldProcess = $null
        if ($oldBot.Pid) {
            $oldProcess = Get-Process -Id $oldBot.Pid -ErrorAction SilentlyContinue
        }
        $expectedBotScript = Join-Path $WorkDir "sts_file_bot.py"
        $isActualBot = (
            $oldProcess -and
            $oldProcess.ProcessName -match "^python(w)?$" -and
            $oldBot.Script -and
            [System.IO.Path]::GetFullPath([string]$oldBot.Script) -eq
                [System.IO.Path]::GetFullPath($expectedBotScript)
        )
        if ($isActualBot) {
            Write-Host "Autoplay bot is already running with PID $($oldBot.Pid)."
            exit 3
        }
        Write-Host "Removing stale bot process record for PID $($oldBot.Pid)."
        Remove-Item -LiteralPath $botProcessFile -Force -ErrorAction SilentlyContinue
    } catch {
        Remove-Item -LiteralPath $botProcessFile -Force -ErrorAction SilentlyContinue
    }
}

$dashboardProcessFile = Join-Path $CommDir "dashboard_process.json"
$dashboardProcess = $null
$dashboardErr = $null
if (Test-Path -LiteralPath $dashboardProcessFile) {
    try {
        $oldDashboard = Get-Content -LiteralPath $dashboardProcessFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($oldDashboard.Pid) {
            $candidateDashboard = Get-Process -Id $oldDashboard.Pid -ErrorAction SilentlyContinue
            if (
                $candidateDashboard -and
                $candidateDashboard.ProcessName -match "^python(w)?$" -and
                $oldDashboard.Script -and
                [System.IO.Path]::GetFullPath([string]$oldDashboard.Script) -eq
                    [System.IO.Path]::GetFullPath($DashboardScript)
            ) {
                $dashboardProcess = $candidateDashboard
                $dashboardErr = [string]$oldDashboard.Err
            }
        }
        if (!$dashboardProcess) {
            Remove-Item -LiteralPath $dashboardProcessFile -Force -ErrorAction SilentlyContinue
        }
    } catch {
        Remove-Item -LiteralPath $dashboardProcessFile -Force -ErrorAction SilentlyContinue
    }
}

"command.txt", "state_latest.json", "state_latest.pretty.json", "state_seq.txt" |
    ForEach-Object {
        $path = Join-Path $CommDir $_
        Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
    }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$gameOut = Join-Path $CommDir "game_run_$stamp.out.log"
$gameErr = Join-Path $CommDir "game_run_$stamp.err.log"
$botOut = Join-Path $CommDir "bot_run_$stamp.out.txt"
$botErr = Join-Path $CommDir "bot_run_$stamp.err.txt"

$gameArgs = @(
    "-Xmx8G",
    "-jar", "ModTheSpire.jar",
    "--skip-launcher",
    "--skip-intro",
    "--mods", "basemod,CommunicationMod"
)
$game = Start-Process -FilePath $Java -ArgumentList $gameArgs -WorkingDirectory $GameDir `
    -RedirectStandardOutput $gameOut -RedirectStandardError $gameErr -PassThru

@{
    Pid = $game.Id
    Out = $gameOut
    Err = $gameErr
    Started = (Get-Date).ToString("o")
} | ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $CommDir "game_process.json") -Encoding ASCII

Write-Host "Started modded Slay the Spire with PID $($game.Id). Waiting for CommunicationMod state..."

$statePath = Join-Path $CommDir "state_latest.json"
$deadline = (Get-Date).AddSeconds(90)
$state = $null
while ((Get-Date) -lt $deadline) {
    if ($game.HasExited) {
        throw "Game exited early. Check $gameOut and $gameErr"
    }
    if (Test-Path -LiteralPath $statePath) {
        try {
            $candidate = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            $commands = @($candidate.available_commands | ForEach-Object { "$($_)".ToLowerInvariant() })
            if ($candidate.ready_for_command -ne $null -and ($candidate.in_game -eq $true -or $commands -contains "start")) {
                $state = $candidate
                break
            }
        } catch {}
    }
    Start-Sleep -Milliseconds 500
}

if ($null -eq $state) {
    throw "Timed out waiting for a usable CommunicationMod state. The launcher rewrote $CommunicationConfig to use $BridgeScript. Check $gameOut, $gameErr, and $GameDir\communication_mod_errors.log."
}

$botSource = Get-Content -LiteralPath $BotScript -Raw
$botVersion = if ($botSource -match 'BOT_VERSION\s*=\s*"([^"]+)"') { $Matches[1] } else { "unknown" }
# Stop immediately after an authoritative target-ascension victory, or after
# the configured number of target-ascension losses.
$botArgs = @(
    $BotScript,
    "--steps", "10000",
    "--max-runs", "$MaxRuns",
    "--max-total-runs", "$MaxTotalRuns",
    "--review-loss-min-act", "$ReviewLossMinAct",
    "--initial-qualifying-losses", "$InitialQualifyingLosses",
    "--restart-on-loss",
    "--ascension", "$Ascension"
)
if ($ContinueAfterVictory) {
    $botArgs += "--continue-after-victory"
}
$env:STS_BOT_STDOUT_LOG = "1"
$env:PYTHONUNBUFFERED = "1"
$bot = Start-Process -FilePath $Python -ArgumentList $botArgs -WorkingDirectory $WorkDir `
    -RedirectStandardOutput $botOut -RedirectStandardError $botErr -WindowStyle Hidden -PassThru

@{
    Pid = $bot.Id
    Version = $botVersion
    Script = $BotScript
    Out = $botOut
    Err = $botErr
    Ascension = $Ascension
    MaxRuns = $MaxRuns
    MaxTotalRuns = $MaxTotalRuns
    TestMode = $TestMode
    TestRuns = $TestRuns
    ContinueAfterVictory = $ContinueAfterVictory
    ReviewLossMinAct = $ReviewLossMinAct
    InitialQualifyingLosses = $InitialQualifyingLosses
    Started = (Get-Date).ToString("o")
} | ConvertTo-Json -Compress | Set-Content -LiteralPath $botProcessFile -Encoding ASCII

if (!$dashboardProcess) {
    $dashboardPython = Join-Path (Split-Path -Parent $Python) "pythonw.exe"
    if (!(Test-Path -LiteralPath $dashboardPython)) {
        $dashboardPython = $Python
    }
    $dashboardOut = Join-Path $CommDir "dashboard_run_$stamp.out.txt"
    $dashboardErr = Join-Path $CommDir "dashboard_run_$stamp.err.txt"
    $dashboardArgs = @(
        $DashboardScript,
        "--comm-dir", $CommDir
    )
    $dashboardProcess = Start-Process -FilePath $dashboardPython -ArgumentList $dashboardArgs `
        -WorkingDirectory $WorkDir -RedirectStandardOutput $dashboardOut `
        -RedirectStandardError $dashboardErr -PassThru
    @{
        Pid = $dashboardProcess.Id
        Script = $DashboardScript
        Out = $dashboardOut
        Err = $dashboardErr
        Started = (Get-Date).ToString("o")
    } | ConvertTo-Json -Compress | Set-Content -LiteralPath $dashboardProcessFile -Encoding ASCII
    Write-Host "Started live bot dashboard with PID $($dashboardProcess.Id)."
} else {
    Write-Host "Live bot dashboard is already running with PID $($dashboardProcess.Id)."
}

Start-Sleep -Milliseconds 1000
if ($bot.HasExited) {
    $details = if (Test-Path -LiteralPath $botErr) { Get-Content -LiteralPath $botErr -Tail 30 | Out-String } else { "No bot error log was created." }
    throw "Autoplay bot exited immediately.`n$details"
}
if ($dashboardProcess.HasExited) {
    $dashboardDetails = if ($dashboardErr -and (Test-Path -LiteralPath $dashboardErr)) { Get-Content -LiteralPath $dashboardErr -Tail 30 | Out-String } else { "No dashboard error log was created." }
    Write-Warning "Live dashboard exited immediately.`n$dashboardDetails"
}

Write-Host "Started autoplay bot with PID $($bot.Id). Waiting for Ascension $Ascension run to begin..."
$runDeadline = (Get-Date).AddSeconds(30)
$lastState = $state
while ((Get-Date) -lt $runDeadline) {
    if ($bot.HasExited) {
        $details = if (Test-Path -LiteralPath $botErr) { Get-Content -LiteralPath $botErr -Tail 30 | Out-String } else { "No bot error log was created." }
        throw "Autoplay bot stopped before starting a run.`n$details"
    }
    if (Test-Path -LiteralPath $statePath) {
        try {
            $lastState = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($lastState.error) {
                throw "CommunicationMod rejected a command: $($lastState.error)"
            }
            if ($lastState.in_game -eq $true) {
                $startedAscension = [int]$lastState.game_state.ascension_level
                if ($startedAscension -ne $Ascension) {
                    Start-Sleep -Milliseconds 500
                    continue
                }
                Write-Host "Ascension $Ascension Ironclad run started successfully."
                Write-Host "Logs are in $CommDir"
                exit 0
            }
        } catch {
            if ($_.Exception.Message -like "CommunicationMod rejected*") { throw }
        }
    }
    Start-Sleep -Milliseconds 500
}

throw "The bot process is running, but the game stayed at the main menu for 30 seconds. Check $CommDir\bot.log, $CommDir\bridge.log, and $statePath."
