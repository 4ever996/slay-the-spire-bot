import argparse
import ctypes
import json
import os
import re
import sys
import time
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent))
from ironclad_archetypes import ARCHETYPES
from sts_file_bot import archetype_profile, archetype_specialization


ARCHETYPE_LABELS = {
    "strength": "力量",
    "exhaust": "消耗",
    "block": "格挡",
    "self_harm": "自伤",
    "status": "状态 / 诅咒",
    "perfected_strike": "完美打击",
}

ARCHETYPE_COLORS = {
    "strength": "#db6b62",
    "exhaust": "#d99a54",
    "block": "#5b9bd5",
    "self_harm": "#b76aa2",
    "status": "#73a66b",
    "perfected_strike": "#d6b85c",
}

ROOM_LABELS = {
    "MonsterRoom": "普通战斗",
    "MonsterRoomElite": "精英战斗",
    "MonsterRoomBoss": "Boss 战斗",
    "EventRoom": "问号事件",
    "RestRoom": "休息处",
    "ShopRoom": "商店",
    "TreasureRoom": "宝箱",
    "VictoryRoom": "胜利",
}

SCREEN_LABELS = {
    "NONE": "行动中",
    "MAP": "选择路线",
    "CARD_REWARD": "选择卡牌",
    "COMBAT_REWARD": "领取战利品",
    "BOSS_REWARD": "选择 Boss 遗物",
    "SHOP_SCREEN": "商店购物",
    "SHOP": "商店",
    "GRID": "选择卡牌",
    "HAND_SELECT": "选择手牌",
    "EVENT": "处理事件",
    "GAME_OVER": "本局结束",
}

INTENT_LABELS = {
    "ATTACK": "攻击",
    "ATTACK_BUFF": "攻击 + 强化",
    "ATTACK_DEBUFF": "攻击 + 弱化",
    "ATTACK_DEFEND": "攻击 + 格挡",
    "BUFF": "强化",
    "DEBUFF": "弱化",
    "DEFEND": "格挡",
    "DEFEND_BUFF": "格挡 + 强化",
    "DEFEND_DEBUFF": "格挡 + 弱化",
    "ESCAPE": "逃跑",
    "MAGIC": "特殊行动",
    "NONE": "无",
    "SLEEP": "休眠",
    "STUN": "眩晕",
    "UNKNOWN": "未知",
}

SUBSTANTIVE_COMMANDS = (
    "PLAY ", "END", "CHOOSE ", "POTION ", "PROCEED", "RETURN",
    "LEAVE", "SKIP", "START ", "ABANDON",
)


def read_json(path, default=None, attempts=3):
    for attempt in range(attempts):
        try:
            return json.loads(Path(path).read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            if attempt + 1 < attempts:
                time.sleep(0.02)
    return {} if default is None else default


def tail_lines(path, max_bytes=65536):
    path = Path(path)
    try:
        with path.open("rb") as stream:
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(max(0, size - max_bytes), os.SEEK_SET)
            payload = stream.read()
    except OSError:
        return []
    text = payload.decode("utf-8", errors="replace")
    lines = text.splitlines()
    if size > max_bytes and lines:
        lines = lines[1:]
    return lines


def command_from_log_line(line):
    match = re.search(r"\bcmd=(.+)$", str(line or ""))
    return match.group(1).strip() if match else ""


def recent_commands(log_lines, limit=7):
    commands = []
    for line in reversed(log_lines or []):
        if "=== BOT SESSION START" in line:
            break
        command = command_from_log_line(line)
        if not command or command in {"STATE", "WAIT 10", "WAIT 30"}:
            continue
        commands.append(command)
        if len(commands) >= limit:
            break
    return list(reversed(commands))


def completed_runs_from_log(log_lines):
    for line in reversed(log_lines or []):
        if "=== BOT SESSION START" in line:
            break
        match = re.search(r"\bcompleted_runs=(\d+)/(\d+|loop)\b", line)
        if match:
            return int(match.group(1))
    return 0


def command_description(command):
    command = str(command or "").strip()
    upper = command.upper()
    if not command:
        return "等待机器人决策"
    if upper.startswith("PLAY "):
        parts = command.split()
        card = parts[1] if len(parts) > 1 else "?"
        if len(parts) > 2:
            return f"打出手牌 #{card}，目标敌人 #{parts[2]}"
        return f"打出手牌 #{card}"
    if upper == "END":
        return "结束当前回合"
    if upper.startswith("CHOOSE "):
        return f"选择选项 #{command.split(maxsplit=1)[1]}"
    if upper.startswith("POTION USE "):
        return "使用药水 " + command[len("POTION USE "):]
    if upper.startswith("POTION DISCARD "):
        return "丢弃药水 " + command[len("POTION DISCARD "):]
    if upper.startswith("START "):
        return "开始新一局：" + command[len("START "):]
    if upper == "PROCEED":
        return "继续前进"
    if upper in {"RETURN", "LEAVE", "SKIP", "CANCEL"}:
        return "离开或跳过当前界面"
    if upper.startswith("WAIT"):
        return "等待游戏状态稳定"
    if upper == "STATE":
        return "刷新游戏状态"
    return command


def _card_name(card):
    return str((card or {}).get("name") or (card or {}).get("id") or "未知")


def _relic_name(relic):
    return str((relic or {}).get("name") or (relic or {}).get("id") or "未知")


def _potion_name(potion):
    potion_id = str((potion or {}).get("id") or "")
    if potion_id == "Potion Slot":
        return ""
    return str((potion or {}).get("name") or potion_id or "未知")


def _monster_summary(monster):
    name = str(monster.get("name") or monster.get("id") or "敌人")
    hp = int(monster.get("current_hp", 0) or 0)
    max_hp = int(monster.get("max_hp", hp) or hp)
    block = int(monster.get("block", 0) or 0)
    intent = str(monster.get("intent") or "UNKNOWN").upper()
    intent_text = INTENT_LABELS.get(intent, intent)
    damage = int(monster.get("move_adjusted_damage", -1) or -1)
    hits = max(1, int(monster.get("move_hits", 1) or 1))
    if damage >= 0 and intent.startswith("ATTACK"):
        attack = f" {damage}x{hits}" if hits > 1 else f" {damage}"
        intent_text += attack
    block_text = f" +{block}格挡" if block else ""
    return f"{name}  {hp}/{max_hp}{block_text}  |  {intent_text}"


def _empty_profile():
    return {
        "scores": {name: 0.0 for name in ARCHETYPES},
        "confidence": {name: 0.0 for name in ARCHETYPES},
        "leader": "strength",
        "raw_leader": "strength",
        "active_archetypes": [],
        "supporting_archetypes": [],
        "developing_archetypes": [],
        "current_archetypes": [],
        "committed": False,
    }


def build_snapshot(state, process_info=None, log_lines=None):
    state = state or {}
    process_info = process_info or {}
    gs = state.get("game_state") or {}
    in_game = bool(state.get("in_game"))
    profile = archetype_profile(gs) if gs.get("deck") else _empty_profile()
    specialization = archetype_specialization(gs, profile) if gs.get("deck") else 0.0
    combat = gs.get("combat_state") or {}
    player = combat.get("player") or {}
    monsters = [
        monster for monster in combat.get("monsters", [])
        if not monster.get("is_gone") and not monster.get("half_dead")
    ]
    commands = recent_commands(log_lines or [])
    latest_command = commands[-1] if commands else ""
    completed_runs = completed_runs_from_log(log_lines or [])

    hp = int(gs.get("current_hp", player.get("current_hp", 0)) or 0)
    max_hp = int(gs.get("max_hp", player.get("max_hp", 0)) or 0)
    room = str(gs.get("room_type") or "")
    screen = str(gs.get("screen_type") or "")
    current = list(profile.get("current_archetypes") or [])
    active = list(profile.get("active_archetypes") or [])
    developing = list(profile.get("developing_archetypes") or [])
    supporting = list(profile.get("supporting_archetypes") or [])
    leader = str(profile.get("leader") or profile.get("raw_leader") or "strength")

    if active:
        archetype_phase = "已成型"
    elif developing:
        archetype_phase = "发展中"
    elif gs.get("deck"):
        archetype_phase = "尚未定型"
    else:
        archetype_phase = "等待牌组"

    hand = [_card_name(card) for card in combat.get("hand", [])]
    relics = [_relic_name(relic) for relic in gs.get("relics", [])]
    potions = [name for name in (_potion_name(p) for p in gs.get("potions", [])) if name]

    return {
        "bot_version": str(process_info.get("Version") or "unknown"),
        "bot_pid": int(process_info.get("Pid", 0) or 0),
        "target_ascension": int(process_info.get("Ascension", gs.get("ascension_level", 0)) or 0),
        "max_runs": int(process_info.get("MaxRuns", 0) or 0),
        "max_total_runs": int(process_info.get("MaxTotalRuns", 0) or 0),
        "test_mode": str(process_info.get("TestMode") or "Auto"),
        "completed_runs": completed_runs,
        "in_game": in_game,
        "ready": state.get("ready_for_command") is not False,
        "ascension": int(gs.get("ascension_level", 0) or 0),
        "act": int(gs.get("act", 0) or 0),
        "floor": int(gs.get("floor", 0) or 0),
        "room": ROOM_LABELS.get(room, room or "主菜单"),
        "screen": SCREEN_LABELS.get(screen, screen or "等待游戏"),
        "hp": hp,
        "max_hp": max_hp,
        "gold": int(gs.get("gold", 0) or 0),
        "turn": int(combat.get("turn", 0) or 0),
        "energy": int(player.get("energy", 0) or 0),
        "block": int(player.get("block", 0) or 0),
        "deck_size": len(gs.get("deck", [])),
        "draw_size": len(combat.get("draw_pile", [])),
        "discard_size": len(combat.get("discard_pile", [])),
        "hand": hand,
        "relics": relics,
        "potions": potions,
        "enemies": [_monster_summary(monster) for monster in monsters],
        "latest_command": latest_command,
        "decision": command_description(latest_command),
        "recent_commands": commands,
        "archetype_scores": {
            name: round(float(profile["scores"].get(name, 0.0)), 2)
            for name in ARCHETYPES
        },
        "archetype_confidence": {
            name: round(float(profile["confidence"].get(name, 0.0)), 2)
            for name in ARCHETYPES
        },
        "leader": leader,
        "leader_label": ARCHETYPE_LABELS.get(leader, leader),
        "archetype_phase": archetype_phase,
        "current_archetypes": current,
        "active_archetypes": active,
        "developing_archetypes": developing,
        "supporting_archetypes": supporting,
        "committed": bool(profile.get("committed")),
        "specialization": round(float(specialization), 3),
    }


def process_exists(pid):
    pid = int(pid or 0)
    if pid <= 0:
        return False
    if os.name == "nt":
        process_query_limited_information = 0x1000
        handle = ctypes.windll.kernel32.OpenProcess(
            process_query_limited_information, False, pid
        )
        if not handle:
            return False
        ctypes.windll.kernel32.CloseHandle(handle)
        return True
    return Path(f"/proc/{pid}").exists()


def load_runtime_snapshot(comm_dir):
    comm_dir = Path(comm_dir)
    state_path = comm_dir / "state_latest.json"
    process_path = comm_dir / "bot_process.json"
    state = read_json(state_path, {})
    process_info = read_json(process_path, {})
    log_lines = tail_lines(comm_dir / "bot.log")
    snapshot = build_snapshot(state, process_info, log_lines)
    try:
        state_age = max(0.0, time.time() - state_path.stat().st_mtime)
    except OSError:
        state_age = float("inf")
    snapshot["state_age"] = state_age
    snapshot["bot_alive"] = process_exists(snapshot["bot_pid"])
    return snapshot


def run_gui(comm_dir, refresh_ms=500, topmost=True):
    import tkinter as tk
    from tkinter import ttk

    background = "#17191c"
    panel = "#202328"
    panel_alt = "#25292f"
    border = "#353a42"
    text_color = "#f1f3f5"
    muted = "#a8afb8"
    green = "#62c98b"
    amber = "#e0b65c"
    red = "#df6d73"

    root = tk.Tk()
    root.title("杀戮尖塔机器人实时状态")
    root.configure(bg=background)
    root.minsize(410, 700)
    width = 440
    height = min(900, max(700, root.winfo_screenheight() - 80))
    x = max(0, root.winfo_screenwidth() - width - 18)
    root.geometry(f"{width}x{height}+{x}+32")
    if topmost:
        root.attributes("-topmost", True)

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("Monitor.TFrame", background=background)
    style.configure("Panel.TFrame", background=panel)
    style.configure(
        "Monitor.TCheckbutton",
        background=background,
        foreground=muted,
        font=("Microsoft YaHei UI", 9),
    )
    style.map(
        "Monitor.TCheckbutton",
        background=[("active", background)],
        foreground=[("active", text_color)],
    )

    canvas = tk.Canvas(root, bg=background, highlightthickness=0)
    scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
    body = tk.Frame(canvas, bg=background)
    body_window = canvas.create_window((0, 0), window=body, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    def resize_body(event):
        canvas.itemconfigure(body_window, width=event.width)

    def update_scroll_region(_event=None):
        canvas.configure(scrollregion=canvas.bbox("all"))

    canvas.bind("<Configure>", resize_body)
    body.bind("<Configure>", update_scroll_region)

    header = tk.Frame(body, bg=background, padx=18, pady=14)
    header.pack(fill="x")
    title_row = tk.Frame(header, bg=background)
    title_row.pack(fill="x")
    tk.Label(
        title_row,
        text="IRONCLAD BOT",
        bg=background,
        fg=text_color,
        font=("Segoe UI Semibold", 15),
    ).pack(side="left")
    status_var = tk.StringVar(value="等待连接")
    status_label = tk.Label(
        title_row,
        textvariable=status_var,
        bg=background,
        fg=amber,
        font=("Microsoft YaHei UI", 9, "bold"),
    )
    status_label.pack(side="right")
    subtitle_var = tk.StringVar(value="正在读取机器人状态")
    tk.Label(
        header,
        textvariable=subtitle_var,
        bg=background,
        fg=muted,
        anchor="w",
        font=("Microsoft YaHei UI", 9),
    ).pack(fill="x", pady=(3, 0))

    def section(title):
        frame = tk.Frame(body, bg=panel, highlightbackground=border, highlightthickness=1)
        frame.pack(fill="x", padx=14, pady=(0, 10))
        tk.Label(
            frame,
            text=title,
            bg=panel,
            fg=muted,
            anchor="w",
            font=("Microsoft YaHei UI", 9, "bold"),
        ).pack(fill="x", padx=12, pady=(10, 6))
        content = tk.Frame(frame, bg=panel)
        content.pack(fill="x", padx=12, pady=(0, 11))
        return content

    overview = section("当前进度")
    overview.columnconfigure((0, 1), weight=1, uniform="overview")
    progress_vars = {
        name: tk.StringVar(value="--")
        for name in ("progress", "location", "hp", "resources")
    }
    progress_labels = (
        ("progress", "进阶 / 章节"),
        ("location", "楼层 / 场景"),
        ("hp", "生命"),
        ("resources", "能量 / 格挡 / 金币"),
    )
    for index, (key, label) in enumerate(progress_labels):
        cell = tk.Frame(overview, bg=panel_alt, padx=10, pady=7)
        cell.grid(
            row=index // 2,
            column=index % 2,
            sticky="nsew",
            padx=(0 if index % 2 == 0 else 4, 4 if index % 2 == 0 else 0),
            pady=(0 if index < 2 else 4, 4 if index < 2 else 0),
        )
        tk.Label(
            cell, text=label, bg=panel_alt, fg=muted,
            font=("Microsoft YaHei UI", 8), anchor="w",
        ).pack(fill="x")
        tk.Label(
            cell, textvariable=progress_vars[key], bg=panel_alt,
            fg=text_color, font=("Microsoft YaHei UI", 10, "bold"),
            anchor="w", wraplength=175, justify="left",
        ).pack(fill="x", pady=(2, 0))

    hp_canvas = tk.Canvas(
        overview, height=8, bg="#30343a", highlightthickness=0
    )
    hp_canvas.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))

    decision = section("机器人决策")
    decision_var = tk.StringVar(value="等待机器人决策")
    tk.Label(
        decision,
        textvariable=decision_var,
        bg=panel,
        fg=text_color,
        font=("Microsoft YaHei UI", 11, "bold"),
        anchor="w",
        justify="left",
        wraplength=380,
    ).pack(fill="x")
    raw_command_var = tk.StringVar(value="")
    tk.Label(
        decision,
        textvariable=raw_command_var,
        bg=panel,
        fg=muted,
        font=("Consolas", 9),
        anchor="w",
        wraplength=380,
    ).pack(fill="x", pady=(4, 0))

    archetypes = section("流派评分")
    archetype_head = tk.Frame(archetypes, bg=panel)
    archetype_head.pack(fill="x", pady=(0, 7))
    leader_var = tk.StringVar(value="等待牌组")
    tk.Label(
        archetype_head,
        textvariable=leader_var,
        bg=panel,
        fg=text_color,
        font=("Microsoft YaHei UI", 10, "bold"),
        anchor="w",
    ).pack(side="left")
    specialization_var = tk.StringVar(value="专精度 0%")
    tk.Label(
        archetype_head,
        textvariable=specialization_var,
        bg=panel,
        fg=muted,
        font=("Microsoft YaHei UI", 9),
    ).pack(side="right")

    score_rows = {}
    for name in ARCHETYPES:
        row = tk.Frame(archetypes, bg=panel)
        row.pack(fill="x", pady=2)
        label = tk.Label(
            row,
            text=ARCHETYPE_LABELS.get(name, name),
            width=11,
            bg=panel,
            fg=muted,
            anchor="w",
            font=("Microsoft YaHei UI", 9),
        )
        label.pack(side="left")
        bar = tk.Canvas(row, height=19, bg="#30343a", highlightthickness=0)
        bar.pack(side="left", fill="x", expand=True)
        value = tk.Label(
            row,
            text="0.0",
            width=6,
            bg=panel,
            fg=text_color,
            anchor="e",
            font=("Consolas", 9, "bold"),
        )
        value.pack(side="right")
        score_rows[name] = (label, bar, value)

    focus_var = tk.StringVar(value="当前流派：尚未定型")
    tk.Label(
        archetypes,
        textvariable=focus_var,
        bg=panel,
        fg=muted,
        anchor="w",
        justify="left",
        wraplength=380,
        font=("Microsoft YaHei UI", 8),
    ).pack(fill="x", pady=(7, 0))

    combat_section = section("战斗状态")
    combat_var = tk.StringVar(value="当前不在战斗中")
    tk.Label(
        combat_section,
        textvariable=combat_var,
        bg=panel,
        fg=text_color,
        anchor="w",
        justify="left",
        wraplength=380,
        font=("Microsoft YaHei UI", 9),
    ).pack(fill="x")
    enemy_var = tk.StringVar(value="")
    tk.Label(
        combat_section,
        textvariable=enemy_var,
        bg=panel,
        fg=muted,
        anchor="w",
        justify="left",
        wraplength=380,
        font=("Microsoft YaHei UI", 9),
    ).pack(fill="x", pady=(5, 0))

    inventory = section("牌组与资源")
    inventory_var = tk.StringVar(value="牌组 --  遗物 --  药水 --")
    tk.Label(
        inventory,
        textvariable=inventory_var,
        bg=panel,
        fg=text_color,
        anchor="w",
        justify="left",
        wraplength=380,
        font=("Microsoft YaHei UI", 9),
    ).pack(fill="x")
    detail_var = tk.StringVar(value="")
    tk.Label(
        inventory,
        textvariable=detail_var,
        bg=panel,
        fg=muted,
        anchor="w",
        justify="left",
        wraplength=380,
        font=("Microsoft YaHei UI", 8),
    ).pack(fill="x", pady=(5, 0))

    recent = section("最近操作")
    recent_var = tk.StringVar(value="暂无操作")
    tk.Label(
        recent,
        textvariable=recent_var,
        bg=panel,
        fg=muted,
        anchor="w",
        justify="left",
        wraplength=380,
        font=("Consolas", 8),
    ).pack(fill="x")

    footer = tk.Frame(body, bg=background, padx=16)
    footer.pack(fill="x", pady=(0, 14))
    topmost_var = tk.BooleanVar(value=topmost)

    def toggle_topmost():
        root.attributes("-topmost", bool(topmost_var.get()))

    ttk.Checkbutton(
        footer,
        text="保持置顶",
        variable=topmost_var,
        command=toggle_topmost,
        style="Monitor.TCheckbutton",
    ).pack(side="left")

    def open_log_directory():
        try:
            os.startfile(str(Path(comm_dir).resolve()))
        except (AttributeError, OSError):
            pass

    tk.Button(
        footer,
        text="打开日志目录",
        command=open_log_directory,
        bg=panel_alt,
        fg=text_color,
        activebackground=border,
        activeforeground=text_color,
        relief="flat",
        padx=10,
        pady=5,
        font=("Microsoft YaHei UI", 9),
        cursor="hand2",
    ).pack(side="right")

    def names(values):
        return "、".join(ARCHETYPE_LABELS.get(value, value) for value in values)

    def refresh():
        try:
            snapshot = load_runtime_snapshot(comm_dir)
            age = snapshot["state_age"]
            if snapshot["bot_alive"] and age < 8:
                status_var.set("运行中")
                status_label.configure(fg=green)
            elif snapshot["bot_alive"]:
                status_var.set("等待游戏响应")
                status_label.configure(fg=amber)
            else:
                status_var.set("机器人已停止")
                status_label.configure(fg=red)

            target = snapshot["target_ascension"]
            if snapshot["test_mode"].lower() == "loop":
                test_mode_text = f"循环测试 · 已完成 {snapshot['completed_runs']} 局"
            elif snapshot["test_mode"].lower() == "count":
                test_mode_text = (
                    f"定次测试 {snapshot['completed_runs']}/"
                    f"{snapshot['max_total_runs']}"
                )
            else:
                test_mode_text = "训练模式"
            subtitle_var.set(
                f"{snapshot['bot_version']}  |  PID {snapshot['bot_pid'] or '--'}  "
                f"|  目标 A{target}  |  {test_mode_text}"
            )
            progress_vars["progress"].set(
                f"A{snapshot['ascension']}  /  第 {snapshot['act']} 幕"
                if snapshot["in_game"] else f"目标 A{target}  /  主菜单"
            )
            progress_vars["location"].set(
                f"{snapshot['floor']} 层  /  {snapshot['room']}\n{snapshot['screen']}"
            )
            progress_vars["hp"].set(f"{snapshot['hp']} / {snapshot['max_hp']}")
            progress_vars["resources"].set(
                f"{snapshot['energy']}  /  {snapshot['block']}  /  {snapshot['gold']}"
            )

            hp_canvas.update_idletasks()
            hp_width = max(1, hp_canvas.winfo_width())
            hp_ratio = (
                snapshot["hp"] / snapshot["max_hp"]
                if snapshot["max_hp"] > 0 else 0
            )
            hp_color = green if hp_ratio >= 0.55 else amber if hp_ratio >= 0.25 else red
            hp_canvas.delete("all")
            hp_canvas.create_rectangle(0, 0, hp_width, 8, fill="#30343a", outline="")
            hp_canvas.create_rectangle(0, 0, hp_width * hp_ratio, 8, fill=hp_color, outline="")

            decision_var.set(snapshot["decision"])
            raw_command_var.set(snapshot["latest_command"] or "--")

            leader_var.set(
                f"领先：{snapshot['leader_label']}  ·  {snapshot['archetype_phase']}"
            )
            specialization_var.set(
                f"专精度 {round(snapshot['specialization'] * 100)}%"
            )
            max_score = max(18.0, max(snapshot["archetype_scores"].values(), default=0) * 1.08)
            for name, (label, bar, value) in score_rows.items():
                score = snapshot["archetype_scores"].get(name, 0.0)
                confidence = snapshot["archetype_confidence"].get(name, 0.0)
                is_leader = name == snapshot["leader"]
                is_active = name in snapshot["active_archetypes"]
                label.configure(
                    fg=text_color if is_leader else muted,
                    font=("Microsoft YaHei UI", 9, "bold" if is_leader else "normal"),
                )
                value.configure(fg=ARCHETYPE_COLORS[name] if is_leader else text_color)
                value.configure(text=f"{score:.1f}")
                bar.update_idletasks()
                bar_width = max(1, bar.winfo_width())
                bar.delete("all")
                bar.create_rectangle(0, 0, bar_width, 19, fill="#30343a", outline="")
                fill_width = min(bar_width, bar_width * score / max_score)
                bar.create_rectangle(
                    0, 0, fill_width, 19,
                    fill=ARCHETYPE_COLORS[name], outline="",
                )
                if is_active:
                    bar.create_rectangle(
                        1, 1, bar_width - 1, 18,
                        outline=ARCHETYPE_COLORS[name], width=1,
                    )
                if confidence:
                    bar.create_text(
                        6, 9, text=f"置信 {confidence:.1f}", anchor="w",
                        fill="#f7f8fa" if fill_width > 78 else muted,
                        font=("Microsoft YaHei UI", 7),
                    )

            focus_parts = []
            if snapshot["current_archetypes"]:
                focus_parts.append("当前：" + names(snapshot["current_archetypes"]))
            if snapshot["supporting_archetypes"]:
                focus_parts.append("辅助：" + names(snapshot["supporting_archetypes"]))
            if not focus_parts:
                focus_parts.append("当前：尚未形成可靠流派")
            focus_var.set("  |  ".join(focus_parts))

            if snapshot["turn"]:
                hand_text = "、".join(snapshot["hand"]) or "空"
                combat_var.set(
                    f"第 {snapshot['turn']} 回合  |  手牌 {len(snapshot['hand'])}  "
                    f"|  抽牌堆 {snapshot['draw_size']}  |  弃牌堆 {snapshot['discard_size']}\n"
                    f"手牌：{hand_text}"
                )
            else:
                combat_var.set("当前不在战斗中")
            enemy_var.set("\n".join(snapshot["enemies"]) or "暂无敌人")

            inventory_var.set(
                f"牌组 {snapshot['deck_size']}  |  遗物 {len(snapshot['relics'])}  "
                f"|  药水 {len(snapshot['potions'])}"
            )
            relic_text = "、".join(snapshot["relics"][-8:]) or "无"
            potion_text = "、".join(snapshot["potions"]) or "无"
            detail_var.set(f"遗物：{relic_text}\n药水：{potion_text}")

            recent_text = "\n".join(
                f"{index + 1}. {command_description(command)}"
                for index, command in enumerate(snapshot["recent_commands"][-6:])
            )
            recent_var.set(recent_text or "暂无操作")
        except Exception as exc:
            status_var.set("状态读取失败")
            status_label.configure(fg=red)
            subtitle_var.set(f"{type(exc).__name__}: {exc}")
        root.after(max(200, int(refresh_ms)), refresh)

    refresh()
    root.mainloop()
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--comm-dir",
        default=os.environ.get(
            "STS_COMM_DIR", str(Path(__file__).resolve().parent / "sts-comm")
        ),
    )
    parser.add_argument("--refresh-ms", type=int, default=500)
    parser.add_argument("--no-topmost", action="store_true")
    parser.add_argument("--snapshot", action="store_true")
    args = parser.parse_args()
    if args.snapshot:
        print(
            json.dumps(
                load_runtime_snapshot(args.comm_dir),
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0
    return run_gui(
        args.comm_dir,
        refresh_ms=args.refresh_ms,
        topmost=not args.no_topmost,
    )


if __name__ == "__main__":
    raise SystemExit(main())
