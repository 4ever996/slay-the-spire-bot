import argparse
import json
import sys


def selection_payload(ascension, mode, runs):
    ascension = int(ascension)
    runs = int(runs)
    mode = str(mode).lower()
    if not 0 <= ascension <= 20:
        raise ValueError("ascension must be in 0..20")
    if mode not in {"loop", "count"}:
        raise ValueError("mode must be loop or count")
    if not 1 <= runs <= 999:
        raise ValueError("runs must be in 1..999")
    return {
        "ascension": ascension,
        "mode": "Loop" if mode == "loop" else "Count",
        "runs": runs,
    }


def show_dialog(default_ascension=1, default_runs=3):
    import tkinter as tk
    from tkinter import ttk

    result = None
    root = tk.Tk()
    root.title("启动杀戮尖塔机器人")
    root.resizable(False, False)
    root.configure(bg="#17191c")

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(
        "Launch.TCombobox",
        fieldbackground="#2a2e34",
        background="#2a2e34",
        foreground="#f1f3f5",
        arrowcolor="#f1f3f5",
        bordercolor="#41464f",
        lightcolor="#41464f",
        darkcolor="#41464f",
        padding=6,
        font=("Microsoft YaHei UI", 10),
    )
    style.configure(
        "Launch.TRadiobutton",
        background="#202328",
        foreground="#f1f3f5",
        font=("Microsoft YaHei UI", 10),
    )
    style.map(
        "Launch.TRadiobutton",
        background=[("active", "#202328")],
        foreground=[("active", "#ffffff")],
    )
    style.configure(
        "Launch.TSpinbox",
        fieldbackground="#2a2e34",
        foreground="#f1f3f5",
        bordercolor="#41464f",
        arrowcolor="#f1f3f5",
        padding=5,
        font=("Microsoft YaHei UI", 10),
    )

    shell = tk.Frame(root, bg="#17191c", padx=22, pady=20)
    shell.pack(fill="both", expand=True)
    tk.Label(
        shell,
        text="机器人测试设置",
        bg="#17191c",
        fg="#f1f3f5",
        anchor="w",
        font=("Microsoft YaHei UI", 16, "bold"),
    ).pack(fill="x")
    tk.Label(
        shell,
        text="选择战士进阶等级和本次测试方式",
        bg="#17191c",
        fg="#a8afb8",
        anchor="w",
        font=("Microsoft YaHei UI", 9),
    ).pack(fill="x", pady=(3, 15))

    ascension_panel = tk.Frame(
        shell,
        bg="#202328",
        highlightbackground="#353a42",
        highlightthickness=1,
        padx=14,
        pady=12,
    )
    ascension_panel.pack(fill="x", pady=(0, 10))
    tk.Label(
        ascension_panel,
        text="测试进阶等级",
        bg="#202328",
        fg="#a8afb8",
        anchor="w",
        font=("Microsoft YaHei UI", 9, "bold"),
    ).pack(fill="x", pady=(0, 7))
    ascension_var = tk.StringVar(value=str(max(0, min(20, int(default_ascension)))))
    ascension_box = ttk.Combobox(
        ascension_panel,
        textvariable=ascension_var,
        values=[f"{level}" for level in range(21)],
        state="readonly",
        style="Launch.TCombobox",
    )
    ascension_box.pack(fill="x")

    mode_panel = tk.Frame(
        shell,
        bg="#202328",
        highlightbackground="#353a42",
        highlightthickness=1,
        padx=14,
        pady=12,
    )
    mode_panel.pack(fill="x")
    tk.Label(
        mode_panel,
        text="测试方式",
        bg="#202328",
        fg="#a8afb8",
        anchor="w",
        font=("Microsoft YaHei UI", 9, "bold"),
    ).pack(fill="x", pady=(0, 5))

    mode_var = tk.StringVar(value="count")
    count_row = tk.Frame(mode_panel, bg="#202328")
    count_row.pack(fill="x", pady=3)
    ttk.Radiobutton(
        count_row,
        text="仅测试",
        variable=mode_var,
        value="count",
        style="Launch.TRadiobutton",
    ).pack(side="left")
    runs_var = tk.IntVar(value=max(1, min(999, int(default_runs))))
    runs_box = ttk.Spinbox(
        count_row,
        from_=1,
        to=999,
        width=6,
        textvariable=runs_var,
        style="Launch.TSpinbox",
    )
    runs_box.pack(side="left", padx=(6, 6))
    tk.Label(
        count_row,
        text="局",
        bg="#202328",
        fg="#f1f3f5",
        font=("Microsoft YaHei UI", 10),
    ).pack(side="left")

    loop_row = tk.Frame(mode_panel, bg="#202328")
    loop_row.pack(fill="x", pady=(5, 2))
    ttk.Radiobutton(
        loop_row,
        text="循环测试",
        variable=mode_var,
        value="loop",
        style="Launch.TRadiobutton",
    ).pack(side="left")
    tk.Label(
        mode_panel,
        text="循环测试会在胜利或失败后自动开始下一局",
        bg="#202328",
        fg="#8f969f",
        anchor="w",
        font=("Microsoft YaHei UI", 8),
    ).pack(fill="x", padx=(24, 0), pady=(0, 2))

    def sync_run_state(*_args):
        runs_box.configure(state="normal" if mode_var.get() == "count" else "disabled")

    mode_var.trace_add("write", sync_run_state)
    sync_run_state()

    buttons = tk.Frame(shell, bg="#17191c")
    buttons.pack(fill="x", pady=(16, 0))

    def cancel():
        root.destroy()

    def start():
        nonlocal result
        try:
            result = selection_payload(
                ascension_var.get(), mode_var.get(), runs_var.get()
            )
        except (TypeError, ValueError):
            runs_var.set(3)
            return
        root.destroy()

    tk.Button(
        buttons,
        text="取消",
        command=cancel,
        bg="#292d33",
        fg="#d7dbe0",
        activebackground="#353a42",
        activeforeground="#ffffff",
        relief="flat",
        padx=18,
        pady=7,
        font=("Microsoft YaHei UI", 9),
        cursor="hand2",
    ).pack(side="right")
    tk.Button(
        buttons,
        text="开始测试",
        command=start,
        bg="#4fa878",
        fg="#ffffff",
        activebackground="#61bb8a",
        activeforeground="#ffffff",
        relief="flat",
        padx=20,
        pady=7,
        font=("Microsoft YaHei UI", 9, "bold"),
        cursor="hand2",
    ).pack(side="right", padx=(0, 8))

    root.protocol("WM_DELETE_WINDOW", cancel)
    root.bind("<Return>", lambda _event: start())
    root.bind("<Escape>", lambda _event: cancel())
    root.update_idletasks()
    width = 430
    height = root.winfo_reqheight()
    x = max(0, (root.winfo_screenwidth() - width) // 2)
    y = max(0, (root.winfo_screenheight() - height) // 2)
    root.geometry(f"{width}x{height}+{x}+{y}")
    root.lift()
    root.focus_force()
    root.mainloop()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--default-ascension", type=int, default=1)
    parser.add_argument("--default-runs", type=int, default=3)
    parser.add_argument("--validate", nargs=3, metavar=("ASCENSION", "MODE", "RUNS"))
    args = parser.parse_args()
    if args.validate:
        print(json.dumps(selection_payload(*args.validate), ensure_ascii=False))
        return 0
    result = show_dialog(args.default_ascension, args.default_runs)
    if result is None:
        return 2
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
