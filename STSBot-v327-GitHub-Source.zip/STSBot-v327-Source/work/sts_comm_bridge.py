import json
import os
import sys
import time
import traceback
from pathlib import Path


BASE = Path(os.environ.get("STS_COMM_DIR", Path(__file__).resolve().parent / "sts-comm"))
STATE = BASE / "state_latest.json"
STATE_PRETTY = BASE / "state_latest.pretty.json"
SEQ = BASE / "state_seq.txt"
COMMAND = BASE / "command.txt"
LOG = BASE / "bridge.log"


def log(message):
    BASE.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {message}\n")


def atomic_write(path, text, retries=5):
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    tmp.write_text(text, encoding="utf-8")
    for attempt in range(retries):
        try:
            os.replace(str(tmp), str(path))
            return
        except PermissionError:
            if attempt + 1 < retries:
                time.sleep(min(0.005 * (attempt + 1), 0.05))
                continue
            try:
                path.write_text(text, encoding="utf-8")
                return
            finally:
                try:
                    tmp.unlink()
                except FileNotFoundError:
                    pass


def read_command(retries=20):
    claimed = COMMAND.with_name(f"{COMMAND.name}.{os.getpid()}.claimed")
    for attempt in range(retries):
        try:
            os.replace(str(COMMAND), str(claimed))
            break
        except FileNotFoundError:
            return None
        except PermissionError:
            if attempt + 1 >= retries:
                return None
            time.sleep(min(0.005 * (attempt + 1), 0.05))
    text = claimed.read_text(encoding="utf-8-sig").strip()
    try:
        claimed.unlink()
    except FileNotFoundError:
        pass
    return text or None


def main():
    BASE.mkdir(parents=True, exist_ok=True)
    log("bridge starting")
    sys.stdout.write("ready\n")
    sys.stdout.flush()
    seq = 0
    while True:
        raw_line = sys.stdin.buffer.readline()
        if not raw_line:
            log("stdin closed")
            return 0
        try:
            line = raw_line.decode("utf-8")
        except UnicodeDecodeError:
            line = raw_line.decode("gbk", errors="replace")
        seq += 1
        line = line.strip()
        atomic_write(STATE, line + "\n")
        atomic_write(SEQ, str(seq) + "\n")
        try:
            parsed = json.loads(line)
            atomic_write(STATE_PRETTY, json.dumps(parsed, ensure_ascii=False, indent=2) + "\n")
        except Exception:
            log("state json parse failed")
        log(f"state {seq} received")
        command = None
        while command is None:
            command = read_command()
            if command is None:
                time.sleep(0.05)
        log(f"command {command!r}")
        sys.stdout.write(command + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        log(traceback.format_exc())
        raise
