"""Ironclad card-to-archetype scoring matrix.

Each card receives a six-dimensional score in the range 0..12:
0 = unrelated, 1..2 = incidental support, 3..5 = useful support,
6..8 = strong synergy, 9..12 = engine/core card.

The matrix intentionally measures *archetype synergy*, not raw card quality.
Raw quality is still handled by CARD_SCORES in sts_file_bot.py.
"""

ARCHETYPES = (
    "strength",
    "exhaust",
    "block",
    "self_harm",
    "status",
    "perfected_strike",
)


def archetype_vector(
    strength=0,
    exhaust=0,
    block=0,
    self_harm=0,
    status=0,
    perfected_strike=0,
):
    """Build a complete six-label vector while keeping the table readable."""
    values = {
        "strength": strength,
        "exhaust": exhaust,
        "block": block,
        "self_harm": self_harm,
        "status": status,
        "perfected_strike": perfected_strike,
    }
    if any(not isinstance(value, (int, float)) or not 0 <= value <= 12 for value in values.values()):
        raise ValueError(f"archetype scores must be numeric values in 0..12: {values}")
    return values


# All 75 base-game Ironclad cards.  Values are deliberately card-centric:
# a multi-archetype bridge card can score in several columns at once.
CARD_ARCHETYPE_SCORES = {
    "Anger": archetype_vector(strength=3),
    "Armaments": archetype_vector(exhaust=1, block=3, perfected_strike=2),
    "Barricade": archetype_vector(block=12),
    "Bash": archetype_vector(strength=1),
    "Battle Trance": archetype_vector(strength=2, exhaust=2, block=2, self_harm=2, status=2, perfected_strike=2),
    "Berserk": archetype_vector(strength=2, exhaust=1, block=1, self_harm=1, status=1, perfected_strike=1),
    "Blood for Blood": archetype_vector(strength=2, self_harm=9),
    "Bloodletting": archetype_vector(strength=2, exhaust=1, self_harm=8),
    "Bludgeon": archetype_vector(strength=4),
    "Body Slam": archetype_vector(block=8),
    "Brutality": archetype_vector(strength=2, exhaust=1, self_harm=9),
    "Burning Pact": archetype_vector(exhaust=6, block=1, status=6),
    "Carnage": archetype_vector(strength=2, exhaust=2),
    "Clash": archetype_vector(strength=2),
    "Cleave": archetype_vector(strength=3),
    "Clothesline": archetype_vector(strength=2, block=1),
    "Combust": archetype_vector(self_harm=6, status=1),
    "Corruption": archetype_vector(exhaust=12, block=5, status=2),
    "Dark Embrace": archetype_vector(exhaust=10, status=5),
    "Defend_R": archetype_vector(exhaust=1, block=1),
    "Demon Form": archetype_vector(strength=10),
    "Disarm": archetype_vector(exhaust=3, block=5),
    "Double Tap": archetype_vector(strength=5, exhaust=1, self_harm=3, status=3, perfected_strike=5),
    "Dropkick": archetype_vector(strength=4, perfected_strike=1),
    "Dual Wield": archetype_vector(strength=6, exhaust=2, block=4, self_harm=4, status=4, perfected_strike=6),
    "Entrench": archetype_vector(block=10),
    "Evolve": archetype_vector(status=12),
    "Exhume": archetype_vector(exhaust=5, block=3, self_harm=2, status=3),
    "Feed": archetype_vector(block=1, self_harm=2),
    "Feel No Pain": archetype_vector(exhaust=10, block=8, status=5),
    "Fiend Fire": archetype_vector(strength=8, exhaust=9, status=4),
    "Fire Breathing": archetype_vector(status=12),
    "Flame Barrier": archetype_vector(block=4, self_harm=1),
    "Flex": archetype_vector(strength=2),
    "Ghostly Armor": archetype_vector(exhaust=3, block=3),
    "Havoc": archetype_vector(strength=1, exhaust=6, block=1, self_harm=1, status=2, perfected_strike=1),
    "Headbutt": archetype_vector(strength=2, exhaust=4, block=2, self_harm=3, status=3, perfected_strike=4),
    "Heavy Blade": archetype_vector(strength=8),
    "Hemokinesis": archetype_vector(strength=3, self_harm=5),
    "Immolate": archetype_vector(strength=2, exhaust=1, status=6),
    "Impervious": archetype_vector(exhaust=2, block=7),
    "Infernal Blade": archetype_vector(strength=3, exhaust=4, block=1, self_harm=2, status=2, perfected_strike=2),
    "Inflame": archetype_vector(strength=7),
    "Intimidate": archetype_vector(exhaust=2, block=3),
    "Iron Wave": archetype_vector(strength=2, block=4, perfected_strike=1),
    "Juggernaut": archetype_vector(exhaust=4, block=8, status=3),
    "Limit Break": archetype_vector(strength=10, exhaust=3),
    "Metallicize": archetype_vector(block=3),
    "Offering": archetype_vector(strength=3, exhaust=3, block=3, self_harm=4, status=2, perfected_strike=3),
    "Perfected Strike": archetype_vector(perfected_strike=12),
    "Pommel Strike": archetype_vector(strength=3, exhaust=1, perfected_strike=4),
    "Power Through": archetype_vector(exhaust=5, block=6, status=9),
    "Pummel": archetype_vector(strength=4, exhaust=3),
    "Rage": archetype_vector(strength=4, block=7, status=2, perfected_strike=4),
    "Rampage": archetype_vector(strength=3),
    "Reaper": archetype_vector(strength=3, exhaust=2, self_harm=3),
    "Reckless Charge": archetype_vector(strength=3, exhaust=3, self_harm=2, status=7),
    "Rupture": archetype_vector(strength=7, self_harm=11, status=3),
    "Searing Blow": archetype_vector(strength=2),
    "Second Wind": archetype_vector(exhaust=7, block=8, status=8),
    "Seeing Red": archetype_vector(strength=2, exhaust=4, block=2, self_harm=1, status=1, perfected_strike=2),
    "Sentinel": archetype_vector(exhaust=7, block=5),
    "Sever Soul": archetype_vector(strength=2, exhaust=3, status=5),
    "Shockwave": archetype_vector(strength=3, exhaust=2, block=4),
    "Shrug It Off": archetype_vector(exhaust=1, block=3, perfected_strike=1),
    "Spot Weakness": archetype_vector(strength=7),
    "Strike_R": archetype_vector(),
    "Sword Boomerang": archetype_vector(strength=4),
    "Thunderclap": archetype_vector(strength=2, perfected_strike=1),
    "True Grit": archetype_vector(exhaust=4, block=5, status=5),
    "Twin Strike": archetype_vector(strength=6, perfected_strike=4),
    "Uppercut": archetype_vector(strength=3, block=3),
    "Warcry": archetype_vector(exhaust=3, perfected_strike=2),
    "Whirlwind": archetype_vector(strength=3),
    "Wild Strike": archetype_vector(strength=2, status=7, perfected_strike=4),
}


EXPECTED_IRONCLAD_CARD_IDS = frozenset({
    "Anger", "Armaments", "Barricade", "Bash", "Battle Trance", "Berserk",
    "Blood for Blood", "Bloodletting", "Bludgeon", "Body Slam", "Brutality",
    "Burning Pact", "Carnage", "Clash", "Cleave", "Clothesline", "Combust",
    "Corruption", "Dark Embrace", "Defend_R", "Demon Form", "Disarm",
    "Double Tap", "Dropkick", "Dual Wield", "Entrench", "Evolve", "Exhume",
    "Feed", "Feel No Pain", "Fiend Fire", "Fire Breathing", "Flame Barrier",
    "Flex", "Ghostly Armor", "Havoc", "Headbutt", "Heavy Blade", "Hemokinesis",
    "Immolate", "Impervious", "Infernal Blade", "Inflame", "Intimidate",
    "Iron Wave", "Juggernaut", "Limit Break", "Metallicize", "Offering",
    "Perfected Strike", "Pommel Strike", "Power Through", "Pummel", "Rage",
    "Rampage", "Reaper", "Reckless Charge", "Rupture", "Searing Blow",
    "Second Wind", "Seeing Red", "Sentinel", "Sever Soul", "Shockwave",
    "Shrug It Off", "Spot Weakness", "Strike_R", "Sword Boomerang",
    "Thunderclap", "True Grit", "Twin Strike", "Uppercut", "Warcry",
    "Whirlwind", "Wild Strike",
})


def _validate_matrix():
    actual = set(CARD_ARCHETYPE_SCORES)
    missing = EXPECTED_IRONCLAD_CARD_IDS - actual
    extra = actual - EXPECTED_IRONCLAD_CARD_IDS
    malformed = {
        card_id: set(vector) ^ set(ARCHETYPES)
        for card_id, vector in CARD_ARCHETYPE_SCORES.items()
        if set(vector) != set(ARCHETYPES)
    }
    if missing or extra or malformed:
        raise RuntimeError(
            f"invalid Ironclad archetype matrix: missing={sorted(missing)}, "
            f"extra={sorted(extra)}, malformed={malformed}"
        )


_validate_matrix()
ZERO_ARCHETYPE_VECTOR = archetype_vector()
