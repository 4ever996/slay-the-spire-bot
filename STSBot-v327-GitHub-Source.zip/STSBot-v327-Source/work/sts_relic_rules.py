"""Canonical Slay the Spire 1 relic rules used by the Ironclad bot.

The game state already contains the result of many passive relic effects.  The
domains below distinguish those effects from rules that must influence card
order, deck construction, routing, shops, events, or Rest Site choices.
"""

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class RelicRule:
    tier: str
    effect: str
    domains: frozenset[str]
    tags: frozenset[str] = frozenset()
    character: str = "any"


def _rule(tier, effect, domains, tags=(), character="any"):
    return RelicRule(
        tier=tier,
        effect=effect,
        domains=frozenset(domains),
        tags=frozenset(tags),
        character=character,
    )


# This is the complete shared plus Ironclad-specific pool registered by the
# desktop-1.0.jar bundled with the installed game. Character-exclusive relics
# for Silent, Defect, and Watcher are intentionally absent because they cannot
# enter an ordinary Ironclad relic pool.
RELIC_RULES = {
    "TheAbacus": _rule("shop", "Gain 6 Block whenever the draw pile is shuffled.", {"combat_order", "shop"}, {"block", "shuffle"}),
    "Akabeko": _rule("common", "The first Attack each combat gains 8 damage per hit.", {"combat_order", "card_reward", "shop"}, {"attack", "multi_hit", "frontload"}),
    "Anchor": _rule("common", "Start each combat with 10 Block.", {"combat_state", "route", "shop"}, {"block", "frontload"}),
    "Ancient Tea Set": _rule("common", "After entering a Rest Site, start the next combat with 2 extra Energy.", {"combat_state", "route", "rest", "shop"}, {"energy", "campfire", "frontload"}),
    "Art of War": _rule("common", "If no Attack is played this turn, gain 1 Energy next turn.", {"combat_order", "card_reward", "shop"}, {"energy", "skill"}),
    "Astrolabe": _rule("boss", "Transform and upgrade 3 selected cards on pickup.", {"pickup", "boss_reward"}, {"card_quality", "transform"}),
    "Bag of Marbles": _rule("common", "Apply 1 Vulnerable to all enemies at combat start.", {"combat_state", "card_reward", "shop"}, {"vulnerable", "frontload"}),
    "Bag of Preparation": _rule("common", "Draw 2 additional cards at combat start.", {"combat_state", "shop"}, {"draw", "frontload"}),
    "Bird Faced Urn": _rule("rare", "Heal 2 HP whenever a Power is played.", {"combat_order", "card_reward", "route", "shop"}, {"heal", "power"}),
    "Black Star": _rule("boss", "Elites drop an additional relic.", {"route", "boss_reward"}, {"elite", "relic_reward"}),
    "Blood Vial": _rule("common", "Heal 2 HP at combat start.", {"combat_state", "route", "shop", "event"}, {"heal", "frontload"}),
    "Bloody Idol": _rule("special", "Heal 5 HP whenever Gold is gained.", {"route", "event"}, {"heal", "economy", "gold"}),
    "Blue Candle": _rule("uncommon", "Curses can be played; playing one loses 1 HP and Exhausts it.", {"combat_order", "card_reward", "shop", "event"}, {"curse", "exhaust", "self_damage"}),
    "Boot": _rule("common", "Unblocked Attack damage from 1 through 4 is raised to 5.", {"combat_order", "shop"}, {"attack", "frontload"}),
    "Bottled Flame": _rule("uncommon", "Choose an Attack to make Innate.", {"pickup", "card_reward", "shop"}, {"attack", "bottle", "frontload"}),
    "Bottled Lightning": _rule("uncommon", "Choose a Skill to make Innate.", {"pickup", "card_reward", "shop"}, {"skill", "bottle", "frontload"}),
    "Bottled Tornado": _rule("uncommon", "Choose a Power to make Innate.", {"pickup", "card_reward", "shop"}, {"power", "bottle", "frontload"}),
    "Bronze Scales": _rule("common", "Start each combat with 3 Thorns.", {"combat_state", "route", "shop"}, {"damage", "frontload"}),
    "Busted Crown": _rule("boss", "Gain 1 Energy each turn but see 2 fewer cards in rewards.", {"combat_state", "card_reward", "boss_reward"}, {"energy", "reward_penalty"}),
    "Calipers": _rule("rare", "At turn start lose 15 Block instead of all Block.", {"combat_order", "card_reward", "shop"}, {"block", "retain_block"}),
    "Calling Bell": _rule("boss", "Gain a Curse and one Common, Uncommon, and Rare relic.", {"pickup", "event", "boss_reward"}, {"curse", "relic_reward"}),
    "CaptainsWheel": _rule("rare", "Gain 18 Block at the start of turn 3.", {"combat_state", "combat_future", "shop"}, {"block", "timed"}),
    "Cauldron": _rule("shop", "On pickup, choose from 5 random Potions.", {"pickup", "shop"}, {"potion"}),
    "Centennial Puzzle": _rule("common", "The first time HP is lost each combat, draw 3 cards.", {"combat_order", "card_reward", "shop"}, {"draw", "self_damage"}),
    "CeramicFish": _rule("common", "Gain 9 Gold whenever a card is added to the deck.", {"card_reward", "route", "shop"}, {"economy", "gold"}),
    "Chemical X": _rule("shop", "X-cost cards receive 2 additional X.", {"combat_order", "card_reward", "shop"}, {"energy", "x_cost"}),
    "ClockworkSouvenir": _rule("shop", "Start each combat with 1 Artifact.", {"combat_state", "card_reward", "shop"}, {"artifact", "frontload"}),
    "Coffee Dripper": _rule("boss", "Gain 1 Energy each turn but Rest cannot heal.", {"combat_state", "route", "rest", "boss_reward"}, {"energy", "no_rest"}),
    "The Courier": _rule("uncommon", "Merchant stock replenishes and prices are 20% lower.", {"route", "shop"}, {"economy", "discount"}),
    "CultistMask": _rule("special", "Produces a cosmetic sound at combat start.", {"no_decision"}),
    "Cursed Key": _rule("boss", "Gain 1 Energy each turn; non-Boss chests add a Curse.", {"combat_state", "route", "event", "boss_reward"}, {"energy", "curse", "chest"}),
    "Darkstone Periapt": _rule("uncommon", "Gain 6 Max HP whenever a Curse is obtained.", {"card_reward", "event", "shop"}, {"curse", "max_hp"}),
    "Dead Branch": _rule("rare", "Whenever a card is Exhausted, add a random card to the hand.", {"combat_order", "card_reward", "shop"}, {"exhaust", "draw", "random_card"}),
    "DollysMirror": _rule("shop", "Add a copy of a selected deck card.", {"pickup", "shop"}, {"duplicate", "card_quality"}),
    "Dream Catcher": _rule("common", "Resting offers a card reward.", {"rest", "card_reward", "shop"}, {"campfire", "card_reward"}),
    "Du-Vu Doll": _rule("rare", "Start combat with 1 Strength per Curse in the deck.", {"combat_state", "card_reward", "shop", "event"}, {"curse", "strength"}),
    "Ectoplasm": _rule("boss", "Gain 1 Energy each turn but Gold can no longer be gained.", {"combat_state", "route", "shop", "boss_reward"}, {"energy", "no_gold"}),
    "Empty Cage": _rule("boss", "Remove 2 selected cards on pickup.", {"pickup", "boss_reward"}, {"remove", "card_quality"}),
    "Enchiridion": _rule("special", "Add a random Power to the opening hand; it costs 0 this turn.", {"combat_state", "combat_order"}, {"power", "random_card", "frontload"}),
    "Eternal Feather": _rule("uncommon", "At Rest Sites heal 3 HP per 5 cards in the deck.", {"route", "rest", "shop"}, {"heal", "campfire"}),
    "FaceOfCleric": _rule("special", "Gain 1 Max HP after each combat.", {"route", "event"}, {"max_hp", "combat_reward"}),
    "FossilizedHelix": _rule("rare", "Prevent the first HP loss each combat with Buffer.", {"combat_state", "combat_order", "shop"}, {"buffer", "frontload"}),
    "Frozen Egg 2": _rule("uncommon", "Future Power cards are upgraded when obtained.", {"card_reward", "shop"}, {"power", "upgrade"}),
    "Frozen Eye": _rule("shop", "The draw pile can be viewed in order.", {"no_decision", "shop"}, {"draw_order"}),
    "Fusion Hammer": _rule("boss", "Gain 1 Energy each turn but Smith is disabled.", {"combat_state", "rest", "boss_reward"}, {"energy", "no_smith"}),
    "Gambling Chip": _rule("rare", "At combat start discard any number, then draw that many.", {"combat_order", "shop"}, {"draw", "discard", "frontload"}),
    "Ginger": _rule("rare", "Weak cannot be applied to the player.", {"combat_state", "route", "shop"}, {"debuff_immunity"}),
    "Girya": _rule("rare", "Rest Sites can Lift up to 3 times for 1 permanent Strength.", {"rest", "card_reward", "shop"}, {"campfire", "strength"}),
    "Golden Idol": _rule("special", "Gold gains are increased by 25%.", {"route", "event"}, {"economy", "gold"}),
    "Gremlin Horn": _rule("uncommon", "Whenever an enemy dies, gain 1 Energy and draw 1 card.", {"combat_order", "card_reward", "shop"}, {"energy", "draw", "on_kill"}),
    "GremlinMask": _rule("special", "Start each combat with 1 Weak.", {"combat_state", "route"}, {"negative", "frontload"}),
    "HandDrill": _rule("shop", "Breaking enemy Block applies 2 Vulnerable.", {"combat_order", "card_reward", "shop"}, {"vulnerable", "attack"}),
    "Happy Flower": _rule("common", "Gain 1 Energy every 3 turns.", {"combat_future", "combat_order", "shop"}, {"energy", "counter"}),
    "HornCleat": _rule("uncommon", "Gain 14 Block at the start of turn 2.", {"combat_state", "combat_future", "shop"}, {"block", "timed"}),
    "Ice Cream": _rule("rare", "Unspent Energy is carried between turns.", {"combat_order", "card_reward", "shop"}, {"energy", "retain_energy", "x_cost"}),
    "Incense Burner": _rule("rare", "Gain 1 Intangible every 6 turns.", {"combat_future", "combat_order", "route", "shop"}, {"intangible", "counter"}),
    "InkBottle": _rule("uncommon", "Draw 1 card whenever 10 cards have been played.", {"combat_order", "card_reward", "shop"}, {"draw", "card_chain", "counter"}),
    "Juzu Bracelet": _rule("common", "Question rooms cannot contain normal enemy combats.", {"route", "shop"}, {"question", "safety"}),
    "Kunai": _rule("uncommon", "Every 3 Attacks in one turn grant 1 Dexterity.", {"combat_order", "card_reward", "shop"}, {"attack_chain", "dexterity"}),
    "Lantern": _rule("common", "Gain 1 Energy on turn 1 of each combat.", {"combat_state", "shop"}, {"energy", "frontload"}),
    "LetterOpener": _rule("uncommon", "Every 3 Skills in one turn deal 5 damage to all enemies.", {"combat_order", "card_reward", "shop"}, {"skill_chain", "damage"}),
    "Lizard Tail": _rule("rare", "Once per run, lethal damage revives the player at 50% Max HP.", {"combat_state", "route", "shop", "event"}, {"revive"}),
    "Mango": _rule("rare", "Gain 14 Max HP on pickup.", {"pickup", "route", "shop"}, {"max_hp"}),
    "Mark of the Bloom": _rule("special", "Healing is disabled for the rest of the run.", {"combat_state", "route", "rest", "event"}, {"no_heal", "negative"}),
    "Matryoshka": _rule("uncommon", "The next 2 non-Boss chests contain an extra relic.", {"route", "shop"}, {"chest", "relic_reward", "counter"}),
    "MawBank": _rule("common", "Gain 12 Gold on entering a floor until Gold is spent at a shop.", {"route", "shop"}, {"economy", "gold", "counter"}),
    "MealTicket": _rule("common", "Heal 15 HP whenever a shop is entered.", {"route", "shop"}, {"heal", "shop_route"}),
    "Meat on the Bone": _rule("uncommon", "After combat, heal 12 HP when at or below half HP.", {"route", "shop"}, {"heal", "combat_reward"}),
    "Medical Kit": _rule("shop", "Status cards can be played and Exhausted.", {"combat_order", "card_reward", "shop"}, {"status", "exhaust"}),
    "Membership Card": _rule("shop", "All shop prices are reduced by 50%.", {"route", "shop"}, {"economy", "discount"}),
    "Mercury Hourglass": _rule("uncommon", "At turn start deal 3 damage to all enemies.", {"combat_state", "combat_future", "shop"}, {"damage", "timed"}),
    "Molten Egg 2": _rule("uncommon", "Future Attack cards are upgraded when obtained.", {"card_reward", "shop"}, {"attack", "upgrade"}),
    "Mummified Hand": _rule("uncommon", "Playing a Power makes a random positive-cost card cost 0 this turn.", {"combat_order", "card_reward", "shop"}, {"power", "energy", "card_chain"}),
    "MutagenicStrength": _rule("special", "Start combat with 3 Strength that is removed after turn 1.", {"combat_state", "combat_order"}, {"strength", "frontload"}),
    "Necronomicon": _rule("special", "The first Attack costing 2 or more each turn is played twice.", {"combat_order", "card_reward", "event"}, {"attack", "duplicate", "curse"}),
    "NeowsBlessing": _rule("special", "The first 3 combat enemies begin at 1 HP.", {"route", "combat_state"}, {"frontload", "counter", "elite"}),
    "Nilry's Codex": _rule("special", "At end of turn choose 1 of 3 random cards for the draw pile.", {"combat_order", "card_reward", "event"}, {"random_card", "draw"}),
    "Nloth's Gift": _rule("special", "Triple the chance of Rare cards in combat rewards.", {"card_reward", "route", "event"}, {"card_quality", "combat_reward"}),
    "NlothsMask": _rule("special", "The next non-Boss chest is empty.", {"route", "event"}, {"chest", "negative"}),
    "Nunchaku": _rule("common", "Every 10 Attacks played grant 1 Energy.", {"combat_order", "card_reward", "shop"}, {"attack_chain", "energy", "counter"}),
    "Oddly Smooth Stone": _rule("common", "Start each combat with 1 Dexterity.", {"combat_state", "card_reward", "shop"}, {"dexterity"}),
    "Odd Mushroom": _rule("special", "Vulnerable increases incoming damage by 25% instead of 50%.", {"combat_state", "route", "event"}, {"debuff_mitigation"}),
    "Old Coin": _rule("rare", "Gain 300 Gold on pickup.", {"pickup", "route", "shop"}, {"economy", "gold"}),
    "Omamori": _rule("common", "Negate the next 2 Curses obtained.", {"route", "event", "shop"}, {"curse", "counter"}),
    "OrangePellets": _rule("shop", "Playing an Attack, Skill, and Power in one turn removes debuffs.", {"combat_order", "card_reward", "shop"}, {"debuff_cleanse", "card_chain", "power"}),
    "Orichalcum": _rule("common", "End the turn with 6 Block if no Block is present.", {"combat_order", "shop"}, {"block"}),
    "Ornamental Fan": _rule("uncommon", "Every 3 Attacks in one turn grant 4 Block.", {"combat_order", "card_reward", "shop"}, {"attack_chain", "block"}),
    "Orrery": _rule("shop", "Choose cards from 5 consecutive card rewards on pickup.", {"pickup", "card_reward", "shop"}, {"card_quality"}),
    "Pandora's Box": _rule("boss", "Transform all Strikes and Defends on pickup.", {"pickup", "boss_reward"}, {"transform", "card_quality"}),
    "Pantograph": _rule("uncommon", "Heal 25 HP at the start of Boss combats.", {"combat_state", "route", "shop"}, {"heal", "boss"}),
    "Peace Pipe": _rule("rare", "Rest Sites can remove a card from the deck.", {"rest", "card_reward", "shop"}, {"campfire", "remove", "card_quality"}),
    "Pear": _rule("uncommon", "Gain 10 Max HP on pickup.", {"pickup", "route", "shop"}, {"max_hp"}),
    "Pen Nib": _rule("common", "Every 10th Attack deals double damage.", {"combat_order", "card_reward", "shop"}, {"attack_chain", "damage", "counter"}),
    "Philosopher's Stone": _rule("boss", "Gain 1 Energy each turn; enemies start with 1 Strength.", {"combat_state", "route", "boss_reward"}, {"energy", "enemy_strength"}),
    "Pocketwatch": _rule("rare", "Playing 3 or fewer cards this turn draws 3 extra next turn.", {"combat_order", "card_reward", "shop"}, {"draw", "card_limit"}),
    "Potion Belt": _rule("common", "Gain 2 Potion slots on pickup.", {"pickup", "shop"}, {"potion"}),
    "Prayer Wheel": _rule("rare", "Normal enemy combats offer an additional card reward.", {"route", "card_reward", "shop"}, {"combat_reward", "card_quality"}),
    "PreservedInsect": _rule("common", "Elites enter combat with 25% less Max HP.", {"combat_state", "route", "shop"}, {"elite", "damage"}),
    "PrismaticShard": _rule("shop", "Colored cards from other characters may appear.", {"card_reward", "shop"}, {"variance", "negative_model"}),
    "Question Card": _rule("uncommon", "Card rewards contain 1 additional card.", {"card_reward", "route", "shop"}, {"card_quality", "combat_reward"}),
    "Red Mask": _rule("special", "Apply 1 Weak to all enemies at combat start.", {"combat_state", "route", "event"}, {"weak", "frontload"}),
    "Regal Pillow": _rule("common", "Resting heals 15 additional HP.", {"route", "rest", "shop"}, {"heal", "campfire"}),
    "Runic Dome": _rule("boss", "Gain 1 Energy each turn but enemy Intents are hidden.", {"combat_state", "route", "boss_reward"}, {"energy", "hidden_intent"}),
    "Runic Pyramid": _rule("boss", "Cards are not discarded from the hand at end of turn.", {"combat_order", "card_reward", "boss_reward"}, {"retain_hand"}),
    "SacredBark": _rule("boss", "Double the numerical effects of Potions.", {"combat_order", "route", "boss_reward"}, {"potion"}),
    "Shovel": _rule("rare", "Rest Sites can Dig for a random relic.", {"rest", "route", "shop"}, {"campfire", "relic_reward"}),
    "Shuriken": _rule("uncommon", "Every 3 Attacks in one turn grant 1 Strength.", {"combat_order", "card_reward", "shop"}, {"attack_chain", "strength"}),
    "Singing Bowl": _rule("uncommon", "Skipping a card reward can grant 2 Max HP.", {"card_reward", "shop"}, {"max_hp", "card_quality"}),
    "SlaversCollar": _rule("boss", "Gain 1 Energy each turn in Elite and Boss combats.", {"combat_state", "route", "boss_reward"}, {"energy", "elite", "boss"}),
    "Sling": _rule("shop", "Start Elite combats with 2 Strength.", {"combat_state", "route", "shop"}, {"strength", "elite", "frontload"}),
    "Smiling Mask": _rule("common", "Merchant card removal always costs 50 Gold.", {"route", "shop"}, {"economy", "remove"}),
    "Snecko Eye": _rule("boss", "Draw 2 extra cards each turn and randomize card costs on draw.", {"combat_state", "card_reward", "boss_reward"}, {"draw", "confusion"}),
    "Sozu": _rule("boss", "Gain 1 Energy each turn but Potions cannot be obtained or used.", {"combat_state", "route", "shop", "boss_reward"}, {"energy", "no_potion"}),
    "Spirit Poop": _rule("special", "Has no run effect and lowers final score by 1.", {"no_decision", "event"}, {"negative"}),
    "SsserpentHead": _rule("special", "Gain 50 Gold whenever a Question room is entered.", {"route", "event"}, {"question", "economy", "gold"}),
    "StoneCalendar": _rule("rare", "At the end of turn 7 deal 52 damage to all enemies once.", {"combat_future", "combat_order", "shop"}, {"damage", "timed"}),
    "Strange Spoon": _rule("shop", "Cards that would Exhaust have a 50% chance to discard instead.", {"combat_order", "card_reward", "shop"}, {"exhaust", "variance"}),
    "Strawberry": _rule("common", "Gain 7 Max HP on pickup.", {"pickup", "route", "shop"}, {"max_hp"}),
    "StrikeDummy": _rule("uncommon", "Cards containing Strike deal 3 additional damage.", {"combat_order", "card_reward", "shop"}, {"attack", "strike"}),
    "Sundial": _rule("uncommon", "Every 3 draw-pile shuffles grant 2 Energy.", {"combat_order", "card_reward", "shop"}, {"shuffle", "energy", "counter"}),
    "Thread and Needle": _rule("rare", "Start each combat with 4 Plated Armor.", {"combat_state", "route", "shop"}, {"block"}),
    "Tiny Chest": _rule("common", "Every 4th Question room becomes a Treasure room.", {"route", "shop"}, {"question", "chest", "counter"}),
    "Tiny House": _rule("boss", "Gain a Potion, 50 Gold, 5 Max HP, heal 5, upgrade one random card, and choose a card.", {"pickup", "boss_reward"}, {"potion", "gold", "max_hp", "heal", "upgrade", "card_quality"}),
    "Toolbox": _rule("shop", "Choose 1 of 3 random Colorless cards at combat start.", {"combat_order", "shop"}, {"random_card", "frontload"}),
    "Torii": _rule("rare", "Unblocked enemy Attack damage of 5 or less is reduced to 1.", {"combat_state", "combat_order", "route", "shop"}, {"damage_reduction"}),
    "Toxic Egg 2": _rule("uncommon", "Future Skill cards are upgraded when obtained.", {"card_reward", "shop"}, {"skill", "upgrade"}),
    "Toy Ornithopter": _rule("common", "Heal 5 HP whenever a Potion is used.", {"combat_order", "route", "shop"}, {"heal", "potion"}),
    "TungstenRod": _rule("rare", "Lose 1 less HP whenever HP would be lost.", {"combat_state", "combat_order", "card_reward", "route", "shop"}, {"damage_reduction", "self_damage"}),
    "Turnip": _rule("rare", "Frail cannot be applied to the player.", {"combat_state", "route", "shop"}, {"debuff_immunity"}),
    "Unceasing Top": _rule("rare", "Whenever the hand becomes empty during the turn, draw 1 card.", {"combat_order", "card_reward", "shop"}, {"draw", "card_chain"}),
    "Vajra": _rule("common", "Start each combat with 1 Strength.", {"combat_state", "card_reward", "shop"}, {"strength"}),
    "Velvet Choker": _rule("boss", "Gain 1 Energy each turn but at most 6 cards may be played each turn.", {"combat_order", "card_reward", "boss_reward"}, {"energy", "card_limit"}),
    "Lee's Waffle": _rule("shop", "Gain 7 Max HP and heal to full on pickup.", {"pickup", "route", "shop"}, {"max_hp", "heal"}),
    "War Paint": _rule("common", "Upgrade 2 random Skills on pickup.", {"pickup", "shop"}, {"skill", "upgrade"}),
    "WarpedTongs": _rule("special", "At turn start upgrade a random hand card for that combat.", {"combat_state", "combat_future", "event"}, {"upgrade", "random_card"}),
    "Whetstone": _rule("common", "Upgrade 2 random Attacks on pickup.", {"pickup", "shop"}, {"attack", "upgrade"}),
    "White Beast Statue": _rule("uncommon", "A Potion always appears in combat rewards.", {"route", "shop"}, {"potion", "combat_reward"}),
    "WingedGreaves": _rule("rare", "Choose any reachable map node 3 times.", {"route", "shop"}, {"map_control", "counter"}),
    "Black Blood": _rule("boss", "Heal 12 HP after combat, replacing Burning Blood.", {"route", "boss_reward"}, {"heal", "combat_reward"}, "ironclad"),
    "Brimstone": _rule("shop", "At turn start gain 2 Strength and all enemies gain 1 Strength.", {"combat_state", "combat_future", "card_reward", "route", "shop"}, {"strength", "enemy_strength"}, "ironclad"),
    "Burning Blood": _rule("starter", "Heal 6 HP after combat.", {"route"}, {"heal", "combat_reward"}, "ironclad"),
    "Champion Belt": _rule("rare", "Applying Vulnerable also applies 1 Weak.", {"combat_order", "card_reward", "shop"}, {"vulnerable", "weak"}, "ironclad"),
    "Charon's Ashes": _rule("rare", "Whenever a card is Exhausted, deal 3 damage to all enemies.", {"combat_order", "card_reward", "shop"}, {"exhaust", "damage"}, "ironclad"),
    "Magic Flower": _rule("rare", "All healing is increased by 50%.", {"combat_state", "card_reward", "route", "shop"}, {"heal"}, "ironclad"),
    "Mark of Pain": _rule("boss", "Gain 1 Energy each turn; shuffle 2 Wounds into the draw pile at combat start.", {"combat_state", "card_reward", "boss_reward"}, {"energy", "status"}, "ironclad"),
    "Paper Frog": _rule("uncommon", "Vulnerable enemies take 75% additional Attack damage.", {"combat_order", "card_reward", "shop"}, {"vulnerable", "damage"}, "ironclad"),
    "Red Skull": _rule("common", "Gain 3 Strength while at or below 50% HP.", {"combat_state", "card_reward", "route", "shop"}, {"strength", "low_hp"}, "ironclad"),
    "Runic Cube": _rule("boss", "Draw 1 card whenever HP is lost.", {"combat_order", "card_reward", "boss_reward"}, {"draw", "self_damage"}, "ironclad"),
    "Self Forming Clay": _rule("uncommon", "Whenever HP is lost, gain 3 Block next turn.", {"combat_order", "combat_future", "card_reward", "shop"}, {"block", "self_damage"}, "ironclad"),
}


def _normal_key(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


_ALIASES = {_normal_key(relic_id): relic_id for relic_id in RELIC_RULES}
_ALIASES.update({
    "theboot": "Boot",
    "abacus": "TheAbacus",
    "captainswheel": "CaptainsWheel",
    "ceramicfish": "CeramicFish",
    "charonsashes": "Charon's Ashes",
    "courier": "The Courier",
    "medicalkit": "Medical Kit",
    "mummifiedhand": "Mummified Hand",
    "paperfrog": "Paper Frog",
    "preservedinsect": "PreservedInsect",
    "regalpillow": "Regal Pillow",
    "sacredbark": "SacredBark",
    "selfformingclay": "Self Forming Clay",
    "slaverscollar": "SlaversCollar",
    "stonecalendar": "StoneCalendar",
    "strike_dummy": "StrikeDummy",
    "tungstenrod": "TungstenRod",
    "whitebeast": "White Beast Statue",
    "wingboots": "WingedGreaves",
})


def canonical_relic_id(value):
    """Return the installed game's canonical ID while preserving mod relics."""
    raw = str(value or "")
    return _ALIASES.get(_normal_key(raw), raw)


def relic_ids(state):
    return {
        canonical_relic_id(relic.get("id") or relic.get("name"))
        for relic in (state or {}).get("relics", [])
        if relic.get("id") or relic.get("name")
    }


def relic_counter(state, relic_id, default=-1):
    wanted = canonical_relic_id(relic_id)
    for relic in (state or {}).get("relics", []):
        current = canonical_relic_id(relic.get("id") or relic.get("name"))
        if current != wanted:
            continue
        try:
            return int(relic.get("counter", default))
        except (TypeError, ValueError):
            return default
    return default


def relic_rule(relic_or_id):
    if isinstance(relic_or_id, dict):
        relic_or_id = relic_or_id.get("id") or relic_or_id.get("name")
    return RELIC_RULES.get(canonical_relic_id(relic_or_id))


_SHOP_TIER_BASE = {
    "common": 44,
    "uncommon": 52,
    "rare": 61,
    "shop": 54,
}

_SHOP_TAG_BONUS = {
    "block": 3,
    "card_chain": 5,
    "card_quality": 4,
    "damage_reduction": 5,
    "debuff_cleanse": 7,
    "debuff_immunity": 4,
    "dexterity": 3,
    "discount": 12,
    "draw": 5,
    "economy": 3,
    "energy": 5,
    "frontload": 2,
    "heal": 4,
    "intangible": 7,
    "max_hp": 3,
    "relic_reward": 3,
    "strength": 4,
}

_SHOP_SCORE_OVERRIDES = {
    "Bird Faced Urn": 67,
    "Cauldron": 40,
    "Chemical X": 56,
    "ClockworkSouvenir": 67,
    "DollysMirror": 63,
    "Dream Catcher": 54,
    "Frozen Eye": 0,
    "HandDrill": 18,
    "Happy Flower": 60,
    "Membership Card": 90,
    "OrangePellets": 72,
    "Orrery": 62,
    "PrismaticShard": 0,
    "Strange Spoon": 50,
    "The Courier": 76,
    "Toolbox": 51,
}


def default_shop_score(relic_or_id):
    """Return a deck-agnostic shop score; callers add live synergies."""
    rule = relic_rule(relic_or_id)
    if rule is None:
        return 50
    relic_id = canonical_relic_id(
        relic_or_id.get("id") or relic_or_id.get("name")
        if isinstance(relic_or_id, dict)
        else relic_or_id
    )
    if relic_id in _SHOP_SCORE_OVERRIDES:
        return _SHOP_SCORE_OVERRIDES[relic_id]
    score = _SHOP_TIER_BASE.get(rule.tier, 48)
    return score + sum(_SHOP_TAG_BONUS.get(tag, 0) for tag in rule.tags)


IRONCLAD_RELIC_IDS = frozenset(RELIC_RULES)
EXPLICIT_COMBAT_RELIC_IDS = frozenset(
    relic_id
    for relic_id, rule in RELIC_RULES.items()
    if "combat_order" in rule.domains or "combat_future" in rule.domains
)
ROUTE_RELIC_IDS = frozenset(
    relic_id for relic_id, rule in RELIC_RULES.items() if "route" in rule.domains
)
REST_RELIC_IDS = frozenset(
    relic_id for relic_id, rule in RELIC_RULES.items() if "rest" in rule.domains
)
CARD_REWARD_RELIC_IDS = frozenset(
    relic_id
    for relic_id, rule in RELIC_RULES.items()
    if "card_reward" in rule.domains
)
