import argparse
import json
import os
import re
import sys
import time
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent))
from sts_turn_planner import (
    BLOCK_VALUE,
    RISKY_POWER_HP_THRESHOLDS,
    SAFE_POWER_VALUES,
    UPGRADE_COST_REDUCTION_CARDS,
    adjusted_block,
    build_model,
    dual_wield_target_index,
    exhume_card_score,
    plan_turn,
    power_amount,
    secret_weapon_card_score,
    simulate_card,
)
from ironclad_archetypes import (
    ARCHETYPES,
    CARD_ARCHETYPE_SCORES,
    ZERO_ARCHETYPE_VECTOR,
)
from sts_relic_rules import (
    canonical_relic_id,
    default_shop_score,
    relic_counter as modeled_relic_counter,
    relic_ids as canonical_relic_ids,
    relic_rule,
)


BASE = Path(os.environ.get("STS_COMM_DIR", Path(__file__).resolve().parent / "sts-comm"))
STATE = BASE / "state_latest.json"
SEQ = BASE / "state_seq.txt"
COMMAND = BASE / "command.txt"
BOT_LOG = BASE / "bot.log"
BOT_VERSION = "v327"
BOT_STDOUT_LOG = os.environ.get("STS_BOT_STDOUT_LOG", "").lower() in {
    "1", "true", "yes", "on",
}


POTION_BASE_SCORES = {
    "FairyPotion": 92,
    "CultistPotion": 78,
    "EntropicBrew": 72,
    "Fruit Juice": 70,
    "DuplicationPotion": 68,
    "LiquidMemories": 66,
    "HeartOfIron": 64,
    "Regen Potion": 62,
    "BloodPotion": 58,
    "PowerPotion": 56,
    "ColorlessPotion": 54,
    "Energy Potion": 54,
    "BlessingOfTheForge": 52,
    "Strength Potion": 50,
    "FearPotion": 48,
    "Block Potion": 47,
    "Weak Potion": 45,
    "SpeedPotion": 44,
    "Dexterity Potion": 44,
    "EssenceOfSteel": 43,
    "LiquidBronze": 42,
    "Swift Potion": 42,
    "GamblersBrew": 41,
    "Fire Potion": 40,
    "Explosive Potion": 38,
    "AttackPotion": 38,
    "SkillPotion": 38,
    "SteroidPotion": 37,
    "Ancient Potion": 34,
    "ElixirPotion": 34,
    "DistilledChaos": 33,
    "SmokeBomb": 32,
    "SneckoOil": 28,
}
POTION_ID_ALIASES = {
    "fairyinabottle": "FairyPotion",
    "fairypotion": "FairyPotion",
    "cultistpotion": "CultistPotion",
    "entropicbrew": "EntropicBrew",
    "fruitjuice": "Fruit Juice",
    "duplicationpotion": "DuplicationPotion",
    "liquidmemories": "LiquidMemories",
    "heartofiron": "HeartOfIron",
    "regenpotion": "Regen Potion",
    "bloodpotion": "BloodPotion",
    "powerpotion": "PowerPotion",
    "colorlesspotion": "ColorlessPotion",
    "energypotion": "Energy Potion",
    "blessingoftheforge": "BlessingOfTheForge",
    "strengthpotion": "Strength Potion",
    "fearpotion": "FearPotion",
    "blockpotion": "Block Potion",
    "weakpotion": "Weak Potion",
    "speedpotion": "SpeedPotion",
    "dexteritypotion": "Dexterity Potion",
    "essenceofsteel": "EssenceOfSteel",
    "liquidbronze": "LiquidBronze",
    "swiftpotion": "Swift Potion",
    "gamblersbrew": "GamblersBrew",
    "firepotion": "Fire Potion",
    "explosivepotion": "Explosive Potion",
    "attackpotion": "AttackPotion",
    "skillpotion": "SkillPotion",
    "flexpotion": "SteroidPotion",
    "steroidpotion": "SteroidPotion",
    "ancientpotion": "Ancient Potion",
    "elixir": "ElixirPotion",
    "elixirpotion": "ElixirPotion",
    "distilledchaos": "DistilledChaos",
    "smokebomb": "SmokeBomb",
    "snecko oil": "SneckoOil",
    "sneckooil": "SneckoOil",
}
REVIVE_POTION_IDS = {"FairyPotion"}
REVIVE_RELIC_IDS = {"Lizard Tail", "LizardTail"}
MARK_OF_BLOOM_IDS = {"Mark of the Bloom", "MarkOfTheBloom"}
POTION_REPLACEMENT_MARGIN = 7.0


CARD_SCORES = {
    "Offering": 100,
    "Immolate": 98,
    "Feed": 95,
    "Reaper": 92,
    "Corruption": 86,
    "Fiend Fire": 84,
    "Demon Form": 82,
    "Impervious": 82,
    "Disarm": 82,
    "Shockwave": 82,
    "Adrenaline": 80,
    "Apotheosis": 80,
    "Dark Shackles": 90,
    "Feel No Pain": 74,
    "Dark Embrace": 72,
    "Barricade": 66,
    "Limit Break": 70,
    "Inflame": 69,
    "Spot Weakness": 68,
    "Shrug It Off": 67,
    "Pommel Strike": 65,
    "Battle Trance": 64,
    "Flame Barrier": 63,
    "Ghostly Armor": 58,
    "Ghostly": 110,
    "Power Through": 66,
    "Second Wind": 60,
    "Uppercut": 61,
    "Carnage": 60,
    "Hemokinesis": 58,
    "Whirlwind": 57,
    "Pummel": 62,
    "Sword Boomerang": 52,
    "Armaments": 56,
    "Burning Pact": 55,
    "True Grit": 53,
    "Clothesline": 52,
    "Thunderclap": 50,
    "Headbutt": 48,
    "Cleave": 45,
    "Anger": 48,
    "Iron Wave": 42,
    "Twin Strike": 48,
    "Perfected Strike": 38,
    "Flex": 35,
    "Body Slam": 34,
    "Blood for Blood": 52,
    "Combust": 46,
    "Juggernaut": 45,
    "Sentinel": 44,
    "Rupture": 42,
    "Brutality": 50,
    "Bloodletting": 38,
    "Reckless Charge": 44,
    "Wild Strike": 45,
    "Warcry": 28,
    "Heavy Blade": 24,
    "Entrench": 24,
    "Evolve": 48,
    "Fire Breathing": 50,
    "Double Tap": 78,
    "Clash": 5,
    "Searing Blow": 0,
    "Berserk": 0,
}

# Temporary card choices from potions and combat effects need immediate-combat
# values rather than permanent deck-building scores. In particular, a retained
# Dark Shackles can answer a boss's next heavy hit even when the current intent
# is not yet attacking.
COMBAT_TEMP_CARD_SCORES = {
    "Apotheosis": 92,
    "Dark Shackles": 90,
    "Master of Strategy": 88,
    "Panic Button": 86,
    "PanicButton": 86,
    "Hand of Greed": 80,
    "HandOfGreed": 80,
    "Secret Weapon": 58,
    "Trip": 68,
    "Blind": 68,
    "Finesse": 64,
    "Flash of Steel": 62,
    "Good Instincts": 58,
    "Purity": 24,
    "Sadistic Nature": 18,
}

UPGRADE_PRIORITY = {
    "Bash": 80,
    "Armaments": 78,
    "Offering": 76,
    "Inflame": 74,
    "Demon Form": 72,
    "Perfected Strike": 58,
    "Bludgeon": 82,
    "Pommel Strike": 70,
    "Shrug It Off": 68,
    "True Grit": 66,
    "Uppercut": 64,
    "Disarm": 62,
    "Shockwave": 60,
    "Whirlwind": 58,
    "Evolve": 72,
    "Fire Breathing": 70,
    "Power Through": 68,
    "Strike_R": 5,
    "Defend_R": 20,
}

BOSS_RELIC_SCORES = {
    "Black Blood": 68,
    "Snecko Eye": 92,
    "Runic Pyramid": 90,
    "Coffee Dripper": 86,
    "Fusion Hammer": 78,
    "Cursed Key": 76,
    "Sozu": 72,
    "SlaversCollar": 70,
    "Astrolabe": 66,
    "Empty Cage": 64,
    "Pandora's Box": 62,
    "Calling Bell": 80,
    "Mark of Pain": 58,
    "Busted Crown": 35,
    "Ectoplasm": 25,
    "Runic Dome": 10,
    "Velvet Choker": 74,
    "Black Star": 54,
}

NON_COMBAT_RELICS = {
    "Burning Blood",
    # CommunicationMod already exposes the ordered draw pile, so Frozen Eye
    # does not add combat information to this bot.
    "Frozen Eye",
    "NeowsBlessing",
    "Golden Idol",
    "Red Mask",
    "SsserpentHead",
    "MawBank",
    "NlothsGift",
}

REPEATABLE_EXHAUST_SOURCES = {"Burning Pact", "True Grit", "Havoc"}
MASS_EXHAUST_SOURCES = {"Corruption", "Second Wind", "Fiend Fire", "Sever Soul"}
ONE_SHOT_EXHAUST_SOURCES = {
    "Offering", "Impervious", "Disarm", "Shockwave", "Intimidate", "Exhume",
}
EXHUME_DIRECT_TARGET_IDS = {
    "Carnage", "Dark Shackles", "Disarm", "Feed", "Fiend Fire",
    "Ghostly Armor", "Impervious", "Infernal Blade", "Intimidate",
    "Limit Break", "Offering", "Reaper", "Seeing Red", "Shockwave",
    "Warcry",
}
EXHAUST_SYNERGY_CARDS = (
    REPEATABLE_EXHAUST_SOURCES
    | MASS_EXHAUST_SOURCES
    | ONE_SHOT_EXHAUST_SOURCES
)
FLIGHT_BREAKER_CARDS = {"Pummel", "Sword Boomerang", "Whirlwind", "Twin Strike", "Thunderclap", "Cleave", "Anger"}
BYRD_KNOCKDOWN_CONTROL_WEIGHTS = {
    "Pummel": 1.0,
    "Twin Strike": 0.5,
    "Sword Boomerang": 0.45,
    "Double Tap": 0.35,
    "Anger": 0.22,
}
BYRD_KNOCKDOWN_REWARD_BONUS = {
    "Pummel": 45,
    "Twin Strike": 28,
    "Sword Boomerang": 26,
    "Double Tap": 22,
    "Anger": 18,
}

# These cards are broadly useful enough that they are allowed to cross an
# established archetype boundary.  This is intentionally a short whitelist:
# a high raw score alone must not make every unrelated card an automatic pick.
UNIVERSAL_REWARD_CARDS = {
    "Adrenaline", "Apotheosis", "Battle Trance", "Dark Shackles", "Disarm", "Feed",
    "Double Tap", "Flame Barrier", "Immolate", "Impervious", "Offering", "Pommel Strike",
    "Reaper", "Shockwave", "Shrug It Off", "Uppercut",
}

# High-ascension rewards should preserve cards that remain valuable after Act 1
# instead of letting several narrow hallway attacks win through accumulated
# emergency bonuses. Conditional engine cards are handled separately below so
# rarity never turns a dead Barricade or Limit Break into an automatic pick.
HIGH_ASCENSION_PREMIUM_LONG_TERM_CARDS = {
    "Battle Trance", "Disarm", "Feed", "Fiend Fire", "Flame Barrier",
    "Immolate", "Impervious", "Offering", "Power Through", "Shockwave",
}
ACT1_TRANSITIONAL_COMMON_CARDS = {
    "Anger", "Cleave", "Clothesline", "Headbutt", "Iron Wave",
    "Perfected Strike", "Sword Boomerang", "Thunderclap", "Twin Strike",
    "Wild Strike",
}

# First-act decks that are overly defensive can reach the boss without enough
# damage to win.  These cards are allowed to cross the current archetype when
# the deck still lacks a credible first-boss damage plan.
ACT1_BOSS_DAMAGE_CARDS = {
    "Blood for Blood", "Bludgeon", "Carnage", "Cleave", "Clothesline", "Fiend Fire",
    "Hemokinesis", "Immolate",
    "Pummel", "Sword Boomerang", "Twin Strike", "Uppercut", "Whirlwind",
}
# Broader set used only while acquiring emergency damage.  Keeping this
# separate from ACT1_BOSS_DAMAGE_CARDS prevents a pile of modest attacks from
# falsely satisfying the long-boss readiness check.
ACT1_BOSS_REWARD_DAMAGE_CARDS = ACT1_BOSS_DAMAGE_CARDS | {
    "Anger", "Blood for Blood", "Feed", "Headbutt", "Heavy Blade",
    "Perfected Strike", "Rampage", "Wild Strike",
}
ACT1_BOSS_SCALING_CARDS = {
    "Brutality", "Combust", "Demon Form", "Fire Breathing", "Inflame", "Rupture",
    "Spot Weakness",
}
SLIME_BOSS_AOE_REWARD_BONUS = {
    "Cleave": 44,
    "Thunderclap": 34,
    "Whirlwind": 40,
    "Immolate": 34,
    "Combust": 30,
    "Fire Breathing": 28,
}
HEXAGHOST_WEAK_SOURCES = {"Clothesline", "Intimidate", "Shockwave", "Uppercut"}
PERFECTED_STRIKE_CARDS = {
    "Strike_B", "Strike_G", "Strike_P", "Strike_R", "Swift Strike",
    "Perfected Strike", "Pommel Strike", "Twin Strike", "Wild Strike",
}
ARCHETYPE_MATCH_MIN = 3
SECONDARY_ARCHETYPE_MATCH_MIN = 5
DEVELOPING_ARCHETYPE_MATCH_MIN = 5
ARCHETYPE_BRIDGE_TOTAL_MIN = 7
MAX_ACTIVE_ARCHETYPES = 2
SHOP_STRONG_ARCHETYPE_MATCH_MIN = 8
SHOP_PREMIUM_UNIVERSAL_MIN = 90
SHOP_EXCEPTIONAL_CARD_MIN = 70
SHOP_RELIC_PRIORITY_BONUS = 12
SHOP_RELIC_BASE_SCORES = {
    # Hand Drill is too situational to justify consuming most of an early
    # shop's gold merely because relics normally outrank cards.
    "HandDrill": 18,
    # The bot receives the same draw-order information directly from
    # CommunicationMod, making this relic a redundant shop purchase.
    "Frozen Eye": 0,
    # Prismatic Shard invalidates the Ironclad-only reward/archetype model and
    # turns later card rewards into choices the bot cannot evaluate reliably.
    "PrismaticShard": 0,
}
X_COST_CARD_IDS = {
    "Conjure Blade", "Malaise", "Multi-Cast", "Reinforced Body",
    "Skewer", "Tempest", "Transmutation", "Whirlwind",
}
DRAW_SETUP_VALUES = {
    "Adrenaline": 2,
    "Battle Trance": 3,
    "Burning Pact": 2,
    "Deep Breath": 2,
    "Finesse": 1,
    "Impatience": 2,
    "Master of Strategy": 3,
    "Offering": 3,
    "Shrug It Off": 1,
    "Thinking Ahead": 2,
    "Warcry": 1,
}
DRAW_ORDER_BLOCK_CARDS = {
    "Armaments", "Defend_R", "Flame Barrier", "Ghostly", "Ghostly Armor", "Impervious",
    "Iron Wave", "Power Through", "Second Wind", "Shrug It Off", "True Grit",
}
DRAW_ORDER_CONTROL_CARDS = {
    "Disarm", "Intimidate", "Shockwave", "Trip", "Uppercut",
}
DRAW_ORDER_ENERGY_CARDS = {
    "Adrenaline", "Bloodletting", "Offering", "Seeing Red",
}
SAFE_RELIC_FILLERS = {"Armaments", "Defend_R", "Flex", "Seeing Red"}
STRENGTH_SOURCE_CARDS = {"Demon Form", "Inflame", "J.A.X.", "Rupture", "Spot Weakness"}
STRENGTH_SOURCE_RELICS = {"Brimstone", "Girya", "Red Skull", "Shuriken", "Vajra"}
SELF_DAMAGE_SOURCE_CARDS = {
    "Bloodletting", "Brutality", "Combust", "Hemokinesis", "J.A.X.",
    "Offering", "Pain",
}
TUNGSTEN_NULLIFIED_SELF_DAMAGE_SOURCES = {"Brutality", "Combust", "Pain"}
STRENGTH_PAYOFF_CARDS = {
    "Heavy Blade", "Limit Break", "Pummel", "Reaper", "Sword Boomerang",
    "Twin Strike", "Whirlwind",
}
BARRICADE_SUPPORT_WEIGHTS = {
    "Impervious": 3,
    "Entrench": 3,
    "Power Through": 2,
    "Flame Barrier": 2,
    "Second Wind": 2,
    "Shrug It Off": 1,
    "Ghostly Armor": 1,
    "Body Slam": 1,
}

LATE_ACT1_DEFENSIVE_CARDS = {
    "Armaments", "Barricade", "Entrench", "Flame Barrier", "Ghostly", "Ghostly Armor",
    "Impervious", "Metallicize", "Power Through", "Second Wind",
    "Shrug It Off", "True Grit",
}

CRITICAL_HP_DEFENSIVE_REWARDS = {
    "Flame Barrier", "Ghostly", "Ghostly Armor", "Impervious", "Power Through",
    "Second Wind", "Shrug It Off",
}
LOW_RESERVE_DEFENSIVE_REWARDS = CRITICAL_HP_DEFENSIVE_REWARDS | {
    "Iron Wave", "True Grit",
}
FORCED_ELITE_DEFENSIVE_REWARDS = {
    "Disarm", "Flame Barrier", "Ghostly", "Ghostly Armor", "Impervious", "Iron Wave",
    "Metallicize", "Power Through", "Shockwave", "Shrug It Off", "True Grit",
}
CRITICAL_ROUTE_SELF_DAMAGE_CARDS = {
    "Bloodletting", "Brutality", "Combust", "Hemokinesis", "J.A.X.",
}
ACT2_DAMAGE_ENGINE_REWARDS = {
    "Bludgeon", "Carnage", "Combust", "Demon Form", "Fiend Fire",
    "Immolate", "Inflame", "Spot Weakness",
}
ACT2_LOW_RESERVE_FRONTLOAD_CARDS = {"Bludgeon", "Carnage", "Immolate"}
DOUBLE_TAP_PREMIUM_ATTACKS = {
    "Bludgeon", "Carnage", "Fiend Fire", "Heavy Blade", "Immolate",
    "Perfected Strike", "Pummel", "Reaper", "Uppercut", "Whirlwind",
}

ACT2_SWARM_CONTROL_BONUS = {
    "Immolate": 32,
    "Whirlwind": 44,
    "Cleave": 52,
    "Combust": 42,
    "Reaper": 30,
    "Fire Breathing": 38,
}

EARLY_SWARM_CONTROL_BONUS = {
    "Cleave": 32,
    "Whirlwind": 30,
    "Combust": 24,
    "Immolate": 20,
}

# Once a speculative status payoff has entered the deck, the first permanent
# status generator is worth more than another setup or generic utility card.
# Keep this to the four Ironclad cards that create reusable status fuel.
STATUS_FUEL_REWARD_BONUS = {
    "Power Through": 50,
    "Reckless Charge": 42,
    "Immolate": 36,
    "Wild Strike": 34,
}

# Act 2 asks for block that works immediately against repeated 20+ damage
# turns. Armaments and True Grit remain useful cards, but they do not by
# themselves make that transition package complete.
ACT2_TRANSITION_DEFENSE_CARDS = {
    "Disarm", "Flame Barrier", "Ghostly", "Ghostly Armor", "Impervious", "Iron Wave",
    "Power Through", "Shockwave", "Shrug It Off",
}
ACT2_HIGH_OUTPUT_DEFENSE_CARDS = {
    # Disarm is excellent long-fight mitigation, but it cannot absorb a
    # Nemesis-sized hit on the turn it is drawn. Keep one separate count for
    # cards that immediately produce a large amount of Block.
    "Flame Barrier", "Ghostly", "Impervious", "Power Through",
}
ACT2_DIRECT_BLOCK_DRAW_CARDS = {
    # Keep this separate from DEFENSIVE_PACKAGE_CARDS. Disarm and Shockwave
    # are excellent mitigation, but neither puts Block in hand on a later
    # Book of Stabbing turn. This count measures actual defensive draw density.
    "Armaments", "Flame Barrier", "Ghostly", "Ghostly Armor", "Impervious",
    "Iron Wave", "Metallicize", "Power Through", "Rage", "Second Wind",
    "Sentinel", "Shrug It Off", "True Grit",
}
ACT2_ATTACK_SATURATION_PREMIUM_CARDS = {
    # These attacks add a distinct run-defining role rather than another
    # interchangeable medium hit.
    "Bludgeon", "Feed", "Fiend Fire", "Immolate", "Reaper",
}
ACT2_ATTACK_HEAVY_BLOCK_BRIDGE_CARDS = {
    "Armaments", "Iron Wave", "Metallicize", "Rage", "Shrug It Off",
    "True Grit",
}
ACT1_BOSS_TRANSITION_DEFENSE_REWARDS = {
    "Flame Barrier", "Impervious", "Power Through", "Shockwave",
}

# A starter Defend is not an Act 2 defensive plan. These cards count as a
# reliable first-act foundation; slower engine pieces such as Barricade,
# Entrench, Armaments, and Second Wind deliberately do not.
ACT1_DEFENSE_FOUNDATION_CARDS = {
    "Disarm", "Flame Barrier", "Ghostly Armor", "Impervious", "Iron Wave",
    "Metallicize", "Power Through", "Shockwave", "Shrug It Off", "True Grit",
}

# A focused build still needs enough cards that actually prevent damage. These
# cards may cross an archetype boundary while that defensive package is short.
DEFENSIVE_PACKAGE_CARDS = LATE_ACT1_DEFENSIVE_CARDS | {
    "Disarm", "Iron Wave", "Sentinel", "Shockwave",
}
DEFENSIVE_SHORTFALL_BOOST_CARDS = LATE_ACT1_DEFENSIVE_CARDS | {
    "Iron Wave", "Sentinel", "Shockwave",
}

ARCHETYPE_CARD_POINTS = {
    archetype: {
        cid: vector[archetype]
        for cid, vector in CARD_ARCHETYPE_SCORES.items()
        if vector[archetype] > 0
    }
    for archetype in ARCHETYPES
}


ARCHETYPE_CORE_CARDS = {
    "strength": {"Demon Form", "Limit Break", "Inflame", "Spot Weakness", "Heavy Blade"},
    "exhaust": {"Corruption", "Dark Embrace", "Feel No Pain", "Fiend Fire"},
    "block": {"Barricade", "Entrench", "Body Slam", "Juggernaut"},
    "self_harm": {"Rupture", "Brutality", "Combust"},
    "status": {"Evolve", "Fire Breathing"},
    "perfected_strike": {"Perfected Strike"},
}

ARCHETYPE_RELIC_POINTS = {
    "strength": {
        "Brimstone": 10, "Girya": 6, "Shuriken": 5, "Vajra": 4,
        "Red Skull": 3, "Pen Nib": 2,
    },
    "exhaust": {
        "Dead Branch": 12, "CharonsAshes": 8, "Charon's Ashes": 8,
        "Medical Kit": 4,
    },
    "block": {
        "Calipers": 10, "Thread and Needle": 4, "Oddly Smooth Stone": 3,
        "Orichalcum": 2,
    },
    "self_harm": {
        "Runic Cube": 9, "Self Forming Clay": 3, "Red Skull": 4,
        "Magic Flower": 3,
    },
    "status": {
        "Mark of Pain": 12, "Medical Kit": 8, "Blue Candle": 4,
        "Du-Vu Doll": 10, "Cursed Key": 4, "Calling Bell": 5, "Darkstone Periapt": 4,
        "CharonsAshes": 4, "Charon's Ashes": 4, "Runic Cube": 2,
    },
    "perfected_strike": {"Strike Dummy": 12, "Molten Egg 2": 3},
}

ARCHETYPE_RELIC_LOOKUP = {
    relic_id: {archetype: points for archetype, relics in ARCHETYPE_RELIC_POINTS.items() if (points := relics.get(relic_id))}
    for relic_id in {relic_id for relics in ARCHETYPE_RELIC_POINTS.values() for relic_id in relics}
}
HAND_SELECT_MODE = None
GRID_SELECT_MODE = None
MIN_EXHAUST_ATTACK_CORE = 4
CARD_REWARD_SKIPPED = False
CARD_REWARD_SKIPPED_CONTEXT = None
SHOP_SESSION_TOKEN = None
SHOP_ENTRY_SENT = False
SHOP_SCREEN_SEEN = False
SHOP_EXIT_SENT = False
SHOP_CARD_PURCHASES = 0
LAST_MAP_NODE = None
ORRERY_REWARD_TAKES = 0
MATCH_GAME_SESSION = None
MATCH_GAME_MEMORY = {}
MATCH_GAME_MATCHED = set()
MATCH_GAME_FIRST = None
MATCH_GAME_SECOND = None
MATCH_GAME_NEEDS_WAIT = False
MATCH_GAME_VOID_PAIR = None
MATCH_GAME_ATTEMPTED_PAIRS = set()
MATCH_GAME_PICK_COUNTS = {}
# CommunicationMod may briefly publish a main-menu frame while an event or new
# run is resolving. Confirm it through several fresh states before restarting.
UNEXPECTED_MENU_CONFIRM_POLLS = 3
RUN_SESSION_SERIAL = 0
LAST_POTION_ATTEMPT = None
PENDING_DUPLICATION_TARGET = None
SMOKE_BOMB_ESCAPE_PENDING = None
COMBAT_RELIC_MEMORY_KEY = None
COMBAT_RELIC_MEMORY = {}
POTION_RETRY_GUARD_SECONDS = 1.2
LAST_POLICY_ATTEMPT = None
POLICY_RETRY_GUARD_SECONDS = 6.0
ABANDON_COMMANDS = ("ABANDON",)

DUPLICATION_CARD_VALUES = {
    "Immolate": 34,
    "Bludgeon": 32,
    "Fiend Fire": 30,
    "Limit Break": 30,
    "Reaper": 28,
    "Impervious": 28,
    "Perfected Strike": 24,
    "Heavy Blade": 24,
    "Pummel": 22,
    "Spot Weakness": 32,
    "Disarm": 32,
    "Carnage": 22,
    "Uppercut": 20,
    "Feed": 20,
    "Flame Barrier": 20,
    "Power Through": 20,
    "Juggernaut": 30,
}
DUPLICATION_REORDER_SAFE_CARDS = {
    "Anger", "Cleave", "Defend_R", "Flame Barrier", "Headbutt",
    "Iron Wave", "Strike_R", "Sword Boomerang", "Twin Strike",
}
DUPLICATION_DURABLE_BOSS_IDS = {
    "AwakenedOne", "BronzeAutomaton", "Champ", "Deca", "Donu",
    "Hexaghost", "SlimeBoss", "TheCollector", "TheGuardian", "TimeEater",
}
DUPLICATION_PRESSURE_ELITE_IDS = {
    "BookOfStabbing", "GremlinLeader", "GremlinNob", "Lagavulin",
}
FIXED_DUPLICATION_BLOCK_IDS = set(BLOCK_VALUE) - {"PanicButton"}

MATCH_GAME_CURSES = {
    "ascendersbane",
    "clumsy",
    "curseofthebell",
    "decay",
    "doubt",
    "injury",
    "necronomicurse",
    "normality",
    "pain",
    "parasite",
    "regret",
    "shame",
    "writhe",
}


def log(message):
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {message}\n"
    write_error = None
    for attempt in range(5):
        try:
            BASE.mkdir(parents=True, exist_ok=True)
            with BOT_LOG.open("a", encoding="utf-8") as handle:
                handle.write(line)
            write_error = None
            break
        except OSError as exc:
            write_error = exc
            if attempt < 4:
                time.sleep(0.05)
                continue
    if write_error is not None:
        # Log readers, antivirus, or indexing can briefly lock a Windows file.
        # Losing one durable line is preferable to losing the run.
        print(
            f"bot.log write failed ({type(write_error).__name__}): "
            f"{line.rstrip()}",
            file=sys.stderr,
            flush=True,
        )
    if BOT_STDOUT_LOG:
        print(line, end="", flush=True)


def combat_relic_memory_key(gs):
    combat = (gs or {}).get("combat_state") or {}
    if not combat:
        return None
    return (
        (gs or {}).get("seed"),
        int((gs or {}).get("act", 0) or 0),
        int((gs or {}).get("floor", 0) or 0),
        int(combat.get("turn", 0) or 0),
    )


def game_state_with_relic_memory(gs):
    global COMBAT_RELIC_MEMORY_KEY, COMBAT_RELIC_MEMORY
    key = combat_relic_memory_key(gs)
    if key != COMBAT_RELIC_MEMORY_KEY:
        COMBAT_RELIC_MEMORY_KEY = key
        COMBAT_RELIC_MEMORY = {}
    if key is None:
        return gs
    prepared = dict(gs)
    prepared["_bot_relic_memory"] = dict(COMBAT_RELIC_MEMORY)
    return prepared


def remember_combat_relic_play(command, gs):
    """Persist hidden per-turn relic state across one-card live replans."""
    global COMBAT_RELIC_MEMORY_KEY, COMBAT_RELIC_MEMORY
    if not isinstance(command, str) or not command.startswith("PLAY "):
        return
    key = combat_relic_memory_key(gs)
    if key is None:
        return
    if key != COMBAT_RELIC_MEMORY_KEY:
        COMBAT_RELIC_MEMORY_KEY = key
        COMBAT_RELIC_MEMORY = {}
    try:
        hand_index = int(command.split()[1]) - 1
        card = ((gs.get("combat_state") or {}).get("hand") or [])[hand_index]
    except (IndexError, TypeError, ValueError):
        return

    card_type = str(card.get("type") or "").upper()
    if card_type == "ATTACK":
        COMBAT_RELIC_MEMORY["attacks_played"] = (
            int(COMBAT_RELIC_MEMORY.get("attacks_played", 0) or 0) + 1
        )
    if "OrangePellets" in canonical_relic_ids(gs):
        card_bit = {"ATTACK": 1, "SKILL": 2, "POWER": 4}.get(
            card_type, 0
        )
        if card_bit:
            mask = int(
                COMBAT_RELIC_MEMORY.get("orange_pellets_mask", 0) or 0
            ) | card_bit
            COMBAT_RELIC_MEMORY["orange_pellets_mask"] = (
                0 if mask == 7 else mask
            )
    if (
        card_type == "ATTACK"
        and card_cost(card) >= 2
        and "Necronomicon" in canonical_relic_ids(gs)
    ):
        COMBAT_RELIC_MEMORY["necronomicon_used"] = True


def load_state(timeout=1.0):
    deadline = time.time() + timeout
    while True:
        try:
            return json.loads(STATE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            if time.time() >= deadline:
                raise
            time.sleep(0.05)


def seq_num():
    try:
        return int(SEQ.read_text(encoding="utf-8").strip())
    except Exception:
        return 0


def send_command(command, timeout=45):
    old_seq = seq_num()
    COMMAND.write_text(command, encoding="utf-8")
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(0.2)
        if seq_num() > old_seq:
            state = load_state()
            delay = transition_delay(command, state)
            if delay:
                time.sleep(delay)
            return state
    log(f"timeout after command: {command}")
    return load_state()


def is_main_menu_state(state):
    return state.get("in_game") is False and command_available(state, "start")


def should_guard_unexpected_menu(state, run_active, terminal_seen):
    """Whether a menu frame can be a transient publication from a live run."""
    return bool(run_active and not terminal_seen and is_main_menu_state(state))


def transition_delay(command, state):
    normalized = command.strip().upper()
    if normalized == "PROCEED" and is_main_menu_state(state):
        return 1.25
    if normalized.startswith("WAIT "):
        return 0.6
    return 0


def execute_abandon_run(send, attempts=4, sleep=time.sleep, poll_delay=0.75):
    state = send(ABANDON_COMMANDS[0])
    if is_main_menu_state(state):
        return state
    for attempt in range(attempts):
        sleep(poll_delay)
        state = send("STATE")
        if is_main_menu_state(state):
            return state
        log(f"abandon poll {attempt + 1} did not reach main menu")
    return state


def execute_policy_command(command, send=send_command):
    if command in {"ABANDON_RUN", "RECOVER_DEATH", "RESET_WRONG_RUN"}:
        return execute_abandon_run(send)
    return send(command)


def command_available(state, command):
    command = command.lower()
    available = [c.lower() for c in state.get("available_commands", [])]
    if command in ("confirm", "proceed"):
        return any(c in available for c in ("proceed", "confirm", "继续", "确认"))
    if command in ("return", "skip", "cancel", "leave"):
        return any(c in available for c in ("return", "skip", "cancel", "leave", "返回", "跳过", "离开"))
    return command in available


def available_exit_command(state, preferred=("leave", "return", "skip", "cancel")):
    """Return the exact exit command advertised by CommunicationMod."""
    available = [command.lower() for command in state.get("available_commands", [])]
    for command in preferred:
        if command in available:
            return command.upper()
    return None


def card_id(card):
    return card.get("id") or card.get("name") or ""


def normalized_potion_id(potion):
    """Return one canonical potion id across CommunicationMod naming variants."""
    if not potion:
        return ""
    if isinstance(potion, str):
        raw = potion
    else:
        raw = potion.get("id") or potion.get("name") or ""
    normalized = re.sub(r"[^a-z0-9]+", "", str(raw).lower())
    return POTION_ID_ALIASES.get(normalized, str(raw))


def _relic_ids(gs):
    return {
        relic.get("id") or relic.get("name") or ""
        for relic in gs.get("relics", [])
    }


def _relic_is_available(relic):
    """Best-effort check for one-use relics exposed by different mod versions."""
    if relic.get("used_up") or relic.get("usedUp") or relic.get("grayscale"):
        return False
    counter = relic.get("counter")
    # CommunicationMod uses -1 while Lizard Tail is live and -2 once spent;
    # some other adapters expose the consumed state as zero.
    if (
        counter == 0
        or isinstance(counter, (int, float)) and counter <= -2
    ) and (relic.get("id") or relic.get("name")) in REVIVE_RELIC_IDS:
        return False
    return True


def revive_reserve_hp(gs):
    """Return extra HP supplied by still-available resurrection resources."""
    relic_ids = _relic_ids(gs)
    if relic_ids & MARK_OF_BLOOM_IDS:
        return 0
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    sacred_bark = bool(relic_ids & {"SacredBark", "Sacred Bark"})
    reserve = 0
    for potion in gs.get("potions", []):
        if normalized_potion_id(potion) in REVIVE_POTION_IDS:
            reserve += max(1, int(max_hp * (0.60 if sacred_bark else 0.30)))
    for relic in gs.get("relics", []):
        rid = relic.get("id") or relic.get("name") or ""
        if rid in REVIVE_RELIC_IDS and _relic_is_available(relic):
            reserve += max(1, int(max_hp * 0.50))
    return reserve


def effective_hp_ratio(gs, revive_weight=1.0):
    """Strategic HP ratio including a discounted or full second life."""
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    current_hp = max(0, int(gs.get("current_hp", max_hp) or 0))
    reserve = revive_reserve_hp(gs)
    return max(
        0.0,
        min(1.0, (current_hp + reserve * max(0.0, float(revive_weight))) / max_hp),
    )


def campfire_revive_reserve_hp(gs):
    """Count only the strongest single second life at a campfire."""
    if revive_reserve_hp(gs) <= 0:
        return 0
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    relic_ids = _relic_ids(gs)
    strongest = 0
    if any(
        normalized_potion_id(potion) == "FairyPotion"
        for potion in gs.get("potions", [])
    ):
        strongest = max(
            strongest,
            int(
                max_hp
                * (0.60 if relic_ids & {"SacredBark", "Sacred Bark"} else 0.30)
            ),
        )
    if any(
        (relic.get("id") or relic.get("name")) in REVIVE_RELIC_IDS
        and _relic_is_available(relic)
        for relic in gs.get("relics", [])
    ):
        strongest = max(strongest, int(max_hp * 0.50))
    return max(0, strongest)


def potion_score(potion, gs, context="held"):
    """Context-sensitive potion value used for rewards, shops and replacement.

    The score combines raw effect strength, current HP, act pressure, deck
    synergies, upcoming boss demands, relic interactions and duplicate utility.
    """
    pid = normalized_potion_id(potion)
    if not pid or pid == "Potion Slot":
        return -999.0
    score = float(POTION_BASE_SCORES.get(pid, 32))
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    current_hp = max(0, int(gs.get("current_hp", max_hp) or 0))
    hp_ratio = current_hp / max_hp
    floor = int(gs.get("floor", 0) or 0)
    act = int(gs.get("act", 1 if floor <= 16 else 2 if floor <= 33 else 3) or 1)
    room_type = gs.get("room_type") or ""
    deck = gs.get("deck", [])
    deck_ids = {card_id(card) for card in deck}
    relic_ids = _relic_ids(gs)
    sacred_bark = bool(relic_ids & {"SacredBark", "Sacred Bark"})
    boss_or_elite = room_type in {"MonsterRoomBoss", "MonsterRoomElite"}
    defense_shortfall = defensive_package_shortfall(gs)
    strength_sources = boss_strength_scaling_source_count(gs)
    strength_payoffs = len(deck_ids & STRENGTH_PAYOFF_CARDS)
    exhaust_engine = bool(
        deck_ids & {"Corruption", "Dark Embrace", "Feel No Pain", "Burning Pact", "True Grit"}
        or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}
    )
    status_engine = bool(
        deck_ids & {"Fire Breathing", "Evolve", "Power Through", "Wild Strike", "Reckless Charge"}
        or any(card.get("type") in {"STATUS", "CURSE"} for card in deck)
    )
    high_cost_cards = sum(
        1 for card in deck
        if isinstance(card.get("cost"), int) and int(card.get("cost", 0) or 0) >= 2
    )
    power_count = sum(card.get("type") == "POWER" for card in deck)
    skill_count = sum(card.get("type") == "SKILL" for card in deck)
    attack_count = sum(card.get("type") == "ATTACK" for card in deck)
    upcoming_boss = upcoming_boss_id(gs)

    if pid == "FairyPotion":
        score += (1.0 - hp_ratio) * 42
        if not any((r.get("id") or r.get("name")) in REVIVE_RELIC_IDS for r in gs.get("relics", [])):
            score += 8
        if act >= 2:
            score += 7
    elif pid == "BloodPotion":
        score += (1.0 - hp_ratio) * 36
        if hp_ratio <= 0.35:
            score += 14
    elif pid == "Regen Potion":
        score += (1.0 - hp_ratio) * 32
        if boss_or_elite or floor >= 13:
            score += 8
    elif pid == "Fruit Juice":
        score += 9 + act * 2
    elif pid in {"Block Potion", "SpeedPotion", "Dexterity Potion", "EssenceOfSteel", "HeartOfIron"}:
        score += defense_shortfall * 7
        score += max(0.0, 0.55 - hp_ratio) * 26
        if boss_or_elite:
            score += 7
    elif pid in {"Strength Potion", "SteroidPotion", "CultistPotion"}:
        score += strength_payoffs * 4 + min(14, strength_sources * 4)
        if "Limit Break" in deck_ids:
            score += 18 if pid != "CultistPotion" else 10
        if pid == "CultistPotion" and boss_or_elite:
            score += 12
    elif pid == "Energy Potion":
        score += min(18, high_cost_cards * 3)
        if "Snecko Eye" in relic_ids:
            score += 9
        if deck_ids & {"Offering", "Whirlwind", "Fiend Fire", "Demon Form", "Barricade"}:
            score += 8
    elif pid == "DuplicationPotion":
        best_copy = max(
            (DUPLICATION_CARD_VALUES.get(card_id(card), 0) for card in deck),
            default=0,
        )
        score += min(24, best_copy * 0.55)
        if "Limit Break" in deck_ids and strength_sources:
            score += 12
    elif pid == "LiquidMemories":
        best_return = max((CARD_SCORES.get(card_id(card), 20) for card in deck), default=20)
        score += min(20, max(0, best_return - 55) * 0.35)
        if deck_ids & {"Offering", "Impervious", "Reaper", "Fiend Fire"}:
            score += 8
    elif pid == "BlessingOfTheForge":
        upgrade_value = sum(
            max(0, UPGRADE_PRIORITY.get(card_id(card), CARD_SCORES.get(card_id(card), 20)) - 45)
            for card in deck
            if int(card.get("upgrades", 0) or 0) <= 0
        )
        score += min(22, upgrade_value * 0.08)
    elif pid == "ElixirPotion":
        score += 18 if exhaust_engine else 5
        if status_engine:
            score += 10
    elif pid in {"Fire Potion", "Explosive Potion"}:
        score += 10 if act == 1 else 3
        if pid == "Explosive Potion" and act == 2:
            score += 8
        if not act2_swarm_control_score(gs):
            score += 8
    elif pid == "FearPotion":
        score += min(18, strength_payoffs * 4 + high_cost_cards * 2)
        if upcoming_boss in {
            "champ", "theguardian", "guardian", "hexaghost", "slimeboss",
        }:
            score += 7
    elif pid == "Weak Potion":
        score += defense_shortfall * 5
        if upcoming_boss in {"champ", "hexaghost", "theguardian", "guardian"}:
            score += 9
    elif pid == "LiquidBronze":
        if upcoming_boss in {"hexaghost", "theguardian", "guardian"} or act >= 2:
            score += 8
    elif pid == "GamblersBrew":
        score += min(14, len(deck) * 0.35)
        if status_engine:
            score += 5
    elif pid == "Swift Potion":
        score += min(12, len(deck) * 0.25)
        if "Runic Pyramid" in relic_ids:
            score -= 8
    elif pid == "PowerPotion":
        score += min(18, power_count * 2)
        if power_count <= 1:
            score += 5
    elif pid == "SkillPotion":
        score += min(12, skill_count * 0.45)
        if exhaust_engine:
            score += 6
    elif pid == "AttackPotion":
        score += min(12, attack_count * 0.30)
        if strength_sources:
            score += 5
    elif pid == "ColorlessPotion":
        score += 5 + defense_shortfall * 2
    elif pid == "EntropicBrew":
        empty_slots = sum(
            normalized_potion_id(held) == "Potion Slot"
            for held in gs.get("potions", [])
        )
        score += empty_slots * 10
        if not empty_slots:
            score -= 10
    elif pid == "SmokeBomb":
        score += max(0.0, 0.45 - hp_ratio) * 55
        if act >= 2:
            score += 9
        if boss_or_elite:
            score -= 10
    elif pid == "Ancient Potion":
        if upcoming_boss in {"thecollector", "collector"}:
            score += 8
        if deck_ids & {"Flex", "Berserk"}:
            score += 8
    elif pid == "SneckoOil":
        if high_cost_cards >= 6:
            score += 8
        if "Runic Pyramid" in relic_ids:
            score -= 12

    if sacred_bark:
        score *= 1.22
    held_ids = [
        normalized_potion_id(held)
        for held in gs.get("potions", [])
        if normalized_potion_id(held) != "Potion Slot"
    ]
    duplicate_count = held_ids.count(pid)
    if duplicate_count:
        # A second copy can be excellent, but identical tactical coverage has
        # lower marginal value than filling a missing role.
        score -= duplicate_count * (3 if pid in {"FairyPotion", "Strength Potion", "Energy Potion"} else 7)
    if context == "reward" and "White Beast Statue" in relic_ids:
        score -= 2
    return round(score, 2)


def potion_from_reward(reward):
    """Extract a potion object from the different reward JSON layouts."""
    candidate = reward.get("potion")
    if isinstance(candidate, dict):
        return candidate
    if isinstance(candidate, str):
        return {"id": candidate}
    for key in ("id", "name", "potion_id", "potion_name"):
        value = reward.get(key)
        if value and str(value).upper() != "POTION":
            return {"id": value}
    return {"id": "UnknownPotion"}


def best_potion_replacement(gs, incoming_potion):
    """Return the weakest discardable slot when a new potion is a real upgrade."""
    if _relic_ids(gs) & {"Sozu"}:
        return None
    incoming_score = potion_score(incoming_potion, gs, context="reward")
    held = []
    for index, potion in enumerate(gs.get("potions", [])):
        if normalized_potion_id(potion) == "Potion Slot":
            continue
        if potion.get("can_discard") is False:
            continue
        held.append((potion_score(potion, gs, context="held"), index, potion))
    if not held:
        return None
    held_score, slot, held_potion = min(held, key=lambda item: item[0])
    relic_ids = _relic_ids(gs)
    margin = POTION_REPLACEMENT_MARGIN
    if "White Beast Statue" in relic_ids:
        margin += 2
    if "Potion Belt" in relic_ids:
        margin -= 1
    if normalized_potion_id(incoming_potion) == "FairyPotion":
        margin -= 3
    if incoming_score < held_score + margin:
        return None
    return {
        "slot": slot,
        "incoming_score": incoming_score,
        "held_score": held_score,
        "held_id": normalized_potion_id(held_potion),
        "incoming_id": normalized_potion_id(incoming_potion),
    }


def prepare_hand_select_mode(command, state):
    global HAND_SELECT_MODE, GRID_SELECT_MODE
    match = re.match(r"^PLAY\s+(\d+)(?:\s|$)", command or "", re.IGNORECASE)
    if not match:
        return
    hand = ((state.get("game_state") or {}).get("combat_state") or {}).get("hand", [])
    index = int(match.group(1)) - 1
    if not 0 <= index < len(hand):
        return
    # A new play means any earlier optional/auto-resolved prompt is over.
    HAND_SELECT_MODE = None
    GRID_SELECT_MODE = None
    card = hand[index]
    cid = card_id(card)
    if cid == "Burning Pact" or (cid == "True Grit" and int(card.get("upgrades", 0) or 0) > 0):
        HAND_SELECT_MODE = "exhaust_one"
    elif cid == "Armaments" and int(card.get("upgrades", 0) or 0) == 0:
        HAND_SELECT_MODE = "upgrade_one"
    elif cid == "Dual Wield":
        gs = state.get("game_state") or {}
        combat = gs.get("combat_state") or {}
        try:
            model = build_model(combat, gs)
            target_index = dual_wield_target_index(model, index)
        except (IndexError, TypeError, ValueError):
            target_index = None
        if target_index is not None:
            target_card = model.hand[target_index]
            HAND_SELECT_MODE = {
                "kind": "dual_wield",
                "uuid": target_card.uuid,
                "card_id": target_card.card_id,
                "card_type": target_card.card_type,
                "upgrades": target_card.upgrades,
            }
    elif cid == "Exhume":
        GRID_SELECT_MODE = "exhume"
    elif cid == "Headbutt":
        GRID_SELECT_MODE = "headbutt"
    elif cid == "Secret Weapon":
        GRID_SELECT_MODE = "secret_weapon"


def count_deck(gs, ids):
    ids = set(ids)
    return sum(1 for c in gs.get("deck", []) if card_id(c) in ids)


def exhume_reward_ready(gs):
    """Require a dependable future target before adding permanent Exhume."""
    deck = gs.get("deck", [])
    deck_ids = {card_id(card) for card in deck}
    if deck_ids & {"Corruption", "Fiend Fire", "Second Wind", "Sever Soul"}:
        return True
    for card in deck:
        cid = card_id(card)
        if card.get("type") in {"CURSE", "STATUS"} or cid == "Exhume":
            continue
        if cid == "Limit Break" and int(card.get("upgrades", 0) or 0) > 0:
            continue
        if card.get("exhausts") or cid in EXHUME_DIRECT_TARGET_IDS:
            return True
    return False


def estimate_damage(card, energy, player_block):
    cid = card_id(card)
    up = int(card.get("upgrades", 0) or 0)
    if cid == "Strike_R":
        return 6 + 3 * min(up, 1)
    if cid == "Bash":
        return 8 + 2 * min(up, 1)
    if cid == "Pommel Strike":
        return 9 + up
    if cid == "Anger":
        return 6 + 2 * min(up, 1)
    if cid == "Twin Strike":
        return (5 + 2 * min(up, 1)) * 2
    if cid == "Clothesline":
        return 12 + 2 * min(up, 1)
    if cid == "Headbutt":
        return 9 + 3 * min(up, 1)
    if cid == "Iron Wave":
        return 5 + 2 * min(up, 1)
    if cid == "Cleave":
        return 8 + 3 * min(up, 1)
    if cid == "Thunderclap":
        return 4 + 3 * min(up, 1)
    if cid == "Uppercut":
        return 13
    if cid == "Carnage":
        return 20 + 8 * min(up, 1)
    if cid == "Hemokinesis":
        return 15 + 5 * min(up, 1)
    if cid == "Blood for Blood":
        # Bosses normally make this cheap before the second deck cycle.
        return 18 + 4 * min(up, 1)
    if cid == "Fiend Fire":
        # Four other cards is a conservative normal-hand estimate.
        return (7 + 3 * min(up, 1)) * 4
    if cid == "Wild Strike":
        return 12 + 5 * min(up, 1)
    if cid == "Perfected Strike":
        return 6 + 2 * count_strikes_hint(card)
    if cid == "Whirlwind":
        return (5 + 3 * min(up, 1)) * max(1, energy)
    if cid == "Bludgeon":
        return 32 + 10 * min(up, 1)
    if cid == "Immolate":
        return 21 + 7 * min(up, 1)
    if cid == "Feed":
        return 10 + 2 * min(up, 1)
    if cid == "Reaper":
        return 4 + min(up, 1)
    if cid == "Body Slam":
        return player_block
    if cid == "Heavy Blade":
        return 14 + 6 * min(up, 1)
    if cid == "Rampage":
        return 8
    if cid == "Sword Boomerang":
        return (3 + min(up, 1)) * 3
    if cid == "Sever Soul":
        return 16 + 6 * min(up, 1)
    if card.get("type") == "ATTACK":
        return 7 + 3 * min(up, 1)
    return 0


def count_strikes_hint(_card):
    try:
        state = load_state()
        return count_deck(state.get("game_state", {}), PERFECTED_STRIKE_CARDS)
    except Exception:
        return 5


def estimate_block(card, current_block):
    cid = card_id(card)
    up = int(card.get("upgrades", 0) or 0)
    if cid == "Defend_R":
        return 5 + 3 * min(up, 1)
    if cid == "Shrug It Off":
        return 8 + 3 * min(up, 1)
    if cid == "Flame Barrier":
        return 12 + 4 * min(up, 1)
    if cid == "Power Through":
        return 15 + 5 * min(up, 1)
    if cid == "Impervious":
        return 30 + 10 * min(up, 1)
    if cid == "PanicButton":
        return 30 + 10 * min(up, 1)
    if cid == "Ghostly Armor":
        return 10 + 3 * min(up, 1)
    if cid == "Armaments":
        return 5
    if cid == "True Grit":
        return 7 + 2 * min(up, 1)
    if cid == "Iron Wave":
        return 5 + 2 * min(up, 1)
    if cid == "Entrench":
        return current_block
    if cid == "Second Wind":
        return 12
    if card.get("type") == "SKILL":
        return 5
    return 0


def incoming_damage(combat):
    total = 0
    for monster in combat.get("monsters", []):
        if monster.get("is_gone") or monster.get("half_dead"):
            continue
        intent = monster.get("intent", "")
        if "ATTACK" in intent:
            total += max(0, int(monster.get("move_adjusted_damage", 0) or 0)) * max(1, int(monster.get("move_hits", 1) or 1))
    return total


def choose_target(monsters):
    alive = [(i, m) for i, m in enumerate(monsters) if not m.get("is_gone") and not m.get("half_dead") and m.get("current_hp", 0) > 0]
    if not alive:
        return 0
    attacking = [(i, m) for i, m in alive if "ATTACK" in m.get("intent", "")]
    pool = attacking or alive
    return min(pool, key=lambda x: (x[1].get("current_hp", 999), x[1].get("max_hp", 999)))[0]


def choose_weak_potion_target(monsters, fallback=0, turn=None):
    """Aim Weak at the largest current attack that can receive the debuff."""
    def power_amount_for(monster, power_ids):
        return max(
            (
                int(power.get("amount", 0) or 0)
                for power in monster.get("powers", [])
                if (power.get("id") or power.get("name")) in power_ids
            ),
            default=0,
        )

    alive = [
        (index, monster)
        for index, monster in enumerate(monsters)
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    if turn is not None and int(turn or 0) <= 1:
        leader = next(
            (
                item
                for item in alive
                if (item[1].get("id") or item[1].get("name"))
                == "GremlinLeader"
                and "ATTACK" not in str(item[1].get("intent") or "")
                and power_amount_for(item[1], {"Artifact"}) <= 0
                and power_amount_for(item[1], {"Weak", "Weakened"}) <= 0
            ),
            None,
        )
        living_minions = [
            item for item in alive
            if (item[1].get("id") or item[1].get("name"))
            != "GremlinLeader"
        ]
        if leader is not None and len(living_minions) >= 2:
            # Three Weak survives the Leader's opening buff/summon sequence and
            # still covers its first multi-hit. Spending it on a five-damage
            # minion saved two HP in the logged A19 fight, while the unweakened
            # 11x3 Leader attack cost nine avoidable HP two turns later.
            return leader[0]

    attacking = [
        (index, monster) for index, monster in alive
        if "ATTACK" in str(monster.get("intent") or "")
    ]
    if not attacking:
        return fallback

    without_artifact = [
        item for item in attacking
        if power_amount_for(item[1], {"Artifact"}) <= 0
    ]
    if without_artifact:
        attacking = without_artifact
    not_already_weak = [
        item for item in attacking
        if power_amount_for(item[1], {"Weak", "Weakened"}) <= 0
    ]
    if not_already_weak:
        attacking = not_already_weak
    return max(
        attacking,
        key=lambda item: (
            max(0, int(item[1].get("move_adjusted_damage", 0) or 0))
            * max(1, int(item[1].get("move_hits", 1) or 1)),
            int(item[1].get("max_hp", 0) or 0),
            -item[0],
        ),
    )[0]


def card_cost(card):
    cost = int(card.get("cost", 0) or 0)
    return max(0, cost)


def playable_cards(combat):
    energy = combat.get("player", {}).get("energy", 0)
    cards = []
    for i, card in enumerate(combat.get("hand", []), start=1):
        if card.get("is_playable") and card_cost(card) <= energy:
            cards.append((i, card))
    return cards


def setup_draw_count(card):
    """Return the real draw count for cards used by outer setup heuristics."""
    cid = card_id(card)
    upgrades = min(1, int(card.get("upgrades", 0) or 0))
    if cid == "Battle Trance":
        return 3 + upgrades
    if cid == "Burning Pact":
        return 2 + upgrades
    if cid == "Deep Breath":
        return 1 + upgrades
    if cid == "Master of Strategy":
        return 3 + upgrades
    if cid == "Offering":
        return 3 + 2 * upgrades
    if cid == "Warcry":
        return 1 + upgrades
    return int(DRAW_SETUP_VALUES.get(cid, 0) or 0)


def known_top_draw_cards(combat, count):
    """Return visible draws in game order; CommunicationMod stores top last."""
    pile = combat.get("draw_pile") or []
    count = min(max(0, int(count or 0)), len(pile))
    return list(reversed(pile[-count:])) if count else []


def _gamblers_brew_card_key(card):
    uuid = card.get("uuid")
    if uuid:
        return ("uuid", uuid)
    return (
        "card",
        card_id(card),
        card.get("type") or "",
        int(card.get("upgrades", 0) or 0),
        int(card.get("cost", 0) or 0),
    )


def exact_gamblers_brew_selection(combat, gs, max_hand_size=6):
    """Find the safest exact discard subset against the visible draw order."""
    hand = list(combat.get("hand") or [])
    draw_pile = list(combat.get("draw_pile") or [])
    if not hand or not draw_pile or len(hand) > max_hand_size:
        return None

    best = None
    for keep_mask in range(1 << len(hand)):
        kept = [
            card for index, card in enumerate(hand)
            if keep_mask & (1 << index)
        ]
        discarded = [
            card for index, card in enumerate(hand)
            if not keep_mask & (1 << index)
        ]
        discard_count = len(discarded)
        if discard_count == 0 or discard_count > len(draw_pile):
            continue

        drawn = known_top_draw_cards(combat, discard_count)
        preview = dict(combat)
        preview["hand"] = [dict(card) for card in kept + drawn]
        preview["draw_pile"] = [
            dict(card) for card in draw_pile[:-discard_count]
        ]
        preview["discard_pile"] = [
            dict(card)
            for card in list(combat.get("discard_pile") or []) + discarded
        ]
        preview["cards_discarded_this_turn"] = (
            int(combat.get("cards_discarded_this_turn", 0) or 0)
            + discard_count
        )
        preview_gs = dict(gs)
        preview_gs["combat_state"] = preview
        try:
            plan = plan_turn(preview, preview_gs)
        except Exception:
            continue

        # Once the potion is committed, preserving more HP is more valuable
        # than the planner's ordinary damage-race tiebreakers. A direct kill
        # still outranks every merely surviving line.
        rank = (
            int(bool(plan.score[0])),
            int(bool(plan.score[1])),
            -int(plan.hp_loss),
            plan.score,
            -discard_count,
        )
        if best is None or rank > best[0]:
            best = (
                rank,
                {
                    "kind": "gamblers_brew_exact",
                    "discard_keys": [
                        _gamblers_brew_card_key(card) for card in discarded
                    ],
                    "discard_uuids": [
                        card.get("uuid") for card in discarded
                        if card.get("uuid")
                    ],
                    "discard_ids": [card_id(card) for card in discarded],
                    "keep_ids": [card_id(card) for card in kept],
                    "draw_ids": [card_id(card) for card in drawn],
                    "planned_hp_loss": int(plan.hp_loss),
                    "survives": bool(plan.score[0]),
                    "wins": bool(plan.score[1]),
                },
            )
    return best[1] if best is not None else None


def draw_order_status_support(gs, combat, card):
    player = combat.get("player") or {}
    power_ids = {
        power.get("id") or power.get("name") or ""
        for power in player.get("powers", [])
    }
    relic_ids = {
        relic.get("id") or relic.get("name") or ""
        for relic in gs.get("relics", [])
    }
    if power_ids & {"Evolve", "Fire Breathing"}:
        return True
    if card.get("type") == "STATUS" and "Medical Kit" in relic_ids:
        return True
    if card.get("type") == "CURSE" and "Blue Candle" in relic_ids:
        return True
    return False


def draw_order_card_quality(gs, combat, card, hp, incoming):
    """Estimate whether a known draw advances this turn or its survival plan."""
    cid = card_id(card)
    card_type = card.get("type") or ""
    if card_type in {"STATUS", "CURSE"}:
        if draw_order_status_support(gs, combat, card):
            return 5
        # Slimed at least converts one energy into an exhaust instead of
        # permanently occupying the hand, but it is still a poor forced draw.
        return -3 if cid == "Slimed" and card.get("is_playable") else -12

    energy = int((combat.get("player") or {}).get("energy", 0) or 0)
    block = int((combat.get("player") or {}).get("block", 0) or 0)
    quality = 0
    if card_type == "ATTACK":
        quality += 8 + min(24, estimate_damage(card, max(1, energy), block))
    if cid in DRAW_ORDER_BLOCK_CARDS:
        block_value = estimate_block(card, block)
        quality += min(24, block_value) * (2 if incoming > block or hp < 30 else 1)
    if cid in DRAW_ORDER_CONTROL_CARDS:
        quality += 18 if incoming > block else 10
    if cid in DRAW_ORDER_ENERGY_CARDS:
        quality += 16
    if cid in DRAW_SETUP_VALUES:
        quality += 6
    if card_type == "POWER":
        quality += 12
    if quality <= 0:
        quality = 5
    cost = int(card.get("cost", 0) or 0)
    if cost > energy + 2:
        quality //= 2
    return quality


def known_draw_window(gs, combat, card, hp, incoming):
    """Describe the exact part of a draw and the unknown post-shuffle tail."""
    requested = setup_draw_count(card)
    drawable = len(combat.get("draw_pile") or []) + len(combat.get("discard_pile") or [])
    # Playing the draw card opens one hand slot. Burning Pact opens a second
    # slot by exhausting its selected card before drawing.
    opened_slots = 2 if card_id(card) == "Burning Pact" else 1
    hand_capacity = max(0, 10 - len(combat.get("hand") or []) + opened_slots)
    draws = min(requested, drawable, hand_capacity)
    if draws <= 0:
        return {"cards": [], "unknown": 0, "draws": 0, "quality": 0, "all_clog": False}

    if card_id(card) == "Deep Breath":
        # The shuffle randomizes both piles before the card is drawn.
        known = []
        unknown = draws
    else:
        known = known_top_draw_cards(combat, min(draws, len(combat.get("draw_pile") or [])))
        unknown = draws - len(known)
    qualities = [
        draw_order_card_quality(gs, combat, drawn, hp, incoming)
        for drawn in known
    ]
    all_clog = bool(known) and unknown == 0 and all(value < 0 for value in qualities)
    return {
        "cards": known,
        "unknown": unknown,
        "draws": draws,
        "quality": sum(qualities) + 6 * unknown,
        "all_clog": all_clog,
    }


def deep_breath_shuffle_is_harmful(gs, combat):
    """Protect a useful known draw order from Deep Breath's full shuffle."""
    draw_pile = combat.get("draw_pile") or []
    discard_pile = combat.get("discard_pile") or []
    if not draw_pile or not discard_pile:
        return False

    unsupported_junk = [
        card
        for card in discard_pile
        if card.get("type") in {"STATUS", "CURSE"}
        and not draw_order_status_support(gs, combat, card)
    ]
    if unsupported_junk:
        return True

    player = combat.get("player") or {}
    hp = int(player.get("current_hp", gs.get("current_hp", 1)) or 1)
    incoming = incoming_damage(combat)
    known_top = known_top_draw_cards(combat, min(5, len(draw_pile)))
    qualities = [
        draw_order_card_quality(gs, combat, card, hp, incoming)
        for card in known_top
    ]
    return bool(qualities and max(qualities) >= 24 and sum(qualities) >= 18)


def relic_counter(gs, relic_id, default=-1):
    return modeled_relic_counter(gs, relic_id, default)


def second_wind_sentinel_attack_unlock(combat):
    """Return whether Second Wind can turn a retained Sentinel into attack energy."""
    hand = combat.get("hand") or []
    energy = int((combat.get("player") or {}).get("energy", 0) or 0)
    sentinel_energy = sum(
        2 + min(1, int(card.get("upgrades", 0) or 0))
        for card in hand
        if card_id(card) == "Sentinel"
    )
    if sentinel_energy <= 0:
        return False

    for second_wind in hand:
        if (
            card_id(second_wind) != "Second Wind"
            or not second_wind.get("is_playable", True)
            or card_cost(second_wind) > energy
        ):
            continue
        unlocked_energy = energy - card_cost(second_wind) + sentinel_energy
        if any(
            card.get("type") == "ATTACK"
            and card_cost(card) > energy
            and card_cost(card) <= unlocked_energy
            for card in hand
        ):
            return True
    return False


def continuation_setup_command(gs, combat, cards, hp, target):
    incoming = incoming_damage(combat)
    if incoming > 0:
        return None

    hand = combat.get("hand", [])
    drawable = len(combat.get("draw_pile") or []) + len(combat.get("discard_pile") or [])
    attacks_available = any(card.get("type") == "ATTACK" for _, card in cards)
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    monster_ids = {
        monster.get("id") for monster in combat.get("monsters", [])
        if not monster.get("is_gone") and not monster.get("half_dead")
    }
    choker_count = relic_counter(gs, "Velvet Choker")
    if second_wind_sentinel_attack_unlock(combat):
        # The exact planner follows the deterministic energy chain. The logged
        # Collector line had one energy, Carnage, Second Wind and Sentinel; a
        # forced Shrug spent that energy and displaced 58 boss damage.
        return None
    if drawable > 0 and len(hand) < 10:
        draw_candidates = []
        for index, card in cards:
            cid = card_id(card)
            if cid not in DRAW_SETUP_VALUES:
                continue
            if cid == "Deep Breath" and deep_breath_shuffle_is_harmful(gs, combat):
                continue
            if cid == "Burning Pact" and len(hand) < 2:
                continue
            if cid == "Offering":
                max_hp = max(1, int(gs.get("max_hp", hp) or hp))
                post_offering_floor = max(12, int(max_hp * 0.22))
                if hp - 6 <= post_offering_floor:
                    # This override runs before the exact planner. At a thin
                    # reserve, let the planner prove that Offering is useful
                    # instead of forcing six HP into an otherwise quiet turn.
                    continue
            window = known_draw_window(gs, combat, card, hp, incoming)
            if window["draws"] <= 0:
                continue
            draw_candidates.append((index, card, window))
        free_draw_candidates = [
            item for item in draw_candidates
            if card_cost(item[1]) == 0 and not item[2]["all_clog"]
        ]
        if (
            attacks_available
            and free_draw_candidates
            and "TimeEater" not in monster_ids
            and "GremlinNob" not in monster_ids
            and choker_count < 5
        ):
            # Reveal free draw before spending energy on attacks or disposable
            # statuses. The live bot replans immediately with the real card;
            # this matters especially while pushing Slime Boss below its split.
            index, card, _ = max(
                free_draw_candidates,
                key=lambda item: (
                    item[2]["quality"],
                    item[2]["draws"],
                    card_id(item[1]) != "Warcry",
                ),
            )
            return f"PLAY {index} {target}" if card.get("has_target") else f"PLAY {index}"
        if attacks_available:
            return None
        useful_draw_candidates = [
            item for item in draw_candidates if not item[2]["all_clog"]
        ]
        if useful_draw_candidates:
            index, card, _ = max(
                useful_draw_candidates,
                key=lambda item: (
                    item[2]["quality"],
                    item[2]["draws"],
                    -card_cost(item[1]),
                    card_id(item[1]) != "Warcry",
                ),
            )
            return f"PLAY {index} {target}" if card.get("has_target") else f"PLAY {index}"

    if "Pocketwatch" in relic_ids:
        return None
    if any(monster.get("id") == "TimeEater" for monster in combat.get("monsters", [])):
        return None
    if choker_count >= 5:
        return None

    fillers = [
        (index, card)
        for index, card in cards
        if card_id(card) in SAFE_RELIC_FILLERS and not card.get("has_target")
    ]
    if not fillers:
        return None

    ink_count = relic_counter(gs, "InkBottle")
    letter_count = relic_counter(gs, "LetterOpener")
    trigger_candidates = []
    if 0 <= ink_count < 10:
        needed = 10 - ink_count
        energy = int(combat.get("player", {}).get("energy", 0) or 0)
        if len(fillers) >= needed and sum(sorted(card_cost(card) for _, card in fillers)[:needed]) <= energy:
            trigger_candidates.extend(fillers)
    if 0 <= letter_count < 3:
        skills = [(index, card) for index, card in fillers if card.get("type") == "SKILL"]
        needed = 3 - letter_count
        energy = int(combat.get("player", {}).get("energy", 0) or 0)
        if len(skills) >= needed and sum(sorted(card_cost(card) for _, card in skills)[:needed]) <= energy:
            trigger_candidates.extend(skills)
    if trigger_candidates:
        index, card = min(trigger_candidates, key=lambda item: (card_cost(item[1]), item[0]))
        return f"PLAY {index}"
    return None


def automaton_prebeam_status_setup_command(gs, combat, cards):
    """Deploy a paired status Power before Automaton's Hyper Beam cycle."""
    turn = max(1, int(combat.get("turn", 1) or 1))
    if turn < 5 or (turn - 5) % 6 != 0 or incoming_damage(combat) > 0:
        return None

    automaton = next(
        (
            monster
            for monster in combat.get("monsters", [])
            if not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            and (monster.get("id") or monster.get("name"))
            == "BronzeAutomaton"
        ),
        None,
    )
    if automaton is None:
        return None
    boss_hp = int(automaton.get("current_hp", 0) or 0)
    boss_max_hp = max(1, int(automaton.get("max_hp", boss_hp) or boss_hp))
    if boss_hp <= max(72, boss_max_hp // 4):
        return None

    player = combat.get("player") or {}
    evolve_active = has_power(player, {"Evolve"})
    fire_breathing_active = has_power(player, {"Fire Breathing"})
    if evolve_active == fire_breathing_active:
        return None
    missing_power = "Fire Breathing" if evolve_active else "Evolve"

    visible_status_fuel = sum(
        card.get("type") in {"STATUS", "CURSE"}
        for pile_name in ("hand", "draw_pile", "discard_pile")
        for card in combat.get(pile_name, [])
    )
    durable_status_fuel = status_source_count(gs) + persistent_curse_count(gs)
    if visible_status_fuel < 2 or durable_status_fuel < 2:
        return None

    for index, card in cards:
        if card_id(card) == missing_power and not card.get("has_target"):
            return f"PLAY {index}"
    return None


def transient_dead_branch_cycle_command(gs, combat, cards, hp, incoming, block, plan):
    """Open a late Transient observation window instead of accepting a thin next draw."""
    if max(1, int(combat.get("turn", 1) or 1)) < 4:
        return None
    if not any(
        (monster.get("id") or monster.get("name")) == "Transient"
        and not monster.get("is_gone")
        and int(monster.get("current_hp", 0) or 0) > 0
        for monster in combat.get("monsters", [])
    ):
        return None
    relic_ids = _relic_ids(gs)
    if "Dead Branch" not in relic_ids:
        return None
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    if incoming < max(50, int(max_hp * 0.70)):
        return None
    if block < max(12, int(incoming * 0.25)):
        # Establish the current turn's guaranteed defense before gambling on
        # generated cards or a post-shuffle draw.
        return None
    choker_count = relic_counter(gs, "Velvet Choker")
    if choker_count >= 3:
        return None
    score = getattr(plan, "score", ())
    planned_loss = max(0, int(getattr(plan, "hp_loss", 0) or 0))
    if (
        len(score) < 2
        or not score[0]
        or score[1]
        or planned_loss <= 0
        or hp - planned_loss > max(46, int(max_hp * 0.58))
    ):
        return None
    if not any(
        card.get("type") in {"STATUS", "CURSE"}
        for card in combat.get("hand", [])
    ):
        return None

    candidates = []
    for index, card in cards:
        if card_id(card) != "Burning Pact":
            continue
        window = known_draw_window(gs, combat, card, hp, incoming)
        if window["draws"] < 2 or window["all_clog"] or window["unknown"] <= 0:
            continue
        candidates.append((window["quality"], window["draws"], -card_cost(card), index))
    if not candidates:
        return None
    return f"PLAY {max(candidates)[3]}"


def critical_defensive_draw_command(gs, combat, cards, hp, incoming, block, plan):
    """Reveal a defensive draw before spending the turn's remaining energy."""
    score = getattr(plan, "score", ())
    if (
        len(score) >= 2 and score[0] and score[1]
        or int(getattr(plan, "hp_loss", 0) or 0) <= 0
    ):
        # Raw lethal intent is irrelevant once the exact line kills or fully
        # blocks it. Spending energy on an unknown draw can destroy that line.
        return None
    if incoming <= block or has_power(combat.get("player") or {}, {"No Draw"}):
        return None
    if not combat.get("draw_pile") and not combat.get("discard_pile"):
        return None

    hp_loss = int(getattr(plan, "hp_loss", 0) or 0)
    severe_loss = hp_loss >= max(10, int(hp * 0.35))
    near_lethal = incoming - block >= max(1, hp - int(gs.get("max_hp", hp) or hp) // 10)
    if not severe_loss and not near_lethal:
        return None

    monsters = [
        monster
        for monster in combat.get("monsters", [])
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    monster_ids = {monster.get("id") for monster in monsters}
    if "GremlinNob" in monster_ids or relic_counter(gs, "Velvet Choker") >= 5:
        return None
    for monster in monsters:
        if monster.get("id") != "TimeEater":
            continue
        time_warp = next(
            (
                int(power.get("amount", 0) or 0)
                for power in monster.get("powers", [])
                if (power.get("id") or power.get("name")) == "Time Warp"
            ),
            0,
        )
        if time_warp >= 11:
            return None

    first_command = plan.commands[0] if getattr(plan, "commands", ()) else None
    planned_card = None
    if first_command and first_command.startswith("PLAY "):
        try:
            planned_index = int(first_command.split()[1]) - 1
            planned_card = (combat.get("hand") or [])[planned_index]
        except (ValueError, IndexError):
            planned_card = None
    hand_by_id = {
        card_id(card): card
        for card in combat.get("hand", [])
        if card.get("is_playable")
    }
    corruption = hand_by_id.get("Corruption")
    payoff_in_hand = next(
        (
            hand_by_id.get(payoff_id)
            for payoff_id in ("Feel No Pain", "Dark Embrace")
            if hand_by_id.get(payoff_id) is not None
        ),
        None,
    )
    active_payoff = has_power(
        combat.get("player") or {}, {"Feel No Pain", "Dark Embrace"}
    )
    engine_affordable = bool(
        corruption
        and (
            active_payoff
            or payoff_in_hand
            and card_cost(corruption) + card_cost(payoff_in_hand)
            <= int((combat.get("player") or {}).get("energy", 0) or 0)
        )
    )
    if (
        engine_affordable
        and planned_card
        and card_id(planned_card) in {"Corruption", "Feel No Pain", "Dark Embrace"}
    ):
        # Drawing first can spend the one energy needed to put the payoff down,
        # permanently stranding a complete Corruption engine. Let the exact
        # planner establish it; its free skills then supply the defensive draw.
        return None
    if planned_card and card_id(planned_card) == "Battle Trance":
        # The exact planner can see all three known draws and their follow-up
        # costs. In the logged Collector turn, replacing its zero-cost Battle
        # Trance with Shrug spent the energy needed by the resulting defense
        # and increased damage taken from 37 to 39.
        return None

    candidates = []
    for index, card in cards:
        if card_id(card) not in {"Shrug It Off", "Finesse"}:
            continue
        window = known_draw_window(gs, combat, card, hp, incoming)
        if (
            window["draws"] <= 0
            or window["all_clog"]
            or window["unknown"] <= 0
        ):
            # The turn planner has already simulated every fully known draw.
            # Overriding it with the same information can spend the energy
            # needed by a better attack/block line, as it did against Transient.
            continue
        candidates.append((index, card, window))
    if not candidates:
        return None

    if (
        "Transient" in monster_ids
        and int(combat.get("turn", 1) or 1) <= 2
        and hp_loss <= max(2, int((gs.get("max_hp", hp) or hp) * 0.04))
    ):
        # The logged A15 run spent Shrug to pull Impervious into Transient's
        # 40-damage opener merely to save one HP. Leaving that card on top puts
        # it in the next natural hand, where the attack is ten higher and the
        # one-shot block is materially more valuable.
        candidates = [
            item
            for item in candidates
            if not any(
                card_id(drawn) == "Impervious"
                for drawn in item[2]["cards"]
            )
        ]
        if not candidates:
            return None

    index, card, window = max(
        candidates,
        key=lambda item: (
            estimate_block(item[1], block),
            item[2]["quality"],
            -card_cost(item[1]),
        ),
    )
    command = f"PLAY {index}"
    if command == first_command:
        return None
    top_ids = [card_id(drawn) for drawn in window["cards"]]
    log(
        f"priority defensive draw: {command} planned={first_command} "
        f"hp_loss={hp_loss} incoming={incoming} block={block} hp={hp} "
        f"known_top={top_ids} unknown={window['unknown']}"
    )
    return command


def priority_offering_command(gs, combat, cards, hp, incoming, block):
    """Use Offering to break a retained, status-clogged hand while still safe."""
    offering = next(
        (
            (index, card)
            for index, card in cards
            if card_id(card) == "Offering" and card_cost(card) == 0
        ),
        None,
    )
    drawable = len(combat.get("draw_pile") or []) + len(combat.get("discard_pile") or [])
    if offering is None or drawable <= 0 or hp <= 12:
        return None

    draw_window = known_draw_window(gs, combat, offering[1], hp, incoming)
    if draw_window["draws"] <= 0 or draw_window["all_clog"]:
        return None

    monsters = [
        monster
        for monster in combat.get("monsters", [])
        if not monster.get("is_gone") and int(monster.get("current_hp", 0) or 0) > 0
    ]
    for monster in monsters:
        if monster.get("id") != "TimeEater":
            continue
        time_warp = next(
            (
                int(power.get("amount", 0) or 0)
                for power in monster.get("powers", [])
                if (power.get("id") or power.get("name")) == "Time Warp"
            ),
            0,
        )
        if time_warp >= 10:
            return None

    hand = combat.get("hand", [])
    junk = sum(card.get("type") in {"STATUS", "CURSE"} for card in hand)
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    retained_clog = "Runic Pyramid" in relic_ids and len(hand) >= 8 and junk >= 2
    playable_attacks = any(card.get("type") == "ATTACK" for _, card in cards)
    energy = int((combat.get("player") or {}).get("energy", 0) or 0)
    open_hand_draw = len(hand) <= 7 and (energy <= 2 or not playable_attacks)
    if not retained_clog and not open_hand_draw:
        return None

    self_damage = 6
    if hp - self_damage <= max(0, incoming - block):
        return None
    return f"PLAY {offering[0]}"


def has_power(player, power_ids):
    return any(power.get("id") in power_ids for power in player.get("powers", []))


def has_exhaust_synergy(gs):
    return any(card_id(c) in EXHAUST_SYNERGY_CARDS for c in gs.get("deck", []))


def remember_duplication_target(gs, combat, card, target=None):
    global PENDING_DUPLICATION_TARGET
    PENDING_DUPLICATION_TARGET = {
        "act": int(gs.get("act", 0) or 0),
        "floor": int(gs.get("floor", 0) or 0),
        "turn": int(combat.get("turn", 0) or 0),
        "uuid": str(card.get("uuid") or ""),
        "card_id": card_id(card),
        "target": target,
        "potion_count": sum(
            potion.get("id") == "DuplicationPotion"
            and potion.get("can_use", True)
            for potion in gs.get("potions", [])
        ),
    }


def pending_duplication_command(state, gs, combat):
    """Play the selected card after its selected duplication potion disappears."""
    global PENDING_DUPLICATION_TARGET
    pending = PENDING_DUPLICATION_TARGET
    if not pending:
        return None
    signature = (
        int(gs.get("act", 0) or 0),
        int(gs.get("floor", 0) or 0),
        int(combat.get("turn", 0) or 0),
    )
    if signature != (pending["act"], pending["floor"], pending["turn"]):
        PENDING_DUPLICATION_TARGET = None
        return None
    current_potion_count = sum(
        potion.get("id") == "DuplicationPotion"
        and potion.get("can_use", True)
        for potion in gs.get("potions", [])
    )
    if current_potion_count >= int(pending.get("potion_count", 1) or 1):
        return None
    if not command_available(state, "play"):
        return None

    hand = combat.get("hand", [])
    card_index = next(
        (
            index
            for index, card in enumerate(hand)
            if pending["uuid"] and str(card.get("uuid") or "") == pending["uuid"]
        ),
        None,
    )
    if card_index is None:
        matching = [index for index, card in enumerate(hand) if card_id(card) == pending["card_id"]]
        card_index = matching[0] if len(matching) == 1 else None
    if card_index is None:
        PENDING_DUPLICATION_TARGET = None
        return None

    card = hand[card_index]
    energy = int((combat.get("player") or {}).get("energy", 0) or 0)
    if not card.get("is_playable") or card_cost(card) > energy:
        PENDING_DUPLICATION_TARGET = None
        return None
    target = pending.get("target")
    if card.get("has_target"):
        monsters = combat.get("monsters", [])
        if (
            target is None
            or target >= len(monsters)
            or monsters[target].get("is_gone")
            or int(monsters[target].get("current_hp", 0) or 0) <= 0
        ):
            target = choose_target(monsters)
    PENDING_DUPLICATION_TARGET = None
    command = f"PLAY {card_index + 1}"
    if card.get("has_target"):
        command += f" {target}"
    return command


def duplication_card_commit_worthy(card, target, combat, hp, critical_reserve):
    """Reject static high scores that waste Duplication Potion this turn."""
    cid = card_id(card)
    player = combat.get("player") or {}
    strength = next(
        (
            int(power.get("amount", 0) or 0)
            for power in player.get("powers", [])
            if (power.get("id") or power.get("name")) == "Strength"
        ),
        0,
    )
    monsters = combat.get("monsters", [])
    target_monster = (
        monsters[target]
        if isinstance(target, int) and 0 <= target < len(monsters)
        else None
    )
    target_id = (
        target_monster.get("id") or target_monster.get("name") or ""
        if target_monster
        else ""
    )
    max_hp = max(1, int(player.get("max_hp", hp) or hp))
    low_reserve_durable_target = bool(
        target_id
        in (DUPLICATION_DURABLE_BOSS_IDS | DUPLICATION_PRESSURE_ELITE_IDS)
        and hp / max_hp <= 0.85
    )
    if cid == "Feed":
        if target_monster is None:
            return False
        damage = estimate_damage(
            card,
            int(player.get("energy", 0) or 0),
            int(player.get("block", 0) or 0),
        ) + strength
        if has_power(player, {"Weak", "Weakened"}):
            damage = int(damage * 0.75)
        if has_power(target_monster, {"Vulnerable"}):
            damage = int(damage * 1.5)
        target_life = max(
            1,
            int(target_monster.get("current_hp", 0) or 0)
            + max(0, int(target_monster.get("block", 0) or 0)),
        )
        # Feed's premium is the max-HP trigger. Spend Duplication only when
        # the first copy leaves the target alive and the second secures it.
        return damage < target_life <= damage * 2
    if (
        cid == "Heavy Blade"
        and strength <= 0
        and not critical_reserve
        and not low_reserve_durable_target
    ):
        return False
    if cid != "Fiend Fire" or critical_reserve:
        return True

    healthy_boss = next(
        (
            monster
            for monster in monsters
            if (monster.get("id") or monster.get("name"))
            in DUPLICATION_DURABLE_BOSS_IDS
            and not monster.get("is_gone")
            and int(monster.get("current_hp", 0) or 0)
            > max(72, int(monster.get("max_hp", 1) or 1) * 0.35)
        ),
        None,
    )
    target_is_boss = bool(
        target_monster
        and (target_monster.get("id") or target_monster.get("name"))
        in DUPLICATION_DURABLE_BOSS_IDS
    )
    core_cards_at_risk = sum(
        card_id(held)
        in {
            "Bash", "Corruption", "Demon Form", "Disarm", "Heavy Blade",
            "Impervious", "Limit Break", "Offering", "Power Through",
            "Reaper", "Shockwave", "Spot Weakness",
        }
        for held in combat.get("hand", [])
        if str(held.get("uuid") or "") != str(card.get("uuid") or "")
    )
    return not healthy_boss or target_is_boss or core_cards_at_risk == 0


def duplicated_fiend_fire_target(card, target, combat, hp, block):
    """Redirect severe Bronze Orb overkill into a healthy Automaton."""
    if card_id(card) != "Fiend Fire" or not isinstance(target, int):
        return target

    monsters = combat.get("monsters", [])
    if not 0 <= target < len(monsters):
        return target
    orb = monsters[target]
    if (orb.get("id") or orb.get("name")) != "BronzeOrb":
        return target

    automaton_index = next(
        (
            index
            for index, monster in enumerate(monsters)
            if (monster.get("id") or monster.get("name")) == "BronzeAutomaton"
            and not monster.get("is_gone")
            and int(monster.get("current_hp", 0) or 0)
            > max(72, int(monster.get("max_hp", 1) or 1) * 0.35)
        ),
        None,
    )
    if automaton_index is None:
        return target

    player = combat.get("player") or {}
    player_powers = player.get("powers", [])

    def player_power_amount(power_id):
        return next(
            (
                int(power.get("amount", 0) or 0)
                for power in player_powers
                if (power.get("id") or power.get("name")) == power_id
            ),
            0,
        )

    hand = combat.get("hand", [])
    fuel = max(0, len(hand) - 1)
    strength = player_power_amount("Strength")
    per_hit = max(
        0,
        7 + 3 * min(1, int(card.get("upgrades", 0) or 0)) + strength,
    )
    if player_power_amount("Weakened") > 0:
        per_hit = int(per_hit * 0.75)
    orb_life = max(1, int(orb.get("current_hp", 0) or 0)) + max(
        0, int(orb.get("block", 0) or 0)
    )
    if fuel <= 0 or per_hit * fuel < orb_life * 2:
        return target

    # Feel No Pain makes leaving the Orb alive safe in the logged position.
    # Keep the redirect conservative when the combined attack would still kill.
    feel_no_pain = max(0, player_power_amount("Feel No Pain"))
    current_block = max(
        max(0, int(block or 0)),
        max(0, int(player.get("block", 0) or 0)),
    )
    projected_block = current_block + feel_no_pain * len(hand)
    incoming = sum(
        max(0, int(monster.get("move_adjusted_damage", 0) or 0))
        * max(1, int(monster.get("move_hits", 1) or 1))
        for monster in monsters
        if not monster.get("is_gone")
        and int(monster.get("current_hp", 0) or 0) > 0
        and "ATTACK" in str(monster.get("intent") or "")
    )
    if hp <= max(0, incoming - projected_block):
        return target
    return automaton_index


def emergency_duplication_block_candidate(combat, hp, incoming, block):
    """Find duplicated fixed Block that prevents death or a critical reserve."""
    player = combat.get("player") or {}
    powers = {
        power.get("id") or power.get("name"): int(power.get("amount", 0) or 0)
        for power in player.get("powers", [])
    }
    if powers.get("NoBlockPower", 0) > 0:
        return None

    energy = max(0, int(player.get("energy", 0) or 0))
    dexterity = int(powers.get("Dexterity", 0) or 0)
    frail = powers.get("Frail", 0) > 0
    options = []
    for hand_index, card in enumerate(combat.get("hand", [])):
        cid = card_id(card)
        if (
            cid not in FIXED_DUPLICATION_BLOCK_IDS
            or not card.get("is_playable")
            or card_cost(card) > energy
        ):
            continue
        base, upgrade = BLOCK_VALUE[cid]
        gained = adjusted_block(
            base + upgrade * min(1, int(card.get("upgrades", 0) or 0)),
            dexterity,
            frail,
        )
        if gained > 0:
            options.append((hand_index, card, card_cost(card), gained))
    if not options:
        return None

    normal_best = 0
    subset_values = []
    for mask in range(1 << len(options)):
        spent = 0
        gained = 0
        for option_index, (_, _, cost, block_gain) in enumerate(options):
            if mask & (1 << option_index):
                spent += cost
                gained += block_gain
        if spent <= energy:
            normal_best = max(normal_best, gained)
            subset_values.append((mask, gained))
    max_hp = max(1, int(player.get("max_hp", hp) or hp))
    pressure = max(0, incoming - block)
    normal_remaining = hp - max(0, pressure - normal_best)
    emergency = normal_remaining <= 0
    critical_reserve = bool(
        hp <= int(max_hp * 0.55)
        and pressure >= max(24, int(max_hp * 0.30))
        and normal_remaining <= max(16, int(max_hp * 0.20))
    )
    if not emergency and not critical_reserve:
        return None

    best = None
    for candidate_index, (hand_index, card, cost, block_gain) in enumerate(options):
        duplicated_best = max(
            (
                gained + block_gain
                for mask, gained in subset_values
                if mask & (1 << candidate_index)
            ),
            default=0,
        )
        remaining_hp = hp - max(0, incoming - block - duplicated_best)
        if remaining_hp <= 0:
            continue
        hp_saved = remaining_hp - normal_remaining
        if (
            not emergency
            and hp_saved < max(5, int(max_hp * 0.06))
        ):
            continue
        rank = (remaining_hp, duplicated_best, -cost, -hand_index)
        if best is None or rank > best[0]:
            target = (
                choose_target(combat.get("monsters", []))
                if card.get("has_target")
                else None
            )
            best = (rank, card, target, normal_best, duplicated_best)
    return best


def slime_boss_duplication_split_candidate(combat, gs, hp, incoming, block):
    """Find a duplicated attack that converts Slime Boss's Slam into a deep split."""
    slime_boss = next(
        (
            monster
            for monster in combat.get("monsters", [])
            if not monster.get("is_gone")
            and not monster.get("half_dead")
            and (monster.get("id") or monster.get("name")) == "SlimeBoss"
            and int(monster.get("current_hp", 0) or 0) > 0
        ),
        None,
    )
    if slime_boss is None or "ATTACK" not in str(slime_boss.get("intent") or ""):
        return None

    boss_hp = int(slime_boss.get("current_hp", 0) or 0)
    boss_max_hp = max(1, int(slime_boss.get("max_hp", boss_hp) or boss_hp))
    split_threshold = boss_max_hp // 2
    unblocked = max(0, incoming - block)
    if boss_hp <= split_threshold or unblocked < max(18, int(gs.get("max_hp", hp) or hp) // 4):
        return None

    try:
        base_plan = plan_turn(combat, gs)
        preview = dict(combat)
        preview_player = dict(combat.get("player") or {})
        preview_powers = [dict(power) for power in preview_player.get("powers", [])]
        if any(
            (power.get("id") or power.get("name")) == "Double Tap"
            and int(power.get("amount", 0) or 0) > 0
            for power in preview_powers
        ):
            return None
        preview_powers.append({"id": "Double Tap", "amount": 1})
        preview_player["powers"] = preview_powers
        preview["player"] = preview_player
        duplicated_plan = plan_turn(preview, gs)
        if not duplicated_plan.commands:
            return None

        first = re.fullmatch(
            r"PLAY\s+(\d+)(?:\s+(\d+))?", duplicated_plan.commands[0]
        )
        if first is None:
            return None
        hand_index = int(first.group(1)) - 1
        hand = combat.get("hand", [])
        if hand_index < 0 or hand_index >= len(hand):
            return None
        card = hand[hand_index]
        if card.get("type") != "ATTACK" or not card.get("is_playable"):
            return None

        model = build_model(preview, gs)
        for command in duplicated_plan.commands:
            parts = command.split()
            if not parts or parts[0] == "END":
                break
            if parts[0] != "PLAY" or len(parts) < 2:
                return None
            current_hand_index = int(parts[1]) - 1
            target_index = None
            if len(parts) >= 3:
                original_target = int(parts[2])
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            model = simulate_card(model, current_hand_index, target_index)
        after = next(
            (
                monster
                for monster in model.monsters
                if monster.monster_id == "SlimeBoss"
            ),
            None,
        )
    except (IndexError, StopIteration, TypeError, ValueError):
        return None

    deep_split_limit = min(split_threshold, int(boss_max_hp * 0.48))
    hp_saved = base_plan.hp_loss - duplicated_plan.hp_loss
    if (
        after is None
        or after.hp > deep_split_limit
        or "ATTACK" in after.intent
        or hp_saved < max(10, int(gs.get("max_hp", hp) or hp) // 8)
    ):
        return None
    target = int(first.group(2)) if first.group(2) is not None else None
    return card, target, base_plan.hp_loss, duplicated_plan.hp_loss, after.hp


def sentry_duplication_pressure_candidate(combat, gs, incoming, block):
    """Use Double Tap preview when it converts an early Sentry attack turn."""
    if (
        gs.get("room_type") != "MonsterRoomElite"
        or int(combat.get("turn", 0) or 0) > 3
    ):
        return None

    living_sentries = [
        (index, monster)
        for index, monster in enumerate(combat.get("monsters", []))
        if (monster.get("id") or monster.get("name")) == "Sentry"
        and not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    attacking_indexes = {
        index
        for index, monster in living_sentries
        if "ATTACK" in str(monster.get("intent") or "")
    }
    if len(living_sentries) < 3 or not attacking_indexes:
        return None

    player = combat.get("player") or {}
    pressure = max(0, incoming - block)
    hp = max(1, int(player.get("current_hp", gs.get("current_hp", 1)) or 1))
    max_hp = max(1, int(gs.get("max_hp", player.get("max_hp", hp)) or hp))
    if len(attacking_indexes) >= 2:
        if pressure < 18:
            return None
    elif pressure < 8 or hp / max_hp > 0.60:
        # The alternating pattern still gives a valuable one-attacker window:
        # if duplication converts all of that damage into a kill, spending the
        # potion now also prevents that Sentry's later attacks and Dazed cards.
        # Keep this extension for a genuinely thinned reserve so a healthy run
        # does not cash the potion for routine ten-point chip.
        return None
    if has_power(player, {"Double Tap"}):
        return None
    preview = dict(combat)
    preview_player = dict(player)
    preview_player["powers"] = [
        dict(power) for power in player.get("powers", [])
    ] + [{"id": "Double Tap", "amount": 1}]
    preview["player"] = preview_player

    def simulate_plan(source, plan):
        model = build_model(source, gs)
        for command in plan.commands:
            match = re.fullmatch(r"PLAY\s+(\d+)(?:\s+(\d+))?", command)
            if match is None:
                break
            hand_index = int(match.group(1)) - 1
            target_index = None
            if match.group(2) is not None:
                original_target = int(match.group(2))
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            model = simulate_card(model, hand_index, target_index)
        return model

    try:
        base_plan = plan_turn(combat, gs)
        duplicated_plan = plan_turn(preview, gs)
        first = re.fullmatch(
            r"PLAY\s+(\d+)(?:\s+(\d+))?", duplicated_plan.commands[0]
        )
        if first is None:
            return None
        hand_index = int(first.group(1)) - 1
        hand = combat.get("hand", [])
        if hand_index < 0 or hand_index >= len(hand):
            return None
        card = hand[hand_index]
        if card.get("type") != "ATTACK" or not card.get("is_playable"):
            return None
        result = simulate_plan(preview, duplicated_plan)
    except (IndexError, StopIteration, TypeError, ValueError):
        return None

    killed_attackers = sum(
        original_index in attacking_indexes and not monster.alive
        for original_index, monster in (
            (monster.original_index, monster) for monster in result.monsters
        )
    )
    hp_saved = base_plan.hp_loss - duplicated_plan.hp_loss
    if killed_attackers < 1 or hp_saved < 8:
        return None
    target = int(first.group(2)) if first.group(2) is not None else None
    return card, target, base_plan.hp_loss, duplicated_plan.hp_loss, killed_attackers


def critical_duplication_attack_conversion_candidate(
    combat, gs, hp, incoming, block
):
    """Use an exact Double Tap preview when duplication avoids a critical hit."""
    player = combat.get("player") or {}
    max_hp = max(1, int(player.get("max_hp", gs.get("max_hp", hp)) or hp))
    pressure = max(0, incoming - block)
    if (
        hp / max_hp > 0.45
        or pressure < max(12, int(max_hp * 0.15))
        or has_power(player, {"Double Tap"})
    ):
        return None

    preview = dict(combat)
    preview_player = dict(player)
    preview_player["powers"] = [
        dict(power) for power in player.get("powers", [])
    ] + [{"id": "Double Tap", "amount": 1}]
    preview["player"] = preview_player
    try:
        base_plan = plan_turn(combat, gs)
        duplicated_plan = plan_turn(preview, gs)
    except Exception:
        return None
    if not base_plan.commands or not duplicated_plan.commands:
        return None
    if len(base_plan.score) > 1 and base_plan.score[1]:
        return None

    first = re.fullmatch(
        r"PLAY\s+(\d+)(?:\s+(\d+))?", duplicated_plan.commands[0]
    )
    if first is None:
        return None
    hand_index = int(first.group(1)) - 1
    hand = combat.get("hand", [])
    if hand_index < 0 or hand_index >= len(hand):
        return None
    card = hand[hand_index]
    if card.get("type") != "ATTACK" or not card.get("is_playable"):
        return None

    base_remaining = hp - base_plan.hp_loss
    duplicated_remaining = hp - duplicated_plan.hp_loss
    critical_floor = max(10, int(max_hp * 0.15))
    hp_saved = duplicated_plan.hp_loss < base_plan.hp_loss and (
        base_plan.hp_loss - duplicated_plan.hp_loss
    )
    if (
        base_remaining > critical_floor
        or duplicated_remaining <= 0
        or hp_saved < max(8, int(max_hp * 0.08))
    ):
        return None

    target = int(first.group(2)) if first.group(2) is not None else None
    duplicated_victory = bool(
        len(duplicated_plan.score) > 1 and duplicated_plan.score[1]
    )
    return (
        card,
        target,
        base_plan.hp_loss,
        duplicated_plan.hp_loss,
        duplicated_victory,
    )


def planned_duplication_potion_command(state, gs, combat, hp, incoming, block):
    """Reserve Duplication Potion for a high-value card in the chosen plan."""
    if not command_available(state, "potion"):
        return None
    potion_index = next(
        (
            index
            for index, potion in enumerate(gs.get("potions", []))
            if potion.get("id") == "DuplicationPotion" and potion.get("can_use", True)
        ),
        None,
    )
    if potion_index is None:
        return None

    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    critical_reserve = hp - max(0, incoming - block) <= max(8, int(max_hp * 0.12))
    defensive_block = emergency_duplication_block_candidate(
        combat, hp, incoming, block
    )
    if defensive_block is not None:
        _, card, target, normal_block, duplicated_block = defensive_block
        remember_duplication_target(gs, combat, card, target)
        normal_remaining = hp - max(
            0, incoming - block - normal_block
        )
        reason = "emergency" if normal_remaining <= 0 else "critical-reserve"
        log(
            f"potion duplicate {reason} block "
            f"card={card_id(card)} normal_block={normal_block} "
            f"duplicated_block={duplicated_block} incoming={incoming - block} "
            f"hp={hp}"
        )
        return f"POTION use {potion_index}"
    living_monsters = [
        monster
        for monster in combat.get("monsters", [])
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    living_ids = {
        monster.get("id") or monster.get("name") or ""
        for monster in living_monsters
    }
    sentry_pressure = sentry_duplication_pressure_candidate(
        combat, gs, incoming, block
    )
    if sentry_pressure is not None:
        card, target_index, base_loss, duplicated_loss, killed_attackers = sentry_pressure
        remember_duplication_target(gs, combat, card, target_index)
        log(
            "potion duplicate Sentry attacker conversion "
            f"card={card_id(card)} target={target_index} "
            f"killed_attackers={killed_attackers} "
            f"hp_loss={base_loss}->{duplicated_loss}"
        )
        return f"POTION use {potion_index}"
    critical_attack_conversion = critical_duplication_attack_conversion_candidate(
        combat, gs, hp, incoming, block
    )
    if critical_attack_conversion is not None:
        card, target_index, base_loss, duplicated_loss, victory = (
            critical_attack_conversion
        )
        remember_duplication_target(gs, combat, card, target_index)
        log(
            "potion duplicate critical attack conversion "
            f"card={card_id(card)} target={target_index} "
            f"hp_loss={base_loss}->{duplicated_loss} victory={victory}"
        )
        return f"POTION use {potion_index}"
    low_reserve_pressure_elite = bool(
        gs.get("room_type") == "MonsterRoomElite"
        and hp / max_hp <= 0.72
        and living_ids & DUPLICATION_PRESSURE_ELITE_IDS
    )
    byrd_swarm_pressure = bool(
        int(gs.get("act", 1) or 1) >= 2
        and gs.get("room_type") == "MonsterRoom"
        and int(combat.get("turn", 0) or 0) <= 2
        and sum(
            (monster.get("id") or monster.get("name")) == "Byrd"
            for monster in living_monsters
        ) >= 3
        and incoming - block >= max(30, int(max_hp * 0.35))
    )
    if (
        gs.get("room_type") != "MonsterRoomBoss"
        and not critical_reserve
        and not low_reserve_pressure_elite
        and not byrd_swarm_pressure
    ):
        return None

    if critical_reserve:
        attacking_byrds = [
            monster
            for monster in living_monsters
            if (monster.get("id") or monster.get("name")) == "Byrd"
            and "ATTACK" in str(monster.get("intent") or "")
        ]
        energy = max(0, int((combat.get("player") or {}).get("energy", 0) or 0))
        whirlwind = next(
            (
                card
                for card in combat.get("hand", [])
                if card_id(card) == "Whirlwind"
                and card.get("is_playable")
            ),
            None,
        )
        if len(attacking_byrds) >= 2 and energy >= 2 and whirlwind is not None:
            player = combat.get("player") or {}
            strength = next(
                (
                    int(power.get("amount", 0) or 0)
                    for power in player.get("powers", [])
                    if (power.get("id") or power.get("name")) == "Strength"
                ),
                0,
            )
            weak = has_power(player, {"Weak", "Weakened"})
            hits = energy + (
                2
                if any(
                    (relic.get("id") or relic.get("name")) == "Chemical X"
                    for relic in gs.get("relics", [])
                )
                else 0
            )
            base_hit = max(
                0,
                5
                + 3 * min(1, int(whirlwind.get("upgrades", 0) or 0))
                + strength,
            )
            if weak:
                base_hit = int(base_hit * 0.75)

            def conservative_duplicated_whirlwind_damage(monster):
                hit = base_hit
                if has_power(monster, {"Vulnerable"}):
                    hit = int(hit * 1.5)
                if has_power(monster, {"Flight"}):
                    hit = int(hit * 0.5)
                return hit * hits * 2

            clears_attacking_byrds = all(
                conservative_duplicated_whirlwind_damage(monster)
                >= int(monster.get("current_hp", 0) or 0)
                + max(0, int(monster.get("block", 0) or 0))
                for monster in attacking_byrds
            )
            if clears_attacking_byrds:
                remember_duplication_target(gs, combat, whirlwind)
                log(
                    "potion duplicate full-energy Whirlwind to clear critical Byrds "
                    f"energy={energy} attackers={len(attacking_byrds)} "
                    f"incoming={incoming - block} hp={hp}"
                )
                return f"POTION use {potion_index}"

    # A duplicated Disarm is immediate block against every hit and remains a
    # permanent defensive upgrade afterwards. The generic plan scan cannot
    # reach it when a non-reorderable attack such as Bash precedes it, which
    # left the A17 Hexaghost potion unused before the opening six-hit attack.
    if gs.get("room_type") in {"MonsterRoomBoss", "MonsterRoomElite"} or critical_reserve:
        energy = int((combat.get("player") or {}).get("energy", 0) or 0)
        disarm_candidates = []
        for card in combat.get("hand", []):
            if (
                card_id(card) != "Disarm"
                or not card.get("is_playable")
                or card_cost(card) > energy
            ):
                continue
            reduction = 2 + min(1, int(card.get("upgrades", 0) or 0))
            for target_index, monster in enumerate(combat.get("monsters", [])):
                if (
                    monster.get("is_gone")
                    or monster.get("half_dead")
                    or int(monster.get("current_hp", 0) or 0) <= 0
                    or "ATTACK" not in str(monster.get("intent") or "")
                ):
                    continue
                hits = max(1, int(monster.get("move_hits", 1) or 1))
                damage = max(0, int(monster.get("move_adjusted_damage", 0) or 0))
                artifact = next(
                    (
                        max(0, int(power.get("amount", 0) or 0))
                        for power in monster.get("powers", [])
                        if (power.get("id") or power.get("name")) == "Artifact"
                    ),
                    0,
                )
                if artifact >= 2:
                    continue
                prevented_now = min(damage, reduction) * hits
                if prevented_now < 8:
                    continue
                durable = int(monster.get("current_hp", 0) or 0) > max(
                    40, int(monster.get("max_hp", 1) or 1) // 4
                )
                disarm_candidates.append(
                    (prevented_now + (reduction * hits if durable else 0), card, target_index, prevented_now)
                )
        if disarm_candidates:
            _, card, target_index, prevented_now = max(
                disarm_candidates, key=lambda item: item[0]
            )
            remember_duplication_target(gs, combat, card, target_index)
            log(
                "potion duplicate Disarm before multi-hit "
                f"target={target_index} prevented_now={prevented_now}"
            )
            return f"POTION use {potion_index}"

    slime_split = slime_boss_duplication_split_candidate(
        combat, gs, hp, incoming, block
    )
    if slime_split is not None:
        card, target_index, base_loss, duplicated_loss, split_hp = slime_split
        remember_duplication_target(gs, combat, card, target_index)
        log(
            "potion duplicate Slime Boss deep split "
            f"card={card_id(card)} split_hp={split_hp} "
            f"hp_loss={base_loss}->{duplicated_loss}"
        )
        return f"POTION use {potion_index}"

    try:
        planner_combat = combat
        if (
            incoming - block < hp
            and deep_breath_shuffle_is_harmful(gs, combat)
            and any(
                card_id(card) == "Deep Breath" and card.get("is_playable")
                for card in combat.get("hand") or []
            )
        ):
            planner_combat = dict(combat)
            planner_hand = [dict(card) for card in combat.get("hand") or []]
            for card in planner_hand:
                if card_id(card) == "Deep Breath":
                    card["is_playable"] = False
            planner_combat["hand"] = planner_hand
            log("draw-order guard: preserve known pile and keep discard pollution out")
        plan = plan_turn(planner_combat, gs)
    except Exception:
        return None

    if not plan.commands:
        return None

    remaining_hand = list(combat.get("hand", []))
    best = None
    for command in plan.commands:
        match = re.fullmatch(r"PLAY\s+(\d+)(?:\s+(\d+))?", command)
        if not match:
            break
        index = int(match.group(1)) - 1
        if index < 0 or index >= len(remaining_hand):
            break
        card = remaining_hand[index]
        cid = card_id(card)
        value = DUPLICATION_CARD_VALUES.get(cid, 0)
        if cid == "Juggernaut" and (
            not juggernaut_support_ready(gs)
            or int(combat.get("turn", 0) or 0) > 4
            or not living_ids & DUPLICATION_DURABLE_BOSS_IDS
        ):
            # Doubling Juggernaut is a boss engine only while enough repeated
            # Block triggers remain and there is time for both stacks to pay.
            value = 0
        if value >= 20 and (best is None or value > best[0]):
            target = int(match.group(2)) if match.group(2) is not None else None
            best = (value, card, target)
        if value >= 20:
            break
        if cid not in DUPLICATION_REORDER_SAFE_CARDS:
            break
        remaining_hand.pop(index)

    if best is None:
        return None
    _, card, target = best
    redirected_target = duplicated_fiend_fire_target(
        card, target, combat, hp, block
    )
    if redirected_target != target:
        log(
            "potion duplicate Fiend Fire redirect Bronze Orb overkill "
            f"target={target}->{redirected_target}"
        )
        target = redirected_target
    if not duplication_card_commit_worthy(
        card, target, combat, hp, critical_reserve
    ):
        return None
    remember_duplication_target(gs, combat, card, target)
    if low_reserve_pressure_elite:
        log(
            "potion duplicate low-reserve pressure elite "
            f"target={target} card={card_id(card)}"
        )
    elif byrd_swarm_pressure:
        log(
            "potion duplicate three-Byrd opening pressure "
            f"target={target} card={card_id(card)} incoming={incoming - block}"
        )
    return f"POTION use {potion_index}"


def extra_energy_plan_improves(combat, gs, amount=2, preserve_hp=False):
    try:
        base_plan = plan_turn(combat, gs)
        preview = dict(combat)
        preview_player = dict(combat.get("player") or {})
        current_energy = int(preview_player.get("energy", 0) or 0)
        preview_player["energy"] = current_energy + amount
        preview["player"] = preview_player
        preview_hand = []
        for raw_card in combat.get("hand", []):
            card = dict(raw_card)
            if (
                not card.get("is_playable")
                and card.get("type") not in {"STATUS", "CURSE"}
                and current_energy < card_cost(card) <= current_energy + amount
            ):
                card["is_playable"] = True
            preview_hand.append(card)
        preview["hand"] = preview_hand
        boosted_plan = plan_turn(preview, gs)
    except Exception:
        return False
    return (
        boosted_plan.score > base_plan.score
        and len(boosted_plan.commands) > len(base_plan.commands)
        and (not preserve_hp or boosted_plan.hp_loss <= base_plan.hp_loss)
    )


def planned_attack_focus_target(combat, gs, plan=None):
    """Return the raw monster index receiving the plan's most attack damage."""
    try:
        model = build_model(combat, gs)
        plan = plan or plan_turn(combat, gs)
        progress_by_target = {}
        first_attack_order = {}
        for order, command in enumerate(plan.commands):
            match = re.fullmatch(r"PLAY\s+(\d+)(?:\s+(\d+))?", command)
            if not match:
                break
            hand_index = int(match.group(1)) - 1
            if hand_index < 0 or hand_index >= len(model.hand):
                return None
            played = model.hand[hand_index]
            target_index = None
            if match.group(2) is not None:
                original_target = int(match.group(2))
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            before = model
            model = simulate_card(model, hand_index, target_index)
            if (
                played.card_type != "ATTACK"
                or not played.has_target
                or target_index is None
            ):
                continue
            raw_target = before.monsters[target_index].original_index
            before_total = (
                before.monsters[target_index].hp
                + before.monsters[target_index].block
            )
            after_total = (
                model.monsters[target_index].hp
                + model.monsters[target_index].block
            )
            progress_by_target[raw_target] = (
                progress_by_target.get(raw_target, 0)
                + max(1, before_total - after_total)
            )
            first_attack_order.setdefault(raw_target, order)
    except (IndexError, StopIteration, TypeError, ValueError):
        return None
    if not progress_by_target:
        return None
    return max(
        progress_by_target,
        key=lambda raw_target: (
            progress_by_target[raw_target],
            -first_attack_order[raw_target],
        ),
    )


def red_skull_card_should_precede_ornithopter_heal(gs, combat):
    """Keep Red Skull online for the next Strength-sensitive planned card."""
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if not {"Red Skull", "Toy Ornithopter"}.issubset(relic_ids):
        return False
    player = combat.get("player") or {}
    hp = int(player.get("current_hp", gs.get("current_hp", 0)) or 0)
    max_hp = max(1, int(player.get("max_hp", gs.get("max_hp", 1)) or 1))
    if hp * 2 > max_hp or min(max_hp, hp + 5) * 2 <= max_hp:
        return False
    try:
        plan = plan_turn(combat, gs)
    except Exception:
        return False
    if not plan.commands:
        return False
    match = re.fullmatch(r"PLAY\s+(\d+)(?:\s+\d+)?", plan.commands[0])
    if not match:
        return False
    hand_index = int(match.group(1)) - 1
    hand = combat.get("hand", [])
    if hand_index < 0 or hand_index >= len(hand):
        return False
    return card_id(hand[hand_index]) in {
        "Fiend Fire", "Heavy Blade", "Limit Break", "Pummel", "Reaper",
        "Sword Boomerang", "Twin Strike", "Whirlwind",
    }


LIQUID_MEMORIES_DRAW_CARDS = set(DRAW_SETUP_VALUES) | {
    "Dropkick", "Pommel Strike",
}


def liquid_memories_candidate_score(card, combat, gs):
    """Rank only cards CommunicationMod can actually replay this state."""
    if card.get("type") in {"CURSE", "STATUS"}:
        return -10000
    player = combat.get("player") or {}
    energy = int(player.get("energy", 0) or 0)
    if card_cost(card) < 0 or card_cost(card) > energy:
        # The current CommunicationMod/BaseMod stack serializes returned cards
        # at their printed cost, so an unaffordable card remains unplayable.
        return -10000
    cid = card_id(card)
    if has_power(player, {"No Draw"}) and cid in LIQUID_MEMORIES_DRAW_CARDS:
        return -10000
    score = CARD_SCORES.get(
        cid, 25 if card.get("type") == "ATTACK" else 10
    )
    try:
        base_loss = int(plan_turn(combat, gs).hp_loss)
        preview = dict(combat)
        returned_card = dict(card)
        returned_card["is_playable"] = True
        preview["hand"] = list(combat.get("hand", [])) + [returned_card]
        preview_loss = int(plan_turn(preview, gs).hp_loss)
    except Exception:
        return score

    improvement = max(0, base_loss - preview_loss)
    if improvement:
        score += improvement * 40
        hp = max(1, int(player.get("current_hp", gs.get("current_hp", 1)) or 1))
        if base_loss >= hp and preview_loss < hp:
            # Actual lethal prevention outranks the static tier list. This is
            # especially important when a humble Defend is the only replay that
            # buys another draw against an Act 2 boss.
            score += 5000
    return score


def liquid_memories_useful_now(combat, gs):
    return any(
        liquid_memories_candidate_score(card, combat, gs) > -10000
        for card in combat.get("discard_pile", [])
    )


def liquid_memories_tactical_window(combat, gs, hp, incoming, block):
    """Keep Liquid Memories until the returned card changes a real turn."""
    if max(1, int(combat.get("turn", 1) or 1)) <= 1:
        # A turn-one discard only contains cards just spent from the opening
        # hand. Rebuying one there trades a rare potion for a tiny local
        # improvement and strands it before the later burst/emergency cycle.
        return False
    candidates = [
        (liquid_memories_candidate_score(card, combat, gs), index, card)
        for index, card in enumerate(combat.get("discard_pile", []))
    ]
    usable = [candidate for candidate in candidates if candidate[0] > -10000]
    if not usable:
        return False

    try:
        base_loss = int(plan_turn(combat, gs).hp_loss)
    except Exception:
        # Keep the older pressure gate as a conservative fallback if an
        # unusual generated card cannot be represented by the planner.
        max_hp = max(
            1,
            int(
                gs.get(
                    "max_hp",
                    (combat.get("player") or {}).get("max_hp", 1),
                )
                or 1
            ),
        )
        unblocked = max(0, incoming - block)
        return bool(
            unblocked >= max(8, int(max_hp * 0.10))
            or hp - unblocked <= int(max_hp * 0.45)
        )
    if base_loss <= 0:
        # The logged A19 line replayed an upgraded Defend at 58/75 even though
        # the remaining hand already blocked Acid Slime's hit completely. The
        # potion was then missing for the forced Sentries elite one room later.
        return False
    if (
        gs.get("room_type") == "MonsterRoom"
        and immediate_next_room_is_forced(gs, "R")
        and forced_elite_within_rooms(gs, max_rooms=2)
        and base_loss < hp
    ):
        # The A19 Centurion hallway spent Liquid Memories to save nine HP,
        # despite a guaranteed campfire immediately before a forced Book of
        # Stabbing. Keep the rare replay for the elite while the exact current
        # plan still survives; a later lethal turn can release it normally.
        log(
            "potion preserve liquid memories through campfire for forced elite "
            f"planned_loss={base_loss} hp={hp}"
        )
        return False

    _, discard_index, returned_card = max(
        usable, key=lambda candidate: (candidate[0], -candidate[1])
    )
    preview = dict(combat)
    returned_card = dict(returned_card)
    returned_card["is_playable"] = True
    preview["hand"] = list(combat.get("hand", [])) + [returned_card]
    preview["discard_pile"] = [
        card
        for index, card in enumerate(combat.get("discard_pile", []))
        if index != discard_index
    ]
    try:
        return int(plan_turn(preview, gs).hp_loss) < base_loss
    except Exception:
        return False


def liquid_memories_defense_setup_command(state, gs, combat, hp, incoming, block):
    """Play a block card into discard when replaying it is the lethal answer."""
    if (
        not command_available(state, "play")
        or not command_available(state, "potion")
        or max(1, int(combat.get("turn", 1) or 1)) <= 1
        or not any(
            normalized_potion_id(potion) == "LiquidMemories"
            and potion.get("can_use", True)
            for potion in gs.get("potions", [])
        )
    ):
        return None
    player = combat.get("player") or {}
    if has_power(player, {"NoBlockPower", "Corruption"}):
        return None
    try:
        if int(plan_turn(combat, gs).hp_loss) < hp:
            return None
    except Exception:
        return None

    energy = max(0, int(player.get("energy", 0) or 0))
    choker_counter = relic_counter(gs, "Velvet Choker", -1)
    if choker_counter >= 5:
        return None
    powers = {
        power.get("id") or power.get("name"): int(power.get("amount", 0) or 0)
        for power in player.get("powers", [])
    }
    dexterity = int(powers.get("Dexterity", 0) or 0)
    frail = powers.get("Frail", 0) > 0
    options = []
    for hand_index, card in playable_cards(combat):
        cid = card_id(card)
        raw_cost = int(card.get("cost", 0) or 0)
        if (
            cid not in FIXED_DUPLICATION_BLOCK_IDS
            or card.get("type") != "SKILL"
            or card.get("has_target")
            or card.get("exhausts")
            or raw_cost < 0
            or card_cost(card) * 2 > energy
        ):
            continue
        base, upgrade = BLOCK_VALUE[cid]
        gained = adjusted_block(
            base + upgrade * min(1, int(card.get("upgrades", 0) or 0)),
            dexterity,
            frail,
        )
        projected_loss = max(0, incoming - block - gained * 2)
        if gained > 0 and projected_loss < hp:
            options.append(
                (projected_loss, -gained, card_cost(card), hand_index, card)
            )
    if not options:
        return None

    projected_loss, _, _, hand_index, card = min(options)
    log(
        "liquid memories lethal setup "
        f"card={card_id(card)} projected_loss={projected_loss} hp={hp}"
    )
    return f"PLAY {hand_index}"


def guardian_mode_shift_plan_cancels_attack(combat, gs):
    """Return whether the exact card line safely interrupts Guardian's hit."""
    raw_guardian = next(
        (
            monster
            for monster in combat.get("monsters", [])
            if not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            and (monster.get("id") or monster.get("name")) == "TheGuardian"
            and "ATTACK" in str(monster.get("intent") or "")
            and any(
                (power.get("id") or power.get("name")) == "Mode Shift"
                and int(power.get("amount", 0) or 0) > 0
                for power in monster.get("powers", [])
            )
        ),
        None,
    )
    if raw_guardian is None:
        return False

    try:
        plan = plan_turn(combat, gs)
        if plan.hp_loss != 0:
            return False
        model = build_model(combat, gs)
        guardian_before = next(
            monster
            for monster in model.monsters
            if monster.monster_id == "TheGuardian"
        )
        guardian_index = guardian_before.original_index
        for command in plan.commands:
            parts = command.split()
            if not parts or parts[0] == "END":
                break
            if parts[0] != "PLAY" or len(parts) < 2:
                return False
            hand_index = int(parts[1]) - 1
            target_index = None
            if len(parts) >= 3:
                original_target = int(parts[2])
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            model = simulate_card(model, hand_index, target_index)
        guardian_after = next(
            (
                monster
                for monster in model.monsters
                if monster.original_index == guardian_index
            ),
            None,
        )
    except (IndexError, StopIteration, TypeError, ValueError):
        return False

    if guardian_after is None or not guardian_after.alive:
        return True
    return bool(
        "ATTACK" not in guardian_after.intent
        and power_amount(guardian_after.powers, "Mode Shift") == 0
        and power_amount(guardian_after.powers, "Sharp Hide") > 0
    )


def guardian_charging_plan_sets_next_cancel(combat, gs):
    """Keep flexible energy when the known next hand can cancel Fierce Bash."""
    raw_guardian = next(
        (
            monster
            for monster in combat.get("monsters", [])
            if not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            and (monster.get("id") or monster.get("name")) == "TheGuardian"
            and (
                str(monster.get("intent") or "").startswith("DEFEND")
                or (
                    str(monster.get("intent") or "") == "DEBUG"
                    and int(monster.get("move_id", -1) or -1) == 6
                )
            )
            and any(
                (power.get("id") or power.get("name")) == "Mode Shift"
                and int(power.get("amount", 0) or 0) > 0
                for power in monster.get("powers", [])
            )
        ),
        None,
    )
    if raw_guardian is None:
        return False

    try:
        plan = plan_turn(combat, gs)
        if plan.hp_loss != 0:
            return False
        model = build_model(combat, gs)
        next_attack_damage = model.known_next_attack_damage
        guardian_before = next(
            monster
            for monster in model.monsters
            if monster.monster_id == "TheGuardian"
        )
        guardian_index = guardian_before.original_index
        for command in plan.commands:
            parts = command.split()
            if not parts or parts[0] == "END":
                break
            if parts[0] != "PLAY" or len(parts) < 2:
                return False
            hand_index = int(parts[1]) - 1
            target_index = None
            if len(parts) >= 3:
                original_target = int(parts[2])
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            model = simulate_card(model, hand_index, target_index)
        guardian_after = next(
            (
                monster
                for monster in model.monsters
                if monster.original_index == guardian_index
            ),
            None,
        )
    except (IndexError, StopIteration, TypeError, ValueError):
        return False

    if guardian_after is None or not guardian_after.alive:
        return False
    remaining_shift = power_amount(guardian_after.powers, "Mode Shift")
    return bool(
        remaining_shift > 0
        and power_amount(guardian_after.powers, "Sharp Hide") == 0
        and next_attack_damage >= remaining_shift + 9
    )


def potion_command(state, gs, combat, hp, incoming, block, target):
    global HAND_SELECT_MODE, GRID_SELECT_MODE
    if not command_available(state, "potion"):
        return None
    player = combat.get("player") or {}
    potions = gs.get("potions", [])
    max_hp = max(1, int(gs.get("max_hp", player.get("max_hp", 1)) or 1))
    floor = int(gs.get("floor", 0) or 0)
    raw_act = gs.get("act")
    if raw_act is None:
        act = 1 if floor <= 16 else 2 if floor <= 33 else 3 if floor <= 51 else 4
    else:
        act = int(raw_act or 1)
    late_preboss_hallway = (
        gs.get("room_type") == "MonsterRoom"
        and (
            act == 1 and floor >= 13
            or act == 2 and floor >= 28
            or act == 3 and floor >= 45
        )
    )
    usable_potions = [
        potion
        for potion in potions
        if potion.get("id") != "Potion Slot" and potion.get("can_use", True)
    ]
    projected_hp = hp - max(0, incoming - block)
    reserve_last_potion = (
        late_preboss_hallway
        and len(usable_potions) == 1
        and projected_hp > max(18, int(max_hp * 0.30))
    )
    reserve_energy_potion = False
    reserve_distilled_chaos = False
    reserve_swift_potion = False
    base_emergency_plan = None

    def find_potion(ids, allow_reserved=False):
        if reserve_last_potion and not allow_reserved:
            return None, None
        if reserve_energy_potion and ids & {"Energy Potion", "EnergyPotion"}:
            return None, None
        if reserve_distilled_chaos and "DistilledChaos" in ids:
            return None, None
        for idx, potion in enumerate(potions):
            if (
                reserve_swift_potion
                and potion.get("id") in {"Swift Potion", "SwiftPotion"}
            ):
                continue
            if potion.get("id") in ids and potion.get("can_use", True):
                return idx, potion
        return None, None

    def prepare_entropic_slot():
        """Consume another usable potion before Entropic Brew fills slots."""
        global GRID_SELECT_MODE
        candidates = [
            (potion_score(potion, gs, context="held"), idx, potion)
            for idx, potion in enumerate(potions)
            if potion.get("can_use", True)
            and normalized_potion_id(potion) not in {
                "Potion Slot", "EntropicBrew",
            }
            and not (
                turn <= 1
                and normalized_potion_id(potion) == "LiquidMemories"
            )
        ]
        if not candidates:
            return None
        _, idx, potion = max(candidates, key=lambda item: item[0])
        if normalized_potion_id(potion) == "LiquidMemories":
            GRID_SELECT_MODE = "liquid_memories"
        log(
            "potion use before entropic brew "
            f"potion={normalized_potion_id(potion)} slot={idx}"
        )
        if potion.get("requires_target"):
            return f"POTION use {idx} {target}"
        return f"POTION use {idx}"

    def entropic_brew_command(allow_reserved=False):
        """Empty every other usable slot before consuming Entropic Brew."""
        idx, potion = find_potion(
            {"EntropicBrew"}, allow_reserved=allow_reserved
        )
        if idx is None:
            return None
        preparation = prepare_entropic_slot()
        if preparation:
            return preparation
        if turn <= 1 and any(
            normalized_potion_id(candidate) == "LiquidMemories"
            and candidate.get("can_use", True)
            for candidate in potions
        ):
            # Do not consume Entropic Brew while its only occupied companion
            # is opening-locked Liquid Memories; both potions keep more value.
            return None
        if potion.get("requires_target"):
            return f"POTION use {idx} {target}"
        return f"POTION use {idx}"

    danger = (
        gs.get("room_type") in {"MonsterRoomBoss", "MonsterRoomElite"}
        or int(gs.get("floor", 0) or 0) >= 13
        or hp <= max_hp * 0.4
        or incoming - block >= 10
    )
    guardian_attack_canceled = guardian_mode_shift_plan_cancels_attack(
        combat, gs
    )

    turn = max(1, int(combat.get("turn", 1) or 1))
    ascension = int(gs.get("ascension_level", 0) or 0)
    ritual_swarm_opening = (
        turn <= 2
        and sum(
            not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            and (monster.get("id") or monster.get("name")) == "Cultist"
            for monster in combat.get("monsters", [])
        ) >= 3
    )
    byrd_swarm_opening = (
        ascension >= 17
        and turn <= 2
        and sum(
            not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            and (monster.get("id") or monster.get("name")) == "Byrd"
            for monster in combat.get("monsters", [])
        ) >= 3
    )
    early_ritual_swarm = ritual_swarm_opening and hp < max_hp
    if ritual_swarm_opening:
        # Three Ritual stacks make the quiet opener the best potion window,
        # including a hallway immediately before the Act 2 boss.
        reserve_last_potion = False
    long_boss_regen_window = (
        gs.get("room_type") == "MonsterRoomBoss"
        and 2 <= turn <= 5
        and max_hp - hp >= max(5, int(max_hp * 0.06))
        and any(
            not monster.get("is_gone")
            and int(monster.get("current_hp", 0) or 0)
            > max(40, int(monster.get("max_hp", 1) or 1) // 4)
            for monster in combat.get("monsters", [])
        )
    )
    book_regen_window = (
        gs.get("room_type") == "MonsterRoomElite"
        and turn <= 2
        and max_hp - hp >= max(10, int(max_hp * 0.12))
        and any(
            not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 60
            and (monster.get("id") or monster.get("name"))
            == "BookOfStabbing"
            for monster in combat.get("monsters", [])
        )
    )
    if (
        (
            hp <= max_hp * 0.45
            or early_ritual_swarm
            or long_boss_regen_window
            or book_regen_window
        )
        and not has_power(player, {"Regen", "Regeneration"})
    ):
        idx, _ = find_potion({"Regen Potion"}, allow_reserved=True)
        if idx is not None:
            if early_ritual_swarm:
                log("potion use regeneration before multi-Cultist scaling cycle")
            elif long_boss_regen_window:
                log("potion use regeneration early enough to mature in long boss")
            elif book_regen_window:
                log("potion use regeneration before Book hit count escalates")
            return f"POTION use {idx}"
        idx, _ = find_potion({"BloodPotion"}, allow_reserved=True)
        blood_heal = max(1, int(max_hp * 0.20))
        missing_hp = max(0, max_hp - hp)
        urgent_recovery = projected_hp <= max(18, int(max_hp * 0.30))
        if idx is not None and (missing_hp >= blood_heal or urgent_recovery):
            # Blood Potion heals all at once. Do not chain a second copy into
            # overheal merely because the long-boss window is still active;
            # the logged A17 Hexaghost used two at 52/75, wasting seven HP of
            # the second potion, then died by exactly eleven total damage.
            return f"POTION use {idx}"

    idx, _ = find_potion({"Fruit Juice"}, allow_reserved=True)
    if idx is not None:
        return f"POTION use {idx}"

    living = [
        monster
        for monster in combat.get("monsters", [])
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    room_type = gs.get("room_type") or ""
    boss_fight = room_type == "MonsterRoomBoss"
    elite_fight = room_type == "MonsterRoomElite"
    dangerous_elite_ids = {
        "BookOfStabbing", "GremlinLeader", "Reptomancer",
        "SlaverBlue", "SlaverBoss", "SlaverRed", "GiantHead",
    }
    dangerous_elite = elite_fight and any(
        (monster.get("id") or monster.get("name")) in dangerous_elite_ids
        for monster in living
    )
    high_ascension_entropic_chain = bool(
        ascension >= 18
        and turn <= 2
        and any(
            normalized_potion_id(potion) == "EntropicBrew"
            and potion.get("can_use", True)
            for potion in potions
        )
        and (
            ritual_swarm_opening
            or elite_fight and (act == 1 or dangerous_elite)
        )
    )
    if high_ascension_entropic_chain:
        # High-ascension elites and three simultaneous Ritual stacks are where
        # a full potion bar must become live combat value. Empty every usable
        # companion slot first, then consume Entropic Brew on the next state so
        # it refills every slot instead of wasting generated potions.
        command = entropic_brew_command(allow_reserved=True)
        if command:
            log(
                "potion chain before high-ascension elite or Ritual swarm "
                f"act={act} floor={floor} enemies="
                f"{sorted(monster.get('id') or monster.get('name') for monster in living)}"
            )
            return command
    strength = next(
        (
            int(power.get("amount", 0) or 0)
            for power in player.get("powers", [])
            if (power.get("id") or power.get("name")) == "Strength"
        ),
        0,
    )
    limit_break_card = next(
        (
            card
            for card in combat.get("hand", [])
            if card_id(card) == "Limit Break"
            and card.get("is_playable")
            and card_cost(card) <= int(player.get("energy", 0) or 0)
        ),
        None,
    )
    limit_break_ready = limit_break_card is not None

    # Offensive potions are run resources, not automatic answers to one mildly
    # uncomfortable hallway turn. The logged A8 Hexaghost run emptied Fear,
    # Skill and Cultist potions into the floor-one Jaw Worm, while the later
    # Awakened One and Giant Head losses held their scaling potions until it was
    # too late. Commit scaling at the start of fights that can actually end the
    # run, and let the normal emergency checks handle everything else.
    living_ids = {
        monster.get("id") or monster.get("name")
        for monster in living
    }
    act1_block_card_count = sum(
        card_id(deck_card) in BLOCK_VALUE
        for deck_card in gs.get("deck", [])
    )
    early_act1_persistent_dexterity = bool(
        ascension >= 18
        and act == 1
        and turn == 1
        and combat_player_power_amount(gs, "Dexterity") <= 1
        and act1_block_card_count >= 3
        and (
            boss_fight
            and hp <= int(max_hp * 0.88)
            and living_ids & {"SlimeBoss", "Hexaghost", "TheGuardian"}
            or room_type == "MonsterRoom"
            and len(living) >= 2
            and hp <= int(max_hp * 0.82)
            and incoming - block >= 10
            and sum(
                int(monster.get("current_hp", 0) or 0)
                + int(monster.get("block", 0) or 0)
                for monster in living
            ) >= 70
        )
    )
    if early_act1_persistent_dexterity:
        idx, _ = find_potion({"Dexterity Potion"}, allow_reserved=True)
        if idx is not None:
            # Persistent Dexterity pays across the whole split/burn cycle. The
            # A19 Slime Boss run carried it until turn nine, while the logged
            # Acid Slime/Red Slaver pair waited until turn five. Early use also
            # lets two enhanced Defends leave energy for tempo in the next hand.
            log("potion use persistent dexterity on Act 1 pressure opener")
            return f"POTION use {idx}"
    low_reserve_sentry_sphere = bool(
        ascension >= 18
        and room_type == "MonsterRoom"
        and turn <= 2
        and hp <= int(max_hp * 0.45)
        and {"Sentry", "SphericGuardian"}.issubset(living_ids)
        and not has_power(player, {"Dexterity"})
    )
    if low_reserve_sentry_sphere:
        idx, _ = find_potion({"Dexterity Potion"}, allow_reserved=True)
        if idx is not None:
            # Both enemies attack over several turns after their quiet opener.
            # Establish persistent Dexterity now: waiting for a larger one-turn
            # preview forfeited two Block that decided the logged A19 fight.
            log("potion use dexterity before low-reserve Sentry/Sphere attrition")
            return f"POTION use {idx}"
    sentry_sphere_energy_control = bool(
        ascension >= 18
        and room_type == "MonsterRoom"
        and turn <= 2
        and hp <= int(max_hp * 0.65)
        and {"Sentry", "SphericGuardian"}.issubset(living_ids)
        and any(
            (monster.get("id") or monster.get("name")) == "Sentry"
            and "ATTACK" in str(monster.get("intent") or "")
            for monster in living
        )
        and incoming - block >= max(18, int(max_hp * 0.20))
        and projected_hp <= max(32, int(max_hp * 0.38))
    )
    if sentry_sphere_energy_control and extra_energy_plan_improves(
        combat, gs, preserve_hp=True
    ):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # This pair alternates into Dazed-heavy hands. Spend even the last
            # pre-boss potion when two extra energy remove the attacking Sentry
            # or materially reduce the combined hit; carrying it at critical
            # reserve has no later value.
            log("potion use energy for low-reserve Sentry/Sphere control")
            return f"POTION use {idx}"
    chaos_top_three = known_top_draw_cards(combat, 3)
    attacking_hits = sum(
        max(1, int(monster.get("move_hits", 1) or 1))
        for monster in living
        if "ATTACK" in str(monster.get("intent") or "")
    )
    current_intangible = has_power(
        player, {"Intangible", "IntangiblePlayer"}
    )
    playable_apparition = any(
        card_id(card) in {"Apparition", "Ghostly"}
        and card.get("is_playable")
        and card_cost(card) <= int(player.get("energy", 0) or 0)
        for card in combat.get("hand", [])
    )
    intangible_swift_reserve = bool(
        (current_intangible or playable_apparition)
        and max(
            0,
            (incoming if current_intangible else attacking_hits) - block,
        ) <= max(3, int(max_hp * 0.08))
    )
    quiet_turn_swift_reserve = bool(
        len(chaos_top_three) == 3
        and incoming <= block
        and not any(
            "ATTACK" in str(monster.get("intent") or "")
            for monster in living
        )
        and sum(estimate_block(card, block) > 0 for card in chaos_top_three) >= 2
    )
    reserve_swift_potion = bool(
        intangible_swift_reserve or quiet_turn_swift_reserve
    )
    if reserve_swift_potion and any(
        potion.get("id") in {"Swift Potion", "SwiftPotion"}
        and potion.get("can_use", True)
        for potion in potions
    ):
        if intangible_swift_reserve:
            # Apparition already compresses every hit to one. Batch 138 spent
            # Swift after establishing Intangible against Collector, drawing
            # through the defensive cards needed for the following 48-damage
            # turn while the current turn was already fully covered.
            log(
                "potion reserve swift during apparition-covered turn "
                f"active={current_intangible} playable={playable_apparition} "
                f"projected_loss="
                f"{max(0, (incoming if current_intangible else attacking_hits) - block)}"
            )
        else:
            # Drawing a known defensive cluster on a quiet turn discards those
            # answers before the enemy's next attack. Batch 110 did exactly this
            # against Snake Plant, turning two Defends and True Grit into dead draws.
            log(
                "potion reserve swift before known quiet-turn block draw "
                f"top={[card_id(card) for card in chaos_top_three]}"
            )
    chaos_mass_exhaust = next(
        (
            card_id(card)
            for card in chaos_top_three
            if card_id(card) in {"Fiend Fire", "Second Wind", "Sever Soul"}
        ),
        None,
    )
    protected_hand_cards = sum(
        card.get("type") not in {"CURSE", "STATUS"}
        for card in combat.get("hand", [])
    )
    chaos_second_wind_rescue = False
    if chaos_mass_exhaust == "Second Wind":
        try:
            if base_emergency_plan is None:
                base_emergency_plan = plan_turn(combat, gs)
            second_wind_card = next(
                card
                for card in chaos_top_three
                if card_id(card) == "Second Wind"
            )
            dexterity = combat_player_power_amount(gs, "Dexterity")
            frail = combat_player_power_amount(gs, "Frail") > 0
            feel_no_pain = combat_player_power_amount(gs, "Feel No Pain")
            block_per_card = adjusted_block(
                5 + 2 * min(1, int(second_wind_card.get("upgrades", 0) or 0)),
                dexterity,
                frail,
            ) + feel_no_pain
            exhaust_payload = sum(
                card.get("type") != "ATTACK"
                for card in combat.get("hand", [])
            )
            current_unblocked = max(0, incoming - block)
            projected_unblocked = max(
                0, current_unblocked - exhaust_payload * block_per_card
            )
            chaos_second_wind_rescue = bool(
                int(base_emergency_plan.hp_loss) >= hp
                and current_unblocked >= hp
                and projected_unblocked < hp
            )
        except (StopIteration, TypeError, ValueError):
            chaos_second_wind_rescue = False
    if (
        chaos_mass_exhaust
        and protected_hand_cards >= 3
        and not chaos_second_wind_rescue
    ):
        # Distilled Chaos plays the visible top three cards without a chance to
        # stop between them. In the logged Champ opener, its third card was
        # Fiend Fire, which exhausted Shockwave and the whole defensive hand.
        reserve_distilled_chaos = True
        log(
            "potion reserve distilled chaos before known mass exhaust "
            f"card={chaos_mass_exhaust} top="
            f"{[card_id(card) for card in chaos_top_three]}"
        )
    elif chaos_second_wind_rescue:
        # The A19 Automaton lethal had Strike then Second Wind visible on top.
        # Preserving Pyramid's Powers guaranteed death, while the automatic
        # mass exhaust supplied enough Block to keep the run alive.
        log(
            "potion release distilled chaos for lethal Second Wind rescue "
            f"top={[card_id(card) for card in chaos_top_three]}"
        )
    if (
        boss_fight
        and turn == 1
        and incoming <= block
        and "BronzeAutomaton" in living_ids
        and "BronzeOrb" not in living_ids
        and any(
            normalized_potion_id(potion) == "DistilledChaos"
            and potion.get("can_use", True)
            for potion in potions
        )
    ):
        # Bronze Orbs arrive on the next turn and immediately take two cards
        # into Stasis. Distilled Chaos is much more useful after that spawn:
        # its free plays can break an Orb or use a returned setup card without
        # consuming the regular energy needed to survive the same turn.
        reserve_distilled_chaos = True
        log("potion reserve distilled chaos until Bronze Orbs spawn")
    guardian_charge_reserve = guardian_charging_plan_sets_next_cancel(
        combat, gs
    )
    if guardian_charge_reserve and any(
        potion.get("id") in {"Energy Potion", "EnergyPotion"}
        and potion.get("can_use", True)
        for potion in potions
    ):
        # The logged A17 opener spent two energy to trigger Defensive Mode on
        # Guardian's quiet turn. The unboosted line left only five Mode Shift,
        # while the exact next hand could clear that plus Charge Up's block and
        # cancel Fierce Bash. Preserve the potion and take the better sequence.
        reserve_energy_potion = True
        log("potion reserve energy for known Guardian next-turn mode shift")
    hexaghost_divider_reserve = bool(
        boss_fight
        and turn == 1
        and incoming <= block
        and hp >= int(max_hp * 0.55)
        and "Hexaghost" in living_ids
    )
    if hexaghost_divider_reserve and any(
        potion.get("id") in {"Energy Potion", "EnergyPotion"}
        and potion.get("can_use", True)
        for potion in potions
    ):
        # Hexaghost's first real action is Divider. Spending two flexible
        # energy on the quiet opener bought one Strike in the logged A17 loss,
        # then left Shockwave plus only one Defend against the six-hit turn.
        reserve_energy_potion = True
        log("potion reserve energy for Hexaghost Divider turn")
    if (
        boss_fight
        and turn <= 2
        and "Brimstone" in _relic_ids(gs)
        and "AwakenedOne" in living_ids
    ):
        try:
            reserve_plan = plan_turn(combat, gs)
            reserve_energy_potion = bool(
                reserve_plan.score[0]
                and hp - reserve_plan.hp_loss
                >= max(12, int(max_hp * 0.15))
            )
        except Exception:
            reserve_energy_potion = False
        if reserve_energy_potion and any(
            potion.get("id") in {"Energy Potion", "EnergyPotion"}
            and potion.get("can_use", True)
            for potion in potions
        ):
            # Brimstone makes Awakened One's first four-hit turn much more
            # dangerous than its opener. If the existing line safely clears
            # the Cultists, keep the flexible two energy for that control turn.
            log(
                "potion reserve energy for Brimstone Awakened multi-hit "
                f"turn={turn} reserve={hp - reserve_plan.hp_loss}/{max_hp}"
            )
    attacking_thieves = [
        (index, monster)
        for index, monster in enumerate(combat.get("monsters", []))
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
        and (monster.get("id") or monster.get("name"))
        in {"Looter", "Mugger"}
        and "ATTACK" in (monster.get("intent") or "")
    ]
    thief_pair_fire_rescue = (
        room_type == "MonsterRoom"
        and turn <= 2
        and len(attacking_thieves) >= 2
        and max(0, incoming - block) >= max(20, int(max_hp * 0.24))
        and projected_hp <= int(max_hp * 0.35)
    )
    if thief_pair_fire_rescue:
        idx, _ = find_potion({"Fire Potion"}, allow_reserved=True)
        if idx is not None:
            fire_target = min(
                attacking_thieves,
                key=lambda item: (
                    int(item[1].get("current_hp", 0) or 0)
                    + int(item[1].get("block", 0) or 0),
                    item[0],
                ),
            )[0]
            # Fire Potion plus the visible Cleave/Combust damage removes the
            # lower thief before its second hit. Waiting until formal lethal
            # paid both eleven-damage attacks in the logged A17 hallway.
            log(
                "potion use fire before low-reserve double-thief cycle "
                f"projected_hp={projected_hp}/{max_hp} target={fire_target}"
            )
            return f"POTION use {idx} {fire_target}"
    healer_pair_opening = (
        room_type == "MonsterRoom"
        and turn <= 2
        and {"Centurion", "Healer"}.issubset(living_ids)
        and not long_boss_damage_ready(gs)
    )
    low_reserve_multi_enemy_opening = (
        room_type == "MonsterRoom"
        and turn <= 2
        and len(living) >= 2
        and hp <= max(32, int(max_hp * 0.45))
        and sum(
            int(monster.get("current_hp", 0) or 0)
            + int(monster.get("block", 0) or 0)
            for monster in living
        ) >= 55
    )
    high_stakes_opening = turn <= 2 and (
        boss_fight
        or dangerous_elite
        or healer_pair_opening
        or ritual_swarm_opening
        or byrd_swarm_opening
        or low_reserve_multi_enemy_opening
    )
    shelled_multi_enemy_attrition = bool(
        ascension >= 18
        and room_type == "MonsterRoom"
        and turn <= 2
        and len(living) >= 2
        and hp <= int(max_hp * 0.55)
        and incoming - block >= max(20, int(max_hp * 0.24))
        and living_ids & {"Shelled Parasite", "Shell Parasite"}
    )

    if ritual_swarm_opening and extra_energy_plan_improves(combat, gs):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # Ritual makes the apparent zero-damage opener the decisive damage
            # window. Use the five-energy line when it adds a real action.
            log("potion use energy before multi-Cultist scaling cycle")
            return f"POTION use {idx}"

    reptomancer_opening_energy_control = bool(
        elite_fight
        and turn <= 2
        and "Reptomancer" in living_ids
        and sum(
            (monster.get("id") or monster.get("name")) == "Dagger"
            for monster in living
        ) >= 2
        and any(
            card_id(card) == "Disarm"
            and card.get("is_playable")
            and card_cost(card) <= int(player.get("energy", 0) or 0) + 2
            for card in combat.get("hand", [])
        )
        and any(
            card_id(card) in {"Cleave", "Immolate", "Reaper", "Whirlwind"}
            and card.get("is_playable")
            for card in combat.get("hand", [])
        )
        and (
            sum(
                potion.get("id") in {"Energy Potion", "EnergyPotion"}
                and potion.get("can_use", True)
                for potion in potions
            ) >= 2
            or hp <= int(max_hp * 0.75)
        )
    )
    if reptomancer_opening_energy_control and extra_energy_plan_improves(
        combat, gs, preserve_hp=True
    ):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # One potion converts the opener from a partial dagger clear into
            # the same clear plus permanent multi-hit suppression. Keep any
            # second copy for the next summon cycle rather than dying with both.
            log("potion use energy for Reptomancer dagger clear plus Disarm")
            return f"POTION use {idx}"

    plated_parasite_attrition = (
        room_type == "MonsterRoom"
        and turn >= 2
        and hp <= max_hp * 0.45
        and bool(living_ids & {"Shelled Parasite", "Shell Parasite"})
        and any(
            (power.get("id") or power.get("name")) == "Plated Armor"
            and int(power.get("amount", 0) or 0) > 0
            for monster in living
            for power in monster.get("powers", [])
        )
    )
    if plated_parasite_attrition and extra_energy_plan_improves(
        combat, gs, preserve_hp=True
    ):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # Plated Armor erases small damage turns. Waiting for a formally
            # lethal turn held an Energy Potion through seven attrition cycles
            # in the logged A15 loss; spend it once the extra cards break more
            # shell without sacrificing this turn's reserve.
            log("potion use energy for low-reserve plated parasite attrition")
            return f"POTION use {idx}"

    support_pair_energy_rescue = (
        room_type == "MonsterRoom"
        and turn <= 2
        and {"Centurion", "Healer"}.issubset(living_ids)
        and hp <= max(24, int(max_hp * 0.35))
        and incoming - block >= max(10, int(max_hp * 0.12))
    )
    if support_pair_energy_rescue and extra_energy_plan_improves(combat, gs):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # At low reserve, spending the potion now can finish the support
            # enemy before its heal/buff cycle and preserve the known defensive
            # draw for the following turn.
            log("potion use energy to finish low-reserve support pair opening")
            return f"POTION use {idx}"

    slaver_opening_reaper_duplication = bool(
        elite_fight
        and turn == 1
        and {"SlaverBlue", "SlaverBoss", "SlaverRed"}.issubset(living_ids)
        and hp <= int(max_hp * 0.70)
        and incoming - block >= max(24, int(max_hp * 0.30))
    )
    if slaver_opening_reaper_duplication:
        reaper = next(
            (
                card
                for card in combat.get("hand", [])
                if (card.get("id") or card.get("name")) == "Reaper"
                and card.get("is_playable", True)
                and int(card.get("cost", 99) or 0)
                <= int(player.get("energy", 0) or 0)
            ),
            None,
        )
        idx, _ = find_potion({"DuplicationPotion"}, allow_reserved=True)
        if reaper is not None and idx is not None:
            # On the logged A19 opener, Energy Potion preempted Duplication
            # Potion even though a doubled Reaper healed through the opening
            # volley and damaged all three Slavers. Duplicate it first; the
            # potion policy can still spend Energy after the forced follow-up.
            remember_duplication_target(gs, combat, reaper)
            log("potion use duplication on Reaper before Slaver energy control")
            return f"POTION use {idx}"

    slaver_opening_energy_control = bool(
        elite_fight
        and turn == 1
        and {"SlaverBlue", "SlaverBoss", "SlaverRed"}.issubset(living_ids)
    )
    if slaver_opening_energy_control and extra_energy_plan_improves(
        combat, gs, preserve_hp=True
    ):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # The extra two energy can combine a Red Slaver kill with the same
            # full block as the unboosted line. Take that control before a
            # generated-card potion leaves Entangle alive for the next hand.
            log("potion use energy for safe triple-Slaver opening control")
            return f"POTION use {idx}"

    if high_stakes_opening and not has_power(player, {"Ritual"}):
        idx, _ = find_potion({"CultistPotion"})
        if idx is not None:
            return f"POTION use {idx}"
    if high_stakes_opening and (
        boss_fight
        or strength_payoff_count(gs) > 0
        or byrd_swarm_opening and act >= 2
    ):
        idx, _ = find_potion({"Strength Potion"})
        if idx is not None:
            if byrd_swarm_opening and not boss_fight:
                log("potion use strength for Act 2 Byrd swarm control")
            return f"POTION use {idx}"
    if high_stakes_opening:
        idx, potion = find_potion({"PowerPotion", "ColorlessPotion"})
        if idx is not None:
            if ritual_swarm_opening:
                log("potion use generated power before multi-Cultist scaling cycle")
            elif low_reserve_multi_enemy_opening:
                log("potion use generated power before low-reserve multi-enemy attrition")
            if potion.get("requires_target"):
                return f"POTION use {idx} {target}"
            return f"POTION use {idx}"

    if danger and turn <= 3 and strength >= 2 and limit_break_ready:
        idx, _ = find_potion({"DuplicationPotion"})
        if idx is not None:
            remember_duplication_target(gs, combat, limit_break_card)
            return f"POTION use {idx}"

    high_stakes_strength_combo = (
        danger
        and strength > 0
        and limit_break_ready
        and (
            gs.get("room_type") in {"MonsterRoomBoss", "MonsterRoomElite"}
            or hp <= max_hp * 0.55
        )
    )
    if high_stakes_strength_combo:
        # Strength Potion must be consumed before Limit Break.  Re-evaluating
        # after each state update intentionally allows two stored potions to
        # stack before the doubling card is played.
        idx, _ = find_potion({"Strength Potion"})
        if idx is not None:
            return f"POTION use {idx}"

    if (
        gs.get("room_type") == "MonsterRoomBoss"
        and turn <= 3
        and extra_energy_plan_improves(combat, gs)
    ):
        idx, _ = find_potion({"Energy Potion", "EnergyPotion"})
        if idx is not None:
            return f"POTION use {idx}"

    lagavulin_expiring_burst = bool(
        ascension >= 18
        and elite_fight
        and turn <= 2
        and any(
            (monster.get("id") or monster.get("name")) == "Lagavulin"
            and (monster.get("intent") or "") in {"SLEEP", "DEBUG"}
            for monster in living
        )
        and any(
            card_id(card) == "Carnage"
            and card.get("ethereal")
            and card.get("is_playable")
            for card in combat.get("hand", [])
        )
    )
    if lagavulin_expiring_burst and extra_energy_plan_improves(combat, gs):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # Carnage disappears at end of turn. The A19 line held this potion,
            # stripped only six Metallicize, then replanned from that partial
            # state and exhausted its best attack without playing it. Convert
            # the last free sleep turn into Bash plus Carnage frontload instead.
            log("potion use energy for expiring Lagavulin Carnage burst")
            return f"POTION use {idx}"

    high_ascension_thin_lagavulin_offense = bool(
        int(gs.get("ascension_level", 0) or 0) >= 18
        and hp <= max_hp * 0.90
        and nonstarter_attack_count(gs) <= 2
        and boss_strength_scaling_source_count(gs) == 0
    )
    lagavulin_opening = (
        elite_fight
        and turn <= 3
        and hp <= max_hp * 0.90
        and any(
            (monster.get("id") or monster.get("name")) == "Lagavulin"
            for monster in living
        )
        and (
            not act1_elite_offense_ready(gs)
            or high_ascension_thin_lagavulin_offense
        )
    )
    if lagavulin_opening and (
        hp <= max_hp * 0.50 or high_ascension_thin_lagavulin_offense
    ):
        for potion_id in ("PowerPotion", "ColorlessPotion"):
            idx, potion = find_potion({potion_id}, allow_reserved=True)
            if idx is not None:
                log(
                    "potion use generated setup before low-reserve "
                    "Lagavulin wake cycle"
                )
                if potion.get("requires_target"):
                    return f"POTION use {idx} {target}"
                return f"POTION use {idx}"
    if lagavulin_opening and extra_energy_plan_improves(combat, gs):
        idx, _ = find_potion({"Energy Potion", "EnergyPotion"})
        if idx is not None:
            log("potion use energy for underpowered Lagavulin opening")
            return f"POTION use {idx}"

    book_escalation_window = (
        elite_fight
        and turn == 3
        and any(
            (monster.get("id") or monster.get("name")) == "BookOfStabbing"
            for monster in living
        )
    )
    if book_escalation_window and extra_energy_plan_improves(
        combat, gs, preserve_hp=True
    ):
        idx, _ = find_potion({"Energy Potion", "EnergyPotion"})
        if idx is not None:
            log("potion use energy before Book of Stabbing hit count escalates")
            return f"POTION use {idx}"

    hard_scaling_hallway = (
        room_type == "MonsterRoom"
        and act >= 2
        and len(living) >= 2
        and sum(
            int(monster.get("current_hp", 0) or 0)
            + int(monster.get("block", 0) or 0)
            for monster in living
        ) >= 90
        and bool(
            living_ids
            & {"Centurion", "Healer", "Sentry", "SphericGuardian"}
        )
    )
    unupgraded_demon_form = any(
        card_id(card) == "Demon Form"
        and card.get("is_playable")
        and card_cost(card) <= int(player.get("energy", 0) or 0)
        and int(card.get("upgrades", 0) or 0) <= 0
        for card in combat.get("hand", [])
    )
    if (
        turn <= 2
        and hp <= max_hp * 0.85
        and hard_scaling_hallway
        and unupgraded_demon_form
    ):
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None:
            # The logged Sentry/Spheric Guardian fight held Forge until death.
            # Demon Form+ gains another Strength every remaining turn, while
            # the rest of the opening hand receives its immediate upgrades.
            log("potion use forge for hard hallway Demon Form scaling")
            return f"POTION use {idx}"

    unupgraded_forge_hand = [
        card
        for card in combat.get("hand", [])
        if card.get("type") not in {"STATUS", "CURSE"}
        and int(card.get("upgrades", 0) or 0) <= 0
    ]
    a19_sentry_forge_opener = bool(
        int(gs.get("ascension_level", 0) or 0) >= 18
        and elite_fight
        and turn <= 1
        and hp <= max_hp * 0.55
        and sum(
            (monster.get("id") or monster.get("name")) == "Sentry"
            for monster in living
        ) >= 3
        and len(unupgraded_forge_hand) >= 4
    )
    if a19_sentry_forge_opener:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None:
            # Three Sentries turn the opening hand into the last clean draw
            # before Dazed cards dominate the cycle. At low reserve, upgrading
            # four or more live cards now is worth more than carrying Forge to
            # a later fight. The Cultist potion is handled earlier, so repeated
            # state updates deliberately drink it first and Forge second.
            log("potion use forge for low-reserve Sentry opening hand")
            return f"POTION use {idx}"
    forge_copies = sum(
        potion.get("id") == "BlessingOfTheForge"
        and potion.get("can_use", True)
        for potion in potions
    )
    if (
        turn <= 2
        and hp <= max_hp * 0.50
        and hard_scaling_hallway
        and len(unupgraded_forge_hand) >= 3
        and (
            forge_copies >= 2
            or projected_hp <= max(12, int(max_hp * 0.25))
            or incoming - block >= 10
        )
    ):
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None:
            # A spare Forge potion is already losing value while a mixed Act 2
            # hallway compounds block and Dazed. Upgrade the whole live hand
            # before attrition turns the potion into an unused run resource.
            log("potion use forge for low-reserve hard hallway hand")
            return f"POTION use {idx}"

    gremlin_leader_forge_control = (
        elite_fight
        and turn <= 4
        and hp <= max_hp * 0.75
        and len(living) >= 2
        and "GremlinLeader" in living_ids
        and int(player.get("energy", 0) or 0) >= 3
        and any(
            card_id(card) == "Disarm"
            and card.get("is_playable")
            and int(card.get("upgrades", 0) or 0) <= 0
            for card in combat.get("hand", [])
        )
        and any(
            card_id(card) == "Whirlwind"
            and card.get("is_playable")
            and int(card.get("upgrades", 0) or 0) <= 0
            for card in combat.get("hand", [])
        )
    )
    if gremlin_leader_forge_control:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None:
            # Disarm+ suppresses every later Leader multi-hit, while an
            # upgraded Whirlwind can still clear the current minion wave.
            log("potion use forge for Gremlin Leader Disarm Whirlwind control")
            return f"POTION use {idx}"

    if gs.get("room_type") == "MonsterRoomBoss":
        forge_values = {
            "Heavy Blade": 6,
            "Limit Break": 6,
            "Perfected Strike": 6,
            "Fiend Fire": 5,
            "Carnage": 4,
            "Spot Weakness": 4,
            "Corruption": 4,
            "Impervious": 4,
            "Offering": 3,
            "Flame Barrier": 3,
            "Feed": 3,
            "True Grit": 3,
            "Feel No Pain": 3,
            "Dark Embrace": 3,
            "Shockwave": 2,
            "Uppercut": 2,
            "Inflame": 2,
            "Body Slam": 2,
            "Pommel Strike": 1,
            "Bash": 1,
            "Strike_R": 1,
            "Defend_R": 1,
        }
        forge_value = sum(
            forge_values.get(card_id(card), 0)
            for card in combat.get("hand", [])
            if int(card.get("upgrades", 0) or 0) <= 0
        )
        if forge_value >= 5 and (turn <= 3 or incoming - block >= 8 or hp <= max_hp * 0.55):
            idx, _ = find_potion({"BlessingOfTheForge"})
            if idx is not None:
                return f"POTION use {idx}"

    early_bronze_fight = (
        danger
        and turn <= 2
        and (len(living) >= 2 or hp <= max_hp * 0.5 or gs.get("room_type") in {"MonsterRoomBoss", "MonsterRoomElite"})
    )
    if early_bronze_fight:
        idx, _ = find_potion({"LiquidBronze"})
        if idx is not None:
            return f"POTION use {idx}"

    target_hp = min(
        (monster.get("current_hp", 999) for monster in combat.get("monsters", []) if not monster.get("is_gone")),
        default=999,
    )
    lethal_available = any(
        card.get("type") == "ATTACK"
        and card.get("is_playable")
        and estimate_damage(card, int(player.get("energy", 0) or 0), block) >= target_hp
        for card in combat.get("hand", [])
    )
    lagavulin = next(
        (
            monster for monster in living
            if (monster.get("id") or monster.get("name")) == "Lagavulin"
        ),
        None,
    )
    player_strength = next(
        (
            int(power.get("amount", 0) or 0)
            for power in player.get("powers", [])
            if (power.get("id") or power.get("name")) == "Strength"
        ),
        0,
    )
    lagavulin_attrition_escape = bool(
        int(gs.get("ascension_level", 0) or 0) >= 18
        and elite_fight
        and lagavulin
        and (lagavulin.get("intent") or "") not in {"SLEEP", "DEBUG", "STUN"}
        and turn >= 8
        and player_strength <= -4
        and int(lagavulin.get("current_hp", 0) or 0) >= 20
        and hp <= max_hp * 0.75
        and boss_strength_scaling_source_count(gs) == 0
        and nonstarter_attack_count(gs) <= 2
        and not lethal_available
    )
    if lagavulin_attrition_escape:
        idx, _ = find_potion({"SmokeBomb"}, allow_reserved=True)
        if idx is not None:
            log(
                "potion use smoke bomb before terminal Lagavulin attrition "
                f"turn={turn} hp={hp}/{max_hp} enemy_hp={lagavulin.get('current_hp')} "
                f"strength={player_strength}"
            )
            return f"POTION use {idx}"

    proactive_hallway_escape = False
    planned_escape_loss = 0
    planned_escape_hp = hp
    if (
        ascension >= 17
        and act >= 2
        and room_type == "MonsterRoom"
        and turn >= 3
        and len(living) >= 2
        and len(usable_potions) == 1
        and normalized_potion_id(usable_potions[0]) == "SmokeBomb"
    ):
        try:
            if base_emergency_plan is None:
                base_emergency_plan = plan_turn(combat, gs)
            planned_escape_loss = int(base_emergency_plan.hp_loss)
            planned_escape_hp = hp - planned_escape_loss
            proactive_hallway_escape = bool(
                not base_emergency_plan.score[1]
                and planned_escape_loss >= max(12, int(max_hp * 0.18))
                and planned_escape_hp <= max(15, int(max_hp * 0.20))
            )
        except Exception:
            proactive_hallway_escape = False
    if proactive_hallway_escape:
        idx, _ = find_potion({"SmokeBomb"}, allow_reserved=True)
        if idx is not None:
            # A multi-enemy hallway can have a nominally surviving line that
            # spends nearly the entire remaining run reserve. Escape before
            # taking that damage when Smoke Bomb is the only usable potion.
            log(
                "potion use smoke bomb before terminal hallway attrition "
                f"turn={turn} hp={hp}/{max_hp} planned_loss={planned_escape_loss} "
                f"planned_hp={planned_escape_hp} enemies={len(living)}"
            )
            return f"POTION use {idx}"

    if incoming - block >= hp and gs.get("room_type") != "MonsterRoomBoss" and not lethal_available:
        idx, _ = find_potion({"SmokeBomb"})
        if idx is not None:
            return f"POTION use {idx}"

    if danger and incoming > block + 8 and not guardian_attack_canceled:
        idx, potion = find_potion({"Weak Potion"})
        if idx is not None:
            if potion.get("requires_target", True):
                weak_target = choose_weak_potion_target(
                    combat.get("monsters", []), target, turn=turn
                )
                critical_healer_pair = (
                    healer_pair_opening
                    and projected_hp <= max(8, int(max_hp * 0.12))
                )
                if critical_healer_pair:
                    centurion_index = next(
                        (
                            monster_index
                            for monster_index, monster in enumerate(
                                combat.get("monsters", [])
                            )
                            if not monster.get("is_gone")
                            and not monster.get("half_dead")
                            and int(monster.get("current_hp", 0) or 0) > 0
                            and (monster.get("id") or monster.get("name"))
                            == "Centurion"
                            and "ATTACK" in str(monster.get("intent") or "")
                        ),
                        None,
                    )
                    if centurion_index is not None:
                        weak_target = centurion_index
                        log(
                            "potion use weak on persistent Centurion at "
                            "critical support-fight reserve"
                        )
                return f"POTION use {idx} {weak_target}"
            return f"POTION use {idx}"

    has_debuff_intent = any(
        "DEBUFF" in (monster.get("intent") or "")
        for monster in combat.get("monsters", [])
        if not monster.get("is_gone")
    )
    if danger and has_debuff_intent and not has_power(player, {"Artifact"}):
        idx, _ = find_potion({"Ancient Potion"})
        if idx is not None:
            return f"POTION use {idx}"

    if danger and incoming > block + 8 and not guardian_attack_canceled:
        idx, _ = find_potion({"Block Potion"})
        if idx is not None:
            try:
                if base_emergency_plan is None:
                    base_emergency_plan = plan_turn(combat, gs)
                plan_avoids_hp_loss = int(base_emergency_plan.hp_loss) <= 0
            except Exception:
                plan_avoids_hp_loss = False
            block_retains = bool(
                "Calipers" in _relic_ids(gs)
                or has_power(player, {"Barricade"})
            )
            burning_blood_recovery = (
                6 if "Burning Blood" in _relic_ids(gs) else 0
            )
            forced_elite_potion_reserve = bool(
                ascension >= 18
                and act == 1
                and floor <= 8
                and gs.get("room_type") == "MonsterRoom"
                and hp >= int(max_hp * 0.80)
                and 0 < int(base_emergency_plan.hp_loss) <= burning_blood_recovery
                and hp - int(base_emergency_plan.hp_loss)
                >= int(max_hp * 0.65)
                and forced_elite_within_rooms(gs, max_rooms=2)
            )
            if (
                plan_avoids_hp_loss and not block_retains
                or forced_elite_potion_reserve
            ):
                log(
                    "potion preserve block: "
                    + (
                        "recoverable hallway loss before forced elite"
                        if forced_elite_potion_reserve
                        else "exact card plan already avoids all damage"
                    )
                )
            else:
                return f"POTION use {idx}"

    possible_block = sum(
        max(0, estimate_block(card, block))
        for card in combat.get("hand", [])
        if card.get("is_playable")
    )

    current_reserve = hp - max(0, incoming - block - possible_block)
    critical_reserve = current_reserve <= max(8, int(max_hp * 0.12))
    def decisive_plan_improvement(
        candidate_combat, *, hp_margin=None, control_margin=None
    ):
        nonlocal base_emergency_plan
        try:
            if base_emergency_plan is None:
                base_emergency_plan = plan_turn(combat, gs)
            candidate_plan = plan_turn(candidate_combat, gs)
        except Exception:
            return False
        if (
            candidate_plan.score[0] > base_emergency_plan.score[0]
            or candidate_plan.score[1] > base_emergency_plan.score[1]
        ):
            return True
        if (
            hp_margin is not None
            and candidate_plan.hp_loss + hp_margin <= base_emergency_plan.hp_loss
        ):
            return True
        return bool(
            control_margin is not None
            and len(candidate_plan.score) > 2
            and len(base_emergency_plan.score) > 2
            and candidate_plan.hp_loss <= base_emergency_plan.hp_loss
            and candidate_plan.score[2]
            >= base_emergency_plan.score[2] + control_margin
        )

    def potion_preview(
        extra_energy=0, forge=False, dexterity=0, strength=0,
        target_index=None, target_damage=0, target_vulnerable=0,
    ):
        preview = dict(combat)
        preview_player = dict(player)
        preview_player["energy"] = int(player.get("energy", 0) or 0) + extra_energy
        if dexterity or strength:
            preview_powers = [
                dict(raw_power) for raw_power in player.get("powers", [])
            ]
            for power_id, amount in (
                ("Dexterity", dexterity), ("Strength", strength),
            ):
                if not amount:
                    continue
                for raw_power in preview_powers:
                    if (raw_power.get("id") or raw_power.get("name")) == power_id:
                        raw_power["amount"] = (
                            int(raw_power.get("amount", 0) or 0) + amount
                        )
                        break
                else:
                    preview_powers.append({"id": power_id, "amount": amount})
            preview_player["powers"] = preview_powers
        preview["player"] = preview_player
        preview_hand = []
        current_energy = int(player.get("energy", 0) or 0)
        for raw_card in combat.get("hand", []):
            preview_card = dict(raw_card)
            if (
                forge and preview_card.get("type") not in {"STATUS", "CURSE"}
                and not int(preview_card.get("upgrades", 0) or 0)
            ):
                preview_card["upgrades"] = 1
                if (
                    card_id(preview_card) in UPGRADE_COST_REDUCTION_CARDS
                    and card_cost(preview_card) > 0
                    and not has_power(player, {"Confusion"})
                ):
                    preview_card["cost"] = card_cost(preview_card) - 1
                    if card_cost(preview_card) <= current_energy:
                        preview_card["is_playable"] = True
            if (
                extra_energy
                and not preview_card.get("is_playable")
                and preview_card.get("type") not in {"STATUS", "CURSE"}
                and current_energy < card_cost(preview_card) <= current_energy + extra_energy
            ):
                preview_card["is_playable"] = True
            preview_hand.append(preview_card)
        preview["hand"] = preview_hand
        if (
            target_damage > 0 or target_vulnerable > 0
        ) and isinstance(target_index, int):
            preview_monsters = []
            for index, raw_monster in enumerate(combat.get("monsters", [])):
                preview_monster = dict(raw_monster)
                if index == target_index:
                    if target_damage > 0:
                        monster_block = int(raw_monster.get("block", 0) or 0)
                        preview_monster["block"] = max(
                            0, monster_block - target_damage
                        )
                        preview_monster["current_hp"] = max(
                            0,
                            int(raw_monster.get("current_hp", 0) or 0)
                            - max(0, target_damage - monster_block),
                        )
                    if target_vulnerable > 0:
                        preview_powers = [
                            dict(power)
                            for power in raw_monster.get("powers", [])
                        ]
                        for power in preview_powers:
                            if (power.get("id") or power.get("name")) == "Vulnerable":
                                power["amount"] = (
                                    int(power.get("amount", 0) or 0)
                                    + target_vulnerable
                                )
                                break
                        else:
                            preview_powers.append(
                                {"id": "Vulnerable", "amount": target_vulnerable}
                            )
                        preview_monster["powers"] = preview_powers
                preview_monsters.append(preview_monster)
            preview["monsters"] = preview_monsters
        return preview

    a19_sentry_forge_pressure = bool(
        ascension >= 18
        and elite_fight
        and turn <= 2
        and incoming - block >= 10
        and sum(
            (monster.get("id") or monster.get("name")) == "Sentry"
            for monster in living
        ) >= 3
        and len(unupgraded_forge_hand) >= 4
    )
    a19_gremlin_leader_forge_pressure = bool(
        ascension >= 18
        and elite_fight
        and turn <= 2
        and "GremlinLeader" in living_ids
        and sum(
            (monster.get("id") or monster.get("name"))
            != "GremlinLeader"
            for monster in living
        ) >= 1
        and incoming - block >= 10
        and len(unupgraded_forge_hand) >= 3
    )
    if a19_gremlin_leader_forge_pressure:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None and decisive_plan_improvement(
            potion_preview(forge=True), hp_margin=6, control_margin=50,
        ):
            # Leader's opening minions grow whenever they are hit and the
            # following multi-hit can arrive immediately. Upgrade the whole
            # hand when exact replay either saves a meaningful hit or improves
            # the verified minion-control line, rather than carrying Forge to
            # a later turn where the summon cycle has already snowballed.
            log("potion use forge for Gremlin Leader opening control")
            return f"POTION use {idx}"

    if a19_sentry_forge_pressure:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None and decisive_plan_improvement(
            potion_preview(forge=True), control_margin=10,
        ):
            # The first two clean Sentry hands decide whether Dazed cards take
            # over the fight. Spend Forge when replay buys real focus progress.
            log("potion use forge for high-pressure Sentry focus race")
            return f"POTION use {idx}"

    if danger and incoming > block + 8 and not guardian_attack_canceled:
        has_playable_block = any(
            card.get("is_playable") and estimate_block(card, block) > 0
            for card in combat.get("hand", [])
        )
        if has_playable_block:
            idx, potion = find_potion({"SpeedPotion", "Dexterity Potion"})
            if idx is not None:
                potion_id = normalized_potion_id(potion)
                sacred_bark = bool(
                    _relic_ids(gs) & {"SacredBark", "Sacred Bark"}
                )
                dexterity = (
                    (10 if sacred_bark else 5)
                    if potion_id == "SpeedPotion"
                    else (4 if sacred_bark else 2)
                )
                try:
                    if base_emergency_plan is None:
                        base_emergency_plan = plan_turn(combat, gs)
                    dexterity_plan = plan_turn(
                        potion_preview(dexterity=dexterity), gs
                    )
                    hp_saved = (
                        base_emergency_plan.hp_loss - dexterity_plan.hp_loss
                    )
                    base_lethal = base_emergency_plan.hp_loss >= hp
                    meaningful_pressure = bool(
                        hp <= int(max_hp * 0.45)
                        or base_emergency_plan.hp_loss
                        >= max(12, int(max_hp * 0.15))
                        or shelled_multi_enemy_attrition
                    )
                    worth_spending = bool(
                        dexterity_plan.hp_loss < hp
                        and (
                            base_lethal
                            or meaningful_pressure and hp_saved >= 4
                        )
                    )
                except Exception:
                    worth_spending = False
                if worth_spending:
                    log(
                        "potion use dexterity after plan preview "
                        f"potion={potion_id} saved={hp_saved}"
                    )
                    return f"POTION use {idx}"

    whirlwind_ready = any(
        card_id(card) == "Whirlwind" and card.get("is_playable")
        for card in combat.get("hand", [])
    )
    imminent_gremlin_swarm = bool(
        gs.get("room_type") == "MonsterRoom"
        and turn <= 3
        and len(living) >= 3
        and incoming - block >= max(24, int(max_hp * 0.30))
        and any(
            (monster.get("id") or monster.get("name")) == "GremlinWizard"
            and "ATTACK" in str(monster.get("intent") or "")
            and int(monster.get("move_adjusted_damage", 0) or 0) >= 25
            for monster in living
        )
    )
    if whirlwind_ready and (imminent_gremlin_swarm or byrd_swarm_opening):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None and decisive_plan_improvement(
            potion_preview(extra_energy=2), hp_margin=6, control_margin=45
        ):
            # Extra energy scales Whirlwind itself, so the command count need not
            # increase. In the A17 Gremlin Gang loss it changed the exact plan
            # from 37 HP lost to 10 by killing the charged Wizard; against three
            # A17 Byrds the extra hits can also remove Flight before it snowballs.
            log("potion use energy for imminent Whirlwind swarm control")
            return f"POTION use {idx}"

    if (
        act == 1 and turn <= 2 and len(living) >= 2
        and all(monster.get("id") in {"FuzzyLouseNormal", "FuzzyLouseDefensive"}
                for monster in living)
        and incoming - block >= 12
    ):
        idx, potion = find_potion({"Explosive Potion"}, allow_reserved=True)
        if idx is not None:
            preview = dict(combat)
            damage = 20 if "SacredBark" in _relic_ids(gs) else 10
            preview_monsters = []
            for monster in combat.get("monsters", []):
                candidate = dict(monster)
                monster_block = int(monster.get("block", 0) or 0)
                candidate["block"] = max(0, monster_block - damage)
                candidate["current_hp"] = max(
                    0, int(monster.get("current_hp", 0) or 0)
                    - max(0, damage - monster_block)
                )
                preview_monsters.append(candidate)
            # Potion damage does not trigger Louse Curl Up. Replan attacks
            # against the real remaining HP instead of pricing it as chip.
            preview["monsters"] = preview_monsters
            if decisive_plan_improvement(preview, hp_margin=8, control_margin=50):
                log("potion explosive prevents high-pressure Louse opening loss")
                if potion.get("requires_target"):
                    return f"POTION use {idx} {target}"
                return f"POTION use {idx}"

    act1_growth_fire_window = bool(
        ascension >= 18
        and act == 1
        and room_type == "MonsterRoom"
        and turn <= 5
        and len(living) >= 2
        and incoming - block >= max(18, int(max_hp * 0.25))
        and projected_hp <= int(max_hp * 0.60)
    )
    if act1_growth_fire_window:
        idx, _ = find_potion(
            {"Fire Potion", "FirePotion"}, allow_reserved=True
        )
        if idx is not None:
            fire_damage = (
                40
                if _relic_ids(gs) & {"SacredBark", "Sacred Bark"}
                else 20
            )
            energy = int(player.get("energy", 0) or 0)
            best_finisher_damage = max(
                (
                    estimate_damage(card, energy, block)
                    for card in combat.get("hand", [])
                    if card.get("type") == "ATTACK"
                    and card.get("is_playable")
                    and card_cost(card) <= energy
                ),
                default=0,
            )
            growth_targets = [
                (index, monster)
                for index, monster in enumerate(combat.get("monsters", []))
                if not monster.get("is_gone")
                and not monster.get("half_dead")
                and int(monster.get("current_hp", 0) or 0) > 0
                and (monster.get("id") or monster.get("name"))
                in {"Cultist", "GremlinWizard"}
                and "ATTACK" in str(monster.get("intent") or "")
            ]
            growth_targets.sort(
                key=lambda item: (
                    int(item[1].get("move_adjusted_damage", 0) or 0)
                    * max(1, int(item[1].get("move_hits", 1) or 1)),
                    -int(item[1].get("current_hp", 0) or 0),
                ),
                reverse=True,
            )
            for growth_target, monster in growth_targets:
                target_health = (
                    int(monster.get("current_hp", 0) or 0)
                    + int(monster.get("block", 0) or 0)
                )
                if target_health > fire_damage + best_finisher_damage:
                    continue
                preview = potion_preview(
                    target_index=growth_target,
                    target_damage=fire_damage,
                )
                if decisive_plan_improvement(
                    preview, hp_margin=8, control_margin=50
                ):
                    log(
                        "potion use fire plus attack to finish Act 1 "
                        f"growth threat target={growth_target} "
                        f"hp={target_health} incoming={incoming - block}"
                    )
                    return f"POTION use {idx} {growth_target}"

    book_forge_window = (
        dangerous_elite
        and turn <= 3
        and "BookOfStabbing" in living_ids
        and (
            hp <= max_hp * 0.45
            or hp - max(0, incoming - block) <= max(12, int(max_hp * 0.30))
        )
    )
    slaver_forge_window = (
        dangerous_elite and "SlaverRed" in living_ids
        and incoming - block >= max(15, int(max_hp * 0.25))
    )
    shape_forge_escape = (
        room_type == "MonsterRoom"
        and act >= 3
        and turn <= 3
        and len(living) >= 3
        and "Exploder" in living_ids
        and hp <= int(max_hp * 0.45)
        and incoming - block >= max(18, int(max_hp * 0.22))
        and sum(
            card.get("type") == "ATTACK"
            and card.get("is_playable")
            and int(card.get("upgrades", 0) or 0) == 0
            for card in combat.get("hand", [])
        ) >= 2
    )
    if shape_forge_escape:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None and decisive_plan_improvement(
            potion_preview(forge=True), hp_margin=6, control_margin=45
        ):
            # Upgrade the complete attack pair only when the replay proves it
            # removes the Exploder and preserves a meaningful extra reserve.
            log("potion use forge for low-reserve Shapes escape")
            return f"POTION use {idx}"

    if book_forge_window or slaver_forge_window:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None and decisive_plan_improvement(
            potion_preview(forge=True),
            hp_margin=5 if slaver_forge_window else 2,
            control_margin=60 if slaver_forge_window else 8,
        ):
            # Uppercut+ carries Weak through Book's next escalating multi-hit.
            # Compare the complete upgraded hand so block upgrades count too.
            log("potion use forge for elite opening damage/control")
            return f"POTION use {idx}"

    if danger and (incoming - block >= hp or critical_reserve):
        idx, _ = find_potion({"Energy Potion", "EnergyPotion"})
        if idx is not None and decisive_plan_improvement(potion_preview(extra_energy=2)):
            # Re-run the complete hand search with the extra energy. This
            # catches lethal sequences hidden behind a final expensive card,
            # such as the logged Snecko Pommel Strike into Headbutt finish.
            return f"POTION use {idx}"

        idx, _ = find_potion({"BlessingOfTheForge"})
        if idx is not None and decisive_plan_improvement(potion_preview(forge=True)):
            # Forge is also a defensive potion when an upgraded block changes
            # a lethal hallway turn into a surviving one.
            return f"POTION use {idx}"

    if danger and critical_reserve:
        idx, _ = find_potion({"Energy Potion", "EnergyPotion"})
        if idx is not None:
            energy = int(player.get("energy", 0) or 0)
            weak = has_power(player, {"Weakened"})
            emergency_block_ids = {
                "Armaments", "Defend_R", "Entrench", "Flame Barrier",
                "Ghostly Armor", "Impervious", "Iron Wave", "Power Through",
                "Second Wind", "Shrug It Off", "True Grit",
            }
            for reaper in combat.get("hand", []):
                if card_id(reaper) != "Reaper":
                    continue
                reaper_cost = card_cost(reaper)
                if not energy < reaper_cost <= energy + 2 or len(living) < 2:
                    continue

                hit = max(
                    0,
                    4
                    + min(1, int(reaper.get("upgrades", 0) or 0))
                    + strength,
                )
                if weak:
                    hit = int(hit * 0.75)
                healing = sum(min(hit, int(monster.get("current_hp", 0) or 0)) for monster in living)
                block_budget = energy + 2 - reaper_cost
                best_block = [0] * (block_budget + 1)
                for candidate in combat.get("hand", []):
                    if candidate is reaper or card_id(candidate) not in emergency_block_ids:
                        continue
                    cost = card_cost(candidate)
                    if cost > block_budget:
                        continue
                    gained = max(0, estimate_block(candidate, block))
                    for budget in range(block_budget, cost - 1, -1):
                        best_block[budget] = max(
                            best_block[budget],
                            best_block[budget - cost] + gained,
                        )
                boosted_hp = min(max_hp, hp + healing)
                boosted_reserve = boosted_hp - max(
                    0,
                    incoming - block - max(best_block),
                )
                if (
                    healing >= 6
                    and boosted_reserve >= max(8, int(max_hp * 0.10))
                    and boosted_reserve >= current_reserve + 5
                ):
                    # Re-evaluation after the potion lets the normal planner
                    # sequence Reaper and the affordable block card correctly.
                    return f"POTION use {idx}"

    formal_gamble_emergency = incoming - block >= hp
    proactive_hallway_gamble = (
        room_type == "MonsterRoom"
        and act >= 2
        and turn <= 2
        and possible_block == 0
        and incoming - block >= max(24, int(max_hp * 0.30))
    )
    gamble_pressure_ids = {
        "BookOfStabbing", "GremlinLeader", "Reptomancer",
        "SlaverBlue", "SlaverBoss", "SlaverRed", "Byrd", "Chosen",
        "Centurion", "Healer", "Maw", "OrbWalker", "Serpent",
        "Looter", "Mugger",
        "Shelled Parasite", "Shell Parasite", "SnakePlant", "Snecko",
        "SphericGuardian", "Spiker", "Transient", "WrithingMass",
    }
    proactive_multi_enemy_gamble = (
        room_type == "MonsterRoom"
        and act >= 2
        and turn <= 2
        and len(living) >= 2
        and incoming - block >= max(18, int(max_hp * 0.20))
        and projected_hp <= max(30, int(max_hp * 0.45))
        and any(
            (monster.get("id") or monster.get("name")) in gamble_pressure_ids
            for monster in living
        )
    )
    proactive_thief_gamble = (
        proactive_multi_enemy_gamble
        and any(
            (monster.get("id") or monster.get("name")) in {"Looter", "Mugger"}
            for monster in living
        )
    )
    proactive_low_reserve_gamble = (
        room_type in {"MonsterRoom", "MonsterRoomElite"}
        and act >= 2
        and turn <= 3
        and hp <= int(max_hp * 0.45)
        and incoming - block >= max(10, int(max_hp * 0.12))
        and projected_hp <= max(12, int(max_hp * 0.18))
        and any(
            (monster.get("id") or monster.get("name")) in gamble_pressure_ids
            for monster in living
        )
    )
    book_exact_gamble = (
        elite_fight
        and act >= 2
        and turn <= 3
        and "BookOfStabbing" in living_ids
        and incoming - block >= 10
        and projected_hp <= max(30, int(max_hp * 0.40))
    )
    guardian_preimpact_gamble = (
        boss_fight
        and act == 1
        and turn <= 3
        and "TheGuardian" in living_ids
        and incoming - block >= max(30, int(max_hp * 0.38))
        and 0 < len(combat.get("hand", [])) <= 6
        and bool(combat.get("draw_pile"))
    )
    spheric_attrition_gamble = (
        room_type == "MonsterRoom"
        and act >= 2
        and turn <= 6
        and "SphericGuardian" in living_ids
        and incoming - block >= max(18, int(max_hp * 0.20))
        and hp <= int(max_hp * 0.80)
        and 0 < len(combat.get("hand", [])) <= 6
        and bool(combat.get("draw_pile"))
    )
    boss_attrition_gamble = (
        boss_fight
        and turn >= 2
        and incoming - block >= max(18, int(max_hp * 0.20))
        and 0 < len(combat.get("hand", [])) <= 6
        and bool(combat.get("draw_pile"))
    )
    if (
        formal_gamble_emergency
        or proactive_hallway_gamble
        or proactive_multi_enemy_gamble
        or proactive_low_reserve_gamble
        or book_exact_gamble
        or guardian_preimpact_gamble
        or spheric_attrition_gamble
        or boss_attrition_gamble
    ):
        idx, _ = find_potion({"GamblersBrew"})
        if idx is not None:
            planned_reserve = None
            has_surviving_line = False
            plan_wins = False
            try:
                if base_emergency_plan is None:
                    base_emergency_plan = plan_turn(combat, gs)
                has_surviving_line = bool(base_emergency_plan.score[0])
                plan_wins = bool(base_emergency_plan.score[1])
                planned_reserve = hp - int(base_emergency_plan.hp_loss)
            except Exception:
                pass
            known_redraw = known_top_draw_cards(
                combat,
                min(len(combat.get("hand", [])), len(combat.get("draw_pile", []))),
            )
            known_defensive_out = any(
                estimate_block(card, block) > 0
                or card_id(card) in {
                    "Battle Trance", "Offering", "Pommel Strike",
                    "Shrug It Off", "Dark Shackles", "Disarm",
                    "Intimidate", "Shockwave", "Uppercut",
                }
                for card in known_redraw
            )
            known_direct_block = sum(
                estimate_block(card, block) > 0
                for card in known_redraw
            )
            confused = has_power(player, {"Confusion"})
            exact_gamble_plan = None
            if not has_surviving_line or (
                proactive_low_reserve_gamble
                and not confused
            ) or (
                proactive_thief_gamble
                and not confused
            ) or (
                book_exact_gamble
                and not confused
            ) or (
                guardian_preimpact_gamble
                and not confused
            ) or (
                spheric_attrition_gamble
                and not confused
            ) or (
                boss_attrition_gamble
                and not confused
            ) or (
                elite_fight
                and planned_reserve is not None
                and planned_reserve <= 0
                and not confused
            ):
                exact_gamble_plan = exact_gamblers_brew_selection(combat, gs)
            anticipatory_boss_gamble = (
                has_surviving_line
                and not plan_wins
                and boss_fight
                and planned_reserve is not None
                and planned_reserve <= max(10, int(max_hp * 0.15))
                and known_defensive_out
            )
            anticipatory_byrd_gamble = (
                has_surviving_line
                and not plan_wins
                and act >= 2
                and room_type == "MonsterRoom"
                and turn <= 2
                and sum(
                    (monster.get("id") or monster.get("name")) == "Byrd"
                    for monster in living
                ) >= 3
                and planned_reserve is not None
                and planned_reserve <= max(12, int(max_hp * 0.18))
                and known_defensive_out
            )
            anticipatory_gamble = (
                anticipatory_boss_gamble or anticipatory_byrd_gamble
            )
            boss_attrition_redraw = bool(
                boss_attrition_gamble
                and exact_gamble_plan
                and exact_gamble_plan["survives"]
                and base_emergency_plan is not None
                and base_emergency_plan.hp_loss
                >= max(16, int(max_hp * 0.18))
                and exact_gamble_plan["planned_hp_loss"]
                + max(8, int(max_hp * 0.09))
                <= base_emergency_plan.hp_loss
            )
            proactive_block_redraw = (
                proactive_hallway_gamble
                and has_surviving_line
                and not plan_wins
                and planned_reserve is not None
                and hp - planned_reserve
                >= max(18, int(max_hp * 0.24))
                and known_direct_block >= 2
            )
            proactive_critical_redraw = (
                proactive_low_reserve_gamble
                and has_surviving_line
                and not plan_wins
                and planned_reserve is not None
                and planned_reserve <= max(16, int(max_hp * 0.22))
                and known_direct_block >= 2
            )
            book_preimpact_redraw = bool(
                book_exact_gamble
                and exact_gamble_plan
                and exact_gamble_plan["survives"]
                and base_emergency_plan is not None
                and exact_gamble_plan["planned_hp_loss"]
                + max(6, int(max_hp * 0.08))
                <= base_emergency_plan.hp_loss
            )
            multi_enemy_preimpact_redraw = bool(
                proactive_thief_gamble
                and exact_gamble_plan
                and exact_gamble_plan["survives"]
                and base_emergency_plan is not None
                and base_emergency_plan.hp_loss
                >= max(10, int(max_hp * 0.12))
                and exact_gamble_plan["planned_hp_loss"]
                + max(6, int(max_hp * 0.08))
                <= base_emergency_plan.hp_loss
            )
            revive_preserving_elite_redraw = bool(
                elite_fight
                and planned_reserve is not None
                and planned_reserve <= 0
                and exact_gamble_plan
                and exact_gamble_plan["survives"]
                and exact_gamble_plan["planned_hp_loss"] < hp
            )
            guardian_preimpact_redraw = bool(
                guardian_preimpact_gamble
                and not plan_wins
                and known_direct_block >= 2
                and exact_gamble_plan
                and exact_gamble_plan["survives"]
                and base_emergency_plan is not None
                and base_emergency_plan.hp_loss
                >= max(18, int(max_hp * 0.24))
                and exact_gamble_plan["planned_hp_loss"]
                + max(12, int(max_hp * 0.15))
                <= base_emergency_plan.hp_loss
            )
            spheric_preimpact_redraw = bool(
                spheric_attrition_gamble
                and not plan_wins
                and exact_gamble_plan
                and exact_gamble_plan["survives"]
                and base_emergency_plan is not None
                and base_emergency_plan.hp_loss
                >= max(12, int(max_hp * 0.14))
                and exact_gamble_plan["planned_hp_loss"]
                + max(8, int(max_hp * 0.10))
                <= base_emergency_plan.hp_loss
            )
            if (
                not has_surviving_line
                or anticipatory_gamble
                or boss_attrition_redraw
                or proactive_block_redraw
                or proactive_critical_redraw
                or book_preimpact_redraw
                or multi_enemy_preimpact_redraw
                or revive_preserving_elite_redraw
                or guardian_preimpact_redraw
                or spheric_preimpact_redraw
            ):
                if (
                    anticipatory_gamble
                    or boss_attrition_redraw
                    or proactive_block_redraw
                    or proactive_critical_redraw
                    or book_preimpact_redraw
                    or multi_enemy_preimpact_redraw
                    or revive_preserving_elite_redraw
                    or guardian_preimpact_redraw
                    or spheric_preimpact_redraw
                ):
                    reason = (
                        "boss_attrition"
                        if boss_attrition_redraw
                        else "act2_hallway_block_redraw"
                        if proactive_block_redraw
                        else "critical_reserve_redraw"
                        if proactive_critical_redraw
                        else "multi_enemy_preimpact"
                        if multi_enemy_preimpact_redraw
                        else "book_preimpact"
                        if book_preimpact_redraw
                        else "preserve_revive"
                        if revive_preserving_elite_redraw
                        else "guardian_preimpact"
                        if guardian_preimpact_redraw
                        else "spheric_attrition"
                        if spheric_preimpact_redraw
                        else "boss"
                        if anticipatory_boss_gamble
                        else "byrd_swarm"
                    )
                    log(
                        "gamblers brew before impact "
                        f"reason={reason} "
                        f"planned_reserve={planned_reserve}/{max_hp} "
                        f"known_top={[card_id(card) for card in known_redraw]}"
                    )
                exact_survival_redraw = bool(
                    exact_gamble_plan and exact_gamble_plan["survives"]
                )
                full_exact_redraw = bool(
                    exact_survival_redraw
                    and len(exact_gamble_plan["discard_keys"])
                    == len(combat.get("hand", []))
                )
                if full_exact_redraw:
                    HAND_SELECT_MODE = "gamblers_brew_all"
                    log(
                        "gamblers brew full-hand survival redraw "
                        f"known_top={[card_id(card) for card in known_redraw]}"
                    )
                elif exact_survival_redraw:
                    HAND_SELECT_MODE = exact_gamble_plan
                    log(
                        "gamblers brew exact survival subset "
                        f"discard={exact_gamble_plan['discard_ids']} "
                        f"keep={exact_gamble_plan['keep_ids']} "
                        f"draw={exact_gamble_plan['draw_ids']} "
                        f"planned_hp_loss={exact_gamble_plan['planned_hp_loss']}"
                    )
                else:
                    HAND_SELECT_MODE = "gamblers_brew"
                return f"POTION use {idx}"

    hand_statuses = sum(
        1
        for card in combat.get("hand", [])
        if card.get("type") in {"STATUS", "CURSE"}
    )
    playable_status_cleanup = bool(
        "Medical Kit" in _relic_ids(gs)
        or any(
            card_id(card) in {"Fiend Fire", "Second Wind", "Sever Soul"}
            and card.get("is_playable")
            and card_cost(card) <= int(player.get("energy", 0) or 0)
            for card in combat.get("hand", [])
        )
    )
    if danger and hand_statuses >= 2:
        if playable_status_cleanup:
            log("potion preserve elixir: playable status cleanup is already in hand")
        else:
            idx, _ = find_potion({"ElixirPotion"})
            if idx is not None:
                return f"POTION use {idx}"

    low_reserve_hallway = (
        room_type == "MonsterRoom"
        and hp <= max_hp * 0.35
        and incoming - block >= max(10, int(max_hp * 0.10))
    )
    hard_hallway_ids = {
        "Byrd", "Chosen", "Centurion", "Healer", "Maw", "OrbWalker",
        "Serpent", "Shelled Parasite", "Shell Parasite", "SnakePlant",
        "Snecko", "SphericGuardian", "Spiker", "Transient", "WrithingMass",
    }
    hard_hallway = (
        room_type == "MonsterRoom"
        and act >= 2
        and any(
            (monster.get("id") or monster.get("name")) in hard_hallway_ids
            for monster in living
        )
        and (incoming - block >= 8 or turn <= 2)
    )
    imminent_burst_hallway = (
        room_type == "MonsterRoom"
        and max(0, incoming - block) >= max(24, int(max_hp * 0.30))
        and projected_hp <= max(18, int(max_hp * 0.25))
    )
    high_stakes_consumable = (
        boss_fight
        or elite_fight
        or ritual_swarm_opening
        or critical_reserve
        or low_reserve_hallway
        or imminent_burst_hallway
        or late_preboss_hallway
        or hard_hallway
    )
    active_hallway_attack = max(0, incoming - block) >= 8
    meaningful_hallway_threat = (
        low_reserve_hallway
        or hard_hallway and active_hallway_attack
        or late_preboss_hallway
        and projected_hp <= max(24, int(max_hp * 0.45))
    )
    defensive_potion_window = (
        boss_fight
        or elite_fight
        or critical_reserve
        or meaningful_hallway_threat
    )
    if defensive_potion_window and not has_power(
        player, {"Plated Armor", "Metallicize"}
    ):
        idx, _ = find_potion({"EssenceOfSteel", "HeartOfIron"})
        if idx is not None:
            planned_loss = None
            try:
                if base_emergency_plan is None:
                    base_emergency_plan = plan_turn(combat, gs)
                planned_loss = int(base_emergency_plan.hp_loss)
            except Exception:
                pass
            reserve_setup_for_forced_elite = bool(
                room_type == "MonsterRoom"
                and immediate_next_room_is_forced(gs, "R")
                and forced_elite_within_rooms(gs, max_rooms=2)
                and not critical_reserve
                and planned_loss is not None
                and planned_loss <= max(8, int(max_hp * 0.10))
                and hp - planned_loss >= max(12, int(max_hp * 0.18))
            )
            if reserve_setup_for_forced_elite:
                # At 26 HP the logged A16 Snecko line already survived its
                # eight-loss plan and had a guaranteed campfire next. Holding
                # Heart of Iron for the forced Slavers fight was worth far more
                # than reducing that hallway turn.
                log(
                    "potion preserve plated setup for forced elite after rest "
                    f"planned_loss={planned_loss} hp={hp}/{max_hp}"
                )
            elif red_skull_card_should_precede_ornithopter_heal(gs, combat):
                # Drinking first heals across Red Skull's half-HP threshold.
                # Let the planner spend the currently amplified attack, then
                # re-evaluate and drink before ending the same turn.
                log("potion defer defensive setup until Red Skull payoff")
            else:
                return f"POTION use {idx}"

    scaling_potion_window = (
        boss_fight
        or elite_fight
        or ritual_swarm_opening
        or critical_reserve
        or low_reserve_hallway
        or hard_hallway and active_hallway_attack
        or late_preboss_hallway
        and projected_hp <= max(24, int(max_hp * 0.45))
    )
    if danger and (critical_reserve or low_reserve_hallway):
        # A tactical Colorless card is useful one turn before literal lethal.
        # In the v70 Centurion fight the bot waited at 31/105 through a
        # 12-damage turn, then drank Colorless only after falling to 19 HP.
        # Use it while there is still enough reserve for Blind, Panic Button,
        # Finesse, or another generated answer to alter the fight.
        idx, potion = find_potion({"ColorlessPotion"}, allow_reserved=True)
        if idx is None and critical_reserve:
            # Power Potion is less reliable as an immediate defensive answer,
            # so keep its old projected-lethal threshold.
            idx, potion = find_potion({"PowerPotion"}, allow_reserved=True)
        if idx is not None:
            if potion.get("requires_target"):
                return f"POTION use {idx} {target}"
            return f"POTION use {idx}"

    playable_attacks = [
        card
        for card in combat.get("hand", [])
        if card.get("type") == "ATTACK"
        and card.get("is_playable")
        and card_cost(card) <= int(player.get("energy", 0) or 0)
    ]
    planned_loss = max(0, incoming - block - possible_block)
    try:
        if base_emergency_plan is None:
            base_emergency_plan = plan_turn(combat, gs)
        planned_loss = int(base_emergency_plan.hp_loss)
    except Exception:
        pass

    severe_hallway_attrition = (
        hard_hallway
        and active_hallway_attack
        and planned_loss >= max(12, int(max_hp * 0.15))
        and hp - planned_loss <= max(24, int(max_hp * 0.30))
        and len(unupgraded_forge_hand) >= 3
    )
    if severe_hallway_attrition:
        idx, _ = find_potion({"BlessingOfTheForge"}, allow_reserved=True)
        if idx is not None and decisive_plan_improvement(
            potion_preview(forge=True), hp_margin=3, control_margin=18
        ):
            # Price the exact line's loss before it becomes literal lethal.
            # The A17 Snake Plant hand could save HP and upgrade Blood for
            # Blood, three Strikes and Defend, but kept Forge for a future
            # elite until only two HP remained.
            log(
                "potion use forge before severe hard-hallway attrition "
                f"planned_loss={planned_loss} reserve={hp - planned_loss}/{max_hp}"
            )
            return f"POTION use {idx}"

    monsters = combat.get("monsters", [])
    fear_target = target if isinstance(target, int) else 0
    planned_fear_target = planned_attack_focus_target(
        combat, gs, base_emergency_plan
    )
    if planned_fear_target is not None:
        # The old static target chooser could throw Fear at the current attacker
        # while the exact turn plan focused every attack elsewhere. Align the
        # debuff with the damage that will actually follow it.
        fear_target = planned_fear_target
    elif elite_fight:
        red_slaver_target = next(
            (
                index
                for index, monster in enumerate(monsters)
                if (monster.get("id") or monster.get("name")) == "SlaverRed"
                and not monster.get("is_gone")
                and not monster.get("half_dead")
                and int(monster.get("current_hp", 0) or 0) > 0
            ),
            None,
        )
        if red_slaver_target is not None:
            fear_target = red_slaver_target
    collector_target = next(
        (
            index
            for index, monster in enumerate(monsters)
            if (monster.get("id") or monster.get("name")) == "TheCollector"
            and not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            and not any(
                (power.get("id") or power.get("name")) == "Vulnerable"
                and int(power.get("amount", 0) or 0) > 0
                for power in monster.get("powers", [])
            )
        ),
        None,
    )
    collector_swarm_survival_focus = bool(
        boss_fight
        and collector_target is not None
        and planned_fear_target is not None
        and planned_fear_target != collector_target
        and 0 <= planned_fear_target < len(monsters)
        and (
            monsters[planned_fear_target].get("id")
            or monsters[planned_fear_target].get("name")
        ) == "TorchHead"
        and sum(
            (monster.get("id") or monster.get("name")) == "TorchHead"
            and not monster.get("is_gone")
            and not monster.get("half_dead")
            and int(monster.get("current_hp", 0) or 0) > 0
            for monster in monsters
        ) >= 2
        and max(0, incoming - block) >= max(24, int(max_hp * 0.35))
        and planned_loss >= max(12, int(max_hp * 0.18))
        and hp - planned_loss <= max(24, int(max_hp * 0.40))
    )
    if (
        boss_fight
        and collector_target is not None
        and not collector_swarm_survival_focus
    ):
        # Torch Heads are disposable and can be resummoned. Fear belongs on the
        # durable boss so all three vulnerable turns can convert into progress.
        # The exception is an immediately dangerous opening where the exact
        # plan already focuses a Torch Head and otherwise leaves only a single
        # hit of reserve. In that window, Vulnerable must help remove the
        # current attacker instead of missing every attack in the hand.
        fear_target = collector_target
    fear_monster = (
        monsters[fear_target]
        if 0 <= fear_target < len(monsters)
        else None
    )
    fear_target_hp = (
        int(fear_monster.get("current_hp", 0) or 0)
        + int(fear_monster.get("block", 0) or 0)
        if fear_monster is not None
        else 0
    )
    fear_target_already_vulnerable = bool(
        fear_monster
        and any(
            (power.get("id") or power.get("name")) == "Vulnerable"
            and int(power.get("amount", 0) or 0) > 0
            for power in fear_monster.get("powers", [])
        )
    )
    mixed_ritual_fear_window = bool(
        ascension >= 17
        and act == 2
        and room_type == "MonsterRoom"
        and turn == 1
        and len(living) == 2
        and {
            monster.get("id") or monster.get("name") for monster in living
        } == {"Cultist", "Chosen"}
        and fear_monster is not None
        and (fear_monster.get("id") or fear_monster.get("name")) == "Cultist"
        and len(playable_attacks) >= 2
        and not fear_target_already_vulnerable
    )
    if mixed_ritual_fear_window:
        idx, potion = find_potion({"FearPotion"}, allow_reserved=True)
        vulnerable = 6 if _relic_ids(gs) & {"SacredBark", "Sacred Bark"} else 3
        if idx is not None and decisive_plan_improvement(
            potion_preview(
                target_index=fear_target,
                target_vulnerable=vulnerable,
            ),
            control_margin=60,
        ):
            # In the logged A20 pair, Double Tap plus Perfected Strike left the
            # quiet Cultist at seven HP. Fear first makes that same hand lethal,
            # removing Ritual before its first attack instead of saving the
            # potion until the Chosen has already taken most of the run's HP.
            log("potion use fear to finish mixed Cultist opening")
            if potion.get("requires_target", True):
                return f"POTION use {idx} {fear_target}"
            return f"POTION use {idx}"
    fear_commit = bool(
        boss_fight
        or elite_fight
        or ritual_swarm_opening
        or planned_loss >= max(6, int(max_hp * 0.08))
    )
    champ_first_phase_fear_reserve = any(
        (monster.get("id") or monster.get("name")) == "Champ"
        and int(monster.get("current_hp", 0) or 0)
        > int(monster.get("max_hp", 0) or 0) // 2
        for monster in living
    )
    reserve_fear_for_forced_elite = bool(
        room_type == "MonsterRoom"
        and immediate_next_room_is_forced(gs, "R")
        and forced_elite_within_rooms(gs, max_rooms=2)
        and not ritual_swarm_opening
        and planned_loss <= max(5, int(max_hp * 0.07))
    )
    if (
        high_stakes_consumable
        and len(playable_attacks) >= 2
        and fear_commit
        and not champ_first_phase_fear_reserve
        and not reserve_fear_for_forced_elite
        and fear_target_hp >= 12
        and not fear_target_already_vulnerable
    ):
        idx, potion = find_potion({"FearPotion"})
        if idx is not None:
            if potion.get("requires_target", True):
                return f"POTION use {idx} {fear_target}"
            return f"POTION use {idx}"

    critical_snake_plant_setup = (
        room_type == "MonsterRoom"
        and turn <= 2
        and hp <= max(18, int(max_hp * 0.25))
        and any(
            (monster.get("id") or monster.get("name")) == "SnakePlant"
            and "ATTACK" not in str(monster.get("intent") or "")
            for monster in living
        )
    )
    if (
        critical_snake_plant_setup
        and extra_energy_plan_improves(combat, gs)
    ):
        idx, _ = find_potion(
            {"Energy Potion", "EnergyPotion"}, allow_reserved=True
        )
        if idx is not None:
            # The exact draw can turn a quiet debuff turn into both immediate
            # offense and a Feel No Pain engine for the next two multi-hits.
            log("potion use energy for critical Snake Plant exhaust setup")
            return f"POTION use {idx}"
    shelled_defensive_hold = bool(
        turn <= 2
        and incoming - block >= 10
        and any(
            (monster.get("id") or monster.get("name"))
            in {"Shelled Parasite", "Shell Parasite"}
            and any(
                (power.get("id") or power.get("name")) == "Plated Armor"
                and int(power.get("amount", 0) or 0) >= 10
                for power in monster.get("powers", [])
            )
            for monster in living
        )
        and any(
            card.get("is_playable")
            and card_id(card) in {"Flame Barrier", "Power Through", "Impervious"}
            for card in combat.get("hand", [])
        )
    )
    if (
        high_stakes_consumable
        and len(playable_attacks) >= 2
        and not shelled_defensive_hold
    ):
        potion_ids = {"SteroidPotion"}
        if critical_snake_plant_setup:
            # CommunicationMod exposes the ordinary Strength Potion under its
            # display-style ID. Spend that persistent potion only in the logged
            # critical Snake Plant window; healthy hallway fights still keep it
            # for a boss or a real Strength combo.
            potion_ids.add("Strength Potion")
        idx, _ = find_potion(potion_ids)
        if idx is not None:
            preserve_critical_steroid = False
            if critical_reserve or hp <= max(12, int(max_hp * 0.18)):
                try:
                    if base_emergency_plan is None:
                        base_emergency_plan = plan_turn(combat, gs)
                    steroid_strength = (
                        10
                        if _relic_ids(gs) & {"SacredBark", "Sacred Bark"}
                        else 5
                    )
                    steroid_plan = plan_turn(
                        potion_preview(strength=steroid_strength), gs
                    )
                    preserve_critical_steroid = bool(
                        base_emergency_plan.score[0]
                        and not steroid_plan.score[1]
                        and steroid_plan.hp_loss > base_emergency_plan.hp_loss
                    )
                except Exception:
                    pass
            if preserve_critical_steroid:
                log(
                    "potion preserve steroid: strength line worsens critical "
                    f"turn hp_loss={base_emergency_plan.hp_loss}->"
                    f"{steroid_plan.hp_loss}"
                )
            elif critical_snake_plant_setup:
                log("potion use strength in critical Snake Plant setup window")
                return f"POTION use {idx}"
            else:
                return f"POTION use {idx}"

    # Entropic Brew is strongest when it can immediately turn several empty
    # slots into tactical answers. Use it in dangerous Act 2/3 elite openings,
    # and also in a critical hallway where saving it has no future value if the
    # next ordinary attack kills the run.
    empty_potion_slots = sum(
        potion.get("id") == "Potion Slot" for potion in potions
    )
    entropic_generation = empty_potion_slots + 1  # its own slot becomes empty
    critical_hallway = (
        room_type == "MonsterRoom"
        and act >= 2
        and hp <= max(18, int(max_hp * 0.22))
    )
    lethal_hallway_entropic = (
        critical_hallway and max(0, incoming - block) >= hp
    )
    opening_entropic = (
        turn <= 2 and (dangerous_elite and act >= 2 or critical_hallway)
    )
    if (
        (opening_entropic or lethal_hallway_entropic)
        and entropic_generation >= 2
    ):
        command = entropic_brew_command(allow_reserved=True)
        if command:
            return command

    if gs.get("room_type") == "MonsterRoomBoss":
        entropic_needs_space = bool(potions) and all(
            normalized_potion_id(potion) != "Potion Slot"
            for potion in potions
        ) and any(
            normalized_potion_id(potion) == "EntropicBrew"
            for potion in potions
        )
        liquid_memories_idx, liquid_memories_potion = find_potion(
            {"LiquidMemories"}
        )
        if (
            turn > 1
            and liquid_memories_idx is not None
            and (
                entropic_needs_space
                or (
                    not guardian_attack_canceled
                    and liquid_memories_tactical_window(
                        combat, gs, hp, incoming, block
                    )
                )
            )
        ):
            GRID_SELECT_MODE = "liquid_memories"
            if liquid_memories_potion.get("requires_target"):
                return f"POTION use {liquid_memories_idx} {target}"
            return f"POTION use {liquid_memories_idx}"
        idx, potion = find_potion({"PowerPotion", "ColorlessPotion"})
        if idx is not None:
            if potion.get("requires_target"):
                return f"POTION use {idx} {target}"
            return f"POTION use {idx}"
        command = entropic_brew_command()
        if command:
            return command

    if scaling_potion_window and turn <= 2 and not has_power(player, {"Ritual"}):
        idx, _ = find_potion({"CultistPotion"})
        if idx is not None:
            return f"POTION use {idx}"

    if scaling_potion_window and not has_power(player, {"Strength"}):
        idx, _ = find_potion({"Strength Potion"})
        if idx is not None:
            preserve_healthy_hallway_strength = bool(
                room_type == "MonsterRoom"
                and len(living) == 1
                and hp >= int(max_hp * 0.72)
                and planned_loss <= max(3, int(max_hp * 0.05))
            )
            if preserve_healthy_hallway_strength:
                # The A19 Chosen line was already losing only one HP, yet spent
                # its persistent Strength potion and immediately entered three
                # Byrds without it. Keep the potion when the exact hallway plan
                # is cheap; the dedicated swarm opener above will spend it.
                log(
                    "potion preserve strength after cheap healthy hallway plan "
                    f"planned_loss={planned_loss} hp={hp}/{max_hp}"
                )
            else:
                return f"POTION use {idx}"

    low_reserve_generated_opening = (
        turn <= 2
        and (
            elite_fight and hp <= int(max_hp * 0.55)
            or hard_hallway and hp <= int(max_hp * 0.60)
        )
    )
    if low_reserve_generated_opening:
        idx, potion = find_potion(
            {"PowerPotion", "ColorlessPotion"}, allow_reserved=True
        )
        if idx is not None:
            # Snecko's Confusion and Lagavulin's wake cycle make the current
            # zero-damage plan misleading. Generate the setup while all three
            # opening energy and the full pre-debuff hand are still available.
            log(
                "potion use generated setup before low-reserve opening "
                f"room={room_type} hp={hp}/{max_hp} enemies={sorted(living_ids)}"
            )
            if potion.get("requires_target"):
                return f"POTION use {idx} {target}"
            return f"POTION use {idx}"

    generated_potion_needed = high_stakes_consumable
    if generated_potion_needed and elite_fight and not critical_reserve:
        try:
            if base_emergency_plan is None:
                base_emergency_plan = plan_turn(combat, gs)
            planned_loss = int(base_emergency_plan.hp_loss)
            generated_potion_needed = bool(
                planned_loss >= max(15, int(max_hp * 0.18))
                or hp - planned_loss <= int(max_hp * 0.55)
            )
        except Exception:
            generated_potion_needed = True
    if generated_potion_needed:
        emergency_potions = {"SneckoOil", "Swift Potion", "Fire Potion", "Explosive Potion", "DistilledChaos", "AttackPotion", "SkillPotion"}
        liquid_memories_idx, _ = find_potion({"LiquidMemories"})
        if (
            liquid_memories_idx is not None
            and not guardian_attack_canceled
            and liquid_memories_tactical_window(
                combat, gs, hp, incoming, block
            )
        ):
            emergency_potions.add("LiquidMemories")
        idx, potion = find_potion(emergency_potions)
        if idx is not None:
            if potion.get("id") == "LiquidMemories":
                GRID_SELECT_MODE = "liquid_memories"
            if potion.get("requires_target"):
                return f"POTION use {idx} {target}"
            return f"POTION use {idx}"

    potion_slots_full = bool(potions) and all(potion.get("id") != "Potion Slot" for potion in potions)
    has_white_beast = any(relic.get("id") == "White Beast Statue" for relic in gs.get("relics", []))
    if potion_slots_full and has_white_beast:
        idx, potion = find_potion({"ColorlessPotion", "AttackPotion", "SkillPotion", "PowerPotion", "Ancient Potion", "SpeedPotion"})
        if idx is not None:
            if potion.get("requires_target"):
                return f"POTION use {idx} {target}"
            return f"POTION use {idx}"

    return None



def should_issue_potion_command(command, gs, now=None):
    """Suppress an immediate duplicate potion command on a stale state.

    CommunicationMod can publish one transitional state before the consumed
    potion disappears.  v2 could therefore send ``POTION use 0`` twice.  The
    command is allowed again after a short guard window in case the first
    attempt was genuinely rejected.
    """
    global LAST_POTION_ATTEMPT
    now = time.monotonic() if now is None else now
    combat = gs.get("combat_state") or {}
    signature = (
        int(gs.get("act", 0) or 0),
        int(gs.get("floor", 0) or 0),
        int(combat.get("turn", 0) or 0),
        command,
        tuple((potion.get("id"), potion.get("can_use", True)) for potion in gs.get("potions", [])),
        tuple(
            (monster.get("id"), int(monster.get("current_hp", 0) or 0))
            for monster in combat.get("monsters", [])
            if not monster.get("is_gone")
        ),
        int((combat.get("player") or {}).get("current_hp", gs.get("current_hp", 0)) or 0),
    )
    if LAST_POTION_ATTEMPT is not None:
        previous_signature, previous_time = LAST_POTION_ATTEMPT
        if signature == previous_signature and now - previous_time < POTION_RETRY_GUARD_SECONDS:
            return False
    LAST_POTION_ATTEMPT = (signature, now)
    return True


def arm_smoke_bomb_escape_guard(command, state, now=None):
    """Remember a Smoke Bomb command until the game has left this combat."""
    global SMOKE_BOMB_ESCAPE_PENDING
    match = re.fullmatch(r"POTION\s+use\s+(\d+)(?:\s+\d+)?", str(command or ""), re.IGNORECASE)
    if not match:
        return False

    gs = state.get("game_state") or {}
    potions = gs.get("potions") or []
    potion_index = int(match.group(1))
    if not 0 <= potion_index < len(potions):
        return False
    if normalized_potion_id(potions[potion_index]) != "SmokeBomb":
        return False

    combat = gs.get("combat_state") or {}
    SMOKE_BOMB_ESCAPE_PENDING = {
        "seed": gs.get("seed"),
        "floor": int(gs.get("floor", 0) or 0),
        "turn": int(combat.get("turn", 0) or 0),
        "armed_at": time.monotonic() if now is None else float(now),
    }
    log(
        "smoke bomb escape armed; suppressing combat commands until room transition "
        f"floor={SMOKE_BOMB_ESCAPE_PENDING['floor']} "
        f"turn={SMOKE_BOMB_ESCAPE_PENDING['turn']}"
    )
    return True


def smoke_bomb_escape_wait_command(state):
    """Block stale PLAY/END frames while Smoke Bomb's escape action resolves."""
    global SMOKE_BOMB_ESCAPE_PENDING
    pending = SMOKE_BOMB_ESCAPE_PENDING
    if pending is None:
        return None

    gs = state.get("game_state") or {}
    same_encounter = bool(
        state.get("in_game")
        and gs.get("seed") == pending["seed"]
        and int(gs.get("floor", 0) or 0) == pending["floor"]
    )
    combat_active = bool(
        str(gs.get("room_phase") or "").upper() == "COMBAT"
        and gs.get("room_type") in {"MonsterRoom", "MonsterRoomElite"}
        and gs.get("screen_type") not in {"COMBAT_REWARD", "GAME_OVER", "MAP"}
    )
    if not same_encounter or not combat_active:
        log(
            "smoke bomb escape completed; releasing combat command guard "
            f"floor={pending['floor']} turn={pending['turn']}"
        )
        SMOKE_BOMB_ESCAPE_PENDING = None
        return None

    return "WAIT 10" if command_available(state, "wait") else "STATE"


def policy_state_signature(state):
    """Return stable game facts that an irreversible command can change."""
    gs = state.get("game_state") or {}
    combat = gs.get("combat_state") or {}
    player = combat.get("player") or {}
    return (
        bool(state.get("in_game")),
        bool(state.get("ready_for_command")),
        gs.get("seed"),
        int(gs.get("act", 0) or 0),
        int(gs.get("floor", 0) or 0),
        gs.get("screen_type"),
        gs.get("room_type"),
        gs.get("action_phase"),
        gs.get("current_action"),
        int(combat.get("turn", 0) or 0),
        int(player.get("current_hp", gs.get("current_hp", 0)) or 0),
        int(player.get("block", 0) or 0),
        int(player.get("energy", 0) or 0),
        tuple(
            (
                card.get("uuid"),
                card_id(card),
                int(card.get("cost", 0) or 0),
                int(card.get("upgrades", 0) or 0),
                bool(card.get("is_playable", True)),
            )
            for card in combat.get("hand", [])
        ),
        tuple(
            (
                monster.get("id"),
                int(monster.get("current_hp", 0) or 0),
                int(monster.get("block", 0) or 0),
                monster.get("intent"),
                int(monster.get("move_adjusted_damage", -1) or -1),
                int(monster.get("move_hits", 1) or 1),
                bool(monster.get("is_gone")),
            )
            for monster in combat.get("monsters", [])
        ),
        tuple(gs.get("choice_list") or []),
        json.dumps(
            gs.get("screen_state") or {},
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        ),
        tuple(
            (
                normalized_potion_id(potion),
                bool(potion.get("can_use", True)),
            )
            for potion in gs.get("potions", [])
        ),
    )


def guard_duplicate_policy_command(command, state, now=None):
    """Wait instead of replaying an irreversible command on the same frame."""
    global LAST_POLICY_ATTEMPT
    if not isinstance(command, str):
        return command
    verb = command.strip().split(maxsplit=1)[0].upper()
    if verb not in {
        "PLAY", "END", "POTION", "CHOOSE", "PROCEED", "RETURN", "LEAVE",
    }:
        return command

    now = time.monotonic() if now is None else now
    attempt = (policy_state_signature(state), command.strip().upper())
    if LAST_POLICY_ATTEMPT is not None:
        previous_attempt, previous_time = LAST_POLICY_ATTEMPT
        if (
            attempt == previous_attempt
            and now - previous_time < POLICY_RETRY_GUARD_SECONDS
        ):
            log(
                f"stale command suppressed command={command!r} "
                f"age={now - previous_time:.2f}s"
            )
            return "WAIT 10" if command_available(state, "wait") else "STATE"
    LAST_POLICY_ATTEMPT = (attempt, now)
    return command


KNOWN_UNKNOWN_INTENT_MOVES = {
    ("BronzeAutomaton", 4),  # Spawn Bronze Orbs.
    ("TheCollector", 1),  # Summon Torch Heads.
    ("Hexaghost", 5),  # Activate before Divider.
    ("Reptomancer", 2),  # Summon Daggers.
}


def opening_intent_unresolved(monster):
    """Separate an unpublished opening intent from a real UNKNOWN move."""
    intent = str(monster.get("intent") or "").upper()
    try:
        move_id = int(monster.get("move_id", -1))
    except (TypeError, ValueError):
        move_id = -1
    if intent == "UNKNOWN" and (monster.get("id"), move_id) in KNOWN_UNKNOWN_INTENT_MOVES:
        return False
    return intent in {"", "DEBUG", "UNKNOWN"}


def writhing_mass_controlled_burst_command(
    model, mass_index, current_loss, gs=None
):
    """Commit a duplicated burst instead of wasting it on a safe chip."""
    double_tap_active = power_amount(model.player_powers, "Double Tap") > 0
    necronomicon_active = "Necronomicon" in _relic_ids(gs or {})
    if not double_tap_active and not necronomicon_active:
        return None
    if current_loss > max(8, int(model.max_hp * 0.12)):
        return None

    current_reserve = model.hp + model.revive_hp - current_loss
    if current_reserve < max(12, int(model.max_hp * 0.16)):
        return None

    mass = model.monsters[mass_index]
    minimum_progress = max(30, int((mass.hp + mass.block) * 0.30))
    best = None
    for hand_index, candidate in enumerate(model.hand):
        if (
            candidate.card_type != "ATTACK"
            or not candidate.is_playable
            or candidate.cost > model.energy
            or (
                necronomicon_active
                and not double_tap_active
                and candidate.cost < 2
            )
        ):
            continue
        target_index = mass_index if candidate.has_target else None
        try:
            result = simulate_card(model, hand_index, target_index)
        except (ValueError, IndexError):
            continue
        post_mass = result.monsters[mass_index]
        progress = (
            mass.hp + mass.block - post_mass.hp - post_mass.block
        )
        survives_current = (
            max(0, result.incoming - result.block)
            < result.hp + result.revive_hp
        )
        lethal = not post_mass.alive
        if not survives_current or (not lethal and progress < minimum_progress):
            continue
        command = f"PLAY {hand_index + 1}"
        if candidate.has_target:
            command += f" {mass.original_index}"
        rank = (int(lethal), progress, -candidate.cost)
        if best is None or rank > best[0]:
            best = (rank, command, candidate.card_id, progress)
    if best is None:
        return None
    return {
        "command": best[1],
        "card": best[2],
        "progress": best[3],
    }


def writhing_mass_safe_non_attack_command(combat, gs):
    """Return the best safe setup/block before locking the current intent."""
    safe_combat = dict(combat)
    safe_hand = []
    for raw_card in combat.get("hand") or []:
        candidate = dict(raw_card)
        if candidate.get("type") == "ATTACK" or card_id(candidate) == "Havoc":
            candidate["is_playable"] = False
        safe_hand.append(candidate)
    safe_combat["hand"] = safe_hand
    safe_plan = plan_turn(safe_combat, gs)
    if not safe_plan.commands or safe_plan.commands[0] == "END":
        return None
    return {
        "command": safe_plan.commands[0],
        "hp_loss": safe_plan.hp_loss,
    }


def writhing_mass_implant_block_command(combat, gs):
    """Front-load Block before an attack rerolls Implant into real damage."""
    living = [
        (index, monster)
        for index, monster in enumerate(combat.get("monsters") or [])
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    if len(living) != 1:
        return None
    raw_mass_index, raw_mass = living[0]
    if (
        raw_mass.get("id") != "WrithingMass"
        or str(raw_mass.get("intent") or "").upper() != "STRONG_DEBUFF"
    ):
        return None

    try:
        model = build_model(combat, gs)
        mass_index = next(
            index
            for index, monster in enumerate(model.monsters)
            if monster.original_index == raw_mass_index
        )
    except (TypeError, ValueError, StopIteration):
        return None

    plated = max(0, power_amount(model.player_powers, "Plated Armor"))
    block_gap = max(0, 38 - model.block - plated)
    if block_gap <= 0:
        return None

    best = None
    for hand_index, candidate in enumerate(model.hand):
        if (
            candidate.card_type != "SKILL"
            or candidate.has_target
            or not candidate.is_playable
            or max(0, candidate.cost) > model.energy
        ):
            continue
        try:
            result = simulate_card(model, hand_index, None)
        except (ValueError, IndexError):
            continue
        block_gain = max(0, result.block - model.block)
        if block_gain <= 0:
            continue

        has_effective_reroll = False
        for attack_index, attack in enumerate(result.hand):
            if (
                attack.card_type != "ATTACK"
                or not attack.is_playable
                or max(0, attack.cost) > result.energy
            ):
                continue
            try:
                attack_result = simulate_card(
                    result,
                    attack_index,
                    mass_index if attack.has_target else None,
                )
            except (ValueError, IndexError):
                continue
            if attack_result.monsters[mass_index].hp < result.monsters[mass_index].hp:
                has_effective_reroll = True
                break
        if not has_effective_reroll:
            continue

        resource_cost = max(0, result.resource_risk - model.resource_risk)
        rank = (
            min(block_gain, block_gap) - min(12, resource_cost),
            block_gain,
            -max(0, candidate.cost),
        )
        if best is None or rank > best[0]:
            best = (rank, hand_index, candidate.card_id, block_gain)

    if best is None:
        return None
    return {
        "command": f"PLAY {best[1] + 1}",
        "card": best[2],
        "block_gain": best[3],
        "block_gap": block_gap,
    }


def writhing_mass_lethal_intent_setup(combat, gs, command):
    """Find a non-attack setup that turns the Mass's current lethal intent safe."""
    parts = str(command or "").split()
    if len(parts) < 2 or parts[0] != "PLAY":
        return None
    try:
        hand_index = int(parts[1]) - 1
        raw_card = (combat.get("hand") or [])[hand_index]
    except (ValueError, IndexError):
        return None
    if raw_card.get("type") != "ATTACK":
        return None

    living = [
        monster
        for monster in combat.get("monsters") or []
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    if len(living) != 1 or living[0].get("id") != "WrithingMass":
        return None

    try:
        model = build_model(combat, gs)
    except (TypeError, ValueError):
        return None
    current_loss = max(0, model.incoming - model.block)
    reserve = model.hp + model.revive_hp
    if current_loss < reserve:
        return None

    safe_setup = writhing_mass_safe_non_attack_command(combat, gs)
    if (
        not safe_setup
        or safe_setup["hp_loss"] >= reserve
        or safe_setup["hp_loss"] >= current_loss
    ):
        return None
    return {
        **safe_setup,
        "current_loss": current_loss,
        "reserve": reserve,
    }


def writhing_mass_reroll_risk(combat, gs, command):
    """Describe a nonlethal attack that can reroll a safe intent dangerously."""
    parts = str(command or "").split()
    if len(parts) < 2 or parts[0] != "PLAY":
        return None
    living = [
        (index, monster)
        for index, monster in enumerate(combat.get("monsters") or [])
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and int(monster.get("current_hp", 0) or 0) > 0
    ]
    if len(living) != 1 or living[0][1].get("id") != "WrithingMass":
        return None
    raw_mass = living[0][1]

    try:
        hand_index = int(parts[1]) - 1
        raw_card = (combat.get("hand") or [])[hand_index]
    except (ValueError, IndexError):
        return None
    if raw_card.get("type") != "ATTACK":
        return None

    try:
        model = build_model(combat, gs)
        mass_index = next(
            index
            for index, monster in enumerate(model.monsters)
            if monster.monster_id == "WrithingMass"
        )
        target_index = None
        if model.hand[hand_index].has_target:
            if len(parts) < 3:
                return None
            original_target = int(parts[2])
            target_index = next(
                index
                for index, monster in enumerate(model.monsters)
                if monster.original_index == original_target
            )
            if target_index != mass_index:
                return None
        result = simulate_card(model, hand_index, target_index)
    except (ValueError, IndexError, StopIteration):
        return None

    post_mass = result.monsters[mass_index]
    if not post_mass.alive:
        return None

    current_loss = max(0, incoming_damage(combat) - model.block)
    if current_loss >= model.hp + model.revive_hp:
        # When the published intent already ends the run, attacking to reroll
        # it is necessary even if the replacement can also be lethal.
        return None
    current_reserve = model.hp + model.revive_hp - current_loss
    mass = model.monsters[mass_index]
    attack_progress = max(
        0,
        mass.hp + mass.block - post_mass.hp - post_mass.block,
    )
    post_attack_loss = max(0, incoming_damage(combat) - result.block)
    post_attack_reserve = result.hp + result.revive_hp - post_attack_loss
    heavy_attrition_reroll = bool(
        current_loss >= max(15, int(model.max_hp * 0.25))
        and post_attack_reserve <= max(24, int(model.max_hp * 0.35))
        and post_attack_reserve > 0
        and attack_progress >= max(10, current_loss // 2)
    )
    if heavy_attrition_reroll:
        # A merely nonlethal intent is not a useful lock when accepting it costs
        # a quarter of max HP and leaves a low reserve. The logged A20 Mass took
        # 21 HP twice while strong attacks sat in hand; make meaningful progress
        # while the current intent is still survivable instead of guaranteeing
        # the same desperate decision from a smaller life total next turn.
        return None
    sustainable_reserve = max(12, int(model.max_hp * 0.16))
    next_turn_ceiling = max(0, int(model.known_next_attack_damage))
    follow_up_reroll = any(
        card.card_type == "ATTACK"
        and card.is_playable
        and max(0, card.cost) <= result.energy
        for card in result.hand
    )
    regeneration = max(0, power_amount(result.player_powers, "Regeneration"))
    recoverable_last_reroll = (
        not follow_up_reroll
        and regeneration > 0
        and current_reserve + regeneration
        >= max(6, int(model.max_hp * 0.08))
    )
    desperation_reroll_window = (
        model.hp + model.revive_hp
        >= max(28, int(model.max_hp * 0.35))
        or current_reserve <= 1
    )
    if (
        current_loss > 0
        and current_reserve < sustainable_reserve
        and post_mass.hp > next_turn_ceiling
        and not recoverable_last_reroll
        and desperation_reroll_window
    ):
        # Merely remaining alive is not a safe lock when the intent consumes the
        # reserve and the exact next draw cannot finish the fight. Batch 18
        # stopped on 34 damage at 47/101 with 73 Mass HP remaining, guaranteeing
        # another desperate reroll at 13 HP. Take that controlled gamble now,
        # while the current HP can still absorb one of the ordinary outcomes.
        # Do not make that bet at critical current HP, or with the final
        # playable attack when Regeneration already buys a real next-turn
        # reserve. The logged A16 Iron Wave rerolled a survivable 24 into 57 at
        # 20 HP even after the hand had already built 13 Block.
        return None

    strength = max(0, power_amount(post_mass.powers, "Strength"))
    weakened = power_amount(post_mass.powers, "Weakened") > 0
    vulnerable = power_amount(result.player_powers, "Vulnerable") > 0
    intangible = power_amount(result.player_powers, "IntangiblePlayer") > 0

    def adjusted_hit(base):
        damage = max(0, base + strength)
        if weakened:
            damage = int(damage * 0.75)
        if vulnerable:
            damage = int(damage * 1.5)
        if intangible:
            damage = min(1, damage)
        return damage

    # At A2+, Strong Strike is 38 and Multi Strike is 9x3. Include both
    # shapes because Strength and Intangible change which one is worse.
    worst_incoming = max(adjusted_hit(38), adjusted_hit(9) * 3)
    worst_loss = max(0, worst_incoming - result.block)
    safe_intent_lock = bool(
        str(raw_mass.get("intent") or "").upper()
        not in {"STRONG_DEBUFF", "DEBUG", "UNKNOWN", ""}
        and current_loss <= max(6, int(model.max_hp * 0.08))
        and worst_loss - current_loss >= max(10, int(model.max_hp * 0.14))
    )
    if worst_loss < result.hp + result.revive_hp and not safe_intent_lock:
        return None
    controlled_burst = writhing_mass_controlled_burst_command(
        model, mass_index, current_loss, gs
    )
    return {
        "card": card_id(raw_card),
        "current_loss": current_loss,
        "current_reserve": current_reserve,
        "worst_incoming": worst_incoming,
        "worst_loss": worst_loss,
        "post_hp": result.hp,
        "post_block": result.block,
        "enemy_hp": post_mass.hp,
        "burst_command": (
            controlled_burst["command"] if controlled_burst else None
        ),
        "burst_card": controlled_burst["card"] if controlled_burst else None,
        "burst_progress": (
            controlled_burst["progress"] if controlled_burst else 0
        ),
    }


def lagavulin_sleep_power_command(combat, cards):
    """Use the free sleep window for Demon Form instead of waking Lagavulin."""
    sleeping = any(
        not monster.get("is_gone")
        and int(monster.get("current_hp", 0) or 0) > 0
        and (monster.get("id") or monster.get("name")) == "Lagavulin"
        and (monster.get("intent") or "") in {"SLEEP", "DEBUG"}
        for monster in combat.get("monsters", [])
    )
    if not sleeping:
        return None
    if any(
        (power.get("id") or power.get("name")) == "Demon Form"
        for power in (combat.get("player") or {}).get("powers", [])
    ):
        return None
    for index, card in cards:
        if card_id(card) == "Demon Form" and card.get("type") == "POWER":
            return f"PLAY {index}"
    return None


def decide_combat(state, gs):
    combat = gs.get("combat_state") or {}
    player = combat.get("player") or {}
    monsters = combat.get("monsters") or []
    living = [m for m in monsters if not m.get("is_gone") and not m.get("half_dead") and m.get("current_hp", 0) > 0]
    turn = int(combat.get("turn", 0) or 0)
    room_phase = str(gs.get("room_phase") or "").upper()
    if (
        turn <= 1
        and not combat.get("hand")
        and not combat.get("draw_pile")
        and not combat.get("discard_pile")
        and not combat.get("exhaust_pile")
        and (living or room_phase == "COMBAT")
    ):
        log("combat setup incomplete: waiting for initial hand and piles")
        return "WAIT 10" if command_available(state, "wait") else "STATE"
    if not living:
        if command_available(state, "proceed"):
            return "PROCEED"
        if command_available(state, "end"):
            return "END"
        return "STATE"

    if (
        turn <= 1
        and command_available(state, "play")
        and not combat.get("discard_pile")
        and not combat.get("exhaust_pile")
        and all(
        opening_intent_unresolved(monster)
        for monster in living
        )
    ):
        # CommunicationMod can publish the opening hand one update before the
        # monsters finish rolling their first intents. Treating that transient
        # frame as a quiet turn made the A6 bot end immediately against three
        # Byrds and deploy Dark Embrace before Snake Plant's 24-damage attack.
        # Once a card has entered discard/exhaust, or PLAY is no longer legal,
        # UNKNOWN can instead be a real mid-turn move such as Slime Split.
        log("combat setup incomplete: waiting for initial monster intents")
        return "WAIT 10" if command_available(state, "wait") else "STATE"

    energy = int(player.get("energy", 0) or 0)
    block = int(player.get("block", 0) or 0)
    hp = int(player.get("current_hp", gs.get("current_hp", 1)) or 1)
    incoming = incoming_damage(combat)
    cards = playable_cards(combat)
    target = choose_target(monsters)
    target_hp = monsters[target].get("current_hp", 999)
    fighting_nob = any(m.get("id") == "GremlinNob" for m in living)
    if (
        turn <= 1
        and not combat.get("hand")
        and not combat.get("discard_pile")
        and not combat.get("exhaust_pile")
    ):
        log("combat setup incomplete: waiting for initial hand")
        return "WAIT 10" if command_available(state, "wait") else "STATE"
    duplication_followup = pending_duplication_command(state, gs, combat)
    if duplication_followup:
        log(f"duplication followup: {duplication_followup}")
        return duplication_followup

    potion_cmd = potion_command(state, gs, combat, hp, incoming, block, target)
    if potion_cmd:
        if should_issue_potion_command(potion_cmd, gs):
            return potion_cmd
        log(f"potion duplicate suppressed: {potion_cmd}")
        return "WAIT 10" if command_available(state, "wait") else "STATE"

    duplication_cmd = planned_duplication_potion_command(
        state, gs, combat, hp, incoming, block
    )
    if duplication_cmd:
        if should_issue_potion_command(duplication_cmd, gs):
            return duplication_cmd
        log(f"potion duplicate suppressed: {duplication_cmd}")
        return "WAIT 10" if command_available(state, "wait") else "STATE"

    liquid_setup_cmd = liquid_memories_defense_setup_command(
        state, gs, combat, hp, incoming, block
    )
    if liquid_setup_cmd:
        return liquid_setup_cmd

    lagavulin_power_cmd = lagavulin_sleep_power_command(combat, cards)
    if lagavulin_power_cmd:
        log("lagavulin sleep setup: deploy Demon Form before wake")
        return lagavulin_power_cmd

    if incoming - block >= hp and combat.get("draw_pile") and not has_power(player, {"No Draw"}):
        emergency_draws = []
        for index, card in cards:
            if (
                card_id(card) in {"Adrenaline", "Battle Trance", "Master of Strategy"}
                and card_cost(card) == 0
            ):
                window = known_draw_window(gs, combat, card, hp, incoming)
                if window["draws"] > 0 and not window["all_clog"]:
                    emergency_draws.append((index, window))
        if emergency_draws:
            visible_status_trigger = any(
                drawn.get("type") in {"STATUS", "CURSE"}
                for _, window in emergency_draws
                for drawn in window["cards"]
            )
            if visible_status_trigger:
                try:
                    setup_plan = plan_turn(combat, gs)
                    first_command = setup_plan.commands[0]
                    parts = first_command.split()
                    planned_card = (
                        combat.get("hand", [])[int(parts[1]) - 1]
                        if len(parts) >= 2 and parts[0] == "PLAY"
                        else None
                    )
                except (IndexError, TypeError, ValueError):
                    first_command = None
                    planned_card = None
                if planned_card and card_id(planned_card) == "Fire Breathing":
                    # The emergency draw shortcut runs before the exact planner.
                    # Respect its setup order when a visible Status/Curse will
                    # trigger Fire Breathing immediately; drawing first loses
                    # that entire AoE proc and can strand an attacker at one HP.
                    log(
                        "status power before priority draw "
                        f"command={first_command} "
                        f"known_top={sorted({card_id(drawn) for _, window in emergency_draws for drawn in window['cards']})}"
                    )
                    return first_command
            index, window = max(
                emergency_draws,
                key=lambda item: (item[1]["quality"], item[1]["draws"]),
            )
            # Draw before spending energy when the visible hand cannot
            # survive, but do not override the exact planner for a fully known
            # dead window of unsupported statuses or curses.
            command = f"PLAY {index}"
            top_ids = [card_id(card) for card in window["cards"]]
            log(
                f"priority draw: {command} reason=projected_lethal "
                f"known_top={top_ids} unknown={window['unknown']}"
            )
            return command

    nob_attackless_hand = bool(
        fighting_nob
        and not any(card.get("type") == "ATTACK" for _, card in cards)
    )
    if nob_attackless_hand:
        hp_ratio = hp / max(1, int(gs.get("max_hp", hp) or hp))
        nob_powers = [
            (index, card)
            for index, card in cards
            if card.get("type") == "POWER"
            and (
                card_id(card) in SAFE_POWER_VALUES
                or hp_ratio >= RISKY_POWER_HP_THRESHOLDS.get(
                    card_id(card), 2.0
                )
            )
        ]
        if nob_powers:
            index, power = max(
                nob_powers,
                key=lambda item: (
                    SAFE_POWER_VALUES.get(card_id(item[1]), 8),
                    -card_cost(item[1]),
                ),
            )
            # Powers do not trigger Enrage. The logged A17 hand contained
            # Inflame plus four Defends; ending immediately missed the scaling
            # that would have closed the race before Nob's 30-damage turn.
            log(f"gremlin nob deploy attackless power={card_id(power)}")
            return f"PLAY {index}"
        nob = next(monster for monster in living if monster.get("id") == "GremlinNob")
        nob_enrage_power_active = any(
            (power.get("id") or power.get("name")) in {"Enrage", "Anger"}
            and int(power.get("amount", 0) or 0) > 0
            for power in nob.get("powers", [])
        )
        nob_enrage_active = (
            nob_enrage_power_active
            or "ATTACK" in str(nob.get("intent") or "")
        )
        if not nob_enrage_active and incoming <= block:
            secret_weapon = next(
                (
                    (index, card)
                    for index, card in cards
                    if card_id(card) == "Secret Weapon"
                    and card.get("is_playable", True)
                    and card_cost(card) <= energy
                    and any(
                        draw_card.get("type") == "ATTACK"
                        for draw_card in combat.get("draw_pile") or []
                    )
                ),
                None,
            )
            if secret_weapon is not None:
                # v263: the attackless-hand guard runs before the exact planner.
                # Let Secret Weapon turn the free Nob opener into real damage
                # instead of ending with a retrievable Clothesline still buried.
                log("gremlin nob attackless secret weapon retrieval")
                return f"PLAY {secret_weapon[0]}"
            safe_draws = []
            for index, card in cards:
                if card.get("type") != "SKILL" or card_id(card) == "Burning Pact":
                    continue
                window = known_draw_window(gs, combat, card, hp, incoming)
                remaining_energy = energy - card_cost(card)
                affordable_attack = any(
                    drawn.get("type") == "ATTACK"
                    and drawn.get("is_playable", True)
                    and card_cost(drawn) <= remaining_energy
                    for drawn in window["cards"]
                )
                if (
                    window["draws"] > 0
                    and not window["all_clog"]
                    and (affordable_attack or window["unknown"] > 0)
                ):
                    safe_draws.append((index, card, window, affordable_attack))
            if safe_draws:
                index, draw_card, window, _ = max(
                    safe_draws,
                    key=lambda item: (
                        item[3], item[2]["quality"], item[2]["draws"],
                        -card_cost(item[1]),
                    ),
                )
                log(
                    "gremlin nob attackless safe draw "
                    f"card={card_id(draw_card)} "
                    f"known_top={[card_id(card) for card in window['cards']]} "
                    f"unknown={window['unknown']}"
                )
                return f"PLAY {index}"
        if nob_enrage_active and hp - incoming > 12:
            enrage_combat = combat
            if not nob_enrage_power_active:
                enrage_combat = dict(combat)
                enrage_monsters = []
                for monster in combat.get("monsters", []):
                    preview_monster = dict(monster)
                    if monster is nob:
                        preview_monster["powers"] = list(
                            preview_monster.get("powers") or []
                        ) + [{"id": "Anger", "amount": 3}]
                    enrage_monsters.append(preview_monster)
                enrage_combat["monsters"] = enrage_monsters
            enrage_plan = plan_turn(enrage_combat, gs)
            end_loss = max(0, incoming - block)
            minimum_savings = (
                6
                if hp / max(1, int(gs.get("max_hp", hp) or hp)) < 0.35
                else 10
            )
            if (
                enrage_plan.commands
                and enrage_plan.commands[0] != "END"
                and enrage_plan.hp_loss + minimum_savings <= end_loss
            ):
                # A large block can still beat the extra Strength decisively.
                # The logged Flame Barrier saved eight HP; ordinary Defend or
                # Armaments lines remain below this threshold and are held.
                log(
                    "gremlin nob profitable attackless defense "
                    f"command={enrage_plan.commands[0]} "
                    f"planned_loss={enrage_plan.hp_loss} end_loss={end_loss}"
                )
                return enrage_plan.commands[0]
            return "END"

        # Before Bellow applies Enrage, fall through to the exact planner. This
        # preserves the one free window for Shockwave and Disarm.

    continuation_cmd = continuation_setup_command(gs, combat, cards, hp, target)
    if continuation_cmd:
        log(f"continuation setup: {continuation_cmd}")
        return continuation_cmd

    offering_cmd = priority_offering_command(gs, combat, cards, hp, incoming, block)
    if offering_cmd:
        log(f"priority draw: {offering_cmd} reason=retained_clog_or_open_hand")
        return offering_cmd

    try:
        plan = plan_turn(combat, gs)
        if plan.commands:
            first_command = plan.commands[0]
            transient_cycle_cmd = transient_dead_branch_cycle_command(
                gs, combat, cards, hp, incoming, block, plan
            )
            if transient_cycle_cmd:
                log(
                    "transient dead-branch cycle before escalating final draw "
                    f"command={transient_cycle_cmd} planned_loss={plan.hp_loss} "
                    f"reserve={hp - plan.hp_loss}/{gs.get('max_hp', hp)}"
                )
                return transient_cycle_cmd
            defensive_draw_cmd = critical_defensive_draw_command(
                gs, combat, cards, hp, incoming, block, plan
            )
            if defensive_draw_cmd:
                return defensive_draw_cmd
            automaton_status_cmd = automaton_prebeam_status_setup_command(
                gs, combat, cards
            )
            if automaton_status_cmd:
                log(
                    "automaton pre-beam status setup "
                    f"command={automaton_status_cmd} planned={first_command} "
                    f"visible_fuel={sum(card.get('type') in {'STATUS', 'CURSE'} for pile in ('hand', 'draw_pile', 'discard_pile') for card in combat.get(pile, []))}"
                )
                return automaton_status_cmd
            if awakened_one_curiosity_active(gs) and first_command.startswith("PLAY "):
                parts = first_command.split()
                try:
                    hand_index = int(parts[1]) - 1
                    planned_card = (combat.get("hand") or [])[hand_index]
                except (ValueError, IndexError):
                    planned_card = None
                if planned_card and awakened_key_power_choice_value(planned_card, gs) > 0:
                    log(
                        "awakened key power priority "
                        f"card={card_id(planned_card)} command={first_command}"
                    )
            if first_command.startswith("PLAY "):
                parts = first_command.split()
                try:
                    planned_index = int(parts[1]) - 1
                    planned_card = (combat.get("hand") or [])[planned_index]
                except (ValueError, IndexError):
                    planned_card = None
                if planned_card and card_id(planned_card) == "Fiend Fire":
                    exhausted = [
                        card_id(card)
                        for index, card in enumerate(combat.get("hand") or [])
                        if index != planned_index
                    ]
                    log(
                        f"fiend fire commit target={parts[2] if len(parts) > 2 else 0} "
                        f"exhaust_count={len(exhausted)} exhausted={exhausted} "
                        f"incoming={incoming} block={block} hp={hp} "
                        f"revive_hp={revive_reserve_hp(gs)}"
                    )
            implant_block = writhing_mass_implant_block_command(combat, gs)
            if implant_block:
                log(
                    "writhing mass block before implant reroll "
                    f"command={implant_block['command']} "
                    f"card={implant_block['card']} "
                    f"block_gain={implant_block['block_gain']} "
                    f"remaining_gap={implant_block['block_gap']}"
                )
                return implant_block["command"]
            lethal_intent_setup = writhing_mass_lethal_intent_setup(
                combat, gs, first_command
            )
            if lethal_intent_setup:
                log(
                    "writhing mass lethal-intent setup "
                    f"command={lethal_intent_setup['command']} "
                    f"planned_loss={lethal_intent_setup['hp_loss']} "
                    f"current_loss={lethal_intent_setup['current_loss']} "
                    f"reserve={lethal_intent_setup['reserve']}"
                )
                return lethal_intent_setup["command"]
            reroll_risk = writhing_mass_reroll_risk(
                combat, gs, first_command
            )
            if reroll_risk and len(plan.score) > 1 and plan.score[1]:
                # The deterministic plan already pays every current Malleable
                # trigger and kills before the enemy acts. Let the first attack
                # through; the live intent is observed and replanned after it.
                log(
                    "writhing mass planned lethal overrides safety lock "
                    f"card={reroll_risk['card']} "
                    f"current_loss={reroll_risk['current_loss']} "
                    f"enemy_hp={reroll_risk['enemy_hp']}"
                )
                reroll_risk = None
            if reroll_risk and reroll_risk.get("burst_command"):
                log(
                    "writhing mass controlled burst "
                    f"planned={reroll_risk['card']} "
                    f"card={reroll_risk['burst_card']} "
                    f"progress={reroll_risk['burst_progress']} "
                    f"current_loss={reroll_risk['current_loss']} "
                    f"worst={reroll_risk['worst_incoming']}"
                )
                return reroll_risk["burst_command"]
            if reroll_risk and command_available(state, "end"):
                safe_setup = writhing_mass_safe_non_attack_command(combat, gs)
                if safe_setup:
                    log(
                        "writhing mass safe setup before intent lock "
                        f"command={safe_setup['command']} "
                        f"planned_loss={safe_setup['hp_loss']} "
                        f"current_loss={reroll_risk['current_loss']}"
                    )
                    return safe_setup["command"]
                log(
                    "writhing mass safety lock "
                    f"card={reroll_risk['card']} "
                    f"current_loss={reroll_risk['current_loss']} "
                    f"reserve={reroll_risk['current_reserve']} "
                    f"worst={reroll_risk['worst_incoming']} "
                    f"post={reroll_risk['post_hp']}hp/"
                    f"{reroll_risk['post_block']}block "
                    f"enemy_hp={reroll_risk['enemy_hp']}"
                )
                return "END"
            log(f"turn plan hp_loss={plan.hp_loss} commands={list(plan.commands)}")
            return first_command
    except Exception as exc:
        log(f"planner fallback: {type(exc).__name__}: {exc}")

    attacks = [(i, c, estimate_damage(c, energy, block)) for i, c in cards if c.get("type") == "ATTACK"]
    lethal = []
    for i, c, d in attacks:
        for mi, monster in enumerate(monsters):
            if monster.get("is_gone") or monster.get("half_dead") or monster.get("current_hp", 0) <= 0:
                continue
            if d >= monster.get("current_hp", 999):
                lethal.append((i, c, d, mi))
    if lethal:
        i, c, _, mi = max(lethal, key=lambda x: (card_id(x[1]) == "Feed", -card_cost(x[1]), x[2]))
        return f"PLAY {i} {mi}"

    powers = set(SAFE_POWER_VALUES)
    for i, card in cards:
        if fighting_nob and card.get("type") == "SKILL":
            continue
        if card_id(card) in {"Dark Embrace", "Feel No Pain"} and not has_exhaust_synergy(gs):
            continue
        if card_id(card) in powers and (incoming <= block + 8 or hp > 35):
            return f"PLAY {i}"

    hp_ratio = hp / max(1, int(gs.get("max_hp", hp) or hp))
    for i, card in cards:
        cid = card_id(card)
        threshold = RISKY_POWER_HP_THRESHOLDS.get(cid)
        if threshold is None or hp_ratio < threshold:
            continue
        if cid == "Berserk" and incoming > 0 and hp - int(incoming * 1.5) <= max(12, int(hp * 0.25)):
            continue
        return f"PLAY {i}"

    zero_first = ["Offering", "Battle Trance", "Anger", "Warcry", "Flex", "Seeing Red"]
    for i, card in cards:
        if fighting_nob and card.get("type") == "SKILL":
            continue
        if card_cost(card) == 0 and card_id(card) in zero_first:
            if card.get("has_target"):
                return f"PLAY {i} {target}"
            return f"PLAY {i}"

    need_block = max(0, incoming - block)
    must_block_against_nob = hp - need_block <= 12
    if need_block > 0 and (incoming >= 10 or hp <= 65) and (not fighting_nob or must_block_against_nob):
        blocks = [(i, c, estimate_block(c, block)) for i, c in cards if estimate_block(c, block) > 0]
        if blocks:
            i, c, _ = max(blocks, key=lambda x: (x[2], -card_cost(x[1])))
            return f"PLAY {i}" if not c.get("has_target") else f"PLAY {i} {target}"

    attacking_targets = [
        (index, monster)
        for index, monster in enumerate(monsters)
        if not monster.get("is_gone")
        and not monster.get("half_dead")
        and monster.get("current_hp", 0) > 0
        and "ATTACK" in (monster.get("intent") or "")
    ]
    spot_weakness = [(i, card) for i, card in cards if card_id(card) == "Spot Weakness"]
    if spot_weakness and attacking_targets:
        i, _ = spot_weakness[0]
        spot_target, _ = max(
            attacking_targets,
            key=lambda item: max(0, item[1].get("move_adjusted_damage", 0) or 0)
            * max(1, item[1].get("move_hits", 1) or 1),
        )
        return f"PLAY {i} {spot_target}"

    if attacks:
        def attack_key(item):
            i, c, damage = item
            penalty = 0
            if card_id(c) == "Hemokinesis" and hp < 36:
                penalty = 12
            return ((damage - penalty) / max(1, card_cost(c)), damage - penalty)
        i, c, _ = max(attacks, key=attack_key)
        return f"PLAY {i} {target}"

    blocks = [(i, c, estimate_block(c, block)) for i, c in cards if estimate_block(c, block) > 0]
    if blocks and incoming > block and (not fighting_nob or must_block_against_nob):
        i, c, _ = max(blocks, key=lambda x: x[2])
        return f"PLAY {i}"

    disposable_statuses = [
        (i, card)
        for i, card in cards
        if card_id(card) == "Slimed" and card.get("exhausts") and card_cost(card) <= energy
    ]
    if disposable_statuses:
        return f"PLAY {disposable_statuses[0][0]}"

    if command_available(state, "end"):
        return "END"
    return "STATE"


def card_archetype_affinity(card_or_id):
    """Return the card's complete six-dimensional archetype vector.

    Unknown/colorless cards receive a zero vector, so callers can always rely
    on the same six labels without special-case key checks.
    """
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return dict(CARD_ARCHETYPE_SCORES.get(cid, ZERO_ARCHETYPE_VECTOR))


def archetype_profile(gs):
    """Build a focused archetype profile from the six-dimensional card data.

    ``scores`` still keeps all six accumulated dimensions, but only the most
    convincing one or two engines become ``active_archetypes``.  This avoids
    the v2 failure mode where bridge cards gradually made five archetypes
    active and almost every later reward counted as compatible.
    """
    scores = {archetype: 0.0 for archetype in ARCHETYPES}
    core_hits = {archetype: 0 for archetype in ARCHETYPES}
    strong_hits = {archetype: 0 for archetype in ARCHETYPES}
    support_hits = {archetype: 0 for archetype in ARCHETYPES}
    relic_signals = {archetype: 0.0 for archetype in ARCHETYPES}
    copies = {}
    deck = gs.get("deck", [])
    deck_ids = {card_id(card) for card in deck}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    status_commit_ready = status_engine_commit_ready(gs)
    fiend_fire_exhaust_engine_ready = bool(
        deck_ids
        & {
            "Burning Pact", "Corruption", "Dark Embrace", "Feel No Pain",
            "Second Wind", "True Grit",
        }
        or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}
    )
    signalled_cards = set()
    entrench_ready = entrench_support_ready(gs)
    body_slam_ready = body_slam_support_ready(gs)

    for card in deck:
        cid = card_id(card)
        copies[cid] = copies.get(cid, 0) + 1
        affinity = card_archetype_affinity(cid)
        if cid == "Entrench" and not entrench_ready:
            # Entrench is not an engine by itself. Until the deck can produce
            # a large block turn, counting its full ten block points falsely
            # locks routing and rewards into a mature block archetype.
            affinity = dict(affinity)
            affinity["block"] = 0
        elif cid == "Body Slam" and not body_slam_ready:
            # Body Slam is a payoff, not a source of Block. An unsupported
            # copy must not add eight points and then make the next copy look
            # like a match for a block archetype it created by itself.
            affinity = dict(affinity)
            affinity["block"] = 0
        for archetype, points in affinity.items():
            # v5: repeated copies are not intrinsically worse.  Every copy
            # contributes its full six-dimensional archetype value.
            scores[archetype] += points

        # A second copy can improve an engine's raw score, but it should not
        # masquerade as a second independent engine component.
        if cid in signalled_cards:
            continue
        signalled_cards.add(cid)
        for archetype, points in affinity.items():
            if points >= 6:
                strong_hits[archetype] += 1
            if points >= 3:
                support_hits[archetype] += 1
            if (
                points > 0
                and
                cid in ARCHETYPE_CORE_CARDS[archetype]
                and not (
                    cid == "Fiend Fire"
                    and archetype == "exhaust"
                    and not fiend_fire_exhaust_engine_ready
                )
            ):
                core_hits[archetype] += 1

    if copies.get("Perfected Strike"):
        strike_support = sum(copies.get(cid, 0) for cid in PERFECTED_STRIKE_CARDS)
        scores["perfected_strike"] += min(6, strike_support)

    curse_count = sum(1 for card in deck if card.get("type") == "CURSE")
    for relic in gs.get("relics", []):
        relic_id = relic.get("id")
        for archetype, base_points in ARCHETYPE_RELIC_LOOKUP.get(relic_id, {}).items():
            points = base_points
            if relic_id == "Blue Candle" and archetype == "status" and curse_count:
                # Candle is a curse engine signal only while the deck actually
                # owns a curse. Once the final curse is removed it is utility,
                # not a reason to keep drafting status cards.
                points += 6
            scores[archetype] += points
            relic_signals[archetype] += points

    stable_strength_sources = strength_source_count(gs)

    raw_ranked = sorted(scores, key=lambda archetype: scores[archetype], reverse=True)
    raw_leader = raw_ranked[0]
    floor = int(gs.get("floor", 0) or 0)
    engine_threshold = 6 if floor <= 16 else 9

    confidence = {}
    for archetype in ARCHETYPES:
        confidence[archetype] = (
            core_hits[archetype] * 6.0
            + min(6.0, relic_signals[archetype])
            + strong_hits[archetype] * 2.0
            + min(3.0, support_hits[archetype] * 0.75)
            + min(3.0, scores[archetype] / 8.0)
        )

    engine_candidates = [
        archetype
        for archetype in ARCHETYPES
        if scores[archetype] >= engine_threshold
        and not (archetype == "strength" and stable_strength_sources <= 0)
        and not (archetype == "status" and not status_commit_ready)
        and not (
            archetype == "status"
            and core_hits[archetype] <= 0
            and relic_signals[archetype] < 8
        )
        and (
            core_hits[archetype] > 0
            or relic_signals[archetype] >= 8
            or strong_hits[archetype] >= 2
        )
    ]
    engine_candidates.sort(
        key=lambda archetype: (confidence[archetype], scores[archetype]),
        reverse=True,
    )

    active_archetypes = []
    if engine_candidates:
        active_archetypes.append(engine_candidates[0])
        primary = engine_candidates[0]
        for archetype in engine_candidates[1:]:
            if len(active_archetypes) >= MAX_ACTIVE_ARCHETYPES:
                break
            # A secondary engine must have its own real signal and retain a
            # meaningful share of the primary engine's score.
            if (
                confidence[archetype] >= 5.0
                and scores[archetype] >= max(engine_threshold, scores[primary] * 0.50)
            ):
                active_archetypes.append(archetype)

    supporting_archetypes = [
        archetype
        for archetype in engine_candidates
        if archetype not in active_archetypes and confidence[archetype] >= 5.0
    ]

    # Before a true engine appears, a clearly dominant package can still guide
    # rewards without permanently locking the run.
    developing_archetypes = []
    if not active_archetypes:
        runner_score = scores[raw_ranked[1]]
        developing_threshold = 10 if floor <= 16 else 14
        if (
            scores[raw_leader] >= developing_threshold
            and support_hits[raw_leader] >= 2
            and scores[raw_leader] - runner_score >= 3
            and not (
                raw_leader == "status"
                and not status_commit_ready
            )
        ):
            developing_archetypes = [raw_leader]

    current_archetypes = active_archetypes or developing_archetypes
    leader = current_archetypes[0] if current_archetypes else raw_leader
    runner_up = next((name for name in raw_ranked if name != leader), raw_ranked[1])
    return {
        "scores": scores,
        "confidence": confidence,
        "core_hits": core_hits,
        "strong_hits": strong_hits,
        "support_hits": support_hits,
        "relic_signals": relic_signals,
        "leader": leader,
        "raw_leader": raw_leader,
        "runner_up": runner_up,
        "active_archetypes": active_archetypes,
        "supporting_archetypes": supporting_archetypes,
        "developing_archetypes": developing_archetypes,
        "current_archetypes": current_archetypes,
        "committed": bool(active_archetypes),
        "strength_source_count": stable_strength_sources,
    }


def archetype_specialization(gs, profile=None):
    """Return a 0..1 estimate of how focused the deck is on one engine.

    The score combines concentration of the six-dimensional totals, the gap
    between first and second place, and whether a real engine is active.  It
    is used for elite-route appetite and campfire risk tolerance; it does not
    penalize taking duplicate cards.
    """
    profile = profile or archetype_profile(gs)
    values = sorted((max(0.0, float(v)) for v in profile["scores"].values()), reverse=True)
    top = values[0] if values else 0.0
    second = values[1] if len(values) > 1 else 0.0
    total = sum(values)
    if top <= 0 or total <= 0:
        return 0.0
    concentration = top / total
    lead = max(0.0, top - second) / max(6.0, top)
    engine_bonus = 0.18 if profile.get("active_archetypes") else 0.07 if profile.get("developing_archetypes") else 0.0
    score = 0.58 * concentration + 0.34 * lead + engine_bonus
    return max(0.0, min(1.0, score))


def high_archetype_specialization(gs, profile=None):
    return archetype_specialization(gs, profile) >= 0.72


def archetype_card_bonus(card, gs, profile=None):
    """Score a reward card against the deck's complete archetype profile.

    The old implementation mostly kept only the single strongest matching
    archetype.  This version keeps the main match, gives meaningful credit to
    a secondary match, and adds a small bridge bonus when one card connects
    multiple already-active engines.
    """
    affinity = card_archetype_affinity(card)
    active_affinity = {
        archetype: points for archetype, points in affinity.items() if points > 0
    }
    if not active_affinity:
        return 0

    profile = profile or archetype_profile(gs)
    floor = int(gs.get("floor", 0) or 0)
    early_multiplier = 1.25 if floor <= 16 else 0.75
    contributions = []
    matched_archetypes = []

    for archetype, points in active_affinity.items():
        if archetype == "status" and not status_reward_axis_ready(card, gs):
            # One speculative Evolve or Fire Breathing is not yet a reason to
            # inflate every generic bridge card carrying a few status points.
            continue
        momentum = profile["scores"][archetype]
        engine_signal = (
            profile["core_hits"][archetype] > 0
            or profile["relic_signals"][archetype] >= 4
            or momentum >= 8
        )
        if momentum < 4 or not engine_signal:
            continue
        contribution = points * min(2.5, momentum / 6.0) * early_multiplier
        if archetype in profile.get("active_archetypes", []):
            contribution += points * (1.25 if floor <= 16 else 0.55)
        elif archetype in profile.get("developing_archetypes", []):
            contribution += points * (0.65 if floor <= 16 else 0.30)
        contributions.append(contribution)
        matched_archetypes.append(archetype)

    if contributions:
        contributions.sort(reverse=True)
        total = contributions[0]
        if len(contributions) >= 2:
            total += contributions[1] * 0.45
        if len(contributions) >= 3:
            total += sum(contributions[2:]) * 0.20

        # A genuine bridge card is more valuable than two unrelated narrow
        # cards because it advances both engines without bloating the deck.
        if len(matched_archetypes) >= 2:
            bridge_strength = sorted(
                (active_affinity[name] for name in matched_archetypes),
                reverse=True,
            )
            total += min(6.0, bridge_strength[1] * 0.5)
        return int(round(total))

    if floor <= 16 and card_id(card) in {
        cid for cards in ARCHETYPE_CORE_CARDS.values() for cid in cards
    }:
        return int(round(max(active_affinity.values()) * 0.6))
    return 0


def archetype_relic_bonus(relic, gs, profile=None):
    affinity = ARCHETYPE_RELIC_LOOKUP.get(
        canonical_relic_id(relic.get("id") or relic.get("name")), {}
    )
    if not affinity:
        return 0
    profile = profile or archetype_profile(gs)
    contributions = [
        points * min(2.0, profile["scores"][archetype] / 7.0)
        for archetype, points in affinity.items()
        if profile["scores"][archetype] >= 4
    ]
    return int(round(max(contributions, default=max(affinity.values()) * 0.35)))


def purge_card_score(card, gs, profile=None):
    cid = card_id(card)
    profile = profile or archetype_profile(gs)
    if card.get("type") == "CURSE" or cid in {
        "AscendersBane", "Clumsy", "CurseOfTheBell", "Decay", "Doubt", "Injury",
        "Necronomicurse", "Normality", "Pain", "Parasite", "Regret", "Shame", "Writhe",
    }:
        if cid in {"AscendersBane", "CurseOfTheBell", "Necronomicurse"}:
            return -100
        severity = {
            "Normality": 80, "Pain": 65, "Regret": 55, "Doubt": 45,
            "Shame": 40, "Decay": 30, "Writhe": 25, "Parasite": 20,
            "Injury": 10, "Clumsy": 5,
        }.get(cid, 25)
        return 125 + severity - curse_retention_value(gs)
    if cid == "Strike_R":
        if profile["committed"] and profile["leader"] == "perfected_strike":
            return 20
        return 80
    if cid == "Defend_R":
        screen_state = gs.get("screen_state") or {}
        selected = screen_state.get("selected_cards", [])
        selected_defends = sum(card_id(chosen) == "Defend_R" for chosen in selected)
        remaining_after_purge = (
            count_deck(gs, {"Defend_R"}) - selected_defends - 1
        )
        multi_purge = int(screen_state.get("num_cards", 1) or 1) > 1
        minimum_defends = 0
        if multi_purge and act2_transition_defense_count(gs) == 0:
            minimum_defends = 2
        if (
            int(gs.get("ascension_level", 0) or 0) >= 17
            and int(gs.get("act", 1) or 1) == 1
            and act2_high_output_defense_count(gs) == 0
        ):
            # Separate Act 1 events can each see a one-card purge screen. A
            # Perfected Strike deck otherwise removes Defend twice in a row and
            # reaches Hexaghost with only two basic block cards.
            minimum_defends = max(minimum_defends, 3)
        if (
            int(gs.get("ascension_level", 0) or 0) >= 18
            and int(gs.get("act", 1) or 1) == 2
            and act2_high_output_defense_count(gs) == 0
        ):
            # Separate one-card removal events can also chain across Act 2.
            # The A19 Perfected Strike deck removed Defend at Golden Wing and
            # Beggar, reached two basics with no burst block, then lost 37 HP
            # in the hallway immediately after its only campfire.
            minimum_defends = max(minimum_defends, 3)
        if remaining_after_purge < minimum_defends:
            # Empty Cage selects twice against the unchanged deck. Re-score the
            # second choice against cards already selected so a focused attack
            # deck cannot accidentally delete its final defensive floor.
            return -40
        return 40
    affinity = card_archetype_affinity(cid)
    if profile["committed"] and affinity.get(profile["leader"], 0) > 0:
        return -20
    return max(0, 35 - CARD_SCORES.get(cid, 25))


def curse_retention_value(gs):
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    value = 0
    if "Du-Vu Doll" in relic_ids:
        value += 60
    if "Blue Candle" in relic_ids:
        value += 25
    if "Fire Breathing" in deck_ids:
        # Keep the mild curse/status that makes this otherwise dead power work.
        # Removing the only source should lose to removing a starter Strike.
        value += 75
    if "Evolve" in deck_ids:
        value += 10
    profile = archetype_profile(gs)
    if profile["committed"] and profile["leader"] == "status":
        value += 25
    if "Blue Candle" in relic_ids and "Rupture" in deck_ids:
        value += 10
    if "Blue Candle" in relic_ids and (
        deck_ids & {"Dark Embrace", "Feel No Pain"}
        or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes", "Runic Cube"}
    ):
        value += 8
    return value


def shop_relic_context_bonus(relic, gs):
    relic_id = canonical_relic_id(relic.get("id") or relic.get("name"))
    curse_count = sum(1 for card in gs.get("deck", []) if card.get("type") == "CURSE")
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = canonical_relic_ids(gs)
    if relic_id in {"Membership Card", "MembershipCard"}:
        current_hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", current_hp or 1) or 1))
        gold = max(0, int(gs.get("gold", 0) or 0))
        price = max(0, int(relic.get("price", 0) or 0))
        remaining_gold = max(0, gold - price)
        if current_hp / max_hp < 0.50 and remaining_gold < 75:
            # A discount relic cannot repair the current route. The logged A19
            # run spent 167 of 170 gold on Membership Card at 23/82 HP, passed
            # another shop with no buying power, then entered Slavers without a
            # potion. Preserve enough gold for an immediate survival purchase.
            return -120
        if int(gs.get("act", 1) or 1) >= 2 and remaining_gold < 50:
            return -28
    if relic_id == "Potion Belt" and "Sozu" in relic_ids:
        # Sozu permanently prevents potion gains, so extra potion slots can
        # never be filled. The A18 Slavers run spent a full shop relic price on
        # Potion Belt after taking Sozu and received literally no benefit.
        return -200
    if relic_id in {"Lee's Waffle", "LeesWaffle"}:
        current_hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", current_hp or 1) or 1))
        missing_hp = max(0, max_hp - current_hp)
        # Waffle immediately restores the whole reserve and adds seven max HP.
        # Treat that concrete recovery as part of the relic, rather than tying
        # it with generic shop relics. The logged A17 shop was at 31/75 and
        # chose Art of War at the same price, then entered Act 2 at 29 HP.
        return min(72, missing_hp + 14)
    if relic_id == "Magic Flower":
        current_hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", current_hp or 1) or 1))
        hp_ratio = current_hp / max_hp
        act = int(gs.get("act", 1) or 1)
        floor = int(gs.get("floor", 0) or 0)
        if relic_ids & MARK_OF_BLOOM_IDS:
            return -180
        rest_opportunities = 0
        if "Coffee Dripper" not in relic_ids:
            if act == 2 and 27 <= floor <= 29:
                # The fixed pre-boss campfire remains, and these floors can
                # still reach one path campfire. The logged A19 shop at 15/92
                # actually rested twice before Collector.
                rest_opportunities = 2
            elif act == 2 and floor <= 32:
                rest_opportunities = 1
        if hp_ratio < 0.45 and rest_opportunities:
            extra_per_rest = max(1, int(max_hp * 0.15))
            reserve_urgency = min(
                36, int(max(0.0, 0.45 - hp_ratio) * max_hp)
            )
            return min(
                96,
                18
                + rest_opportunities * extra_per_rest
                + reserve_urgency
                + (8 if "Burning Blood" in relic_ids else 0),
            )
        healing_sources = count_deck(gs, {"Reaper"})
        healing_sources += int("Burning Blood" in relic_ids)
        return min(24, healing_sources * 8)
    if relic_id == "Du-Vu Doll":
        return curse_count * 12 + (10 if "Blue Candle" in relic_ids else 0)
    if relic_id == "Blue Candle":
        return curse_count * 10 + (10 if deck_ids & {"Fire Breathing", "Rupture"} else 0)
    if relic_id == "Medical Kit":
        return min(20, archetype_profile(gs)["scores"]["status"])
    if relic_id == "Kunai":
        attack_count = sum(
            card.get("type") == "ATTACK" for card in gs.get("deck", [])
        )
        # Kunai is a real defensive engine once an attack-dense deck can
        # plausibly trigger it. The logged A13 shop undervalued it by less
        # than one point below the relic gate and bought two generic skills.
        return min(24, max(0, attack_count - 5) * 7)
    if relic_id == "DollysMirror":
        best_target = max(
            (duplicate_card_score(card, gs) for card in gs.get("deck", [])),
            default=-200,
        )
        if best_target < 70:
            # Mirror is only as good as its best permanent target. Spending an
            # early shop on a second generic attack, or another recurring HP
            # cost, is materially worse than keeping the gold for a real relic.
            return -50
        return min(24, (best_target - 70) // 2)
    if relic_id == "Darkstone Periapt" and "Cursed Key" in relic_ids:
        return 8
    if relic_id == "Chemical X":
        x_cost_cards = sum(
            card_id(card) in X_COST_CARD_IDS
            or int(card.get("cost", -99) or -99) == -1
            for card in gs.get("deck", [])
        )
        if x_cost_cards <= 0:
            # Chemical X has no effect without an X-cost card. The A10 deck
            # spent 146 gold on it with no possible trigger, then entered the
            # fatal Centurion fight without a useful shop investment.
            return -120
        return 18 + min(24, (x_cost_cards - 1) * 12)
    if relic_id == "Brimstone":
        # Brimstone asks the deck to finish every fight quickly. Buying it as
        # a speculative floor-three Strength source, before owning even one
        # Strength payoff, made the logged Automaton scale past the deck's
        # block engine. Keep it available once the damage package exists.
        if strength_payoff_count(gs) == 0:
            return -32
        bonus = 0
        if upcoming_boss_id(gs) == "awakenedone":
            # Curiosity and Brimstone compound every turn. The logged A8 deck
            # bought Brimstone on floor 36 with Awakened One already visible,
            # then faced 48 incoming on turn three and died in phase one while
            # still holding two potions. Do not buy into that known conflict.
            bonus -= 140
        if defensive_package_count(gs) < 2:
            bonus -= 12
        if upcoming_boss_id(gs) in {"automaton", "bronzeautomaton"}:
            automaton_ready = (
                strength_payoff_count(gs) >= 2
                and defensive_package_count(gs) >= 4
                and count_deck(gs, {"Limit Break", "Reaper"}) > 0
            )
            if not automaton_ready:
                # Automaton's delayed Hyper Beam gives Brimstone several turns
                # to amplify the boss. Buy it here only when the deck can both
                # race and recover or multiply Strength before that breakpoint.
                bonus -= 60
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        )
        if (
            int(gs.get("ascension_level", 0) or 0) >= 18
            and int(gs.get("act", 1) or 1) >= 2
        ):
            sustained_race = bool(
                count_deck(gs, {"Reaper"}) > 0
                and strength_payoff_count(gs) >= 2
                and hp_ratio >= 0.55
            )
            controlled_race = bool(
                hp_ratio >= 0.72
                and act2_swarm_control_ready(gs)
                and act2_high_output_defense_count(gs) >= 1
                and defensive_package_count(gs) >= 3
            )
            if not (sustained_race or controlled_race):
                # At A18, Byrds and other multi-hit encounters turn the enemy
                # Strength tick into immediate life loss. Do not buy Brimstone
                # in Act 2+ unless the deck can heal the race or already owns
                # both real swarm control and a stable defensive package.
                bonus -= 90
        if hp_ratio < 0.50:
            # The v78 deck bought Brimstone at 31/80 immediately before a
            # forced Slavers elite. Its first Strength tick turned 29 incoming
            # damage into lethal 32 before the scaling could repay itself.
            bonus -= 48
        elif hp_ratio < 0.65:
            bonus -= 20
        return bonus

    deck = gs.get("deck", [])
    attack_count = sum(card.get("type") == "ATTACK" for card in deck)
    skill_count = sum(card.get("type") == "SKILL" for card in deck)
    power_count = sum(card.get("type") == "POWER" for card in deck)
    cheap_attacks = sum(
        card.get("type") == "ATTACK" and card_cost(card) <= 1
        for card in deck
    )
    cheap_cards = sum(
        card.get("type") not in {"STATUS", "CURSE"} and card_cost(card) <= 1
        for card in deck
    )
    draw_cards = sum(card_id(card) in DRAW_SETUP_VALUES for card in deck)
    expensive_cards = sum(
        card.get("type") not in {"STATUS", "CURSE"} and card_cost(card) >= 2
        for card in deck
    )
    exhaust_sources = sum(
        card.get("exhausts")
        or card_id(card) in REPEATABLE_EXHAUST_SOURCES | MASS_EXHAUST_SOURCES
        for card in deck
    )
    bonus = 0

    if relic_id in {"Akabeko", "Nunchaku", "Ornamental Fan", "Pen Nib", "Shuriken"}:
        bonus += min(24, max(0, cheap_attacks - 2) * 4)
        if relic_id == "Akabeko":
            bonus += min(12, count_deck(gs, {"Pummel", "Sword Boomerang", "Twin Strike", "Whirlwind"}) * 5)
    elif relic_id == "LetterOpener":
        bonus += min(22, max(0, skill_count - 5) * 3)
    elif relic_id == "InkBottle":
        bonus += min(20, max(0, cheap_cards + draw_cards - 6) * 2)
    elif relic_id == "Gremlin Horn":
        bonus += 8 + min(8, count_deck(gs, {"Cleave", "Immolate", "Whirlwind"}) * 4)
    elif relic_id == "Bird Faced Urn":
        bonus += min(24, power_count * 6)
    elif relic_id == "Mummified Hand":
        bonus += min(30, power_count * 7 + expensive_cards * 2)
    elif relic_id == "Ice Cream":
        bonus += min(24, expensive_cards * 3 + count_deck(gs, X_COST_CARD_IDS) * 8)
    elif relic_id in {"TheAbacus", "Sundial"}:
        cycle_pressure = draw_cards + max(0, 18 - len(deck)) // 3
        bonus += min(22, cycle_pressure * (4 if relic_id == "Sundial" else 3))
    elif relic_id == "Centennial Puzzle":
        bonus += min(18, self_damage_source_count(gs) * 5)
    elif relic_id == "OrangePellets":
        has_attack = attack_count > 0
        has_skill = skill_count > 0
        bonus += 8 if has_attack and has_skill and power_count else -12
        bonus += min(12, power_count * 3)
    elif relic_id == "StrikeDummy":
        bonus += min(24, count_deck(gs, PERFECTED_STRIKE_CARDS) * 4)
    elif relic_id == "Champion Belt":
        bonus += min(20, count_deck(gs, {"Bash", "Shockwave", "Thunderclap", "Uppercut"}) * 5)
    elif relic_id == "Strange Spoon":
        if relic_ids & {"Dead Branch", "Charon's Ashes"} or "Corruption" in deck_ids:
            bonus -= 32
        elif exhaust_sources:
            bonus += min(10, exhaust_sources * 2)
    elif relic_id in {"Frozen Egg 2", "Molten Egg 2", "Toxic Egg 2"}:
        remaining_acts = max(0, 4 - int(gs.get("act", 1) or 1))
        bonus += remaining_acts * 5
    elif relic_id in {"Question Card", "Prayer Wheel"}:
        remaining_acts = max(0, 4 - int(gs.get("act", 1) or 1))
        bonus += remaining_acts * (6 if relic_id == "Prayer Wheel" else 4)
    elif relic_id == "Juzu Bracelet":
        bonus += 8 if int(gs.get("ascension_level", 0) or 0) >= 15 else 3
    elif relic_id == "Tiny Chest":
        bonus += 12 if relic_counter(gs, "Tiny Chest") >= 2 else 3
    elif relic_id == "Matryoshka":
        bonus += 10 if int(gs.get("act", 1) or 1) <= 2 else -12
    elif relic_id in {"Bottled Flame", "Bottled Lightning", "Bottled Tornado"}:
        wanted_type = {
            "Bottled Flame": "ATTACK",
            "Bottled Lightning": "SKILL",
            "Bottled Tornado": "POWER",
        }[relic_id]
        premium = max(
            (CARD_SCORES.get(card_id(card), 20) for card in deck if card.get("type") == wanted_type),
            default=0,
        )
        bonus += max(-15, min(18, (premium - 45) // 3))

    rule = relic_rule(relic_id)
    if rule and "negative" in rule.tags:
        bonus -= 100
    return bonus


def status_source_count(gs):
    source_weights = {
        # One Power Through creates two Wounds. With Fire Breathing this is
        # already a repeatable boss-damage engine, not half of one.
        "Power Through": 2,
        "Wild Strike": 1,
        "Reckless Charge": 1,
        "Immolate": 1,
        "Injury": 1,
        "Wound": 1,
        "Burn": 1,
        "Dazed": 1,
    }
    count = sum(source_weights.get(card_id(card), 0) for card in gs.get("deck", []))
    count += sum(
        1
        for card in gs.get("deck", [])
        if card.get("type") == "STATUS" and card_id(card) not in source_weights
    )
    if any(relic.get("id") == "Mark of Pain" for relic in gs.get("relics", [])):
        count += 2
    return count


def persistent_curse_count(gs):
    """Count Curse fuel that remains in the deck after its first draw."""
    return sum(
        card.get("type") == "CURSE" and card_id(card) != "AscendersBane"
        for card in gs.get("deck", [])
    )


def omamori_blocks_next_curse(gs):
    """Return whether Omamori has a charge for the next offered Curse."""
    for relic in gs.get("relics", []):
        if (relic.get("id") or relic.get("name")) != "Omamori":
            continue
        counter = relic.get("counter")
        if counter is None:
            return True
        try:
            return int(counter) > 0
        except (TypeError, ValueError):
            return False
    return False


def cursed_key_chest_should_open(gs):
    """Spend at most one unsupported persistent Curse on Cursed Key chests."""
    if (
        gs.get("room_type") == "TreasureRoomBoss"
        or (gs.get("screen_state") or {}).get("chest_type") == "BossChest"
    ):
        # Boss chests never trigger Cursed Key. Treating them like map chests
        # made the logged A20 run skip its entire Act 1 boss relic reward.
        return True
    if "Cursed Key" not in _relic_ids(gs):
        return True
    if omamori_blocks_next_curse(gs) or curse_retention_value(gs) >= 25:
        return True
    return not (
        int(gs.get("ascension_level", 0) or 0) >= 17
        and persistent_curse_count(gs) >= 1
    )


def status_engine_commit_ready(gs):
    """Return whether status/curse signals form a playable engine yet.

    A single Evolve or Fire Breathing remains a valid Act 1 speculation, but it
    must not commit routing and every later reward before the deck finds fuel.
    The paired powers are enough to commit because common enemies provide
    statuses, while curse relics require an actual persistent curse.
    """
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = {
        relic.get("id") or relic.get("name")
        for relic in gs.get("relics", [])
    }
    status_payoffs = deck_ids & {"Evolve", "Fire Breathing"}
    curse_count = persistent_curse_count(gs)

    if relic_ids & {"Mark of Pain", "Du-Vu Doll"}:
        return True
    if curse_count and relic_ids & {"Blue Candle", "Darkstone Periapt"}:
        return True
    if not status_payoffs:
        return False
    if status_source_count(gs) > 0:
        return True
    if "Fire Breathing" in status_payoffs and curse_count > 0:
        return True
    return status_payoffs == {"Evolve", "Fire Breathing"}


def status_fuel_candidate(card_or_id, gs):
    """Return whether this reward supplies the first fuel for a status payoff."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    if cid not in STATUS_FUEL_REWARD_BONUS or status_source_count(gs) > 0:
        return False
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    return bool(deck_ids & {"Evolve", "Fire Breathing"})


def status_reward_axis_ready(card_or_id, gs):
    """Include a reward that immediately completes a speculative status axis."""
    if status_engine_commit_ready(gs):
        return True
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    if status_fuel_candidate(cid, gs):
        return True
    if cid not in {"Evolve", "Fire Breathing"}:
        return False
    fuel = status_source_count(gs)
    if cid == "Fire Breathing":
        fuel += persistent_curse_count(gs)
    return fuel > 0


def status_curse_engine_established(gs, profile=None):
    """Return whether extra Fire Breathing copies are genuine engine pieces."""
    profile = profile or archetype_profile(gs)
    if (
        "status" not in profile.get("current_archetypes", [])
        and "status" not in profile.get("supporting_archetypes", [])
    ):
        return False
    return status_source_count(gs) + persistent_curse_count(gs) > 0


def status_route_specialization(gs, profile=None):
    """Keep a speculative status payoff from masquerading as elite readiness."""
    profile = profile or archetype_profile(gs)
    specialization = archetype_specialization(gs, profile)
    status_is_direction = bool(
        "status" in profile.get("current_archetypes", [])
        or profile.get("raw_leader") == "status"
    )
    if not status_is_direction:
        return specialization
    if not status_engine_commit_ready(gs):
        return min(0.35, specialization)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    fire_breathing_fuel = (
        persistent_curse_count(gs) if "Fire Breathing" in deck_ids else 0
    )
    if status_source_count(gs) + fire_breathing_fuel == 0:
        return min(0.35, specialization)
    return specialization


def block_damage_engine_ready(gs):
    """Return whether a block shell can turn defense into timely damage."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    if "Juggernaut" in deck_ids:
        return juggernaut_support_ready(gs)
    if "Body Slam" not in deck_ids:
        return False
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Barricade" in deck_ids or "Calipers" in relic_ids:
        return defensive_package_count(gs) >= 2

    # One Body Slam plus one large block card is a useful burst package, but it
    # is not repeatable scaling for Champ or Time Eater. Without retention,
    # require two damage draws and at least two reusable high-block sources.
    repeatable_block_sources = count_deck(gs, {"Power Through", "Flame Barrier"})
    if "Second Wind" in deck_ids and status_source_count(gs) > 0:
        repeatable_block_sources += 1
    return count_deck(gs, {"Body Slam"}) >= 2 and repeatable_block_sources >= 2


def body_slam_support_ready(gs):
    """Require real burst block before drafting Body Slam as an engine card."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if deck_ids & {"Impervious", "Power Through"}:
        return True
    large_block_sources = count_deck(
        gs, {"Impervious", "Power Through", "Flame Barrier"}
    )
    if count_deck(gs, {"Flame Barrier"}) >= 2:
        return True
    if "Entrench" in deck_ids and large_block_sources > 0:
        return True
    if "Barricade" in deck_ids and defensive_package_count(gs) >= 2:
        return True
    if "Second Wind" in deck_ids and status_source_count(gs) > 0:
        return True
    if "Feel No Pain" in deck_ids and exhaust_payoff_ready(gs):
        return True
    return "Calipers" in relic_ids and nonstarter_defense_count(gs) >= 2


def juggernaut_support_ready(gs):
    """Require repeatable nonstarter block before drafting Juggernaut."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    nonstarter_block = nonstarter_defense_count(gs)
    if nonstarter_block >= 3:
        return True
    if nonstarter_block >= 2 and deck_ids & {"Metallicize", "Rage"}:
        return True
    return bool(
        "Feel No Pain" in deck_ids
        and deck_ids
        & {
            "Burning Pact", "Corruption", "Fiend Fire", "Havoc", "Second Wind",
            "Sever Soul", "True Grit",
        }
    )


def act1_elite_offense_ready(gs):
    """Return whether an early deck can finish an Act 1 elite in time."""
    if int(gs.get("act", 1) or 1) != 1:
        return True
    floor = int(gs.get("floor", 0) or 0)
    ascension = int(gs.get("ascension_level", 0) or 0)
    deck = gs.get("deck", [])
    nonstarter_attacks = [
        card for card in deck
        if card.get("type") == "ATTACK"
        and card_id(card) not in {"Strike_R", "Bash"}
    ]
    if len(nonstarter_attacks) >= 2:
        if ascension < 17 or floor > 6:
            return True
        early_frontload_score = sum(
            CARD_SCORES.get(card_id(card), 0)
            + 8 * min(1, int(card.get("upgrades", 0) or 0))
            for card in nonstarter_attacks
        )
        if early_frontload_score >= 105:
            return True
    solo_elite_frontload = {
        "Bludgeon", "Carnage", "Fiend Fire", "Hemokinesis", "Immolate",
        "Perfected Strike", "Uppercut", "Whirlwind",
    }
    if any(card_id(card) in solo_elite_frontload for card in nonstarter_attacks):
        return True
    deck_ids = {card_id(card) for card in deck}
    if nonstarter_attacks and strength_source_count(gs) > 0:
        return True
    if block_damage_engine_ready(gs):
        return True
    if "Fire Breathing" in deck_ids and status_source_count(gs) > 0:
        return True
    if "Rupture" in deck_ids and self_damage_source_count(gs) > 0:
        return True
    return False


def route_combat_specialization(gs, profile=None):
    """Estimate whether archetype focus is mature enough to pay for combats."""
    profile = profile or archetype_profile(gs)
    specialization = status_route_specialization(gs, profile)
    current = profile.get("current_archetypes", [])
    if current == ["block"] and not block_damage_engine_ready(gs):
        # A pile of Shrug It Off cards survives hallway turns but does not kill
        # Act 2 elites. Do not turn defensive card density into elite credit
        # until Body Slam/Juggernaut has a real engine behind it.
        specialization = min(0.25, specialization)
    if (
        bool(gs.get("deck"))
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) <= 7
        and not act1_elite_offense_ready(gs)
    ):
        # One Flame Barrier gave v71 roughly 50% route specialization and led
        # it into floor-6 Lagavulin with no drafted attack.
        specialization = min(0.18, specialization)
    return specialization


def status_payoff_entry_opportunity(gs, profile=None, candidate_id=None):
    """Allow a status payoff to seed an otherwise directionless early deck.

    Evolve and Fire Breathing also receive fuel from enemy-created statuses.
    They are therefore reasonable speculative foundations while no competing
    archetype has a core card or meaningful momentum, even when the deck does
    not yet generate statuses itself. A weak developing score without a core
    card is not enough to close this route prematurely.
    """
    profile = profile or archetype_profile(gs)
    candidate_fuel = status_source_count(gs)
    if candidate_id == "Fire Breathing":
        candidate_fuel += persistent_curse_count(gs)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    guardian_without_fuel = (
        int(gs.get("act", 1) or 1) == 1
        and upcoming_boss_id(gs) in {"guardian", "theguardian"}
        and candidate_fuel == 0
    )
    floor = int(gs.get("floor", 0) or 0)
    if (
        candidate_id == "Evolve"
        and candidate_fuel == 0
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and "Fire Breathing" not in deck_ids
    ):
        # At A18+, enemy-created statuses alone are too intermittent to make
        # Evolve a deck direction. Two consecutive runs drafted it without any
        # owned fuel and never completed the engine. Fire Breathing may still
        # open the speculative route first, and an offered Evolve can then pair
        # with it exactly as the status-archetype policy intends.
        return False
    if guardian_without_fuel and floor >= 7:
        # Enemy-created statuses can justify an early speculative foundation,
        # but Guardian itself supplies none. The logged A17 route still had no
        # fuel on floor eight; Fire Breathing then occupied a boss draw and a
        # Bottled Tornado slot while dealing zero damage across the whole fight.
        return False
    if profile.get("active_archetypes") and "status" not in profile.get("active_archetypes", []):
        return False
    other_archetypes = [name for name in ARCHETYPES if name != "status"]
    if any(profile["core_hits"].get(name, 0) > 0 for name in other_archetypes):
        return False
    offered_cards = (gs.get("screen_state") or {}).get("cards", [])
    for offered in offered_cards:
        cid = card_id(offered)
        if cid in {"Evolve", "Fire Breathing"}:
            continue
        base_score = CARD_SCORES.get(cid, 0)
        other_core = any(
            cid in ARCHETYPE_CORE_CARDS.get(name, set())
            for name in other_archetypes
        )
        if (
            other_core and base_score >= 55
            or cid in UNIVERSAL_REWARD_CARDS and base_score >= 60
            or cid in ACT1_BOSS_DAMAGE_CARDS and base_score >= 60
            or guardian_without_fuel
            and cid in ACT1_BOSS_DAMAGE_CARDS
            and base_score >= 50
        ):
            # Enemy-created statuses still make a speculative payoff viable,
            # but not at the cost of a premium role card or another offered
            # archetype's credible foundation. The logged opening chose Evolve
            # over Pommel Strike and reached Hexaghost without enough output.
            # Guardian itself adds no Status cards, so a solid boss attack such
            # as Clothesline also closes that otherwise-dead speculation.
            return False
    score_limit = 14 if floor <= 16 else 10
    return max((profile["scores"].get(name, 0) for name in other_archetypes), default=0) < score_limit


def pyramid_status_cleanup_capacity(gs):
    """Estimate how reliably a Pyramid deck can remove retained statuses."""
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Medical Kit" in relic_ids:
        return 100

    capacity = 0
    for card in gs.get("deck", []):
        cid = card_id(card)
        if cid == "Second Wind":
            capacity += 55
        elif cid == "Sever Soul":
            capacity += 28
        elif cid == "True Grit":
            capacity += 28 if int(card.get("upgrades", 0) or 0) > 0 else 14
        elif cid == "Fiend Fire":
            # Fiend Fire is a one-shot reset, but a large deck may clog before
            # it is drawn, so it receives much less credit than repeatable tools.
            capacity += 8
    return min(100, capacity)


def exhaust_source_count(gs):
    source_cards = (
        REPEATABLE_EXHAUST_SOURCES
        | MASS_EXHAUST_SOURCES
        | ONE_SHOT_EXHAUST_SOURCES
    )
    return sum(1 for card in gs.get("deck", []) if card_id(card) in source_cards)


def exhaust_payoff_ready(gs):
    """Return whether a payoff power will draw/block often enough to justify itself."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Corruption" in deck_ids or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}:
        return True
    if deck_ids & (
        REPEATABLE_EXHAUST_SOURCES
        | (MASS_EXHAUST_SOURCES - {"Corruption", "Second Wind"})
    ):
        return True
    if "Second Wind" in deck_ids and status_source_count(gs) > 0:
        return True
    # Two single-use cards only repay a fraction of a two-energy Dark Embrace.
    # Three independent triggers are enough to treat the payoff as a real
    # supporting package while later rewards search for repeatable exhaust.
    return exhaust_source_count(gs) >= 3


def second_wind_duplicate_engine_ready(gs):
    """Require dense fuel and a real payoff before adding another Second Wind."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = _relic_ids(gs)
    fuel = status_source_count(gs) + persistent_curse_count(gs)
    payoff_ready = bool(
        deck_ids & {"Feel No Pain", "Dark Embrace", "Evolve", "Fire Breathing"}
        or relic_ids
        & {
            "Dead Branch", "CharonsAshes", "Charon's Ashes",
            "Mark of Pain", "Runic Pyramid",
        }
    )
    return fuel >= 4 and payoff_ready


def dark_embrace_reward_ready(gs):
    """Require enough exhaust throughput to repay a two-energy setup draw."""
    deck_card_ids = [card_id(card) for card in gs.get("deck", [])]
    deck_ids = set(deck_card_ids)
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Corruption" in deck_ids or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}:
        return True
    if deck_ids & {"Burning Pact", "Fiend Fire", "Sever Soul"}:
        return True
    if "Second Wind" in deck_ids and status_source_count(gs) > 0:
        return True
    repeatable_sources = sum(
        card_id_value in REPEATABLE_EXHAUST_SOURCES
        for card_id_value in deck_card_ids
    )
    one_shot_sources = sum(
        card_id_value in ONE_SHOT_EXHAUST_SOURCES
        for card_id_value in deck_card_ids
    )
    # Two isolated exhaust triggers do not repay a two-energy setup. A
    # repeatable source plus two one-shots, or three one-shots, is enough to
    # speculate while later rewards search for a stronger engine.
    return (
        repeatable_sources >= 2
        or (repeatable_sources >= 1 and one_shot_sources >= 2)
        or one_shot_sources >= 3
    )


def upgraded_dark_embrace_bridge(card, gs):
    """Allow a one-energy Dark Embrace to complete a real exhaust shell."""
    if card_id(card) != "Dark Embrace" or int(card.get("upgrades", 0) or 0) <= 0:
        return False
    deck_ids = [card_id(deck_card) for deck_card in gs.get("deck", [])]
    repeatable_sources = sum(
        deck_id in REPEATABLE_EXHAUST_SOURCES for deck_id in deck_ids
    )
    return bool(
        "Feel No Pain" in deck_ids
        and repeatable_sources >= 1
        and exhaust_source_count(gs) >= 2
    )


def late_dark_embrace_engine_ready(gs):
    """Return whether a late Dark Embrace can pay back before the Act 3 boss."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    return bool(
        deck_ids & {"Burning Pact", "Corruption", "Fiend Fire", "Sever Soul"}
        or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}
    )


def corruption_reward_ready(gs):
    """Require skills or a payoff before treating Corruption as an engine."""
    deck = gs.get("deck", [])
    deck_ids = {card_id(card) for card in deck}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    skills = [card for card in deck if card.get("type") == "SKILL"]
    nonstarter_skills = [card for card in skills if card_id(card) != "Defend_R"]
    if relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}:
        return True
    if deck_ids & {"Dark Embrace", "Feel No Pain"}:
        if not is_post_combat_card_reward(gs):
            # A temporary potion/Discovery choice can deploy Corruption now;
            # it does not spend a permanent draw slot and should use the live
            # hand rather than the deck-building density gate below.
            return True
        # A payoff power does not create cards for Corruption to exhaust. The
        # logged A17 transition had only four Defends and one True Grit; taking
        # Corruption over Bludgeon left it unable to control Byrds or Chosen.
        return len(skills) >= 6 and len(nonstarter_skills) >= 2
    return len(skills) >= 7 and len(nonstarter_skills) >= 3


def corruption_payoff_established(gs):
    """Return whether Corruption already has a durable exhaust payoff."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    return bool(
        deck_ids & {"Dark Embrace", "Feel No Pain"}
        or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}
    )


def strength_source_count(gs):
    card_sources = sum(
        1 for card in gs.get("deck", []) if card_id(card) in STRENGTH_SOURCE_CARDS
    )
    relic_sources = sum(
        1 for relic in gs.get("relics", []) if relic.get("id") in STRENGTH_SOURCE_RELICS
    )
    return card_sources + relic_sources


def red_skull_heavy_blade_window(gs):
    """Return whether Red Skull is a dependable near-term Heavy Blade source."""
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Red Skull" not in relic_ids:
        return False
    current_hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", current_hp or 1) or 1))
    if current_hp * 2 <= max_hp:
        return True
    return (
        int(gs.get("act", 1) or 1) == 2
        and upcoming_boss_id(gs) == "champ"
    )


def rupture_long_damage_ready(gs):
    """Require enough repeatable self-damage density for boss scaling."""
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    nullified_sources = (
        TUNGSTEN_NULLIFIED_SELF_DAMAGE_SOURCES
        if relic_ids & {"TungstenRod", "Tungsten Rod"}
        else set()
    )
    source_ids = [
        card_id(card)
        for card in gs.get("deck", [])
        if card_id(card) in SELF_DAMAGE_SOURCE_CARDS
        and card_id(card) not in nullified_sources
    ]
    # Bloodletting is zero-cost, repeats every cycle, and funds the attacks its
    # Rupture trigger scales. Hemokinesis is still only a sparse trigger unless
    # the deck is compact or owns another reusable copy.
    automatic_sources = {"Bloodletting", "Brutality", "Combust", "Pain"}
    reusable_sources = {"Hemokinesis"}
    reusable_count = sum(cid in reusable_sources for cid in source_ids)
    deck_size = len(gs.get("deck", []))
    return bool(
        any(cid in automatic_sources for cid in source_ids)
        or reusable_count >= 2
        or reusable_count >= 1 and (deck_size <= 16 or len(source_ids) >= 3)
    )


def boss_strength_scaling_source_count(gs):
    """Count Strength sources reliable enough for a long Act 3 boss fight."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    count = len(deck_ids & {"Demon Form", "Inflame", "J.A.X.", "Spot Weakness"})
    if "Rupture" in deck_ids and rupture_long_damage_ready(gs):
        count += 1
    for relic in gs.get("relics", []):
        relic_id = relic.get("id")
        if relic_id in {"Brimstone", "Shuriken"}:
            count += 1
        elif relic_id == "Girya" and int(relic.get("counter", 0) or 0) > 0:
            count += 1
    return count


def dedicated_strength_scaling_source_count(gs):
    """Count sources strong enough to justify drafting a dedicated payoff.

    J.A.X. can add Strength over repeated cycles, but paying HP for each use is
    not a durable engine by itself. Keep it in the broad boss-scaling signal,
    while requiring another source before it promotes Heavy Blade over an
    established deck's draw and defense.
    """
    count = boss_strength_scaling_source_count(gs)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    return max(0, count - int("J.A.X." in deck_ids))


def self_damage_source_count(gs):
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    nullified_sources = (
        TUNGSTEN_NULLIFIED_SELF_DAMAGE_SOURCES
        if relic_ids & {"TungstenRod", "Tungsten Rod"}
        else set()
    )
    return sum(
        1
        for card in gs.get("deck", [])
        if card_id(card) in SELF_DAMAGE_SOURCE_CARDS
        and card_id(card) not in nullified_sources
    )


def strength_payoff_count(gs):
    return sum(
        1 for card in gs.get("deck", []) if card_id(card) in STRENGTH_PAYOFF_CARDS
    )


def mature_strength_focus(gs):
    """Keep incidental status fuel from diverting an established Strength run."""
    return bool(
        boss_strength_scaling_source_count(gs) >= 2
        and strength_payoff_count(gs) >= 2
        and count_deck(gs, {"Evolve", "Fire Breathing"}) == 0
    )


def barricade_support_score(gs):
    return sum(
        BARRICADE_SUPPORT_WEIGHTS.get(card_id(card), 0)
        for card in gs.get("deck", [])
    )


def entrench_support_ready(gs):
    """Require both retained Block and a real block payload to double."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    retains_block = "Barricade" in deck_ids or "Calipers" in relic_ids
    return bool(
        retains_block
        and barricade_support_score(gs) >= 2
    )


def nonstarter_defense_count(gs):
    counts = {}
    for card in gs.get("deck", []):
        cid = card_id(card)
        if cid in LATE_ACT1_DEFENSIVE_CARDS:
            counts[cid] = counts.get(cid, 0) + 1
    # Armaments is setup plus five block, not a repeatable defensive package.
    # The logged A6 deck counted three copies as three complete block slots.
    counts["Armaments"] = min(1, counts.get("Armaments", 0))
    return sum(counts.values())


def defensive_package_count(gs):
    counts = {}
    for card in gs.get("deck", []):
        cid = card_id(card)
        if cid in DEFENSIVE_PACKAGE_CARDS:
            if cid == "Sentinel" and exhaust_source_count(gs) == 0:
                continue
            counts[cid] = counts.get(cid, 0) + 1
    counts["Armaments"] = min(1, counts.get("Armaments", 0))
    return sum(counts.values())


def defensive_package_target(gs):
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    ascension = int(gs.get("ascension_level", 0) or 0)
    if act >= 2:
        # One mitigation card such as Shockwave can currently count as a full
        # package slot. Requiring four slots keeps room for three cards that
        # provide real block in longer Act 2 fights.
        return 4
    if floor >= 8:
        return 2
    if floor >= 4 and ascension >= 10:
        # High ascension elites punish a deck that spends all four opening
        # rewards on damage and conditional scaling. Reserve one real defensive
        # draw before the usual floor-five checkpoint.
        return 1
    if floor >= 5 and ascension >= 4:
        # At higher ascension the first elite can already punish an all-offense
        # draft. Start reserving one real defensive slot a floor earlier.
        return 1
    if floor >= 6:
        return 1
    return 0


def defensive_package_shortfall(gs):
    return max(0, defensive_package_target(gs) - defensive_package_count(gs))


def act1_defense_foundation_count(gs):
    return count_deck(gs, ACT1_DEFENSE_FOUNDATION_CARDS)


def act1_defense_foundation_candidate(card_or_id, gs):
    """Secure one real defense, then a second near the Act 1 transition."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    ascension = int(gs.get("ascension_level", 0) or 0)
    foundation_count = act1_defense_foundation_count(gs)
    attack_count = nonstarter_attack_count(gs)
    high_ascension_long_boss = bool(
        ascension >= 17
        and upcoming_boss_id(gs) in {"theguardian", "guardian", "hexaghost"}
    )
    required_attack_count = (
        2
        if high_ascension_long_boss and floor >= 4 and foundation_count == 1
        else 3 if floor <= 8
        else 4 if foundation_count == 1
        else 5
    )
    offense_ready = (
        act1_boss_damage_ready(gs)
        or attack_count >= required_attack_count
    )
    missing_scaling_offered = any(
        early_long_boss_scaling_candidate(reward, gs)
        for reward in (gs.get("screen_state") or {}).get("cards", [])
    )
    return bool(
        act == 1
        and (4 if ascension >= 10 else 5) <= floor < 16
        and foundation_count < 2
        and (
            foundation_count == 0
            or floor >= 10
            or ascension >= 17 and offense_ready
        )
        and offense_ready
        and (
            not missing_scaling_offered
            or (
                high_ascension_long_boss
                and foundation_count <= 1
                and defensive_package_count(gs) <= 1
                and cid in ACT2_HIGH_OUTPUT_DEFENSE_CARDS
            )
        )
        and cid in ACT1_DEFENSE_FOUNDATION_CARDS
        and (
            count_deck(gs, {cid}) == 0
            or (
                foundation_count == 1
                and floor >= 12
                and cid in {"Flame Barrier", "Power Through", "Shrug It Off"}
            )
        )
        and defensive_reward_usable(cid, gs)
    )


def defensive_reward_usable(card_or_id, gs):
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    if cid == "Armaments" and count_deck(gs, {"Armaments"}) >= 1:
        return False
    if cid == "Barricade":
        return barricade_support_score(gs) >= 5
    if cid == "Entrench":
        return entrench_support_ready(gs)
    if cid == "Sentinel":
        return exhaust_source_count(gs) > 0
    return True


def nonstarter_attack_count(gs):
    return sum(
        1
        for card in gs.get("deck", [])
        if card.get("type") == "ATTACK" and card_id(card) not in {"Strike_R", "Bash"}
    )


def act2_direct_block_draw_count(gs):
    """Count cards that can directly turn a draw into recurring survival."""
    counts = {}
    for card in gs.get("deck", []):
        cid = card_id(card)
        if cid not in ACT2_DIRECT_BLOCK_DRAW_CARDS:
            continue
        if cid == "Sentinel" and exhaust_source_count(gs) == 0:
            continue
        if cid == "Rage" and nonstarter_attack_count(gs) < 4:
            continue
        counts[cid] = counts.get(cid, 0) + 1
    # Multiple Armaments still draw as starter-sized block cards. One copy can
    # bridge an attack-heavy deck; later copies do not deepen this role.
    counts["Armaments"] = min(1, counts.get("Armaments", 0))
    return sum(counts.values())


def act1_boss_damage_ready(gs):
    """Return whether the current deck has a credible first-boss damage plan."""
    deck = gs.get("deck", [])
    deck_ids = [card_id(card) for card in deck]
    unconditional_scaling = {"Combust", "Demon Form", "Inflame", "Spot Weakness"}
    if any(cid in unconditional_scaling for cid in deck_ids):
        return True
    if "Fire Breathing" in deck_ids and status_source_count(gs) >= 2:
        return True
    self_damage_sources = {"Bloodletting", "Brutality", "Combust", "Hemokinesis", "Offering", "Pain"}
    if "Rupture" in deck_ids and any(cid in self_damage_sources for cid in deck_ids):
        return True
    frontload_cards = [card for card in deck if card_id(card) in ACT1_BOSS_DAMAGE_CARDS]
    frontload_damage = sum(
        min(28, estimate_damage(card, 3, 0))
        if card_id(card) == "Fiend Fire"
        else estimate_damage(card, 3, 0)
        for card in frontload_cards
    )
    nonstarter_vulnerable = any(cid in {"Shockwave", "Uppercut"} for cid in deck_ids)
    boss_id = upcoming_boss_id(gs)
    # Slime Boss rewards concentrated frontload around the split. Guardian and
    # Hexaghost are longer races where a pile of medium attacks is not enough.
    # A single Fiend Fire plus one vulnerable attack looked sufficient on
    # paper, but the A3 Hexaghost still had 54 HP on turn nine. Hexaghost needs
    # a little more repeatable frontload before the deck stops shopping for
    # damage; Guardian's defensive cycle still rewards the prior threshold.
    if boss_id == "hexaghost":
        frontload_target, vulnerable_discount = 52, 8
    elif boss_id == "theguardian":
        frontload_target, vulnerable_discount = 48, 8
    elif boss_id == "slimeboss":
        # A7 reached Slime Boss with Uppercut, Clothesline, and Whirlwind, but
        # the old 36-point gate declared the deck finished and let a speculative
        # block shell displace both another attack and Inflame. Require enough
        # concentrated damage to push a materially lower split; Vulnerable is
        # useful here, but does not replace another real damage draw.
        frontload_target, vulnerable_discount = 60, 4
    else:
        frontload_target, vulnerable_discount = 48, 8
    vulnerable_target = frontload_target - vulnerable_discount
    return (
        frontload_damage >= frontload_target
        or frontload_damage >= vulnerable_target and nonstarter_vulnerable
    )


def act1_bludgeon_damage_candidate(card_or_id, gs):
    """Recognize Bludgeon as compact first-act boss damage while it is needed."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Bludgeon"
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) < 16
        and not act1_boss_damage_ready(gs)
    )


def act1_rampage_recursion_candidate(card_or_id, gs):
    """Recognize Headbutt plus Rampage as a concrete long-boss damage engine."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Rampage"
        and int(gs.get("act", 1) or 1) == 1
        and 7 <= int(gs.get("floor", 0) or 0) < 16
        and upcoming_boss_id(gs) in {"theguardian", "guardian", "hexaghost"}
        and count_deck(gs, {"Rampage"}) == 0
        and count_deck(gs, {"Headbutt"}) > 0
        and not act1_boss_damage_ready(gs)
    )


def early_rampage_long_boss_candidate(card_or_id, gs):
    """Use one early Rampage as scaling in a still-compact long-boss deck."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    floor = int(gs.get("floor", 0) or 0)
    compact_limit = (
        18
        if (
            int(gs.get("ascension_level", 0) or 0) >= 18
            and upcoming_boss_id(gs) in {"theguardian", "guardian"}
        )
        else 15
    )
    return bool(
        cid == "Rampage"
        and int(gs.get("act", 1) or 1) == 1
        and 1 <= floor <= 8
        and upcoming_boss_id(gs) in {"theguardian", "guardian", "hexaghost"}
        and len(gs.get("deck", [])) <= compact_limit
        and nonstarter_attack_count(gs) >= 1
        and count_deck(gs, {"Rampage"}) == 0
        and not long_boss_damage_ready(gs)
    )


def late_slime_boss_rampage_candidate(card_or_id, gs):
    """Use one Rampage to repair an A18+ Slime Boss damage gap."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    floor = int(gs.get("floor", 0) or 0)
    return bool(
        cid == "Rampage"
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and 10 <= floor < 16
        and upcoming_boss_id(gs) == "slimeboss"
        and count_deck(gs, {"Rampage"}) == 0
        and not long_boss_damage_ready(gs)
        and boss_strength_scaling_source_count(gs) == 0
        and len(gs.get("deck", [])) <= 20
    )


def early_shop_perfected_strike_candidate(card_or_id, gs):
    """Allow one cheap Perfected Strike to convert a starter-heavy early deck."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Perfected Strike"
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) <= 8
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 4
        and nonstarter_attack_count(gs) < 2
        and not act1_boss_damage_ready(gs)
    )


def early_long_boss_scaling_candidate(card_or_id, gs):
    """Open a first long-boss scaling lane while Act 1 can still supply it."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    floor = int(gs.get("floor", 0) or 0)
    if (
        int(gs.get("act", 1) or 1) != 1
        or not 2 <= floor < 16
        or upcoming_boss_id(gs) not in {"theguardian", "hexaghost"}
        or cid not in {"Combust", "Demon Form", "Inflame", "Spot Weakness"}
        or count_deck(gs, {cid}) > 0
    ):
        return False
    if floor >= 9:
        # One Combust is useful chip, but it did not close the logged A16
        # Guardian race. An attack-dense deck may still add its first reliable
        # Strength source at the final reward instead of treating that chip as
        # a complete boss engine.
        return bool(
            cid in {"Inflame", "Spot Weakness"}
            and boss_strength_scaling_source_count(gs) == 0
            and nonstarter_attack_count(gs) >= 3
            and not long_boss_damage_ready(gs)
        )
    if floor < 5 and nonstarter_attack_count(gs) == 0:
        return False
    return (
        not act1_boss_damage_ready(gs)
        or (
            cid in {"Inflame", "Spot Weakness"}
            and boss_strength_scaling_source_count(gs) == 0
        )
    )


def slime_boss_aoe_ready(gs):
    """Return whether the deck can clean up a deliberately softened split."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    if deck_ids & {"Cleave", "Immolate", "Whirlwind"}:
        return True
    # One Combust softens the children but takes several rounds to do so. The
    # logged A16 Slime Boss produced six children while that single copy was the
    # deck's only AoE, so retain the reward bonus for a direct cleanup card.
    if count_deck(gs, {"Combust"}) >= 2:
        return True
    if "Fire Breathing" in deck_ids and status_source_count(gs) > 0:
        return True
    if "Reaper" in deck_ids and strength_source_count(gs) > 0:
        return True
    return False


def slime_boss_aoe_candidate(card_or_id, gs):
    """Keep one real split-cleanup answer eligible before the Act 1 boss."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return (
        int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 6
        and upcoming_boss_id(gs) == "slimeboss"
        and not slime_boss_aoe_ready(gs)
        and cid in SLIME_BOSS_AOE_REWARD_BONUS
        and (cid != "Fire Breathing" or status_source_count(gs) > 0)
    )


DUAL_WIELD_LONG_BOSS_TARGETS = {
    "Bludgeon", "Carnage", "Demon Form", "Heavy Blade", "Immolate",
    "Inflame", "Perfected Strike", "Reaper",
}
FOURTH_ENERGY_RELIC_IDS = {
    "Busted Crown", "Coffee Dripper", "Cursed Key", "Ectoplasm",
    "Fusion Hammer", "Mark of Pain", "Philosopher's Stone", "Runic Dome",
    "SlaversCollar", "Sozu", "Velvet Choker",
}


def dual_wield_long_boss_target_count(gs):
    """Count attacks or stacking Powers worth reproducing over a long fight."""
    return sum(
        card_id(card) in DUAL_WIELD_LONG_BOSS_TARGETS
        and not (
            card_id(card) == "Heavy Blade"
            and strength_source_count(gs) == 0
        )
        and not (
            card_id(card) == "Reaper"
            and strength_source_count(gs) == 0
        )
        for card in gs.get("deck", [])
    )


def dual_wield_long_boss_engine_candidate(card_or_id, gs):
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    if cid != "Dual Wield" or int(gs.get("act", 1) or 1) != 2:
        return False
    if count_deck(gs, {"Dual Wield"}) > 0:
        return False
    target_count = dual_wield_long_boss_target_count(gs)
    has_fourth_energy = bool(_relic_ids(gs) & FOURTH_ENERGY_RELIC_IDS)
    return bool(
        defensive_package_shortfall(gs) == 0
        and target_count >= (2 if has_fourth_energy else 3)
    )


def long_boss_damage_ready(gs):
    """Return whether the deck already owns repeatable Act 2 boss damage."""
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    if "Demon Form" in deck_ids:
        return True
    strength_sources = boss_strength_scaling_source_count(gs)
    strength_payoffs = strength_payoff_count(gs)
    if strength_sources >= 2 and strength_payoffs > 0:
        return True
    if strength_sources >= 1 and strength_payoffs >= 2:
        return True
    if "Fire Breathing" in deck_ids:
        status_sources = status_source_count(gs)
        persistent_curses = persistent_curse_count(gs)
        fire_breathing_copies = count_deck(gs, {"Fire Breathing"})
        if (
            status_sources >= 2
            or persistent_curses >= 2
            or fire_breathing_copies >= 2 and persistent_curses > 0
            or (
                status_sources >= 1
                and {"Evolve", "Combust"} <= deck_ids
            )
        ):
            # Evolve makes one repeatable Wound source cycle reliably, while
            # Combust supplies damage on turns that draw no Status. This exact
            # package already has a long-fight clock and should take missing
            # Act 2 defense instead of adding a three-energy Demon Form.
            return True
    if "Rupture" in deck_ids and rupture_long_damage_ready(gs):
        return True
    if block_damage_engine_ready(gs):
        return True
    if (
        count_deck(gs, {"Dual Wield"}) > 0
        and dual_wield_long_boss_target_count(gs) >= 2
        and (
            bool(_relic_ids(gs) & FOURTH_ENERGY_RELIC_IDS)
            or dual_wield_long_boss_target_count(gs) >= 3
        )
    ):
        return True
    # Starter Strikes make one Perfected Strike hit hard once, but do not make
    # a repeatable long-boss engine. Require a second copy before this package
    # can close Act 2 damage drafting and route caution.
    if (
        count_deck(gs, {"Perfected Strike"}) >= 2
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 6
    ):
        return True
    if "Corruption" in deck_ids and "Juggernaut" in deck_ids:
        return True
    return False


def red_skull_reaper_draw_bridge_candidate(card_or_id, gs):
    """Recognize Brutality as the missing cycle piece for conditional sustain."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", hp or 1) or 1))
    return bool(
        cid == "Brutality"
        and int(gs.get("act", 1) or 1) == 2
        and int(gs.get("floor", 0) or 0) <= 27
        and hp / max_hp >= 0.45
        and "Red Skull" in _relic_ids(gs)
        and count_deck(gs, {"Reaper"}) >= 1
        and count_deck(gs, {"Brutality"}) == 0
        and boss_strength_scaling_source_count(gs) == 0
        and strength_payoff_count(gs) >= 2
    )


def act2_swarm_control_score(gs):
    """Measure real coverage for Byrds, Slavers, and Gremlin Leader adds."""
    deck = gs.get("deck", [])
    deck_ids = {card_id(card) for card in deck}
    score = 0.0
    for cid, value in {
        "Immolate": 1.0,
        "Whirlwind": 0.9,
        "Cleave": 0.75,
        "Combust": 0.7,
        "Thunderclap": 0.45,
    }.items():
        if cid in deck_ids:
            score += value
    combust_copies = sum(card_id(card) == "Combust" for card in deck)
    if combust_copies > 1:
        # A single Combust is too slow for Leader's adds, but two copies deal
        # enough recurring AoE to close the role. Batch 98 still drafted Cleave
        # as if neither copy existed and passed its first Strength engine.
        score += min(0.3, 0.2 * (combust_copies - 1))
    if "Reaper" in deck_ids and strength_source_count(gs) > 0:
        score += 0.65
    if "Fire Breathing" in deck_ids and status_source_count(gs) > 0:
        score += 0.75

    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Mercury Hourglass" in relic_ids:
        score += 0.35
    if "Letter Opener" in relic_ids:
        score += 0.4
    if relic_ids & {"CharonsAshes", "Charon's Ashes"} and has_exhaust_synergy(gs):
        score += 0.6
    return min(1.0, score)


def act2_swarm_control_ready(gs):
    # One Combust helps, but it does not clear Gremlin Leader's adds quickly
    # enough by itself. Whirlwind or equivalent coverage can close this role.
    return act2_swarm_control_score(gs) >= 0.85


def byrd_knockdown_control_score(gs):
    """Measure cheap, concentrated attack instances for A17+ Byrds."""
    score = sum(
        BYRD_KNOCKDOWN_CONTROL_WEIGHTS.get(card_id(card), 0.0)
        for card in gs.get("deck", [])
    )
    return min(1.5, score)


def byrd_knockdown_control_ready(gs):
    """Keep broad AoE and true four-hit control as separate valid answers."""
    return bool(
        act2_swarm_control_ready(gs)
        or byrd_knockdown_control_score(gs) >= 0.95
    )


def high_ascension_byrd_candidate(card_or_id, gs):
    """Repair partial one-hit swarm coverage before leaving Act 1 at A17+."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", hp or 1) or 1))
    swarm_score = act2_swarm_control_score(gs)
    urgent_defense_offered = bool(
        act1_defense_foundation_count(gs) == 0
        and any(
            card_id(offered) in {
                "Flame Barrier", "Impervious", "Power Through",
            }
            for offered in (gs.get("screen_state") or {}).get("cards", [])
        )
    )
    return bool(
        int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and 1 <= int(gs.get("floor", 0) or 0) < 16
        and hp / max_hp >= 0.55
        and 0.45 <= swarm_score < 0.85
        and cid in BYRD_KNOCKDOWN_REWARD_BONUS
        and not byrd_knockdown_control_ready(gs)
        and not urgent_defense_offered
    )


def early_swarm_control_candidate(card_or_id, gs):
    """Secure one real multi-enemy answer before Act 1 rewards thin out."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    if act != 1 or not 1 <= floor <= 6:
        return False
    if act2_swarm_control_score(gs) >= 0.45 or count_deck(gs, {cid}) > 0:
        return False
    return cid in EARLY_SWARM_CONTROL_BONUS


def act2_swarm_control_candidate(card_or_id, gs):
    """Allow one missing swarm answer to cross an archetype boundary."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    at_first_boss_reward = (
        act == 1
        and floor >= 16
        and "Boss" in str(gs.get("room_type") or "")
    )
    late_act1_transition = bool(
        act == 1
        and 10 <= floor < 16
        and act1_boss_damage_ready(gs)
        and act2_swarm_control_score(gs) < 0.45
    )
    if not (
        at_first_boss_reward or late_act1_transition or act == 2
    ) or act2_swarm_control_ready(gs):
        return False
    if count_deck(gs, {cid}) > 0:
        return False
    if cid == "Reaper":
        return strength_source_count(gs) > 0
    if cid == "Fire Breathing":
        # Curses are direct Fire Breathing fuel too. The logged A16 deck had
        # Parasite plus Curse of the Bell, yet the old status-only gate passed
        # Fire Breathing before a forced Slavers route. Keep this as a fallback
        # engine rather than diverting an already complete Strength build.
        return not mature_strength_focus(gs) and (
            status_source_count(gs) > 0 or (
            persistent_curse_count(gs) >= 2
            and not long_boss_damage_ready(gs)
            )
        )
    return cid in ACT2_SWARM_CONTROL_BONUS


def strength_swarm_transition_candidate(card_or_id, gs):
    """Prefer a first Whirlwind once Strength already has one boss payoff."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    return bool(
        cid == "Whirlwind"
        and act == 1
        and 10 <= floor <= 16
        and count_deck(gs, {"Whirlwind"}) == 0
        and count_deck(gs, {"Heavy Blade"}) >= 1
        and strength_source_count(gs) > 0
        and act2_swarm_control_score(gs) < 0.85
    )


def early_strength_whirlwind_candidate(card_or_id, gs):
    """Take the first scalable AoE during the floor-seven reward gap."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Whirlwind"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and 7 <= int(gs.get("floor", 0) or 0) <= 9
        and count_deck(gs, {"Whirlwind"}) == 0
        and strength_source_count(gs) > 0
        and act2_swarm_control_score(gs) < 0.85
    )


def act2_preboss_body_slam_clock_candidate(card_or_id, gs):
    """Turn a mature Act 2 block shell into damage before the boss."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    return bool(
        cid == "Body Slam"
        and int(gs.get("act", 1) or 1) == 2
        and int(gs.get("floor", 0) or 0) >= 31
        and not deck_ids & {"Body Slam", "Juggernaut"}
        and not long_boss_damage_ready(gs)
        and body_slam_support_ready(gs)
        and defensive_package_count(gs) >= 6
        and act2_high_output_defense_count(gs) >= 3
    )


def act2_champ_spot_only_bludgeon_clock_candidate(card_or_id, gs):
    """Take one compact rare hit when conditional Strength overstates the clock."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    relic_ids = _relic_ids(gs)
    offered_ids = {
        card_id(card)
        for card in (gs.get("screen_state") or {}).get("cards", [])
    }
    durable_strength = bool(
        deck_ids & {"Demon Form", "Inflame"}
        or "Rupture" in deck_ids and rupture_long_damage_ready(gs)
        or relic_ids & {"Brimstone", "Shuriken"}
        or any(
            relic.get("id") == "Girya"
            and int(relic.get("counter", 0) or 0) > 0
            for relic in gs.get("relics", [])
        )
    )
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    return bool(
        cid == "Bludgeon"
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and 24 <= int(gs.get("floor", 0) or 0) <= 31
        and upcoming_boss_id(gs) in {"champ", "thechamp"}
        and gs.get("screen_type") == "CARD_REWARD"
        and bool(relic_ids & FOURTH_ENERGY_RELIC_IDS)
        and count_deck(gs, {"Bludgeon"}) == 0
        and count_deck(gs, {"Spot Weakness"}) == 1
        and boss_strength_scaling_source_count(gs) == 1
        and strength_payoff_count(gs) >= 2
        and not durable_strength
        and defensive_package_count(gs) >= 4
        and act2_high_output_defense_count(gs) >= 1
        and hp / max_hp >= 0.50
        and not offered_ids & {"Demon Form", "Inflame", "Limit Break"}
    )


def act2_champ_perfected_scaling_candidate(card_or_id, gs):
    """Add a durable clock when Perfected Strike only supplies flat damage."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid in {"Demon Form", "Inflame", "Spot Weakness"}
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and 24 <= int(gs.get("floor", 0) or 0) <= 31
        and upcoming_boss_id(gs) in {"champ", "thechamp"}
        and gs.get("screen_type") == "CARD_REWARD"
        and count_deck(gs, {cid}) == 0
        and boss_strength_scaling_source_count(gs) == 0
        and count_deck(gs, {"Perfected Strike"}) >= 3
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 7
        and defensive_package_count(gs) >= 3
    )


def act2_damage_engine_candidate(card_or_id, gs):
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    if int(gs.get("act", 1) or 1) != 2 or long_boss_damage_ready(gs):
        return False
    upcoming_boss = upcoming_boss_id(gs)
    relic_ids = _relic_ids(gs)
    if (
        cid == "Carnage"
        and upcoming_boss in {"champ", "thechamp"}
        and "Runic Pyramid" in relic_ids
        and defensive_package_shortfall(gs) > 0
    ):
        # Carnage still exhausts at end of turn under Runic Pyramid. The A19
        # Champ deck called it a long-fight engine over Metallicize+, then lost
        # both the temporary attack and the durable defense it had passed.
        return False
    if cid == "Rampage":
        # Champ gives a weak deck enough cycles for Rampage to become genuine
        # scaling. Pyramid/Pocketwatch, Headbutt, or a compact deck supplies the
        # access needed for that growth instead of another flat Twin Strike.
        return bool(
            upcoming_boss in {"champ", "thechamp"}
            and count_deck(gs, {"Rampage"}) == 0
            and (
                bool(relic_ids & {"Runic Pyramid", "Pocketwatch"})
                or count_deck(gs, {"Headbutt"}) > 0
                or len(gs.get("deck", [])) <= 20
            )
        )
    if cid in {"Bludgeon", "Combust", "Immolate"} and count_deck(gs, {cid}) > 0:
        # A second three-energy frontload card or recurring HP tax fills an
        # existing role; neither is a new long-fight engine. The logged A17
        # decks took both duplicates under this bonus and entered fatal Act 2
        # hallways with less block and draw density.
        return False
    if cid in ACT2_DAMAGE_ENGINE_REWARDS:
        return True
    if dual_wield_long_boss_engine_candidate(cid, gs):
        return True
    if cid == "Body Slam":
        # A mature block shell still needs a way to turn its best defensive
        # draw into boss progress. The A9 Champ deck passed Body Slam despite
        # already owning Impervious and several reusable block cards, then
        # stalled for eighteen turns without a damage engine.
        return body_slam_support_ready(gs) and defensive_package_count(gs) >= 3
    if cid == "Perfected Strike":
        hp = int(gs.get("current_hp", 1) or 1)
        max_hp = max(1, int(gs.get("max_hp", hp) or hp))
        established_strength = boss_strength_scaling_source_count(gs) >= 2
        # A low-reserve Strength deck should deepen survival rather than open a
        # second damage axis from its remaining starter Strikes. The logged A13
        # deck already had Inflame and Spot Weakness, yet Perfected Strike's
        # emergency-engine bonus displaced Shrug immediately after a 36-HP hit.
        return count_deck(gs, PERFECTED_STRIKE_CARDS) >= 4 and not (
            established_strength and hp / max_hp < 0.50
        )
    if cid in {"Heavy Blade", "Pummel", "Reaper"}:
        return strength_source_count(gs) > 0
    if cid == "Limit Break":
        return boss_strength_scaling_source_count(gs) >= 2
    if cid == "Rupture":
        return rupture_long_damage_ready(gs)
    return False


def act2_low_reserve_frontload_candidate(card_or_id, gs):
    """Keep a weak Act 2 hallway deck from rejecting compact safe damage."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    owned_frontload = count_deck(gs, ACT2_LOW_RESERVE_FRONTLOAD_CARDS)
    return (
        int(gs.get("act", 1) or 1) == 2
        and hp / max_hp < 0.42
        and cid in ACT2_LOW_RESERVE_FRONTLOAD_CARDS
        and count_deck(gs, {cid}) == 0
        and owned_frontload < 2
    )


def act2_strength_payoff_candidate(card_or_id, gs):
    """Add one real payoff after Act 2 has established repeatable Strength."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return (
        int(gs.get("act", 1) or 1) == 2
        and dedicated_strength_scaling_source_count(gs) > 0
        and strength_payoff_count(gs) < 2
        and count_deck(gs, {cid}) == 0
        and cid in STRENGTH_PAYOFF_CARDS - {"Limit Break", "Reaper"}
    )


def shuriken_heavy_blade_candidate(card_or_id, gs):
    """Keep the first dedicated Strength payoff in a Shuriken attack deck."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Heavy Blade"
        and int(gs.get("act", 1) or 1) == 2
        and count_deck(gs, {"Heavy Blade"}) == 0
        and "Shuriken" in _relic_ids(gs)
        and nonstarter_attack_count(gs) >= 4
    )


def act2_strength_foundation_candidate(card_or_id, gs):
    """Allow one compact Strength source when attacks lack real scaling."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    late_act1_combust_detour = bool(
        act == 1
        and 8 <= floor < 16
        and count_deck(gs, {"Combust"}) >= 1
        and count_deck(gs, {"Rupture"}) == 0
        and strength_payoff_count(gs) >= 1
    )
    return (
        (
            cid == "Inflame"
            or (
                cid == "Spot Weakness"
                and act == 2
                and strength_payoff_count(gs) >= 2
            )
        )
        and count_deck(gs, {cid}) == 0
        and strength_source_count(gs) == 0
        and nonstarter_attack_count(gs) >= 2
        and (act == 2 or late_act1_combust_detour)
    )


def self_harm_strength_foundation_candidate(card_or_id, gs):
    """Let a mature Act 1 self-damage shell add stable base Strength."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    return bool(
        cid == "Inflame"
        and act == 1
        and 8 <= floor < 16
        and count_deck(gs, {"Inflame", "Demon Form", "Spot Weakness"}) == 0
        and count_deck(gs, {"Rupture"}) >= 1
        and rupture_long_damage_ready(gs)
        and nonstarter_attack_count(gs) >= 2
    )


def act2_jax_spot_weakness_bridge_candidate(card_or_id, gs):
    """Replace a J.A.X.-only Strength signal with repeatable scaling."""
    card = card_or_id if isinstance(card_or_id, dict) else {"id": card_or_id}
    cid = card_id(card)
    multi_hit_payoffs = count_deck(
        gs,
        {"Heavy Blade", "Pummel", "Sword Boomerang", "Twin Strike", "Whirlwind"},
    )
    return bool(
        cid == "Spot Weakness"
        and int(card.get("upgrades", 0) or 0) > 0
        and int(gs.get("ascension_level", 0) or 0) >= 20
        and int(gs.get("act", 1) or 1) == 2
        and 18 <= int(gs.get("floor", 0) or 0) <= 31
        and count_deck(gs, {"Spot Weakness"}) == 0
        and count_deck(gs, {"J.A.X."}) >= 1
        and dedicated_strength_scaling_source_count(gs) == 0
        and count_deck(gs, {"Reaper"}) >= 1
        and multi_hit_payoffs >= 2
    )


def act1_boss_transition_damage_candidate(card_or_id, gs):
    """Prioritize a real Act 2 engine in the first boss's rare reward."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return (
        int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and not long_boss_damage_ready(gs)
        and cid in ACT2_DAMAGE_ENGINE_REWARDS
        and not (
            cid in {"Bludgeon", "Combust", "Immolate"}
            and count_deck(gs, {cid}) > 0
        )
    )


def act1_boss_bludgeon_over_unsupported_double_tap_candidate(card_or_id, gs):
    """Prefer compact damage when Double Tap has no worthwhile target yet."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    reward_ids = {
        card_id(reward)
        for reward in (gs.get("screen_state") or {}).get("cards", [])
    }
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    return (
        cid == "Bludgeon"
        and act1_boss_transition_damage_candidate(cid, gs)
        and "Double Tap" in reward_ids
        and not deck_ids & DOUBLE_TAP_PREMIUM_ATTACKS
    )


def act1_boss_bludgeon_over_feed_transition_candidate(card_or_id, gs):
    """Take compact Act 2 frontload before Feed in a thin A19 attack package."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    reward_ids = {
        card_id(reward)
        for reward in (gs.get("screen_state") or {}).get("cards", [])
    }
    return bool(
        cid == "Bludgeon"
        and int(gs.get("ascension_level", 0) or 0) >= 19
        and act1_boss_transition_damage_candidate(cid, gs)
        and "Feed" in reward_ids
        and count_deck(gs, ACT2_LOW_RESERVE_FRONTLOAD_CARDS) == 0
        and nonstarter_attack_count(gs) <= 3
    )


def act1_boss_feed_over_unsupported_double_tap_candidate(card_or_id, gs):
    """Prefer Feed when Double Tap would only duplicate ordinary attacks."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    reward_ids = {
        card_id(reward)
        for reward in (gs.get("screen_state") or {}).get("cards", [])
    }
    deck_ids = {card_id(deck_card) for deck_card in gs.get("deck", [])}
    return bool(
        cid == "Feed"
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and count_deck(gs, {"Feed"}) == 0
        and "Double Tap" in reward_ids
        and not deck_ids & DOUBLE_TAP_PREMIUM_ATTACKS
    )


def act1_boss_transition_scaling_candidate(card_or_id, gs):
    """Distinguish repeatable boss scaling from another front-load rare."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    sustain_reaper_offered = any(
        card_id(reward) == "Reaper"
        and act1_boss_transition_sustain_candidate(reward, gs)
        for reward in (gs.get("screen_state") or {}).get("cards", [])
    )
    return (
        cid == "Demon Form"
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and not long_boss_damage_ready(gs)
        and strength_payoff_count(gs) > 0
        and not sustain_reaper_offered
    )


def act1_boss_transition_durable_scaling_candidate(card_or_id, gs):
    """Secure rare long-fight scaling when the other transition roles exist."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Demon Form"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and not long_boss_damage_ready(gs)
        and boss_strength_scaling_source_count(gs) == 0
        and nonstarter_attack_count(gs) >= 3
        and act2_swarm_control_score(gs) >= 0.65
        and act2_high_output_defense_count(gs) >= 1
    )


def act1_boss_perfected_frontload_scaling_candidate(card_or_id, gs):
    """Add durable scaling when Perfected Strike is the deck's only clock."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    offered_ids = {
        card_id(reward)
        for reward in (gs.get("screen_state") or {}).get("cards", [])
    }
    return bool(
        cid == "Demon Form"
        and int(gs.get("ascension_level", 0) or 0) >= 19
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and boss_strength_scaling_source_count(gs) == 0
        and count_deck(gs, {"Perfected Strike"}) >= 2
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 6
        and nonstarter_attack_count(gs) >= 4
        and "Immolate" in offered_ids
        and not offered_ids & (ACT2_HIGH_OUTPUT_DEFENSE_CARDS | {"Reaper"})
    )


def first_boss_status_corruption_bridge_candidate(card_or_id, gs):
    """Recognize Corruption when status defense already supplies its payload."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    offered_ids = {
        card_id(card) for card in (gs.get("screen_state") or {}).get("cards", [])
    }
    return bool(
        cid == "Corruption"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and "Corruption" not in deck_ids
        and corruption_reward_ready(gs)
        and "Second Wind" in deck_ids
        and bool(deck_ids & {"Evolve", "Fire Breathing"})
        and status_source_count(gs) >= 3
        and act2_high_output_defense_count(gs) >= 1
        and count_deck(gs, {"Immolate"}) >= 1
        and "Immolate" in offered_ids
    )


def first_boss_mature_status_immolate_candidate(card_or_id, gs):
    """Prefer upgraded Immolate when it completes an A20 status transition."""
    card = card_or_id if isinstance(card_or_id, dict) else {"id": card_or_id}
    cid = card_id(card)
    deck_ids = {card_id(deck_card) for deck_card in gs.get("deck", [])}
    offered_ids = {
        card_id(offered)
        for offered in (gs.get("screen_state") or {}).get("cards", [])
    }
    return bool(
        cid == "Immolate"
        and int(card.get("upgrades", 0) or 0) > 0
        and int(gs.get("ascension_level", 0) or 0) >= 20
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and {"Evolve", "Fire Breathing"}.issubset(deck_ids)
        and status_source_count(gs) >= 2
        and count_deck(gs, {"Cleave", "Immolate", "Whirlwind"}) == 0
        and "Impervious" in offered_ids
    )


def first_boss_block_damage_bridge_candidate(card_or_id, gs):
    """Turn a dense reusable Block shell into an Act 2 damage engine."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Juggernaut"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and count_deck(gs, {"Juggernaut"}) == 0
        and not block_damage_engine_ready(gs)
        and not long_boss_damage_ready(gs)
        and juggernaut_support_ready(gs)
        and nonstarter_defense_count(gs) >= 4
        and act2_high_output_defense_count(gs) >= 2
    )


def low_reserve_strength_cycle_bridge_candidate(card_or_id, gs):
    """Prefer cycle over a second Heavy Blade in a fragile Strength deck."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    offered_ids = {
        card_id(card) for card in (gs.get("screen_state") or {}).get("cards", [])
    }
    return bool(
        cid == "Burning Pact"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 2
        and 18 <= int(gs.get("floor", 0) or 0) <= 31
        and hp / max_hp <= 0.40
        and len(gs.get("deck", [])) >= 18
        and count_deck(gs, {"Burning Pact"}) == 0
        and count_deck(gs, {"Heavy Blade"}) == 1
        and "Heavy Blade" in offered_ids
        and strength_source_count(gs) >= 2
        and nonstarter_attack_count(gs) >= 4
        and act2_high_output_defense_count(gs) == 0
    )


def low_reserve_strength_draw_bridge_candidate(card_or_id, gs):
    """Prefer upgraded draw over a second Heavy Blade at a fragile reserve."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    upgrades = (
        0 if isinstance(card_or_id, str)
        else int(card_or_id.get("upgrades", 0) or 0)
    )
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    offered_ids = {
        card_id(card) for card in (gs.get("screen_state") or {}).get("cards", [])
    }
    draw_bridges = count_deck(
        gs,
        {"Battle Trance", "Burning Pact", "Offering", "Pommel Strike",
         "Shrug It Off"},
    )
    return bool(
        cid == "Pommel Strike"
        and upgrades > 0
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and 18 <= int(gs.get("floor", 0) or 0) <= 31
        and hp / max_hp <= 0.55
        and len(gs.get("deck", [])) >= 20
        and count_deck(gs, {"Pommel Strike"}) == 0
        and count_deck(gs, {"Heavy Blade"}) == 1
        and "Heavy Blade" in offered_ids
        and strength_source_count(gs) >= 2
        and nonstarter_attack_count(gs) >= 6
        and draw_bridges <= 1
        and act2_high_output_defense_count(gs) <= 1
    )


def late_act1_shop_boss_scaling_candidate(card_or_id, gs):
    """Recognize a cheap first Strength source before a long Act 1 boss."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Inflame"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 13
        and upcoming_boss_id(gs) in {"hexaghost", "theguardian", "guardian"}
        and count_deck(gs, {"Inflame"}) == 0
        and strength_source_count(gs) == 0
        and strength_payoff_count(gs) >= 1
        and nonstarter_attack_count(gs) >= 3
        and not long_boss_damage_ready(gs)
    )


def late_act1_hexaghost_tempo_bridge_candidate(card_or_id, gs):
    """Keep one damage-plus-block draw in a thin Hexaghost Strength deck."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Iron Wave"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and 9 <= int(gs.get("floor", 0) or 0) < 16
        and upcoming_boss_id(gs) == "hexaghost"
        and count_deck(gs, {cid}) == 0
        and strength_source_count(gs) >= 1
        and strength_payoff_count(gs) >= 1
        and nonstarter_attack_count(gs) >= 3
        and 1 <= act1_defense_foundation_count(gs) <= 2
        and len(gs.get("deck", [])) <= 20
    )


def act3_transition_direct_aoe_candidate(card_or_id, gs):
    """Take one immediate AoE attack before Act 3 when the deck has none."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Immolate"
        and int(gs.get("act", 1) or 1) == 2
        and int(gs.get("floor", 0) or 0) >= 33
        and "Boss" in str(gs.get("room_type") or "")
        and count_deck(gs, {"Cleave", "Immolate", "Whirlwind"}) == 0
    )


def act1_boss_transition_limit_break_candidate(card_or_id, gs):
    """Convert an established multi-source Strength deck into boss scaling."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        cid == "Limit Break"
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and count_deck(gs, {"Limit Break"}) == 0
        and strength_source_count(gs) >= 2
        and boss_strength_scaling_source_count(gs) >= 1
        and strength_payoff_count(gs) >= 2
    )


def act2_transition_defense_count(gs):
    return count_deck(gs, ACT2_TRANSITION_DEFENSE_CARDS)


def act2_high_output_defense_count(gs):
    return count_deck(gs, ACT2_HIGH_OUTPUT_DEFENSE_CARDS)


def act2_high_output_defense_candidate(card_or_id, gs):
    """Keep drafting until Act 2 owns one immediate answer to a heavy hit."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return (
        int(gs.get("act", 1) or 1) == 2
        and act2_high_output_defense_count(gs) == 0
        and count_deck(gs, {cid}) == 0
        and cid in ACT2_HIGH_OUTPUT_DEFENSE_CARDS
        and defensive_reward_usable(cid, gs)
    )


def act2_attack_heavy_block_bridge_candidate(card_or_id, gs):
    """Open one direct-defense slot when mitigation inflated the old count."""
    card = card_or_id if isinstance(card_or_id, dict) else {"id": card_or_id}
    cid = card_id(card)
    if cid not in ACT2_ATTACK_HEAVY_BLOCK_BRIDGE_CARDS:
        return False
    if cid == "Armaments" and int(card.get("upgrades", 0) or 0) == 0:
        return False
    return bool(
        int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and nonstarter_attack_count(gs) >= 6
        and act2_direct_block_draw_count(gs) < 3
        and act2_high_output_defense_count(gs) == 0
        and count_deck(gs, {cid}) == 0
        and defensive_reward_usable(cid, gs)
    )


def automaton_artifact_break_bonus(card_or_id, gs):
    """Value the first AoE Artifact breaker before Bronze Automaton."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    if (
        cid != "Shockwave"
        or act != 2
        or floor >= 33
        or upcoming_boss_id(gs) not in {"automaton", "bronzeautomaton"}
        or count_deck(gs, {"Shockwave"}) > 0
    ):
        return 0

    # Shockwave strips two of Automaton's three Artifact charges from every
    # enemy while the deck attacks the Orbs. Existing Weak/Vulnerable cards can
    # then cash in once the final charge is gone, so their count raises the
    # value without making Shockwave a universal mandatory pick.
    followup_count = count_deck(
        gs,
        {"Bash", "Clothesline", "Intimidate", "Thunderclap", "Trip", "Uppercut"},
    )
    bonus = 14 + min(8, followup_count * 2)
    if floor >= 27:
        bonus += 8
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    if hp / max_hp < 0.55:
        bonus += 6
    return bonus


def automaton_preboss_cycle_defense_candidate(card_or_id, gs):
    """Fill a missing repeatable defense role before Bronze Automaton."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    common_window = bool(
        int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and 29 <= int(gs.get("floor", 0) or 0) < 33
        and upcoming_boss_id(gs) in {"automaton", "bronzeautomaton"}
        and act2_high_output_defense_count(gs) == 0
    )
    if not common_window:
        return False
    if cid == "Metallicize":
        # At low reserve the first Metallicize pays block every turn of the
        # long Automaton cycle. It is useful even without Strength synergies.
        return bool(
            hp / max_hp < 0.65
            and count_deck(gs, {"Metallicize"}) == 0
        )
    return bool(
        cid == "Shrug It Off"
        and hp / max_hp < 0.60
        and count_deck(gs, {"Shrug It Off"}) <= 1
        and strength_source_count(gs) >= 2
        and strength_payoff_count(gs) >= 2
    )


def automaton_jax_heavy_blade_candidate(card_or_id, gs):
    """Turn repeatable J.A.X. Strength into a late-Act-2 boss payoff."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    return bool(
        cid == "Heavy Blade"
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and 26 <= int(gs.get("floor", 0) or 0) < 33
        and upcoming_boss_id(gs) in {"automaton", "bronzeautomaton"}
        and count_deck(gs, {"Heavy Blade"}) == 0
        and "J.A.X." in deck_ids
        and strength_payoff_count(gs) > 0
        and hp / max_hp >= 0.45
    )


def late_act1_low_reserve_heavy_block_candidate(card_or_id, gs):
    """Secure one high-output block draw before high-ascension Act 2."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    floor = int(gs.get("floor", 0) or 0)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    hp_ratio = hp / max_hp
    defense_checkpoint = (
        12 <= floor < 16 and hp_ratio < 0.45
    ) or (
        9 <= floor < 12
        and hp_ratio < 0.75
        and nonstarter_attack_count(gs) >= 2
    )
    return bool(
        int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and defense_checkpoint
        and act2_high_output_defense_count(gs) == 0
        and cid in ACT2_HIGH_OUTPUT_DEFENSE_CARDS
        and count_deck(gs, {cid}) == 0
        and defensive_reward_usable(cid, gs)
    )


def low_reserve_defense_candidate(card_or_id, gs):
    """Keep one fresh direct block draw eligible in a dangerous HP window."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    ascension = int(gs.get("ascension_level", 0) or 0)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    dangerous_window = act >= 2 or (
        act == 1 and ascension >= 10 and floor >= 9
    )
    post_boss_heal_pending = bool(
        act == 1
        and floor >= 16
        and "Boss" in str(gs.get("room_type") or "")
    )
    return (
        dangerous_window
        and not post_boss_heal_pending
        and hp / max_hp < 0.46
        and cid in LOW_RESERVE_DEFENSIVE_REWARDS
        and count_deck(gs, {cid}) == 0
        and defensive_reward_usable(cid, gs)
    )


def forced_elite_defense_candidate(card_or_id, gs):
    """Prefer durable mitigation when the visible route cannot dodge an elite."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    ascension = int(gs.get("ascension_level", 0) or 0)
    lookahead_rooms = 3 if ascension >= 10 else 2
    return bool(
        int(gs.get("act", 1) or 1) >= 2
        and hp / max_hp < 0.50
        and forced_elite_within_rooms(gs, max_rooms=lookahead_rooms)
        and cid in FORCED_ELITE_DEFENSIVE_REWARDS
        and defensive_reward_usable(cid, gs)
    )


def act2_attack_saturation_blocks(card_or_id, gs):
    """Reject another ordinary attack while an A20 deck cannot absorb Act 2."""
    card = card_or_id if isinstance(card_or_id, dict) else {"id": card_or_id}
    cid = card_id(card)
    if not (
        int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and card.get("type") == "ATTACK"
        and nonstarter_attack_count(gs) >= 6
        and act2_direct_block_draw_count(gs) < 3
        and act2_high_output_defense_count(gs) == 0
    ):
        return False

    if cid in ACT2_ATTACK_SATURATION_PREMIUM_CARDS:
        return False
    if cid in ACT2_DIRECT_BLOCK_DRAW_CARDS:
        return False
    if cid == "Pommel Strike" and count_deck(gs, {cid}) == 0:
        # One cycle attack improves access to the defense being drafted. Later
        # copies are still subject to the density gate.
        return False
    if (
        cid in {"Clothesline", "Uppercut"}
        and count_deck(gs, HEXAGHOST_WEAK_SOURCES) == 0
        and count_deck(gs, {cid}) == 0
    ):
        # Preserve one Weak bridge; repeated debuff attacks remain attacks.
        return False
    if act2_strength_payoff_candidate(card, gs):
        return False
    if shuriken_heavy_blade_candidate(card, gs):
        return False
    if automaton_jax_heavy_blade_candidate(card, gs):
        return False
    if (
        cid == "Heavy Blade"
        and count_deck(gs, {cid}) == 0
        and red_skull_heavy_blade_window(gs)
    ):
        return False
    if cid == "Rampage" and act2_damage_engine_candidate(card, gs):
        return False
    if act2_low_reserve_frontload_candidate(card, gs):
        return False
    if act2_swarm_control_candidate(card, gs):
        return False
    return True


def late_mass_block_candidate(card_or_id, gs):
    """Treat supported Second Wind as missing burst defense late in a run."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    non_attack_payload = sum(
        card.get("type") in {"SKILL", "POWER"}
        for card in gs.get("deck", [])
    )
    return (
        cid == "Second Wind"
        and int(gs.get("act", 1) or 1) >= 2
        and int(gs.get("floor", 0) or 0) >= 30
        and act2_high_output_defense_count(gs) == 0
        and count_deck(gs, {cid}) == 0
        and non_attack_payload >= 8
    )


def critical_dead_branch_perfected_block_candidate(card_or_id, gs):
    """Prefer the first burst Block after a nearly fatal Act 1 boss."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    return bool(
        cid == "Impervious"
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and hp / max_hp < 0.20
        and "Dead Branch" in _relic_ids(gs)
        and count_deck(gs, {"Perfected Strike"}) > 0
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 5
        and nonstarter_attack_count(gs) >= 2
        and act2_transition_defense_count(gs) >= 1
        and act2_high_output_defense_count(gs) == 0
        and count_deck(gs, {cid}) == 0
    )


def act1_boss_transition_defense_candidate(card_or_id, gs):
    """Fill missing immediate defense when the first boss damage plan is done."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    frontload_attrition_bridge = (
        not long_boss_damage_ready(gs)
        and act1_boss_damage_ready(gs)
        and nonstarter_attack_count(gs) >= 6
        and self_damage_source_count(gs) > 0
        and "Reaper" not in deck_ids
        and act2_high_output_defense_count(gs) == 0
    )
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    critical_corruption_block_bridge = (
        cid == "Impervious"
        and hp / max_hp < 0.40
        and corruption_payoff_established(gs)
        and act2_high_output_defense_count(gs) == 0
    )
    critical_frontload_block_bridge = (
        cid == "Impervious"
        and hp / max_hp < 0.28
        and act1_boss_damage_ready(gs)
        and nonstarter_attack_count(gs) >= 6
        and act2_high_output_defense_count(gs) == 0
    )
    critical_dead_branch_perfected_bridge = (
        critical_dead_branch_perfected_block_candidate(cid, gs)
    )
    # At high ascension, reaching the boss reward below half HP with enough
    # frontload but zero Act 2 defense is evidence of an attrition gap. The
    # inter-act heal repairs the reserve, not the missing heavy-hit answer.
    high_ascension_frontload_block_bridge = (
        cid == "Impervious"
        and int(gs.get("ascension_level", 0) or 0) >= 15
        and hp / max_hp < 0.50
        and act1_boss_damage_ready(gs)
        and nonstarter_attack_count(gs) >= 4
        and act2_transition_defense_count(gs) == 0
        and act2_high_output_defense_count(gs) == 0
        and bool(
            deck_ids
            & {"Bludgeon", "Fiend Fire", "Immolate", "Perfected Strike"}
        )
    )
    return (
        int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and (
            long_boss_damage_ready(gs)
            or frontload_attrition_bridge
            or critical_corruption_block_bridge
            or critical_frontload_block_bridge
            or critical_dead_branch_perfected_bridge
            or high_ascension_frontload_block_bridge
        )
        and (
            act2_transition_defense_count(gs) < 2
            or act2_high_output_defense_count(gs) == 0
        )
        and count_deck(gs, {cid}) == 0
        and cid in ACT1_BOSS_TRANSITION_DEFENSE_REWARDS
    )


def first_boss_light_defense_upgrade_candidate(card_or_id, gs):
    """Upgrade a light Block package with its first burst defensive card."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    offered_ids = {
        card_id(card) for card in (gs.get("screen_state") or {}).get("cards", [])
    }
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    return bool(
        cid == "Impervious"
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and hp / max_hp < 0.55
        and act2_high_output_defense_count(gs) == 0
        and act2_transition_defense_count(gs) >= 2
        and nonstarter_attack_count(gs) >= 4
        and act2_swarm_control_score(gs) >= 0.65
        and "Fiend Fire" in offered_ids
    )


def act1_boss_transition_sustain_candidate(card_or_id, gs):
    """Prefer Strength-scaled Reaper when Act 2 otherwise has no recovery plan."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    hp = int(gs.get("current_hp", 1) or 1)
    max_hp = max(1, int(gs.get("max_hp", hp) or hp))
    repeatable_strength_emergency = (
        int(gs.get("ascension_level", 0) or 0) >= 18
        and hp / max_hp < 0.30
        and boss_strength_scaling_source_count(gs) > 0
    )
    static_strength_emergency = (
        int(gs.get("ascension_level", 0) or 0) >= 18
        and hp / max_hp < 0.18
        and strength_source_count(gs) > 0
    )
    return (
        cid == "Reaper"
        and int(gs.get("act", 1) or 1) == 1
        and int(gs.get("floor", 0) or 0) >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and count_deck(gs, {"Reaper"}) == 0
        and (
            boss_strength_scaling_source_count(gs) > 0
            or static_strength_emergency
        )
        and (
            route_recovery_factor(gs) < 0.35
            or repeatable_strength_emergency
            or static_strength_emergency
        )
    )


def combat_player_power_amount(gs, power_id):
    player = (gs.get("combat_state") or {}).get("player") or {}
    for power in player.get("powers", []):
        if (power.get("id") or power.get("name")) == power_id:
            return int(power.get("amount", 0) or 0)
    return 0


def awakened_one_curiosity_active(gs):
    """Return whether the live Awakened One still gains Strength from Powers."""
    for monster in (gs.get("combat_state") or {}).get("monsters", []):
        if (
            monster.get("id") != "AwakenedOne"
            or monster.get("is_gone")
            or int(monster.get("current_hp", 0) or 0) <= 0
        ):
            continue
        curiosity = next(
            (
                int(power.get("amount", 0) or 0)
                for power in monster.get("powers", [])
                if (power.get("id") or power.get("name")) == "Curiosity"
            ),
            0,
        )
        if curiosity > 0:
            return True
    return False


def awakened_active_power_count(gs):
    """Estimate how many persistent card Powers are already active."""
    tracked = {
        "Barricade", "Berserk", "Brutality", "Combust", "Corruption",
        "Dark Embrace", "Demon Form", "Evolve", "Feel No Pain",
        "Fire Breathing", "Juggernaut", "Metallicize", "Rupture",
    }
    player = (gs.get("combat_state") or {}).get("player") or {}
    return sum(
        (power.get("id") or power.get("name")) in tracked
        and int(power.get("amount", 0) or 0) != 0
        for power in player.get("powers", [])
    )


def awakened_key_power_choice_value(card, gs):
    """Value a supported temporary Power despite Awakened One's Curiosity."""
    if card.get("type") != "POWER" or not awakened_one_curiosity_active(gs):
        return 0

    cid = card_id(card)
    player = (gs.get("combat_state") or {}).get("player") or {}
    if any(
        (power.get("id") or power.get("name")) == cid
        for power in player.get("powers", [])
    ):
        return 0

    base_values = {
        "Corruption": 115,
        "Dark Embrace": 100,
        "Feel No Pain": 100,
        "Demon Form": 90,
        "Barricade": 90,
        "Juggernaut": 78,
        "Fire Breathing": 78,
        "Evolve": 70,
        "Inflame": 72,
        "Rupture": 70,
        "Metallicize": 45,
    }
    value = base_values.get(cid, 0)
    if value <= 0:
        return 0
    if (
        "Brimstone" in _relic_ids(gs)
        and cid in {"Demon Form", "Inflame", "Rupture"}
    ):
        return 0

    if cid in {"Corruption", "Dark Embrace", "Feel No Pain"}:
        if not exhaust_payoff_ready(gs):
            return 0
    elif cid == "Evolve":
        if status_source_count(gs) <= 0:
            return 0
    elif cid == "Fire Breathing":
        if status_source_count(gs) + persistent_curse_count(gs) <= 0:
            return 0
    elif cid in {"Barricade", "Juggernaut"}:
        if barricade_support_score(gs) < 2 and defensive_package_count(gs) < 2:
            return 0
    elif cid == "Rupture":
        if self_damage_source_count(gs) <= 0:
            return 0
    elif cid == "Demon Form":
        if strength_payoff_count(gs) <= 0:
            return 0

    hp = int(player.get("current_hp", gs.get("current_hp", 1)) or 1)
    max_hp = max(1, int(player.get("max_hp", gs.get("max_hp", hp)) or hp))
    hp_ratio = hp / max_hp
    active_powers = awakened_active_power_count(gs)
    if hp_ratio < 0.25 or hp_ratio < 0.45 and active_powers:
        return 0
    if active_powers >= 2:
        value //= 4
    elif active_powers == 1:
        value //= 2
    if hp_ratio < 0.55:
        value //= 2
    return value + 5 * min(int(card.get("upgrades", 0) or 0), 1)


def upcoming_boss_id(gs):
    """Read the act boss from the common CommunicationMod field variants."""
    screen = gs.get("screen_state") or {}
    candidates = [
        gs.get("act_boss"), gs.get("boss"), gs.get("boss_id"),
        screen.get("act_boss"), screen.get("boss"), screen.get("boss_id"),
    ]
    for value in candidates:
        if isinstance(value, dict):
            value = value.get("id") or value.get("name")
        if value:
            return str(value).replace(" ", "").lower()
    return ""


def awakened_brimstone_redundant_power(card_or_id, gs):
    """Reject another Strength Power when Brimstone already runs this race."""
    cid = card_or_id if isinstance(card_or_id, str) else card_id(card_or_id)
    return bool(
        int(gs.get("act", 1) or 1) == 3
        and upcoming_boss_id(gs) in {"awakenedone", "awakened"}
        and "Brimstone" in _relic_ids(gs)
        and cid in {"Demon Form", "Inflame", "Rupture"}
    )


def relic_card_reward_bonus(card, gs):
    """Value a permanent card by the relic engines it can actually trigger."""
    relic_ids = canonical_relic_ids(gs)
    cid = card_id(card)
    card_type = card.get("type") or ""
    cost = card_cost(card)
    bonus = 0

    if card_type == "ATTACK" and "Molten Egg 2" in relic_ids:
        bonus += 7
    elif card_type == "SKILL" and "Toxic Egg 2" in relic_ids:
        bonus += 7
    elif card_type == "POWER" and "Frozen Egg 2" in relic_ids:
        bonus += 8

    attack_chain_relics = relic_ids & {
        "Kunai", "Nunchaku", "Ornamental Fan", "Pen Nib", "Shuriken",
    }
    cheap_attack = card_type == "ATTACK" and (cost <= 1 or cid == "Whirlwind")
    if cheap_attack and attack_chain_relics:
        bonus += min(18, len(attack_chain_relics) * 4)
    if "Akabeko" in relic_ids and cid in {
        "Cleave", "Fiend Fire", "Pummel", "Reaper", "Sword Boomerang",
        "Thunderclap", "Twin Strike", "Whirlwind",
    }:
        bonus += 12
    if "StrikeDummy" in relic_ids and cid in PERFECTED_STRIKE_CARDS:
        bonus += 15
    if "Gremlin Horn" in relic_ids and cid in {
        "Cleave", "Immolate", "Reaper", "Thunderclap", "Whirlwind",
    }:
        bonus += 5

    if "LetterOpener" in relic_ids and card_type == "SKILL" and cost <= 1:
        bonus += 6
    if "InkBottle" in relic_ids and cost <= 1 and card_type not in {"STATUS", "CURSE"}:
        bonus += 4
    if "Unceasing Top" in relic_ids and cost == 0 and not card.get("unplayable"):
        bonus += 10
    if "Sundial" in relic_ids and cid in DRAW_SETUP_VALUES:
        bonus += 1
    if "TheAbacus" in relic_ids and cid in DRAW_SETUP_VALUES:
        bonus += 3

    if card_type == "POWER":
        if "Mummified Hand" in relic_ids:
            bonus += 12
        if "Bird Faced Urn" in relic_ids:
            bonus += 8
        if "OrangePellets" in relic_ids:
            bonus += 6
    if "Ice Cream" in relic_ids and (cost >= 2 or cid == "Whirlwind"):
        bonus += 7
    if "Chemical X" in relic_ids and cid in X_COST_CARD_IDS:
        bonus += 24
    if "ClockworkSouvenir" in relic_ids and cid in {"Berserk", "Flex"}:
        bonus += 10

    if "Champion Belt" in relic_ids and cid in {
        "Bash", "Shockwave", "Thunderclap", "Uppercut",
    }:
        bonus += 9
    if "Paper Frog" in relic_ids and cid in {
        "Bash", "Shockwave", "Thunderclap", "Uppercut",
    }:
        bonus += 7
    if relic_ids & {"Dead Branch", "Charon's Ashes"} and (
        card.get("exhausts")
        or cid in REPEATABLE_EXHAUST_SOURCES | MASS_EXHAUST_SOURCES
    ):
        bonus += 8
    if "Medical Kit" in relic_ids and cid in {"Evolve", "Fire Breathing"}:
        bonus += 5

    return min(36, bonus)


def high_ascension_long_term_reward_bonus(card, gs):
    """Reward compact cards that keep solving fights after the first act."""
    if (
        not is_post_combat_card_reward(gs)
        or int(gs.get("ascension_level", 0) or 0) < 18
        or int(gs.get("act", 1) or 1) != 1
        or str(card.get("rarity") or "").upper() not in {"UNCOMMON", "RARE"}
    ):
        return 0

    cid = card_id(card)
    supported = cid in HIGH_ASCENSION_PREMIUM_LONG_TERM_CARDS
    if cid == "Corruption":
        supported = corruption_reward_ready(gs)
    elif cid == "Dark Embrace":
        supported = dark_embrace_reward_ready(gs) or upgraded_dark_embrace_bridge(
            card, gs
        )
    elif cid == "Feel No Pain":
        supported = exhaust_payoff_ready(gs)
    elif cid == "Reaper":
        supported = bool(
            strength_source_count(gs) > 0
            or nonstarter_attack_count(gs) >= 2
        )
    elif cid == "Demon Form":
        supported = bool(
            act1_defense_foundation_count(gs) > 0
            or _relic_ids(gs) & FOURTH_ENERGY_RELIC_IDS
        )
    elif cid == "Barricade":
        supported = barricade_support_score(gs) >= 5
    elif cid == "Exhume":
        supported = exhume_reward_ready(gs)
    elif cid == "Limit Break":
        supported = strength_source_count(gs) > 0
    if not supported:
        return 0

    rarity = str(card.get("rarity") or "").upper()
    floor = int(gs.get("floor", 0) or 0)
    return (12 if rarity == "RARE" else 8) + (4 if floor <= 8 else 0)


def act1_transitional_common_penalty(card, gs):
    """Reduce redundant commons whose main value is surviving early hallways."""
    if (
        not is_post_combat_card_reward(gs)
        or int(gs.get("ascension_level", 0) or 0) < 18
        or int(gs.get("act", 1) or 1) != 1
        or str(card.get("rarity") or "").upper() != "COMMON"
    ):
        return 0

    cid = card_id(card)
    if cid not in ACT1_TRANSITIONAL_COMMON_CARDS:
        return 0
    existing_copies = count_deck(gs, {cid})
    attacks = nonstarter_attack_count(gs)
    if existing_copies == 0 and attacks < 2:
        return 0

    penalty = 10 + (4 if int(gs.get("floor", 0) or 0) >= 8 else 0)
    penalty += min(18, existing_copies * 10)

    profile = archetype_profile(gs)
    affinity = card_archetype_affinity(card)
    strong_fit = any(
        affinity.get(archetype, 0) >= 6
        for archetype in profile.get("current_archetypes", [])
    )
    if cid == "Wild Strike" and (
        "Evolve" in {card_id(deck_card) for deck_card in gs.get("deck", [])}
        or "Fire Breathing" in {
            card_id(deck_card) for deck_card in gs.get("deck", [])
        }
    ):
        strong_fit = True
    if cid in {"Sword Boomerang", "Twin Strike"} and strength_source_count(gs) > 0:
        strong_fit = True
    if cid == "Perfected Strike" and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 6:
        strong_fit = True
    if strong_fit:
        penalty = max(0, penalty - 8)
    return penalty


def card_reward_score(card, gs):
    cid = card_id(card)
    score = CARD_SCORES.get(cid, 25 if card.get("type") == "ATTACK" else 18)
    floor = int(gs.get("floor", 0) or 0)
    deck = gs.get("deck", [])
    deck_ids = {card_id(deck_card) for deck_card in deck}
    existing_copies = count_deck(gs, {cid})
    permanent_choice = is_post_combat_card_reward(gs)
    if (
        cid == "Metallicize"
        and int(gs.get("act", 1) or 1) == 1
        and floor <= 3
        and int(gs.get("ascension_level", 0) or 0) >= 10
        and upcoming_boss_id(gs) in {"hexaghost", "theguardian", "guardian"}
        and act1_defense_foundation_count(gs) == 0
        and nonstarter_attack_count(gs) >= 1
    ):
        # Against long Act 1 bosses, an early Metallicize is dozens of block
        # over the fight once the deck already owns its first real attack. It
        # should not be skipped just because the normal defense checkpoint is
        # floor four; the logged A17 Hexaghost died at five HP after 12 turns.
        score += 30
    if (
        cid == "Metallicize"
        and int(gs.get("act", 1) or 1) == 1
        and 9 <= floor < 16
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and upcoming_boss_id(gs) == "hexaghost"
        and existing_copies == 0
        and act1_defense_foundation_count(gs) == 0
    ):
        # The logged A17 deck had enough medium attacks to reach Hexaghost but
        # no durable block. True Grit won the floor-11 reward 77 to 42, then
        # the fight lasted fifteen turns and ended with 67 boss HP. One
        # Metallicize over that span prevents far more damage than another
        # starter-sized block card without diluting the damage draws further.
        score += 40
    if (
        cid == "Power Through"
        and permanent_choice
        and int(gs.get("act", 1) or 1) == 1
        and floor <= 6
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and existing_copies == 0
        and act1_defense_foundation_count(gs) == 0
        and nonstarter_attack_count(gs) >= 1
    ):
        # A18 hallway damage makes a second starter-sized attack less valuable
        # once the deck already has its first damage pickup. The logged deck
        # passed Power Through by sixteen points on floor four, then entered
        # Guardian without a heavy block card. Keep the checkpoint open through
        # the first elite approach rather than ending it after floor three.
        score += 24
    if (
        permanent_choice
        and int(gs.get("act", 1) or 1) == 1
        and floor <= 2
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and upcoming_boss_id(gs) in {
            "hexaghost", "theguardian", "guardian",
        }
        and relic_counter(gs, "NeowsBlessing") > 0
        and existing_copies == 0
        and act1_defense_foundation_count(gs) == 0
        and cid in {
            "Flame Barrier", "Ghostly", "Ghostly Armor",
            "Impervious", "Power Through",
        }
    ):
        # Neow's Lament makes the opening fights free, so a long-boss run can
        # secure one high-output block card before taking a marginal second
        # attack. This deliberately excludes True Grit and other setup-only
        # defenses: an exceptional damage pickup can still win the first reward.
        score += 12
    if (
        cid == "Metallicize"
        and permanent_choice
        and int(gs.get("act", 1) or 1) == 2
        and 18 <= floor < 33
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and upcoming_boss_id(gs) in {"collector", "thecollector"}
        and existing_copies == 0
        and act2_high_output_defense_count(gs) == 0
    ):
        # Collector repeatedly alternates Torch Head waves with long debuff
        # cycles. The logged Strength deck took a second Shrug over its first
        # Metallicize, then lost a seven-turn fight after paying damage on
        # every uncovered cycle. Secure one durable block engine before the
        # boss when the deck still lacks a heavy-hit defensive answer.
        score += 40
    if (
        cid == "Inflame"
        and permanent_choice
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and floor >= 29
        and upcoming_boss_id(gs) in {"automaton", "bronzeautomaton"}
        and existing_copies == 0
        and boss_strength_scaling_source_count(gs) == 0
        and nonstarter_attack_count(gs) >= 8
    ):
        # Automaton begins with three Artifact, so one unupgraded Disarm is
        # often only an Artifact strip.  The logged A19 attack-dense status
        # deck passed its first Inflame immediately before the boss and died
        # with Automaton at 16 HP; two permanent Strength over the observed
        # follow-up attacks supplied more than that missing damage.
        score += 28
    if cid == "Exhume" and not exhume_reward_ready(gs):
        # Dead Branch rewards cards that exhaust, but Exhume still needs a
        # useful card to retrieve. One unupgraded True Grit only creates a
        # random future target and left the logged Guardian deck drawing a
        # blank Exhume four times during the boss fight.
        score -= 100
    if cid in {"Barricade", "Corruption"} and existing_copies:
        # Their defining effect is already active after the first copy; a
        # second expensive draw adds almost no engine value.
        score -= 120
    elif cid == "Dark Embrace" and existing_copies and permanent_choice:
        # Dark Embrace stacks, so a second copy can still be worthwhile in a
        # complete exhaust engine. It is nevertheless another two-energy
        # setup draw. The logged A17 Automaton deck already had Corruption and
        # three other draw cards, spent its entire opening turn on two copies,
        # and still lacked Feel No Pain or burst block. Price that redundancy
        # without weakening the first copy or temporary combat discoveries.
        draw_bridges = sum(
            card_id(deck_card) in {
                "Battle Trance", "Burning Pact", "Offering",
                "Pommel Strike", "Shrug It Off",
            }
            for deck_card in deck
        )
        duplicate_penalty = 12 + max(0, existing_copies - 1) * 14
        if "Feel No Pain" not in deck_ids:
            duplicate_penalty += 6
        if draw_bridges >= 3:
            duplicate_penalty += 6
        if int(card.get("upgrades", 0) or 0) > 0:
            duplicate_penalty -= 6
        score -= max(8, duplicate_penalty)
    elif cid == "Immolate" and existing_copies and permanent_choice:
        first_boss_missing_heavy_block = (
            int(gs.get("act", 1) or 1) == 1
            and floor >= 16
            and "Boss" in str(gs.get("room_type") or "")
            and act2_high_output_defense_count(gs) == 0
            and any(
                card_id(reward) in ACT2_HIGH_OUTPUT_DEFENSE_CARDS
                for reward in (gs.get("screen_state") or {}).get("cards", [])
            )
        )
        if first_boss_missing_heavy_block:
            # One Immolate already solves Act 2 swarms. The logged A17 deck
            # gave a second copy both transition and frontload credit, passed
            # its first Impervious, and entered Snecko with no heavy-hit answer.
            score -= 55
    elif cid == "Offering" and existing_copies:
        # The first Offering is premium acceleration. Each permanent duplicate
        # repeatedly charges another six HP, and the logged A7 Automaton deck
        # reached four copies after a reward, Dolly's Mirror, and a shop buy.
        # One copy is enough unless the deck has an unusually strong sustain
        # loop; Reaper softens, but does not erase, the duplicate cost.
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
        duplicate_penalty = 72 + max(0, existing_copies - 1) * 55
        late_boss_acceleration = bool(
            existing_copies == 1
            and permanent_choice
            and int(gs.get("act", 1) or 1) == 3
            and floor >= 45
            and len(deck) >= 22
            and effective_hp_ratio(gs, revive_weight=0.50) >= 0.58
            and not _relic_ids(gs) & {"Snecko Eye", "Velvet Choker"}
        )
        if late_boss_acceleration:
            # In a large late-Act-3 deck, a second Offering is a separate way
            # to find the first one, the block engine, or the finishing attack.
            # The logged Donu/Deca deck had five energy and the guaranteed final
            # campfire ahead, but the old flat duplicate penalty put Uppercut
            # forty points ahead. Relax only the second copy near the final
            # boss; third and later copies retain the steep historical guard.
            duplicate_penalty -= 36
        if hp_ratio < 0.60:
            duplicate_penalty += 18
        if "Reaper" in deck_ids and boss_strength_scaling_source_count(gs) > 0:
            duplicate_penalty -= 18
        score -= duplicate_penalty
    elif cid == "Feed" and existing_copies:
        # One Feed is enough to convert clean lethal windows into permanent HP.
        # A second copy mostly adds another two-energy attack and can crowd out
        # the defensive engine that creates those windows in the first place.
        score -= 32 + max(0, existing_copies - 1) * 20
    elif cid == "Combust" and existing_copies and permanent_choice:
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        )
        relic_ids = _relic_ids(gs)
        durable_self_harm_payoff = bool(
            "Rupture" in deck_ids
            or relic_ids & {"Runic Cube", "Self Forming Clay"}
            or (
                "Reaper" in deck_ids
                and boss_strength_scaling_source_count(gs) > 0
            )
        )
        if not durable_self_harm_payoff:
            # Two Combust copies cover swarms, but without Rupture, Cube, Clay,
            # or Strength-backed Reaper the second copy is recurring HP loss,
            # not another engine. Batch 98 took it over the first Inflame.
            score -= 30 + max(0, existing_copies - 1) * 12
        if int(gs.get("act", 1) or 1) >= 2 and hp_ratio <= 0.35:
            # Stacking Combust is legitimate with a healthy reserve, but the
            # second copy charges another HP every turn. At 25/82 the logged
            # A17 run drafted it after Book of Stabbing and died in the forced
            # next hallway; low health needs immediate defense or a skip.
            score -= 30 + max(0, existing_copies - 1) * 15
    elif cid == "Fiend Fire" and existing_copies:
        # A second Fiend Fire does not add another exhaust engine; it adds a
        # second draw that asks the deck to delete its remaining hand.  The v73
        # status/exhaust run chose a second copy over Reaper and Offering, then
        # burned Fire Breathing and Bash against Book of Stabbing.  Keep one
        # premium finisher, and require an unusually complete payoff package
        # before accepting another permanent copy.
        relic_ids = {
            relic.get("id") or relic.get("name")
            for relic in gs.get("relics", [])
        }
        complete_engine = (
            "Dark Embrace" in deck_ids
            and "Feel No Pain" in deck_ids
            and ("Corruption" in deck_ids or "Dead Branch" in relic_ids)
        )
        duplicate_penalty = 90 + max(0, existing_copies - 1) * 45
        if complete_engine:
            duplicate_penalty -= 22
        elif "Dark Embrace" in deck_ids or "Feel No Pain" in deck_ids:
            duplicate_penalty -= 10
        score -= max(25, duplicate_penalty)
    elif cid == "Double Tap" and existing_copies:
        # A second copy does not create another damage engine; it adds another
        # setup draw that competes for the same premium attack. The logged A13
        # deck took one over Feed at the Act 1 boss despite already owning an
        # upgraded copy, then entered Act 2 with almost no defense or sustain.
        score -= 30 + max(0, existing_copies - 1) * 20
    elif cid == "Anger" and existing_copies:
        # One Anger already makes more Angers during combat. Extra permanent
        # copies dilute early draws without adding a new engine piece.
        score -= min(48, existing_copies * 24)
    elif cid == "Twin Strike" and existing_copies:
        # Twin Strike is an efficient first Strength payoff, but repeated copies
        # all fill the same role. The logged A10 deck drafted three by floor five
        # and a fourth in Act 2, leaving too few defensive draws for Writhing
        # Mass. Keep the second copy affordable, then make later copies justify
        # themselves through an established Perfected Strike engine.
        if existing_copies == 1:
            duplicate_penalty = 12
        else:
            duplicate_penalty = 45 + (existing_copies - 2) * 25
        if "Perfected Strike" in deck_ids:
            duplicate_penalty = max(6, duplicate_penalty - 20)
        if (
            existing_copies == 1
            and permanent_choice
            and int(gs.get("act", 1) or 1) == 2
            and floor >= 30
            and len(deck) >= 22
            and gs.get("room_type") == "RestRoom"
            and upcoming_boss_id(gs) in {"collector", "thecollector"}
            and act2_high_output_defense_count(gs) <= 2
        ):
            # A final Dream Catcher reward must improve the Collector matchup,
            # not merely add another copy of an existing damage role. The A19
            # deck already had Demon Form, Heavy Blade, Perfected Strike, and
            # Twin Strike; taking a second Twin expanded the cycle that failed
            # to redraw Impervious before the boss's lethal attack hand.
            duplicate_penalty += 18
        score -= duplicate_penalty
    elif cid == "Pummel" and existing_copies:
        pummel_engine_ready = bool(
            strength_source_count(gs) > 0
            or corruption_payoff_established(gs)
        )
        if not pummel_engine_ready:
            # Pummel exhausts after eight unscaled damage. The logged A17
            # Guardian deck took a second copy over Shrug by one point while it
            # had neither Strength nor an exhaust payoff, then ran out of block
            # over a seventeen-turn fight. One copy supplies early frontload;
            # another must belong to an actual engine.
            score -= 24 + max(0, existing_copies - 1) * 18
    elif (
        cid == "Power Through"
        and existing_copies
        and permanent_choice
        and int(gs.get("act", 1) or 1) == 1
        and upcoming_boss_id(gs) == "slimeboss"
        and not (
            deck_ids & {"Fire Breathing", "Second Wind", "Sever Soul", "Fiend Fire"}
            or _relic_ids(gs) & {"Medical Kit", "MedicalKit"}
        )
    ):
        # One Power Through is already enough burst block for the first boss.
        # Without Fire Breathing or a mass Status outlet, a second copy adds
        # two more Wounds per cycle and no damage to Slime Boss's split race.
        # The logged A17 deck had Evolve but no conversion payoff and took the
        # duplicate over Sword Boomerang, then died to the second child wave.
        score -= 45 + max(0, existing_copies - 1) * 15
    elif cid == "Heavy Blade" and existing_copies >= 2:
        # Keep the first two copies premium Strength payoffs.  A third copy is
        # another two-energy damage draw competing with block and draw, which
        # left the logged A16 deck unable to survive Snecko's bad-cost turns.
        duplicate_penalty = 72 + max(0, existing_copies - 2) * 35
        if (
            int(gs.get("act", 1) or 1) >= 2
            and act2_high_output_defense_count(gs) == 0
        ):
            duplicate_penalty += 32
        score -= duplicate_penalty
    elif cid == "Perfected Strike" and existing_copies >= 4 and permanent_choice:
        # Four copies already turn every retained Strike card into a complete
        # damage package. A fifth two-energy attack crowds out Weak and block;
        # the A19 boss reward passed its first Uppercut by eight points before
        # entering Act 2 with no high-output defensive card.
        duplicate_penalty = 14 + max(0, existing_copies - 4) * 18
        if act2_high_output_defense_count(gs) == 0:
            duplicate_penalty += 12
        score -= duplicate_penalty
    elif cid == "Thunderclap" and existing_copies:
        # One copy supplies the cheap all-enemy Vulnerable setup. A second
        # copy is usually another low-output draw rather than a new engine;
        # the logged A15 deck took two by floor five and its Act 2 hallway
        # fights then lasted seven to ten turns.
        score -= min(60, 20 + max(0, existing_copies - 1) * 24)
    elif cid == "Cleave" and existing_copies:
        # One Cleave already supplies direct swarm coverage. A duplicate is
        # especially poor at low Act 2 reserve, where another attack draw
        # cannot replace the burst block or draw that the route needs.
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        )
        duplicate_penalty = 14 + max(0, existing_copies - 1) * 12
        if int(gs.get("act", 1) or 1) >= 2 and hp_ratio <= 0.40:
            duplicate_penalty += 22
        score -= duplicate_penalty
    elif cid == "Pommel Strike" and existing_copies >= 2:
        # The first two copies are excellent draw glue. A third copy in an
        # attack-heavy, three-energy Act 2 deck is another low-block draw,
        # exactly when one burst-defense card is still missing.
        duplicate_penalty = 12 + max(0, existing_copies - 2) * 14
        if (
            int(gs.get("act", 1) or 1) >= 2
            and act2_high_output_defense_count(gs) == 0
            and nonstarter_attack_count(gs) >= 5
        ):
            duplicate_penalty += 30
        score -= duplicate_penalty
    elif cid == "Shrug It Off" and existing_copies:
        # Shrug remains useful draw-plus-block glue in multiple copies.  Do not
        # treat the third or fourth copy as a deck-building failure; only start
        # applying a serious penalty when the candidate would become the fifth
        # permanent copy, then increase it gradually for truly excessive piles.
        if existing_copies == 2:       # taking the third copy
            score -= 4
        elif existing_copies == 3:     # taking the fourth copy
            score -= 10
        elif existing_copies >= 4:     # fifth copy and beyond
            score -= min(90, 35 + (existing_copies - 4) * 20)
    elif (
        cid == "Disarm"
        and existing_copies
        and int(gs.get("act", 1) or 1) == 1
        and floor >= 9
        and "Boss" not in str(gs.get("room_type") or "")
        and not act1_boss_damage_ready(gs)
    ):
        # A second Disarm can be excellent later, but it must not crowd out
        # the damage needed to finish the Act 1 boss before status-heavy late
        # turns lock the hand.
        score -= 18
    elif cid == "Shockwave" and existing_copies:
        # The first copy is premium mitigation. Repeated two-energy copies
        # compete with actual damage and block, especially in retained hands;
        # the third Shockwave in the logged Collector loss displaced Combust
        # and then another damage draw.
        relic_ids = _relic_ids(gs)
        exhaust_engine = bool(
            deck_ids & {"Corruption", "Dark Embrace", "Feel No Pain"}
            or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}
        )
        duplicate_penalty = (45 if exhaust_engine else 70) + max(
            0, existing_copies - 1
        ) * 35
        score -= min(125, duplicate_penalty)
    elif cid == "Spot Weakness" and existing_copies:
        # One repeatable Spot Weakness can carry a deck that has no other
        # scaling. Once Inflame/Demon Form or another reliable source exists,
        # extra copies mostly crowd the same attack-intent window.
        other_reliable_sources = max(
            0, boss_strength_scaling_source_count(gs) - 1
        )
        if existing_copies >= 2:
            duplicate_penalty = 110 + (existing_copies - 2) * 30
        elif other_reliable_sources >= 2:
            duplicate_penalty = 70
        elif other_reliable_sources == 1:
            duplicate_penalty = 42
        else:
            duplicate_penalty = 15
        score -= min(150, duplicate_penalty)
    elif cid == "Headbutt" and existing_copies:
        # One copy can recur the deck's best attack. Additional copies do not
        # increase Perfected Strike's damage and eventually crowd out the
        # defensive cards that let the recursion matter.
        score -= min(60, existing_copies * 25)
    elif cid == "Clothesline" and existing_copies >= 2 and permanent_choice:
        # Two copies can carry Weak across a long fight. A third two-energy copy
        # is usually deck bulk rather than a new defensive role, as the logged
        # A16 Collector deck demonstrated.
        score -= 40 + max(0, existing_copies - 2) * 20
    elif cid == "Armaments" and existing_copies:
        # Armaments+ can upgrade an entire hand, but extra permanent copies
        # repeatedly draw five block instead of adding a new defensive answer.
        score -= min(80, existing_copies * 34)
    elif cid == "True Grit" and existing_copies:
        # The first copy is flexible block and exhaust support. Repeated
        # copies increasingly replace real damage draws, especially before
        # Corruption can make their energy cost disappear.
        score -= min(36, existing_copies * 14)
    elif cid == "Burning Pact" and existing_copies:
        # A second copy accelerates deck depletion and repeatedly competes with
        # real damage draws. One Pact is enough to turn exhaust payoffs on.
        score -= min(42, existing_copies * 22)
    elif cid == "Second Wind" and existing_copies:
        # A second copy repeatedly competes with the attacks and status
        # generators the first copy needs. Only a dense status/curse package
        # with an actual exhaust payoff earns redundancy.
        if second_wind_duplicate_engine_ready(gs):
            score -= min(50, existing_copies * 35)
        else:
            score -= min(130, 105 + max(0, existing_copies - 1) * 20)
    elif cid == "Evolve" and existing_copies:
        # One Evolve already fixes status-heavy draw cycles. Extra copies are
        # setup draws that do not add damage. The logged A8 Guardian deck took
        # a second unfueled copy, then passed the first Reckless Charge that
        # could actually activate both Evolve and Fire Breathing.
        score -= min(130, 85 + max(0, existing_copies - 1) * 35)
    elif cid == "Rupture" and existing_copies >= 2:
        # Two copies can multiply a dense self-damage package. A third setup
        # draw is much harder to deploy and is especially dangerous against
        # Awakened One. The logged A10 deck bought copies two and three in Act
        # 3, then drew two dead Ruptures on its fatal second-phase turn.
        score -= 80 + max(0, existing_copies - 2) * 35
    elif cid == "Fire Breathing" and existing_copies:
        # Fire Breathing stacks: every copy adds another damage trigger whenever
        # a Status or Curse is drawn.  Its fuel/readiness checks elsewhere still
        # decide whether the card belongs in the deck, but duplicate count alone
        # must never lower its reward score.
        pass
    elif cid == "Reaper" and existing_copies:
        # One Reaper is a powerful sustain plan. A second copy competes for
        # two energy and another draw, so it should not beat the Strength
        # source that makes the first copy scale. Keep a smaller penalty once
        # the deck already owns two reliable long-fight Strength sources.
        score -= 22 if boss_strength_scaling_source_count(gs) >= 2 else 45
    elif cid == "Entrench" and existing_copies:
        # One copy can turn Power Through or Impervious into a defensive plan.
        # Without Barricade, extra copies are mostly expensive dead draws; even
        # a Barricade deck receives diminishing value from repeated Entrenches.
        has_barricade = any(card_id(deck_card) == "Barricade" for deck_card in deck)
        penalty_per_copy = 18 if has_barricade else 45
        score -= min(60, existing_copies * penalty_per_copy)
    if (
        cid == "Dual Wield"
        and permanent_choice
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and count_deck(gs, {"Dual Wield"}) == 0
        and dual_wield_long_boss_target_count(gs) < 2
        and defensive_package_shortfall(gs) > 0
        and not dual_wield_long_boss_engine_candidate(card, gs)
    ):
        # Archetype affinity alone made the logged A20 floor-19 reward label
        # Dual Wield as both Perfected Strike and Strength support. It had only
        # one worthwhile copy target and two missing defensive roles, so the
        # setup card diluted the draw without constituting an actual engine.
        score -= 32
    if (
        cid == "Disarm"
        and existing_copies == 0
        and permanent_choice
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and int(card.get("upgrades", 0) or 0) > 0
        and (gs.get("current_hp", 1) or 1)
        / max(1, gs.get("max_hp", 1) or 1) <= 0.60
        and act2_high_output_defense_count(gs) == 0
    ):
        # Upgraded Disarm removes three damage from every later hit. At a thin
        # Act 2 reserve that is a distinct defensive role, not a weaker Iron
        # Wave; batch 89 passed it immediately before Chosen's multi-hit kill.
        score += 32
    if (
        cid == "Disarm"
        and existing_copies == 0
        and int(gs.get("act", 1) or 1) == 2
        and upcoming_boss_id(gs) == "champ"
    ):
        # One Disarm covers Book's growing multi-hit and remains a premium
        # answer after Champ cleanses at half HP. The logged A13 reward chose
        # Shrug instead immediately before a forced Book elite.
        score += 36
    if (
        cid == "Blood for Blood"
        and floor <= 6
        and self_damage_source_count(gs) == 0
    ):
        # Before the deck can lower its four-energy cost on demand, Blood for
        # Blood is often unavailable in the exact Act 1 elite that early damage
        # is meant to solve. Prefer an immediately playable attack when offered.
        score -= 12
    if (
        cid == "Pummel"
        and floor >= 9
        and strength_source_count(gs) == 0
        and "The Boot" not in _relic_ids(gs)
    ):
        # Four two-damage hits are not a boss solution without Strength (or The
        # Boot). The A17 Guardian deck took Pummel over Clothesline, then needed
        # 25 turns to finish neither the elite nor the boss damage race.
        score -= 30
    if cid == "Wild Strike":
        has_evolve = "Evolve" in deck_ids
        has_fire_breathing = "Fire Breathing" in deck_ids
        if not (has_evolve or has_fire_breathing):
            # Wounds are a cost, not an archetype engine. The logged A6
            # Guardian deck treated two unsupported Wild Strikes as a complete
            # status package and clogged its second boss cycle.
            score -= 22 + min(45, existing_copies * 45)
        elif has_evolve and not has_fire_breathing and existing_copies:
            # Evolve repairs the draw lost to Wounds, but does not turn them
            # into damage. The A9 Automaton deck took three Wild Strikes with
            # Evolve alone and spent its boss turns cycling setup instead of
            # producing enough output. One fuel card is enough while the run
            # is still searching for Fire Breathing.
            score -= min(60, existing_copies * 30)
        elif has_fire_breathing and existing_copies >= 2:
            # Fire Breathing makes generated Wounds valuable, so retain two
            # copies before applying only a mild deck-density penalty.
            score -= min(24, (existing_copies - 1) * 12)
    if cid == "Warcry" and int(card.get("upgrades", 0) or 0) <= 0 and floor >= 9:
        # The one-energy version merely replaces itself while delaying one
        # card. Generic exhaust/status affinity pushed it over the late Act 1
        # skip line after unsupported Entrench stopped faking a block core.
        score -= 12
    if cid == "Fiend Fire" and "Dead Branch" in {
        relic.get("id") for relic in gs.get("relics", [])
    }:
        # This is an immediate damage, hand-cleanup and refill engine. The A9
        # first-boss reward had Dead Branch already in play but chose the much
        # slower Demon Form by four points, leaving Act 2 short on tempo.
        score += 24
    if (
        cid == "Offering"
        and existing_copies == 0
        and int(gs.get("act", 1) or 1) == 2
        and upcoming_boss_id(gs) in {"collector", "thecollector"}
        and "Fiend Fire" in deck_ids
    ):
        # Offering both finds Fiend Fire sooner and supplies the energy and hand
        # size that turn it into a real Collector burst. The logged A15 reward
        # put unsupported Reaper four points ahead, then never found a playable
        # Fiend Fire during the fatal boss fight.
        score += 18
    if cid == "Flex":
        relic_ids = _relic_ids(gs)
        locks_in_strength = (
            "Limit Break" in deck_ids
            or bool(
                relic_ids
                & {
                    "ClockworkSouvenir", "Clockwork Souvenir",
                    "OrangePellets", "Orange Pellets",
                }
            )
        )
        if not locks_in_strength and strength_payoff_count(gs) < 2:
            # One Sword Boomerang is not enough reason to add a zero-impact
            # draw. The logged Guardian deck accepted Flex exactly at the skip
            # threshold, then died one draw cycle short of the kill.
            score -= 20
    if cid == "Rage":
        attack_count = sum(1 for deck_card in deck if deck_card.get("type") == "ATTACK")
        if attack_count >= 9:
            # Rage is a compact defensive engine in attack-dense decks. The
            # logged Perfected Strike run skipped it, then exhausted every real
            # block card by turn three of Collector.
            score += min(24, (attack_count - 8) * 4)
            hp = int(gs.get("current_hp", 1) or 1)
            max_hp = max(1, int(gs.get("max_hp", hp) or hp))
            if (
                permanent_choice
                and int(gs.get("act", 1) or 1) == 2
                and hp / max_hp < 0.50
            ):
                # At low reserve, every attack in the next hand turns Rage
                # into useful block. The logged A19 reward tied Rage with a
                # redundant Anger, then died one turn later with four attacks
                # and no block card; break that tie toward the repeatable
                # defensive engine.
                score += 18
    if cid == "Entrench" and not entrench_support_ready(gs):
        score -= 55
    if cid == "Body Slam" and not body_slam_support_ready(gs):
        # Starter Defends and Shrug provide survival, not a dependable Body Slam
        # damage turn. Keep it out until the deck can generate burst block.
        score -= 65
    if (
        floor <= 3
        and nonstarter_attack_count(gs) == 0
        and cid in {"True Grit", "Second Wind", "Burning Pact"}
    ):
        # Exhaust tools are useful after the deck has real cards to cycle toward.
        # Before the first damage pickup they dilute the starter's already thin
        # attack density and can remove the few attacks needed in Sentries.
        score -= 30
    if cid == "Juggernaut" and not juggernaut_support_ready(gs):
        # Starter Defends alone do not make a damage engine. The A7 Hexaghost
        # run took Juggernaut on floor four with only one Shrug, then arrived at
        # the boss with neither scaling nor enough repeated block triggers.
        score -= 55
    if (
        int(gs.get("act", 1) or 1) == 1
        and floor <= 3
        and any(relic.get("id") == "NeowsBlessing" for relic in gs.get("relics", []))
        and nonstarter_defense_count(gs) == 0
        and cid in CRITICAL_HP_DEFENSIVE_REWARDS
    ):
        # Neow's Lament already solves the first few damage checks. Use that
        # temporary safety to secure one high-output defensive draw instead of
        # taking a third attack before the first real elite, as happened in the
        # logged A8 Sentries loss.
        score += 45
    defense_shortfall = defensive_package_shortfall(gs)
    if (
        cid in DEFENSIVE_SHORTFALL_BOOST_CARDS
        and defense_shortfall
        and defensive_reward_usable(cid, gs)
        and not (cid == "Shockwave" and existing_copies)
    ):
        defense_bonus = min(24, defense_shortfall * 12)
        ascension = int(gs.get("ascension_level", 0) or 0)
        if (
            int(gs.get("act", 1) or 1) >= 2 or ascension >= 4
        ) and defense_shortfall == 1:
            # Mature Act 2 decks should not stop one card short of a reliable
            # defensive package merely because their archetype is committed.
            defense_bonus = 24
        if existing_copies and defense_shortfall == 1 and long_boss_damage_ready(gs):
            # A second copy can deepen an existing answer, but it should not
            # displace the missing scaling piece in an otherwise boss-ready
            # deck. The logged Champ route needs its second Inflame more than
            # a second Flame Barrier.
            defense_bonus = min(defense_bonus, 12)
        score += defense_bonus
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
        act = int(gs.get("act", 1) or 1)
        if hp_ratio < 0.55 and (act >= 2 or ascension >= 4):
            # At 44/90 after the Act 2 Slavers, Feed's universal-card score
            # still beat the final missing Iron Wave. The next two forced
            # fights converted that long-term value into an immediate death.
            score += 24
        elif hp_ratio < 0.40:
            # A nearly dead deck needs the missing block now. In v28, Pommel
            # Strike beat Shrug It Off by four points at 18 HP immediately
            # before the fatal Reptomancer route.
            score += 18
    if act1_defense_foundation_candidate(card, gs):
        # Batch 21 repeatedly entered Act 2 with only starter Defends because
        # another archetype-matching attack beat the first real block card.
        # Pay strongly for the first role, then modestly for the second slot.
        score += 36 if act1_defense_foundation_count(gs) == 0 else 32
    low_reserve_first_foundation = bool(
        int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and 4 <= floor < 16
        and (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        ) < 0.60
        and act1_defense_foundation_count(gs) == 0
        and cid in ACT1_DEFENSE_FOUNDATION_CARDS
        and count_deck(gs, {cid}) == 0
        and defensive_reward_usable(cid, gs)
    )
    if low_reserve_first_foundation:
        # The A19 deck left Lagavulin at 38/68 with no nonstarter block,
        # then took Double Tap over Ghostly Armor by four points and died to
        # Hexaghost. Low reserve makes the first real defensive draw necessary
        # even when a competing card is tagged as missing boss scaling.
        score += 12
    if (
        cid == "Feed"
        and permanent_choice
        and existing_copies == 0
        and int(gs.get("ascension_level", 0) or 0) >= 17
        and int(gs.get("act", 1) or 1) == 1
        and 4 <= floor <= 12
        and "Boss" not in str(gs.get("room_type") or "")
        and act1_defense_foundation_count(gs) == 0
        and nonstarter_attack_count(gs) >= 2
        and any(
            card_id(reward) in ACT1_DEFENSE_FOUNDATION_CARDS
            and defensive_reward_usable(reward, gs)
            for reward in (gs.get("screen_state") or {}).get("cards", [])
        )
    ):
        # Feed is premium long-term value, but it cannot create Fatal windows
        # if the deck dies before the first boss. Batch 114 already had
        # Whirlwind and Pummel, passed True Grit for Feed, and never found a
        # nonstarter block card before Hexaghost.
        score -= 24
    if (
        int(gs.get("act", 1) or 1) == 1
        and floor >= 12
        and upcoming_boss_id(gs) == "hexaghost"
        and defense_shortfall == 1
        and nonstarter_attack_count(gs) >= 5
        and cid in DEFENSIVE_SHORTFALL_BOOST_CARDS
        and defensive_reward_usable(cid, gs)
    ):
        # Divider makes the final missing real block draw worth more than a
        # sixth medium attack. The logged A6 deck already had five nonstarter
        # attacks but still took Blood for Blood over Iron Wave by 21 points.
        score += 24
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
    first_boss_damage_emergency = bool(
        int(gs.get("act", 1) or 1) == 1
        and (
            (
                floor >= 16
                and "Boss" in str(gs.get("room_type") or "")
                and not long_boss_damage_ready(gs)
                and defensive_package_count(gs) >= 2
            )
            or (
                floor >= 9
                and upcoming_boss_id(gs) in {
                    "theguardian", "guardian", "hexaghost",
                }
                and not act1_boss_damage_ready(gs)
                and nonstarter_defense_count(gs) >= 3
            )
        )
    )
    if (
        first_boss_damage_emergency
        and floor < 16
        and cid in {"Combust", "Demon Form", "Inflame", "Spot Weakness"}
        and count_deck(gs, {cid}) == 0
    ):
        # A defense-saturated late-Act-1 deck still needs a clock for Guardian
        # or Hexaghost. The A17 deck had four nonstarter block cards, took a
        # redundant Power Through at nine HP, and then needed 25 turns against
        # Guardian. Let the first persistent damage source beat another block
        # pickup once the existing defense package is already credible.
        score += 24
    if (
        hp_ratio < 0.28
        and cid in CRITICAL_HP_DEFENSIVE_REWARDS
        and defensive_reward_usable(cid, gs)
        and not first_boss_damage_emergency
    ):
        # At critical HP, one real block draw is more valuable than another
        # synergy card unless a late Act 1 deck is already defense-saturated
        # and still lacks the damage needed for its long boss.
        critical_bonus = 60
        if (
            int(gs.get("act", 1) or 1) >= 2
            and int(gs.get("ascension_level", 0) or 0) >= 10
        ):
            # At high ascension, leaving an Act 2 reward at critical HP without
            # an immediate block draw is often terminal. The logged Collector
            # run chose Heavy Blade+ over Ghostly Armor at 13/80 HP.
            critical_bonus += 15
        score += critical_bonus
    if low_reserve_defense_candidate(card, gs):
        # Scale the premium with actual danger. This is deliberately a reward-
        # time rule: it does not lower Heavy Blade's normal Strength score, but
        # at 22/74 before Automaton it lets a first Power Through prevent a
        # terminal draw cycle. Milder windows settle close calls such as the
        # logged 103-point Immolate versus 101-point Iron Wave reward.
        reserve_bonus = 18
        if hp_ratio < 0.42:
            reserve_bonus += 12
        if hp_ratio < 0.35:
            reserve_bonus += 20
        if int(gs.get("act", 1) or 1) == 2 and floor >= 28:
            reserve_bonus += 20
        if (
            cid in ACT2_HIGH_OUTPUT_DEFENSE_CARDS
            and act2_high_output_defense_count(gs) < 2
        ):
            reserve_bonus += 20
        score += reserve_bonus
    if forced_elite_defense_candidate(card, gs):
        # The logged A14 deck was at 32/75 with a campfire followed by a forced
        # Book of Stabbing. It took a fourth Strength payoff over Metallicize;
        # Heavy Blade was never safe to spend two energy on, while three block
        # per turn would have covered every remaining multi-hit cycle.
        score += 42
    if late_mass_block_candidate(card, gs):
        # A skill-dense late deck with no burst Block should not reject Second
        # Wind merely because its damage archetype is already committed. The
        # A13 Strength run skipped it at full HP, then had only starter-sized
        # blocks after Reptomancer and died in the next forced hallway.
        score += 55
    if act2_damage_engine_candidate(card, gs):
        score += 45 if floor >= 27 else 35
        if cid == "Rupture" and self_damage_source_count(gs) > 0:
            score += 30
    if act2_preboss_body_slam_clock_candidate(card, gs):
        # Batch 138 reached Collector with Impervious, Power Through and two
        # Flame Barriers but no way to convert those large block turns into
        # progress. A Dream Catcher Body Slam lost to Offering by twelve points;
        # this narrow pre-boss premium closes that clock without promoting an
        # unsupported early copy.
        score += 20
    if act2_champ_spot_only_bludgeon_clock_candidate(card, gs):
        # A single Spot Weakness plus two payoff cards satisfied the broad boss
        # readiness gate, but the logged 26-card deck drew Spot only on Champ's
        # debuff turn and dealt just 187 damage in nine turns. With four energy
        # and an existing defensive shell, one Bludgeon is a compact 32-damage
        # rare that advances the phase clock without pretending Spot is durable.
        score += 52
    if act2_champ_perfected_scaling_candidate(card, gs):
        # Four Perfected Strikes made the broad readiness gate report a complete
        # engine, yet they did not grow through Champ's long first phase. The
        # logged A20 deck passed Demon Form before its final campfire and died
        # after ten turns with 122 boss HP. Add the missing durable Strength axis.
        score += 28
    if act1_boss_transition_scaling_candidate(card, gs):
        # Immolate can solve the next hallway, but it does not stop a three-
        # energy deck from stalling against Champ. Secure the offered repeatable
        # engine when the deck already has a Strength payoff.
        score += 20
    if act1_boss_transition_durable_scaling_candidate(card, gs):
        # One Combust and one heavy block card already cover the minimum Act 2
        # transition roles. The A17 Automaton deck instead took Immolate by 68
        # points, never found scaling, and died with the boss at seven HP.
        score += 75
    if act1_boss_perfected_frontload_scaling_candidate(card, gs):
        # Two upgraded Perfected Strikes already carry the immediate damage
        # role, but they do not grow through Collector's repeated summons. The
        # logged A19 deck took Immolate at 169 over Demon Form at 119, then
        # reached Collector without any durable scaling and stalled at 149 HP.
        score += 60
    if first_boss_status_corruption_bridge_candidate(card, gs):
        # Power Through, Fire Breathing, and Second Wind already make every
        # free Skill and exhaust trigger useful. The logged A17 reward treated
        # a second Immolate as new status fuel and missed this completed bridge.
        score += 24
    if first_boss_mature_status_immolate_candidate(card, gs):
        # The A20 Mark of Pain deck already had upgraded Evolve and Fire
        # Breathing, but chose a second Impervious over Immolate+. Impervious
        # covered one heavy turn; Immolate's 28 AoE plus Burn fuel would have
        # shortened both the 44-damage thieves fight and the later Book race.
        score += 42
    if first_boss_block_damage_bridge_candidate(card, gs):
        # The logged A17 Slime Boss deck already owned Power Through, three
        # Shrugs, and Flame Barrier. Juggernaut converts that repeated Block
        # into the missing Book/Champ clock instead of adding another attack.
        score += 36
    if low_reserve_strength_cycle_bridge_candidate(card, gs):
        # Preserve the first Heavy Blade as the Strength payoff. At critical
        # Act 2 HP, a second copy cannot find the block cards or Demon Form that
        # make the first one work; one Burning Pact can cycle toward both.
        score += 50
    if low_reserve_strength_draw_bridge_candidate(card, gs):
        # The first Heavy Blade remains the Strength deck's dedicated payoff.
        # At low Act 2 reserve, upgraded Pommel reaches that payoff, Reaper, or
        # Flame Barrier more reliably than another two-energy damage draw.
        score += 40
    if act2_jax_spot_weakness_bridge_candidate(card, gs):
        # J.A.X. is one-shot, costs HP, and cannot carry a long Act 2 fight by
        # itself. The logged A20 deck had Reaper, Pummel, and Twin Strike, yet
        # passed Spot Weakness+ by three points and never gained repeatable
        # Strength. Promote this exact engine-completion offer over generic block.
        score += 12
    if act3_transition_direct_aoe_candidate(card, gs):
        # Reaper plus slow Combust looked complete to the Act 2 swarm metric,
        # but neither replaced an immediate multi-target attack in Act 3. The
        # logged reward tied Immolate with unsupported Corruption by list order,
        # then the run was drained by Shapes and Darklings.
        score += 18
    if act1_boss_transition_limit_break_candidate(card, gs):
        # Two Spot Weakness copies plus multi-hit payoffs already produce real
        # Strength. At the first boss reward, Limit Break turns that package
        # into a Champ clock instead of adding a second front-load AoE rare.
        score += 80
    if act2_high_output_defense_candidate(card, gs):
        # Disarm, Weak and small repeatable blocks do not replace one card that
        # can answer Nemesis, Book of Stabbing or an Act 2 boss's heavy turn.
        score += 45
    if act2_attack_heavy_block_bridge_candidate(card, gs):
        # Three batch-142 decks each had six to eight drafted attacks but only
        # two direct defensive draws. Disarm and Shockwave made the broad
        # package look complete; promote one first-copy block bridge anyway.
        score += 18
    score += automaton_artifact_break_bonus(card, gs)
    if late_act1_low_reserve_heavy_block_candidate(card, gs):
        # Light cycle blocks do not replace one draw that can absorb an Act 2
        # heavy hit. At A18, secure that role at the first late-Act-1 checkpoint
        # once frontload is adequate, rather than taking unsupported Brutality.
        score += 26 if int(gs.get("floor", 0) or 0) < 12 else 20
    if automaton_preboss_cycle_defense_candidate(card, gs):
        # This Strength deck already has enough scaling and payoffs. Fill the
        # missing block/draw role before Bronze Automaton's Hyper Beam instead.
        score += 45
    if act2_strength_payoff_candidate(card, gs):
        # The logged A10 Rupture deck had Bloodletting and Reaper, but rejected
        # both offered Strength attacks as off-archetype. One additional payoff
        # converts repeatable Strength into the kill speed Act 2 demands.
        score += 24
    if shuriken_heavy_blade_candidate(card, gs):
        # Pummel and Twin Strike help trigger Shuriken, but they do not replace
        # a card that multiplies the Strength it creates. The logged A19 status
        # deck skipped Heavy Blade+ after gaining Shuriken because generic
        # payoff counting incorrectly marked it as an off-archetype third card.
        score += 28
    if act1_boss_transition_damage_candidate(card, gs):
        # The logged A5 block deck took Impervious over Fiend Fire by three
        # points, then could not outpace Shelled Parasite or Mystic's heals.
        # A boss reward is the last guaranteed chance to add an Act 2 engine.
        # In the A10 batch-10 logs, unsupported Brutality beat Bludgeon by five,
        # and Impervious beat Demon Form by ten despite a complete defense
        # package; both decks then ran out of damage in Act 2.
        score += 40
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        )
        if hp_ratio < 0.28 and defensive_package_count(gs) >= 2:
            # Critical HP normally boosts premium block, but the Act transition
            # cannot repair a deck that has no repeatable damage at all. The
            # logged A10 reward was exactly this collision: Impervious received
            # both critical-defense and transition-defense credit while the
            # only damage engine remained far behind.
            score += 55
    if act1_boss_bludgeon_over_unsupported_double_tap_candidate(card, gs):
        # The A17 deck had only Bash, Anger and Thunderclap as Double Tap
        # targets. Taking setup over Bludgeon's self-contained 32 damage left
        # it without an Act 2 damage clock and it died to Bronze Automaton.
        score += 24
    if act1_boss_bludgeon_over_feed_transition_candidate(card, gs):
        # Feed's permanent HP is excellent after a deck can create lethal
        # windows. The A19 transition deck had only Twin Strike and Iron Wave,
        # chose Feed over 32 immediate damage, then spent six turns breaking a
        # Spheric Guardian and lost 39 HP before its second Act 2 hallway.
        score += 24
    if act1_boss_feed_over_unsupported_double_tap_candidate(card, gs):
        # The A18 Collector deck had no attack worth duplicating, yet generic
        # Strength affinity put Double Tap one point above Feed. Feed supplies
        # comparable front-load while turning routine lethal windows into the
        # reserve the deck lacked in the fourteen-turn boss fight.
        score += 14
    if act1_boss_transition_defense_candidate(card, gs):
        # The logged A8 Strength deck already had Spot Weakness, Whirlwind,
        # and Heavy Blade, yet took another slow scaling power over Impervious.
        # A Shockwave plus one light block card also failed to protect the
        # logged A10 status/Strength deck. Keep looking until the deck owns at
        # least one high-output answer rather than trusting the raw card count.
        shortfall = max(1, 2 - act2_transition_defense_count(gs))
        score += 34 + shortfall * 17
        if not long_boss_damage_ready(gs):
            # A13's dense self-harm/frontload deck already had enough attacks
            # to clear Act 1, but no sustain and no card that could absorb one
            # Act 2 heavy hit. It chose Demon Form over Impervious, then lost 34
            # and 28 HP in its first two hallway fights. Fill that survival role
            # before adding a three-energy scaling turn.
            score += 40
        if (
            cid == "Impervious"
            and hp_ratio < 0.28
            and act1_boss_damage_ready(gs)
            and nonstarter_attack_count(gs) >= 6
            and act2_high_output_defense_count(gs) == 0
        ):
            # Finishing the first boss below 28% despite a saturated frontload
            # package is evidence that the deck lacks a heavy-hit answer. The
            # A17 Slime Boss deck had eight added attacks and two Iron Waves,
            # yet took Immolate over its first burst block and died four rooms
            # into Act 2. The inter-act heal repairs HP, not that structural gap.
            score += 50
    if critical_dead_branch_perfected_block_candidate(card, gs):
        # This shell already has enough Strike density to keep Perfected Strike
        # live, while Dead Branch turns Impervious into both a heavy-hit answer
        # and a generated replacement. The logged A19 run finished Hexaghost at
        # seven HP, passed this card for Immolate, and died in the first Act 2
        # hallway without ever owning burst Block.
        score += 36
    if first_boss_light_defense_upgrade_candidate(card, gs):
        # Several Shrugs and Iron Wave cover ordinary turns but cannot absorb
        # Book, Slavers, or a boss heavy hit. The logged A17 deck already had
        # Whirlwind plus Cleave, yet took Fiend Fire over its first burst block.
        score += 60
    if (
        int(gs.get("act", 1) or 1) == 1
        and floor >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and cid in ACT2_HIGH_OUTPUT_DEFENSE_CARDS
        and act2_high_output_defense_count(gs) == 0
        and not corruption_payoff_established(gs)
        and any(
            card_id(reward) == "Corruption"
            for reward in (gs.get("screen_state") or {}).get("cards", [])
        )
    ):
        # When the reward explicitly offers a payoff-free Corruption pivot,
        # compare it against the missing Act 2 survival role rather than letting
        # generic rare-card value hand the choice to Corruption or base Reaper.
        score += 16
    if act1_boss_transition_sustain_candidate(card, gs):
        # The A6 Strength run took Demon Form over Reaper by two points, then
        # reached Reptomancer with ample damage but no way to recover hallway
        # losses. Existing Strength turns Reaper into both AoE and route sustain.
        sustain_bonus = 30
        if not act2_swarm_control_ready(gs):
            # With an existing Strength source, Reaper simultaneously fills
            # the missing sustain and AoE slots. The logged Collector run took
            # redundant slow scaling instead and never found multi-target
            # damage for the boss's repeated Torch Heads.
            sustain_bonus += 60
        hp = int(gs.get("current_hp", 1) or 1)
        max_hp = max(1, int(gs.get("max_hp", hp) or hp))
        if (
            int(gs.get("ascension_level", 0) or 0) >= 18
            and hp / max_hp < 0.30
            and boss_strength_scaling_source_count(gs) > 0
        ):
            # At 20/85 with Demon Form+, Reaper was already a supported sustain
            # card, but Impervious still won by 45 points because its block is
            # immediate. Price the repeatable Strength conversion separately:
            # it can refill the route several times while one Impervious cannot.
            sustain_bonus += 60
        score += sustain_bonus
    if status_fuel_candidate(card, gs):
        # Enemy statuses make speculative powers usable in some encounters,
        # but a permanent source turns them into a deck engine every fight.
        score += STATUS_FUEL_REWARD_BONUS[cid]
    if early_swarm_control_candidate(card, gs):
        # The logged A15 deck passed Cleave for Pummel on floor two, never saw
        # another AoE reward, and paid heavily in Fungi Beast and Byrd fights.
        # Fill this role once while early rewards are still plentiful.
        score += EARLY_SWARM_CONTROL_BONUS[cid]
        if (
            cid == "Whirlwind"
            and int(gs.get("ascension_level", 0) or 0) >= 18
        ):
            # A18's larger elite and Act 2 multi-enemy health pools make the
            # first scalable AoE role more urgent than another ordinary cycle
            # card. The logged floor-six reward missed Whirlwind by four points
            # and later died to Slavers with no multi-target attack at all.
            score += 10
    if high_ascension_byrd_candidate(card, gs):
        # Cleave is useful AoE, but each play removes only one of A17+'s four
        # Flight stacks.  The logged A19 deck treated that single Cleave as a
        # complete answer, drafted Pommel Strike over Twin Strike, and died to
        # the first three-Byrd fight.  Reserve a separate role for concentrated
        # attack instances, then stop paying this bonus once either role is met.
        score += BYRD_KNOCKDOWN_REWARD_BONUS[cid]
    if act2_swarm_control_candidate(card, gs):
        # A8 twice entered Act 2 without a dependable multi-enemy answer. One
        # run passed Immolate for Barricade by a single point and died to
        # Byrds; another passed Cleave for a fourth defensive card and died to
        # Gremlin Leader's replenishing minions. Fill this encounter gap once,
        # then let normal archetype scoring resume.
        swarm_bonus = ACT2_SWARM_CONTROL_BONUS.get(cid, 0)
        if (
            cid == "Immolate"
            and int(gs.get("act", 1) or 1) == 1
            and floor >= 16
            and "Boss" in str(gs.get("room_type") or "")
            and defensive_package_count(gs) >= 2
            and act2_high_output_defense_count(gs) >= 1
        ):
            # Batch 15 entered Act 2 with Iron Wave, Disarm and Power Through
            # but no multi-target damage. Impervious won the boss reward by 37
            # points, and the deck then died to three Cultists. Once immediate
            # defense is credible, pay for Immolate's missing encounter role.
            swarm_bonus += 45
        if (
            int(gs.get("act", 1) or 1) == 2
            and act2_swarm_control_score(gs) >= 0.45
        ):
            # Partial coverage should complement rather than close the role.
            # In the logged Gremlin Leader run, one Combust suppressed Cleave's
            # entire missing-swarm bonus and Heavy Blade won by 72 points.
            swarm_bonus += 25
        if (
            int(gs.get("act", 1) or 1) == 2
            and upcoming_boss_id(gs) in {"collector", "thecollector"}
        ):
            # Collector can replace both Torch Heads after they are killed.
            # Entering that fight with only single-target attacks turns every
            # summon into another full damage cycle.
            swarm_bonus += 28
        score += swarm_bonus
    if slime_boss_aoe_candidate(card, gs):
        # The logged A8 deck had enough single-target damage to force a split,
        # but only Thunderclap to finish both medium Slimes. Prefer one compact
        # cleanup card before generic draw or another single-target attack.
        score += SLIME_BOSS_AOE_REWARD_BONUS[cid]
    if strength_swarm_transition_candidate(card, gs):
        # A second Heavy Blade improves the same boss draw; Whirlwind converts
        # that Strength into the missing Byrd/Slaver/Leader coverage for Act 2.
        score += 55
    if (
        cid == "Flame Barrier"
        and int(gs.get("act", 1) or 1) == 1
        and (
            4 <= floor < 16
            or (
                1 <= floor <= 3
                and int(gs.get("ascension_level", 0) or 0) >= 15
            )
        )
        and upcoming_boss_id(gs) in {"theguardian", "guardian"}
        and existing_copies == 0
    ):
        # Guardian's four-hit cycle turns the first Flame Barrier into both a
        # high-output block card and 24 contact damage. It should not lose a
        # first-act tie to generic draw or attack-density value. At A17, waiting
        # until floor four made the untouched starter deck pass it on floor two.
        guardian_bonus = 20
        if (
            floor <= 3
            and int(gs.get("ascension_level", 0) or 0) >= 15
            and act1_defense_foundation_count(gs) == 0
        ):
            # At A17, taking Twin Strike over the opening Flame Barrier left
            # the deck with no answer to Guardian's first Fierce Bash cycle.
            # Secure this uniquely efficient block/damage card before routing
            # and later rewards are forced to repair a depleted HP reserve.
            guardian_bonus += 30
        score += guardian_bonus
    if (
        cid == "Flame Barrier"
        and int(gs.get("act", 1) or 1) == 1
        and 12 <= floor < 16
        and int(gs.get("ascension_level", 0) or 0) >= 15
        and upcoming_boss_id(gs) == "hexaghost"
        and existing_copies == 0
        and act2_high_output_defense_count(gs) == 0
        and act1_boss_damage_ready(gs)
    ):
        # Once Hexaghost damage is covered, the last Act 1 rewards must build
        # an Act 2 HP buffer. The logged A17 deck took Hemokinesis over Flame
        # Barrier, lost 51 HP to the boss, and entered Act 2 without one
        # high-output defensive draw.
        score += 30
    if (
        cid == "Flame Barrier"
        and permanent_choice
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and floor <= 3
        and upcoming_boss_id(gs) == "slimeboss"
        and existing_copies == 0
        and act1_defense_foundation_count(gs) == 0
        and nonstarter_attack_count(gs) >= 1
    ):
        # Once the opener has one real attack, A18+ hallway and elite damage
        # make the first premium block draw more urgent than a second medium
        # attack. Flame Barrier also remains useful against the Slime Boss
        # children, so this is defense foundation rather than a dead detour.
        score += 22
    if (
        cid == "Flame Barrier"
        and permanent_choice
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and floor <= 2
        and upcoming_boss_id(gs) == "hexaghost"
        and existing_copies == 0
        and act1_defense_foundation_count(gs) == 0
        and nonstarter_attack_count(gs) <= 1
    ):
        # Divider and Hexaghost's later multi-hit turns convert the first Flame
        # Barrier into both premium block and meaningful boss damage. Keep the
        # offer live after one early attack as well: the logged A19 deck already
        # had Twin Strike, chose Clothesline by nine points, then lost 52 HP to
        # Sentries before reaching Hexaghost without a high-output block card.
        score += 30
    attacks = sum(1 for c in deck if c.get("type") == "ATTACK")
    if floor < 8 and card.get("type") == "ATTACK":
        score += max(0, 7 - attacks) * 4
        if (
            floor >= 1
            and cid not in {"Strike_R", "Bash"}
            and cid in ACT1_BOSS_REWARD_DAMAGE_CARDS
            and not (cid == "Anger" and existing_copies)
        ):
            # Secure two real damage draws before a generic utility card can
            # win on raw score. At floor three of the logged A7 Hexaghost run,
            # this makes Clothesline beat Shrug while the deck owns only Pummel.
            score += max(0, 2 - nonstarter_attack_count(gs)) * 20
        elif (
            cid == "Pommel Strike"
            and floor <= 4
            and existing_copies == 0
            and nonstarter_attack_count(gs) < 2
        ):
            # Pommel Strike is modest raw damage, but early on its draw makes
            # it a complete second tempo pickup. The logged A19 deck chose
            # Headbutt 95 to 69, then took eleven turns against Sentries while
            # its attacks and defensive draws arrived in separate hands.
            score += max(0, 2 - nonstarter_attack_count(gs)) * 20
    if (
        int(gs.get("act", 1) or 1) == 1
        and 4 <= floor <= 8
        and cid == "Carnage"
        and not act1_boss_damage_ready(gs)
    ):
        # Twenty repeatable frontload is materially different from a third
        # medium attack. The A10 Hexaghost deck took its first Shrug here and
        # later died exactly one Carnage cycle short of the kill.
        score += 40
    if (
        permanent_choice
        and cid == "Immolate"
        and existing_copies == 0
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 1
        and 6 <= floor <= 10
        and upcoming_boss_id(gs) == "hexaghost"
        and hp_ratio >= 0.55
        and not act1_boss_damage_ready(gs)
    ):
        # A pile of medium attacks can still miss Hexaghost's A19 damage clock.
        # Immolate compresses substantially more repeatable damage into one draw;
        # batch 90 passed it for Iron Wave by four points and died with 54 HP left.
        score += 16
    if early_long_boss_scaling_candidate(card, gs):
        # Once one real attack has been drafted, a Guardian/Hexaghost route may
        # establish its first engine as early as floor two. Batch 19 already had
        # Clothesline, but another generic attack beat the offered Inflame.
        score += 24
    if act1_bludgeon_damage_candidate(card, gs):
        # Batch 20 passed 32 immediate damage for Double Tap on floor six, then
        # assembled Strength without a meaningful payoff and died to Hexaghost.
        # Keep this bonus scoped to an unresolved first-act damage requirement;
        # Bludgeon does not receive an inflated permanent base score later.
        score += 52
    if act1_rampage_recursion_candidate(card, gs):
        # The logged A17 Guardian deck already had Headbutt but skipped Rampage
        # as off-archetype on floor thirteen. Together they provide repeatable
        # scaling for a long boss rather than one more isolated medium attack.
        rampage_recursion_bonus = 24
        if (
            int(gs.get("ascension_level", 0) or 0) >= 18
            and floor >= 12
            and upcoming_boss_id(gs) == "hexaghost"
        ):
            # Hexaghost's late Burn cycle demands repeatable single-target
            # growth. The logged A19 deck already had Headbutt, but sparse Feel
            # No Pain won by 42 points and the boss survived ten turns.
            rampage_recursion_bonus += 50
        score += rampage_recursion_bonus
    if early_rampage_long_boss_candidate(card, gs):
        # Rampage does not need Headbutt while the deck is still this small:
        # repeated natural cycles scale through Guardian or Hexaghost. The
        # logged A17 Guardian deck instead took Cleave's hallway bonus and
        # exhausted thirteen turns of attacks with the boss still at 48 HP.
        score += 56
    if early_strength_whirlwind_candidate(card, gs):
        # Early swarm coverage used to stop at floor six and resume at floor ten.
        # An A19 Inflame deck found Whirlwind on floor seven, took a second small
        # block card instead, and paid heavily to Slime Boss and Act 2 Byrds.
        score += 28
    if permanent_choice and late_slime_boss_rampage_candidate(card, gs):
        # A late defensive shell still needs repeatable damage before Slime
        # Boss. Disarm affects only the current body and is erased by the split;
        # Rampage keeps scaling through the long child cleanup. The A19 deck
        # took Disarm by fifty points and reached turn fourteen with one large
        # Slime still untouched.
        score += 80
    if (
        int(gs.get("act", 1) or 1) == 1
        and floor <= 7
        and cid == "Perfected Strike"
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 3
        and not act1_boss_damage_ready(gs)
    ):
        # A starter-heavy deck still needs one dependable damage draw before
        # the first elite. This can seed Perfected Strike without making the
        # untouched starter deck count as an established archetype.
        score += 20
    if (
        permanent_choice
        and int(gs.get("act", 1) or 1) == 1
        and gs.get("screen_type") == "CARD_REWARD"
        and upcoming_boss_id(gs) == "hexaghost"
        and cid == "Perfected Strike"
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 4
        and not act1_boss_damage_ready(gs)
        and (
            12 <= floor < 16
            or (
                int(gs.get("ascension_level", 0) or 0) >= 18
                and 9 <= floor < 12
                and nonstarter_attack_count(gs) <= 2
            )
        )
    ):
        # Late in Act 1, Hexaghost needs repeatable single-target output rather
        # than another setup card. Four remaining starter Strikes are enough
        # when the deck still owns at most two drafted attacks; batch 89 chose
        # Brutality here and reached turn ten with 128 boss HP remaining.
        score += 18
        if (
            int(gs.get("ascension_level", 0) or 0) >= 18
            and nonstarter_attack_count(gs) <= 2
        ):
            score += 6
    has_flight_breaker = any(card_id(c) in FLIGHT_BREAKER_CARDS for c in deck)
    if (
        floor < 17
        and cid in FLIGHT_BREAKER_CARDS
        and not has_flight_breaker
    ):
        score += 15
    if (
        floor >= 9
        and int(gs.get("act", 1) or 1) == 1
        and "Boss" not in str(gs.get("room_type") or "")
        and not act1_boss_damage_ready(gs)
    ):
        if cid in ACT1_BOSS_SCALING_CARDS:
            score += 36
        elif cid in ACT1_BOSS_REWARD_DAMAGE_CARDS:
            score += 30
    elif (
        floor >= 9
        and int(gs.get("act", 1) or 1) == 1
        and cid in ACT1_BOSS_SCALING_CARDS
        and upcoming_boss_id(gs) in {"theguardian", "hexaghost"}
    ):
        # Once frontload is adequate, long bosses still reward one compact
        # scaling card over a redundant copy of a medium attack.
        score += 8
    if (
        floor >= 9
        and int(gs.get("act", 1) or 1) == 1
        and "Boss" not in str(gs.get("room_type") or "")
        and upcoming_boss_id(gs) == "hexaghost"
        and cid in HEXAGHOST_WEAK_SOURCES
        and not any(card_id(deck_card) in HEXAGHOST_WEAK_SOURCES for deck_card in deck)
    ):
        # Divider and the later multi-hit cycle make the first Weak source both
        # damage-race support and real survival. The logged A5 deck chose
        # Combust over Clothesline by one point, then died with 81 boss HP.
        score += 16
    if (
        cid == "Combust"
        and int(gs.get("act", 1) or 1) == 1
        and floor >= 12
        and upcoming_boss_id(gs) in {"theguardian", "guardian"}
        and not act1_boss_damage_ready(gs)
        and nonstarter_defense_count(gs) >= 1
        and deck_ids & {"Clothesline", "Shockwave", "Uppercut"}
    ):
        # Guardian rewards sustained, non-contact damage once one Weak source
        # and one real block card already cover survival. The logged A16 deck
        # took Shockwave over Combust despite already owning Clothesline and
        # Flame Barrier, then died after fifteen turns with the boss at 15 HP.
        score += 40
    if (
        floor >= 10
        and int(gs.get("act", 1) or 1) == 1
        and "Boss" not in str(gs.get("room_type") or "")
        and not act1_boss_damage_ready(gs)
        and cid in LATE_ACT1_DEFENSIVE_CARDS
        and nonstarter_defense_count(gs) >= 3
        and not (cid == "Shrug It Off" and existing_copies < 4)
    ):
        # Once a first-act deck already has a real defensive package, another
        # block card cannot displace the damage required for the boss race.
        score -= 65
    if cid in {"Fire Breathing", "Evolve"}:
        permanent_fuel = status_source_count(gs)
        if cid == "Fire Breathing":
            permanent_fuel += persistent_curse_count(gs)
        payoff_count = count_deck(gs, {"Fire Breathing", "Evolve"})
        status_profile = archetype_profile(gs)
        if permanent_fuel == 0:
            if payoff_count == 0 and status_payoff_entry_opportunity(
                gs, status_profile, cid
            ):
                score += 22 if cid == "Fire Breathing" else 18
            else:
                # One payoff may seed a directionless deck. Until real fuel
                # appears, another payoff only compounds dead setup draws.
                score -= 45 + min(70, payoff_count * 35)
        elif cid == "Evolve" and existing_copies == 0 and permanent_fuel >= 2:
            # The first Evolve is the consistency engine for a real status deck.
            # In the logged A16 run, two Power Throughs plus Wild Strike still
            # left it tied with a second Pommel Strike, and generic tie-breaking
            # discarded the archetype's only answer to Wound-heavy draws.
            score += 12 + min(12, permanent_fuel * 3)
    if cid == "Fire Breathing":
        permanent_fuel = status_source_count(gs) + persistent_curse_count(gs)
        if permanent_fuel > 0:
            # Reward actual Status/Curse fuel independently of copy count. This
            # keeps multiple Fire Breathing copies attractive for the intended
            # engine without making an unfueled pile look complete.
            score += min(18, permanent_fuel * 6)
        if existing_copies == 0 and status_source_count(gs) >= 2:
            # One Power Through already creates two Wounds every cycle. The A17
            # block/self-harm deck rejected Fire Breathing despite owning that
            # exact source, then lacked damage for Gremlin Leader and Cultists.
            # Pay once for opening the completed damage engine, even when two
            # weaker archetype scores have already occupied the focus slots.
            score += 40
    retained_statuses = {
        "Power Through": 2,
        "Wild Strike": 1,
        "Reckless Charge": 1,
        "Immolate": 1,
    }
    if (
        cid in retained_statuses
        and any(relic.get("id") == "Runic Pyramid" for relic in gs.get("relics", []))
    ):
        # Pyramid turns generated statuses into permanent hand occupancy. A
        # one-shot Fiend Fire is useful, but it is not reliable enough to make
        # repeated Power Through picks free in a large retained hand.
        pressure = status_source_count(gs)
        clog_penalty = (
            25
            + retained_statuses[cid] * 15
            + pressure * 8
            - pyramid_status_cleanup_capacity(gs)
        )
        score -= max(0, clog_penalty)
    if cid == "Rupture":
        if self_damage_source_count(gs) == 0:
            # Archetype bridge points are not actual self-damage triggers.
            score -= 100
        elif permanent_choice and not rupture_long_damage_ready(gs):
            # One Hemokinesis plus a single-use Offering in a large deck only
            # produces two Strength over an entire first cycle. Do not label
            # that sparse package a complete Act 2 boss engine.
            score -= 45
    source_count = strength_source_count(gs)
    payoff_count = strength_payoff_count(gs)
    has_strength = source_count > 0
    if cid == "Inflame":
        if boss_strength_scaling_source_count(gs) >= 2:
            # Static Strength such as Vajra improves payoffs but does not make a
            # second setup card redundant in a long boss race.
            score -= 65
        elif existing_copies:
            score -= 20
    elif cid == "Demon Form":
        if existing_copies:
            score -= 80
        elif (
            int(gs.get("act", 1) or 1) == 1
            and upcoming_boss_id(gs) == "slimeboss"
            and payoff_count == 0
            and (act1_boss_damage_ready(gs) or floor >= 9)
        ):
            # Demon Form consumes an entire three-energy turn before it deals
            # damage. Against Slime Boss, an unsupported copy does not improve
            # the split quickly enough to displace real frontload plus Weak/
            # Vulnerable such as Uppercut.
            score -= 28
        if (
            permanent_choice
            and int(gs.get("ascension_level", 0) or 0) >= 18
            and int(gs.get("act", 1) or 1) == 1
            and floor <= 6
            and upcoming_boss_id(gs) == "slimeboss"
            and payoff_count == 0
            and act1_defense_foundation_count(gs) == 0
            and nonstarter_attack_count(gs) <= 3
            and not (_relic_ids(gs) & FOURTH_ENERGY_RELIC_IDS)
        ):
            # An unsupported three-cost Power consumes the entire turn in the
            # exact A19 window where hallway damage and the first elite decide
            # the run. Keep Demon Form premium after defense or a Strength
            # payoff exists; before either role is present, take live tempo.
            score -= 24
        if (
            permanent_choice
            and existing_copies == 0
            and int(gs.get("ascension_level", 0) or 0) >= 18
            and int(gs.get("act", 1) or 1) == 1
            and 9 <= floor < 16
            and act1_defense_foundation_count(gs) == 0
            and long_boss_damage_ready(gs)
            and any(
                card_id(reward) in ACT1_DEFENSE_FOUNDATION_CARDS
                and defensive_reward_usable(reward, gs)
                for reward in (gs.get("screen_state") or {}).get("cards", [])
            )
        ):
            # The logged A20 Guardian deck already had repeatable Rupture plus
            # Combust scaling, but spent its final hallway reward on a second,
            # three-energy clock. It entered Act 2 without one nonstarter Block
            # draw. Once the boss clock exists, complete that survival role.
            score -= 48
    if cid in STRENGTH_SOURCE_CARDS and payoff_count > 0:
        score += 20 + min(12, max(0, payoff_count - 1) * 4)
    if cid == "Heavy Blade":
        repeatable_strength = dedicated_strength_scaling_source_count(gs)
        deck_ids = {card_id(deck_card) for deck_card in deck}
        red_skull_window = red_skull_heavy_blade_window(gs)
        automaton_jax_payoff = automaton_jax_heavy_blade_candidate(card, gs)
        strength_engine_ready = repeatable_strength > 0 or (
            has_strength and "Limit Break" in deck_ids
        ) or red_skull_window or automaton_jax_payoff
        if strength_engine_ready:
            # Heavy Blade is the dedicated payoff for an established Strength
            # engine. Multiple independent Strength sources make it safer to
            # treat the card as a defining damage piece rather than a dead draw.
            score += 60 + min(12, max(0, source_count - 1) * 6)
            if red_skull_window:
                # Champ inevitably enables Red Skull before Execute. Heavy
                # Blade converts that conditional Strength into the burst the
                # logged A10 deck missed by four boss HP.
                score += 18
            if automaton_jax_payoff:
                # J.A.X. supplied six Strength over the logged Automaton fight,
                # but the build lock rejected Heavy Blade+ immediately before
                # the boss. Its amplified two-energy hit is the missing race
                # payoff in this narrow, fully supported window.
                score += 18
            if int(card.get("upgrades", 0) or 0) > 0:
                score += 8
        elif has_strength:
            # One point from Vajra or another static relic improves the card,
            # but is not by itself a scaling engine. Keep a useful bonus
            # without letting the first Heavy Blade displace draw or AoE.
            score += 18
            if permanent_choice and existing_copies:
                # Static Strength makes the first copy serviceable, but it does
                # not scale a second copy through a long boss fight. The logged
                # A17 deck took that duplicate over its first Feel No Pain.
                score -= min(48, existing_copies * 24)
        else:
            score -= 30
            if permanent_choice:
                # Two A17 decks treated generic attack affinity as if it were a
                # Strength source, drafted Heavy Blade first, and never found
                # Strength. Keep the card merely serviceable as raw frontload;
                # it becomes a premium payoff only after a real source exists.
                score -= 18
                if existing_copies:
                    score -= min(72, existing_copies * 36)
                if floor <= 3 and nonstarter_attack_count(gs) < 2:
                    score += 8
                if (
                    int(gs.get("ascension_level", 0) or 0) >= 18
                    and int(gs.get("act", 1) or 1) == 1
                    and floor <= 2
                    and nonstarter_attack_count(gs) == 0
                ):
                    # At A19, skipping the only playable floor-one damage card
                    # by two points left the starter deck facing an early elite.
                    # Heavy Blade is not yet a Strength payoff, but 14 immediate
                    # damage is a valid first foundation and keeps later defense
                    # rewards available instead of forcing another attack pick.
                    score += 12
            elif floor <= 3 and nonstarter_attack_count(gs) < 2:
                # Temporary combat choices still value its immediate 14 damage.
                score += 28
    elif cid == "Limit Break":
        if not has_strength:
            # Limit Break literally cannot be played at zero Strength. The A8
            # status deck took it as a first-boss pivot anyway, then drew a
            # dead card throughout the fatal Spheric Guardian fight.
            score -= 100
        elif int(gs.get("act", 1) or 1) >= 2 and boss_strength_scaling_source_count(gs) < 2:
            # One Inflame does not make a late Limit Break a complete damage
            # plan. The logged Champ deck needed the offered Carnage instead.
            score -= 35
    elif cid == "Sword Boomerang" and not has_strength:
        existing_copies = count_deck(gs, {"Sword Boomerang"})
        score -= 22 + min(24, existing_copies * 12)
    if (
        permanent_choice
        and int(gs.get("act", 1) or 1) >= 2
        and len(deck) >= 24
    ):
        saturated_strength_attack = (
            cid == "Anger" and attacks >= 10
            or cid == "Whirlwind" and act2_swarm_control_ready(gs)
            or cid in {"Pummel", "Sword Boomerang", "Twin Strike"}
            and payoff_count >= 4
        )
        if saturated_strength_attack:
            # Once a large Strength deck already owns several payoff attacks,
            # another medium hit lowers the chance of drawing Spot Weakness,
            # block, or cycle. Heavy Blade and Reaper remain exempt because
            # they fill the distinct boss-damage and sustain roles.
            score -= 28 + min(28, max(0, payoff_count - 3) * 8)
    if cid == "Reaper":
        max_hp = max(1, int(gs.get("max_hp", 80) or 80))
        current_hp = max(0, int(gs.get("current_hp", max_hp) or 0))
        missing_hp = max(0, max_hp - current_hp)
        if (
            int(gs.get("act", 1) or 1) == 1
            and floor <= 8
            and nonstarter_attack_count(gs) < 2
            and boss_strength_scaling_source_count(gs) == 0
        ):
            # Reaper is sustain after Strength exists, not an early damage
            # foundation by itself. The logged floor-two deck passed a ready
            # Perfected Strike for four unscaled damage and entered Act 2
            # without enough output to stop Mystic's repeated heals.
            score -= 50
        if (
            int(gs.get("act", 1) or 1) == 1
            and floor >= 16
            and "Boss" in str(gs.get("room_type") or "")
        ):
            # Act transition heals 75% of missing HP after this choice. Value
            # only the wound that will remain, not the low post-boss snapshot.
            missing_hp = (missing_hp + 3) // 4
        score += min(30, missing_hp // 2)
        if has_strength:
            score += 20 + min(16, source_count * 6)
    if cid == "Barricade":
        support = barricade_support_score(gs)
        if support <= 0:
            score -= 50
        elif support < 5:
            # A few medium block cards do not create enough excess Block for
            # Barricade to repay its draw and energy. Power Through plus one
            # Shrug scored exactly three in the logged A13 deck but never
            # retained meaningful Block before the Collector kill turn.
            score -= 60
        else:
            score += min(18, (support - 4) * 4)
    if cid == "Dark Embrace":
        # Dark Embrace costs two energy before it refunds any draws. The logged
        # A8 deck treated one True Grit as a complete engine and passed an
        # immediate 26-damage Perfected Strike while at 25 HP.
        if not has_exhaust_synergy(gs):
            score -= 80
        elif not (
            dark_embrace_reward_ready(gs)
            or upgraded_dark_embrace_bridge(card, gs)
        ):
            score -= 65
        elif floor >= 40 and not late_dark_embrace_engine_ready(gs):
            # Second Wind plus one status is technically an engine, but a new
            # floor-47 power has too few combats left to repay its setup cost.
            score -= 55
    elif cid == "Feel No Pain":
        if not has_exhaust_synergy(gs):
            score -= 80
        elif not exhaust_payoff_ready(gs):
            score -= 65
        elif (
            existing_copies == 0
            and int(gs.get("act", 1) or 1) <= 2
            and {"Corruption", "Dark Embrace"}.issubset(deck_ids)
        ):
            # Corruption and Dark Embrace already supply free exhaust plus
            # replacement draws. The first Feel No Pain completes that loop's
            # defense instead of merely adding another generally useful Power.
            score += 28
    if cid == "Corruption" and not corruption_reward_ready(gs):
        # Fiend Fire alone signals exhaust damage, not a skill-dense Corruption
        # engine. Taking the power here only adds a dead draw to the first boss.
        score -= 85
    elif (
        cid == "Corruption"
        and int(gs.get("act", 1) or 1) == 1
        and floor >= 16
        and "Boss" in str(gs.get("room_type") or "")
        and not corruption_payoff_established(gs)
        and "exhaust" not in archetype_profile(gs).get("current_archetypes", [])
    ):
        # Skill density makes Corruption playable, but it does not erase the
        # cost of abandoning an established Act 1 engine. In the logged A10
        # Perfected Strike deck this speculative pivot beat Offering by ten
        # points, then had neither Dark Embrace nor Feel No Pain to repay it.
        speculative_penalty = 18
        if act2_high_output_defense_count(gs) == 0:
            # Do not spend the first boss reward on a payoff-free pivot while
            # the deck still has no card that can absorb an Act 2 heavy hit.
            # In batch 18 this makes Impervious beat Corruption by evidence,
            # while Corruption remains available when no survival card is shown.
            speculative_penalty += 16
        score -= speculative_penalty
    deck_ids = {card_id(deck_card) for deck_card in deck}
    if (
        cid == "Hemokinesis"
        and count_deck(
            gs,
            CRITICAL_ROUTE_SELF_DAMAGE_CARDS - {"Hemokinesis"},
        )
        and "Rupture" not in deck_ids
        and not (
            "Reaper" in deck_ids
            and boss_strength_scaling_source_count(gs) > 0
        )
    ):
        # Combust or another HP tax is not itself a self-harm payoff. The A13
        # deck treated that cost as a mature archetype signal and took
        # Hemokinesis over Uppercut, then paid the extra life throughout both
        # Gremlin Leader and Slavers without Rupture or meaningful Reaper heal.
        score -= 12
    if cid == "Power Through" and "Corruption" in deck_ids:
        score += 12
        if deck_ids & {"Dark Embrace", "Feel No Pain"}:
            score += 10
    if cid == "Perfected Strike" and count_deck(gs, PERFECTED_STRIKE_CARDS) >= 5:
        score += 10
    if (
        cid == "Combust"
        and permanent_choice
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and floor >= 28
        and upcoming_boss_id(gs) in {"collector", "thecollector"}
        and existing_copies == 0
        and not long_boss_damage_ready(gs)
        and count_deck(gs, {"Perfected Strike"}) == 0
        and any(
            card_id(reward) == "Perfected Strike"
            for reward in (gs.get("screen_state") or {}).get("cards", [])
        )
    ):
        # Starter Strikes make a first Perfected Strike hit once, but do not
        # create a repeatable Collector clock. Combust supplies persistent boss
        # progress and clears recurring Torch Heads without spending later
        # draws, which is the missing role in this late Act 2 reward.
        score += 24
    if (
        cid == "Perfected Strike"
        and existing_copies == 0
        and int(gs.get("act", 1) or 1) == 1
        and floor >= 9
        and count_deck(gs, PERFECTED_STRIKE_CARDS) <= 4
        and (
            act1_boss_damage_ready(gs)
            or nonstarter_attack_count(gs) >= 4
        )
    ):
        # Four remaining Strike cards make this a medium two-energy attack,
        # not a late archetype foundation. The logged Guardian reward put it
        # one point above Battle Trance despite already having enough frontload.
        score -= 20
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(
        1, gs.get("max_hp", 1) or 1
    )
    if (
        int(gs.get("act", 1) or 1) >= 2
        and hp_ratio < 0.30
        and cid in CRITICAL_ROUTE_SELF_DAMAGE_CARDS
    ):
        # Repeated HP costs are acceptable while the route has a reserve, but
        # drafting one at critical health adds another lethal draw. Keep
        # Offering exempt: its immediate energy and draw can itself be the
        # survival tool. Strength-scaled Reaper softens, but does not erase, the
        # route cost.
        self_damage_penalty = 35 + (20 if floor >= 34 else 0)
        if "Reaper" in deck_ids and boss_strength_scaling_source_count(gs) > 0:
            self_damage_penalty -= 12
        score -= max(20, self_damage_penalty)
    score += archetype_card_bonus(card, gs)
    score += relic_card_reward_bonus(card, gs)
    score += high_ascension_long_term_reward_bonus(card, gs)
    score -= act1_transitional_common_penalty(card, gs)
    if awakened_brimstone_redundant_power(card, gs):
        # Brimstone already supplies repeatable Strength while also advancing
        # Awakened One's clock. Another setup draw spends energy and grants an
        # immediate permanent Curiosity trigger for redundant scaling.
        score -= 120
    if len(deck) > 23 and score < 55:
        score -= 12
    return score


def duplicate_card_score(card, gs, profile=None):
    """Value a Dolly's Mirror target as an additional permanent copy."""
    cid = card_id(card)
    if cid in {"Barricade", "Corruption", "Demon Form"}:
        # These expensive scaling powers are one-copy engines. A second copy is
        # usually a dead draw until the first has already paid its setup cost.
        return -200
    if cid == "Offering" and count_deck(gs, {"Offering"}) >= 1:
        # A mirror target must add a new engine piece, not double an existing
        # six-HP acceleration tax.
        return card_reward_score(card, gs) - 35
    if cid in CRITICAL_ROUTE_SELF_DAMAGE_CARDS and count_deck(gs, {cid}) >= 1:
        # A second recurring HP tax is not a premium Mirror target. Rupture can
        # reward playing the existing copy, but it does not make drawing and
        # paying for another copy free over an entire act.
        return card_reward_score(card, gs) - 45
    if (
        cid == "Impervious"
        and int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and "Snecko Eye" in _relic_ids(gs)
        and count_deck(gs, {"Impervious"}) == 1
        and act2_high_output_defense_count(gs) == 1
        and count_deck(
            gs,
            ACT2_DAMAGE_ENGINE_REWARDS
            | {"Perfected Strike", "Pummel", "Whirlwind"},
        ) >= 2
    ):
        # Snecko already rewards the two-cost card, while a second copy gives
        # high ascension Act 2 another independent answer to boss burst turns.
        # The logged Collector deck duplicated its second Immolate instead and
        # died after damage was already sufficient but block density was not.
        return card_reward_score(card, gs) + 55
    if cid == "Feel No Pain" and count_deck(gs, {cid}) >= 1:
        deck_ids = {card_id(deck_card) for deck_card in gs.get("deck", [])}
        relic_ids = _relic_ids(gs)
        repeatable_sources = count_deck(gs, REPEATABLE_EXHAUST_SOURCES)
        complete_engine = bool(
            deck_ids & {"Corruption", "Dark Embrace", "Fiend Fire", "Second Wind"}
            or relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}
            or repeatable_sources >= 2
            or exhaust_source_count(gs) >= 4
        )
        if not complete_engine:
            # One Feel No Pain is enough for a sparse Burning Pact package.
            # Mirror should copy cycle or frontload until mass/repeatable
            # exhaust can trigger a second stack often enough to repay a draw.
            return card_reward_score(card, gs) - 45
    if card.get("type") in {"CURSE", "STATUS"}:
        return -180
    if cid in {"Strike_R", "Defend_R", "Bash"}:
        return -40 + CARD_SCORES.get(cid, 0)
    return card_reward_score(card, gs)


def is_post_combat_card_reward(gs):
    """Distinguish permanent rewards from potion/Discovery-style combat picks."""
    combat = gs.get("combat_state") or {}
    if any(
        not monster.get("is_gone") and int(monster.get("current_hp", 0) or 0) > 0
        for monster in combat.get("monsters", [])
    ):
        return False
    # CARD_REWARD outside a live combat is permanent, including rewards after
    # event combats. Optionality comes from the available commands, not room.
    return True


def reward_archetype_compatibility(card, gs, profile=None):
    """Explain whether a permanent reward belongs in the focused build.

    Primary and secondary engines use different match thresholds.  A premium
    core card may also open a sensible new engine (``pivot``), which prevents
    cards such as Corruption from being rejected merely because an early
    Evolve made status the current leader.
    """
    profile = profile or archetype_profile(gs)
    current = list(profile.get("current_archetypes", []))
    active = list(profile.get("active_archetypes", []))
    affinity = card_archetype_affinity(card)
    cid = card_id(card)
    floor = int(gs.get("floor", 0) or 0)
    act = int(gs.get("act", 1) or 1)
    limit_break_engine_ready = not (
        cid == "Limit Break"
        and (
            strength_source_count(gs) == 0
            or act >= 2 and boss_strength_scaling_source_count(gs) < 2
        )
    )
    dark_embrace_engine_ready = not (
        cid == "Dark Embrace"
        and not (
            dark_embrace_reward_ready(gs)
            or upgraded_dark_embrace_bridge(card, gs)
        )
    )
    feel_no_pain_engine_ready = not (
        cid == "Feel No Pain" and not exhaust_payoff_ready(gs)
    )
    entrench_engine_ready = not (
        cid == "Entrench" and not entrench_support_ready(gs)
    )
    barricade_engine_ready = not (
        cid == "Barricade" and not defensive_reward_usable(cid, gs)
    )
    juggernaut_engine_ready = not (
        cid == "Juggernaut" and not juggernaut_support_ready(gs)
    )
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(
        1, gs.get("max_hp", 1) or 1
    )
    brutality_engine_ready = not (
        cid == "Brutality"
        and "self_harm" not in current
        and profile.get("committed")
        and count_deck(gs, {"Rupture"}) == 0
        and "Runic Cube" not in _relic_ids(gs)
        and not red_skull_reaper_draw_bridge_candidate(card, gs)
        and not (hp_ratio >= 0.78 and has_sustain(gs))
    )
    awakened_brimstone_power_risk = awakened_brimstone_redundant_power(card, gs)

    matched = []
    for index, name in enumerate(current):
        if active:
            minimum = ARCHETYPE_MATCH_MIN if index == 0 else SECONDARY_ARCHETYPE_MATCH_MIN
        else:
            minimum = DEVELOPING_ARCHETYPE_MATCH_MIN
        if affinity.get(name, 0) >= minimum:
            matched.append(name)
    if (
        not limit_break_engine_ready
        or not dark_embrace_engine_ready
        or not feel_no_pain_engine_ready
        or not entrench_engine_ready
        or not barricade_engine_ready
        or not juggernaut_engine_ready
        or not brutality_engine_ready
    ):
        matched = []

    current_points = sorted(
        (affinity.get(name, 0) for name in current), reverse=True
    )
    bridge = (
        limit_break_engine_ready
        and dark_embrace_engine_ready
        and feel_no_pain_engine_ready
        and entrench_engine_ready
        and barricade_engine_ready
        and juggernaut_engine_ready
        and brutality_engine_ready
        and
        len(current_points) >= 2
        and current_points[0] >= 2
        and current_points[1] >= 2
        and current_points[0] + current_points[1] >= ARCHETYPE_BRIDGE_TOTAL_MIN
    )
    deck = gs.get("deck", [])
    sparse_cycle = sum(
        card_id(deck_card) in DRAW_SETUP_VALUES
        or card_id(deck_card) == "Pommel Strike"
        for deck_card in deck
    ) <= 1
    universal_cycle_need = (
        cid == "Burning Pact"
        and len(deck) >= 18
        and count_deck(gs, {"Burning Pact"}) == 0
        and sparse_cycle
    )
    universal = cid in UNIVERSAL_REWARD_CARDS or universal_cycle_need
    early_damage_need = (
        floor <= 8
        and (
            nonstarter_attack_count(gs) < 3
            or (
                act == 1
                and floor >= 4
                and cid in ACT1_BOSS_DAMAGE_CARDS
                and not act1_boss_damage_ready(gs)
            )
        )
        and card.get("type") == "ATTACK"
        and CARD_SCORES.get(cid, 0) >= 45
    )
    early_swarm_need = early_swarm_control_candidate(card, gs)
    byrd_knockdown_need = high_ascension_byrd_candidate(card, gs)
    hexaghost_tempo_bridge_need = (
        late_act1_hexaghost_tempo_bridge_candidate(card, gs)
    )
    boss_damage_need = (
        (
            act == 1
            and floor >= 9
            and "Boss" not in str(gs.get("room_type") or "")
            and not act1_boss_damage_ready(gs)
            and (
                cid in ACT1_BOSS_DAMAGE_CARDS
                and CARD_SCORES.get(cid, 0) >= 45
                or cid in ACT1_BOSS_REWARD_DAMAGE_CARDS
                and CARD_SCORES.get(cid, 0) >= 48
                or cid in ACT1_BOSS_SCALING_CARDS
                and CARD_SCORES.get(cid, 0) >= 45
            )
        )
        or late_slime_boss_rampage_candidate(card, gs)
    )
    late_perfected_strike_need = bool(
        act == 1
        and 9 <= floor < 16
        and cid == "Perfected Strike"
        and count_deck(gs, {"Perfected Strike"}) == 0
        and count_deck(gs, PERFECTED_STRIKE_CARDS) >= (
            4 if upcoming_boss_id(gs) == "hexaghost" else 5
        )
        and nonstarter_attack_count(gs) <= 2
        and not act1_boss_damage_ready(gs)
    )
    rampage_recursion_need = act1_rampage_recursion_candidate(card, gs)
    early_long_boss_scaling_need = early_long_boss_scaling_candidate(card, gs)
    bludgeon_damage_need = act1_bludgeon_damage_candidate(card, gs)
    defense_need = (
        cid in DEFENSIVE_PACKAGE_CARDS
        and defensive_package_shortfall(gs) > 0
        and defensive_reward_usable(cid, gs)
    )
    act1_defense_foundation_need = act1_defense_foundation_candidate(card, gs)
    critical_defense_need = (
        (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1) < 0.28
        and cid in CRITICAL_HP_DEFENSIVE_REWARDS
        and defensive_reward_usable(cid, gs)
    )
    low_reserve_defense_need = low_reserve_defense_candidate(card, gs)
    forced_elite_defense_need = forced_elite_defense_candidate(card, gs)
    late_mass_block_need = late_mass_block_candidate(card, gs)
    attack_heavy_block_bridge_need = (
        act2_attack_heavy_block_bridge_candidate(card, gs)
    )
    status_corruption_bridge_need = (
        first_boss_status_corruption_bridge_candidate(card, gs)
    )
    block_damage_bridge_need = (
        first_boss_block_damage_bridge_candidate(card, gs)
    )
    low_reserve_strength_cycle_need = (
        low_reserve_strength_cycle_bridge_candidate(card, gs)
    )
    automaton_cycle_defense_need = (
        automaton_preboss_cycle_defense_candidate(card, gs)
    )
    automaton_jax_payoff_need = automaton_jax_heavy_blade_candidate(card, gs)
    act2_damage_need = act2_damage_engine_candidate(card, gs)
    act2_champ_perfected_scaling_need = (
        act2_champ_perfected_scaling_candidate(card, gs)
    )
    act2_low_reserve_frontload_need = act2_low_reserve_frontload_candidate(card, gs)
    act2_high_output_defense_need = act2_high_output_defense_candidate(card, gs)
    act2_attack_saturation = act2_attack_saturation_blocks(card, gs)
    act2_strength_payoff_need = act2_strength_payoff_candidate(card, gs)
    shuriken_heavy_blade_need = shuriken_heavy_blade_candidate(card, gs)
    act2_strength_foundation_need = act2_strength_foundation_candidate(card, gs)
    self_harm_strength_foundation_need = (
        self_harm_strength_foundation_candidate(card, gs)
    )
    act2_jax_strength_bridge_need = act2_jax_spot_weakness_bridge_candidate(
        card, gs
    )
    red_skull_heavy_blade_need = (
        cid == "Heavy Blade"
        and act == 2
        and floor >= 24
        and count_deck(gs, {"Heavy Blade"}) == 0
        and red_skull_heavy_blade_window(gs)
    )
    red_skull_reaper_draw_bridge_need = (
        red_skull_reaper_draw_bridge_candidate(card, gs)
    )
    status_axis_capacity = bool(
        "status" in current
        or "status" in profile.get("supporting_archetypes", [])
        or len(active) < MAX_ACTIVE_ARCHETYPES
        or (
            cid in {"Evolve", "Fire Breathing"}
            and count_deck(gs, {"Evolve", "Fire Breathing"}) == 0
            and status_source_count(gs) >= 2
        )
    )
    act2_swarm_need = (
        act2_swarm_control_candidate(card, gs)
        and (cid != "Fire Breathing" or status_axis_capacity)
    )
    strength_swarm_transition_need = strength_swarm_transition_candidate(card, gs)
    slime_boss_aoe_need = slime_boss_aoe_candidate(card, gs)
    status_fuel_need = status_fuel_candidate(card, gs) and status_axis_capacity
    transition_damage_need = act1_boss_transition_damage_candidate(card, gs)
    transition_defense_need = act1_boss_transition_defense_candidate(card, gs)
    a20_early_boss_scaling_gap = (
        int(gs.get("ascension_level", 0) or 0) >= 20
        and floor >= 35
        and boss_strength_scaling_source_count(gs) == 0
        and nonstarter_attack_count(gs) >= 6
    )
    late_boss_scaling_need = (
        act == 3
        and (floor >= 40 or a20_early_boss_scaling_gap)
        and cid in {"Demon Form", "Inflame", "Spot Weakness"}
        and boss_strength_scaling_source_count(gs) < 2
        and (
            strength_payoff_count(gs) > 0
            or cid == "Demon Form"
        )
        and CARD_SCORES.get(cid, 0) >= 60
    )

    candidate_main = max(ARCHETYPES, key=lambda name: affinity.get(name, 0))
    candidate_peak = affinity.get(candidate_main, 0)
    is_core = cid in ARCHETYPE_CORE_CARDS.get(candidate_main, set())
    candidate_engine_ready = not (
        cid == "Rupture" and self_damage_source_count(gs) == 0
        or cid == "Body Slam" and not body_slam_support_ready(gs)
    ) and (
        limit_break_engine_ready
        and dark_embrace_engine_ready
        and feel_no_pain_engine_ready
        and entrench_engine_ready
        and barricade_engine_ready
        and juggernaut_engine_ready
        and brutality_engine_ready
    )
    developing_build_open = bool(
        act >= 2
        and current
        and not active
        and candidate_engine_ready
        and CARD_SCORES.get(cid, 0) >= 45
    )
    payoff_count = count_deck(gs, {"Evolve", "Fire Breathing"})
    status_foundation = (
        cid in {"Evolve", "Fire Breathing"}
        and payoff_count == 0
        and status_payoff_entry_opportunity(gs, profile, cid)
    )
    status_payoff_fuel = status_source_count(gs)
    if cid == "Fire Breathing":
        status_payoff_fuel += persistent_curse_count(gs)
    mature_strength_status_detour = bool(
        cid in {"Evolve", "Fire Breathing"}
        and mature_strength_focus(gs)
    )
    status_fueled_payoff = (
        cid in {"Evolve", "Fire Breathing"}
        and status_payoff_fuel >= 2
        and status_axis_capacity
        and not mature_strength_status_detour
    )
    supported_exhaust_payoff = (
        cid == "Feel No Pain"
        and act <= 2
        and floor <= 33
        and count_deck(gs, {"Feel No Pain"}) == 0
        and exhaust_payoff_ready(gs)
    )
    cross_link = any(affinity.get(name, 0) >= 2 for name in current)
    existing_support = (
        profile["support_hits"].get(candidate_main, 0) >= 1
        or profile["relic_signals"].get(candidate_main, 0) >= 2
    )
    supporting_core_matches = [
        name
        for name in profile.get("supporting_archetypes", [])
        if cid in ARCHETYPE_CORE_CARDS.get(name, set())
        and affinity.get(name, 0) >= SECONDARY_ARCHETYPE_MATCH_MIN
        and candidate_engine_ready
    ]
    premium_early_core = floor <= 16 and CARD_SCORES.get(cid, 0) >= 80
    developing_pivot = (
        bool(current)
        and not active
        and floor <= 8
        and candidate_main not in current
        and is_core
        and candidate_engine_ready
        and candidate_peak >= 6
        and CARD_SCORES.get(cid, 0) >= 65
    )
    pivot = (
        bool(current)
        # A run should settle on its engines during Act 1. Later rewards can
        # reinforce a mature supporting engine, but may not bootstrap an
        # unrelated archetype merely from generic bridge points.
        and floor <= 16
        and candidate_main not in current
        and is_core
        and candidate_engine_ready
        and candidate_peak >= 9
        and (cross_link or existing_support or premium_early_core)
    )

    compatible = (
        not current and candidate_engine_ready
        or developing_build_open
        or bool(matched)
        or bridge
        or bool(supporting_core_matches)
        or supported_exhaust_payoff
        or status_fueled_payoff
        or status_foundation
        or developing_pivot
        or pivot
        or universal
        or early_swarm_need
        or byrd_knockdown_need
        or early_damage_need
        or bludgeon_damage_need
        or early_long_boss_scaling_need
        or hexaghost_tempo_bridge_need
        or boss_damage_need
        or late_perfected_strike_need
        or rampage_recursion_need
        or defense_need
        or act1_defense_foundation_need
        or critical_defense_need
        or low_reserve_defense_need
        or forced_elite_defense_need
        or late_mass_block_need
        or attack_heavy_block_bridge_need
        or status_corruption_bridge_need
        or block_damage_bridge_need
        or low_reserve_strength_cycle_need
        or automaton_cycle_defense_need
        or automaton_jax_payoff_need
        or status_fuel_need
        or transition_damage_need
        or transition_defense_need
        or act2_damage_need
        or act2_champ_perfected_scaling_need
        or act2_low_reserve_frontload_need
        or act2_high_output_defense_need
        or act2_strength_payoff_need
        or shuriken_heavy_blade_need
        or act2_strength_foundation_need
        or self_harm_strength_foundation_need
        or act2_jax_strength_bridge_need
        or red_skull_heavy_blade_need
        or red_skull_reaper_draw_bridge_need
        or act2_swarm_need
        or strength_swarm_transition_need
        or slime_boss_aoe_need
        or late_boss_scaling_need
    )
    if awakened_brimstone_power_risk:
        compatible = False
        reason = "awakened_brimstone_power_risk"
    elif act2_attack_saturation:
        compatible = False
        reason = "act2_attack_saturation"
    elif mature_strength_status_detour:
        # Incidental Wounds or a Curse do not justify abandoning a mature
        # Strength lane. Batch 98 passed Shockwave for a first Fire Breathing
        # despite already owning Demon Form, Inflame, and multiple payoffs.
        compatible = False
        reason = "mature_strength_focus"
    elif not feel_no_pain_engine_ready:
        compatible = False
        reason = "unsupported_exhaust_payoff"
    elif not entrench_engine_ready:
        compatible = False
        reason = "missing_block_retention"
    elif not barricade_engine_ready:
        compatible = False
        reason = "insufficient_barricade_support"
    elif not juggernaut_engine_ready:
        compatible = False
        reason = "insufficient_juggernaut_support"
    elif not brutality_engine_ready:
        compatible = False
        reason = "unsupported_self_harm_power"
    elif status_corruption_bridge_need:
        reason = "first_boss_status_corruption_bridge"
    elif block_damage_bridge_need:
        reason = "first_boss_block_damage_bridge"
    elif low_reserve_strength_cycle_need:
        reason = "low_reserve_strength_cycle_bridge"
    elif automaton_cycle_defense_need:
        reason = "automaton_preboss_cycle_defense_need"
    elif automaton_jax_payoff_need:
        reason = "automaton_jax_strength_payoff_need"
    elif attack_heavy_block_bridge_need:
        reason = "act2_attack_heavy_block_bridge"
    elif matched:
        reason = "matches:" + "+".join(matched)
    elif bridge:
        reason = "bridge"
    elif supporting_core_matches:
        reason = "supports:" + "+".join(supporting_core_matches)
    elif supported_exhaust_payoff:
        reason = "supported_exhaust_payoff"
    elif status_fueled_payoff:
        reason = "status_fueled_payoff"
    elif status_foundation:
        reason = "status_foundation"
    elif developing_build_open:
        # If Act 1 ended without a real engine, a developing package remains a
        # score bias rather than a hard lock. Reopen only solid tempo cards and
        # keep the normal reward threshold as the final quality gate.
        reason = "developing_build_open"
    elif developing_pivot:
        reason = f"developing_pivot:{candidate_main}"
    elif pivot:
        reason = f"pivot:{candidate_main}"
    elif act2_high_output_defense_need:
        reason = "act2_high_output_defense_need"
    elif universal:
        reason = "universal_cycle_need" if universal_cycle_need else "universal"
    elif early_swarm_need:
        reason = "early_swarm_control_need"
    elif byrd_knockdown_need:
        reason = "high_ascension_byrd_knockdown_need"
    elif strength_swarm_transition_need:
        reason = "strength_swarm_transition_need"
    elif early_damage_need:
        reason = "early_damage_need"
    elif bludgeon_damage_need:
        reason = "act1_bludgeon_damage_need"
    elif early_long_boss_scaling_need:
        reason = "early_long_boss_scaling_need"
    elif hexaghost_tempo_bridge_need:
        reason = "late_act1_hexaghost_tempo_bridge"
    elif boss_damage_need:
        reason = "act1_boss_damage_need"
    elif late_perfected_strike_need:
        reason = "late_act1_starter_strike_damage_need"
    elif rampage_recursion_need:
        reason = "act1_rampage_recursion_need"
    elif defense_need:
        reason = "defense_need"
    elif act1_defense_foundation_need:
        reason = "act1_defense_foundation_need"
    elif critical_defense_need:
        reason = "critical_hp_defense_need"
    elif low_reserve_defense_need:
        reason = "low_reserve_defense_need"
    elif forced_elite_defense_need:
        reason = "forced_elite_defense_need"
    elif late_mass_block_need:
        reason = "late_mass_block_need"
    elif status_fuel_need:
        reason = "status_fuel_need"
    elif transition_damage_need:
        reason = "act1_boss_transition_damage_need"
    elif transition_defense_need:
        reason = "act1_boss_transition_defense_need"
    elif act2_strength_foundation_need:
        reason = "act2_strength_foundation_need"
    elif self_harm_strength_foundation_need:
        reason = "self_harm_strength_foundation_need"
    elif act2_jax_strength_bridge_need:
        reason = "act2_jax_repeatable_strength_bridge"
    elif act2_champ_perfected_scaling_need:
        reason = "act2_champ_perfected_scaling_gap"
    elif act2_damage_need:
        reason = "act2_damage_engine_need"
    elif act2_low_reserve_frontload_need:
        reason = "act2_low_reserve_frontload_need"
    elif act2_strength_payoff_need:
        reason = "act2_strength_payoff_need"
    elif shuriken_heavy_blade_need:
        reason = "shuriken_heavy_blade_payoff_need"
    elif red_skull_heavy_blade_need:
        reason = "red_skull_heavy_blade_need"
    elif red_skull_reaper_draw_bridge_need:
        reason = "red_skull_reaper_draw_bridge_need"
    elif act2_swarm_need:
        reason = "act2_swarm_control_need"
    elif slime_boss_aoe_need:
        reason = "slime_boss_aoe_need"
    elif late_boss_scaling_need:
        reason = "late_boss_scaling_need"
    elif not current:
        reason = "no_established_archetype"
    else:
        reason = "off_archetype"
    return {
        "compatible": compatible,
        "reason": reason,
        "matched": matched,
        "pivot": candidate_main if pivot or developing_pivot else None,
        "current_archetypes": current,
    }


def shop_card_purchase_fit(card, gs, profile=None, card_score=None):
    """Apply a stricter archetype gate to permanent cards bought for gold."""
    profile = profile or archetype_profile(gs)
    card_score = card_reward_score(card, gs) if card_score is None else card_score
    cid = card_id(card)
    affinity = card_archetype_affinity(card)
    current = list(profile.get("current_archetypes", []))

    if (
        cid == "Second Wind"
        and count_deck(gs, {cid}) > 0
        and not second_wind_duplicate_engine_ready(gs)
    ):
        # A low-health shop made a merely redundant copy look like emergency
        # defense and spent the gold needed for a permanent relic. The first
        # copy already performs the mass cleanup in an ordinary block shell.
        return False, "unsupported_duplicate"

    if shop_tactical_survival_bonus(card, gs) > 0:
        return True, "immediate_survival_need"

    if (
        cid == "Heavy Blade"
        and count_deck(gs, {cid}) > 0
        and defensive_package_shortfall(gs) >= 2
    ):
        # Keep Heavy Blade premium for a Strength deck's first payoff, but do
        # not spend shop gold on a duplicate while the deck still has no safe
        # Act 2 defensive cycle. The A13 deck did exactly that before a forced
        # Gremlin Leader and had eight attacks but no nonstarter block.
        return False, "duplicate_before_defense"

    if early_shop_perfected_strike_candidate(card, gs):
        return True, "starter_strike_damage_need"

    if act1_bludgeon_damage_candidate(card, gs):
        return True, "act1_bludgeon_damage_need"

    if act2_high_output_defense_candidate(card, gs):
        return True, "high_output_defense_need"

    if (
        cid == "Pummel"
        and count_deck(gs, {cid}) == 0
        and "strength" in profile.get("current_archetypes", [])
        and strength_source_count(gs) >= 1
        and card_score >= 80
    ):
        # Four Strength-scaled hits are a genuine engine payoff, not a routine
        # card purchase. This lets the first Pummel compete with shop relics while
        # the stricter default still rejects ordinary merely-compatible cards.
        return True, "strong_archetype:strength"

    if late_act1_shop_boss_scaling_candidate(card, gs):
        return True, "late_act1_boss_scaling_need"

    if dual_wield_long_boss_engine_candidate(card, gs):
        return True, "long_boss_copy_engine_need"

    if (
        defensive_package_shortfall(gs) > 0
        and cid in DEFENSIVE_SHORTFALL_BOOST_CARDS
        and cid != "Sentinel"
        and defensive_reward_usable(cid, gs)
    ):
        # Relics remain the default purchase, but a mature offense with no
        # defensive package has a concrete emergency rather than a speculative
        # off-archetype opportunity.
        return True, "defensive_package_need"

    if current:
        strong_matches = [
            archetype
            for archetype in current
            if affinity.get(archetype, 0) >= SHOP_STRONG_ARCHETYPE_MATCH_MIN
        ]
        core_matches = [
            archetype
            for archetype in current
            if cid in ARCHETYPE_CORE_CARDS.get(archetype, set())
            and affinity.get(archetype, 0) >= DEVELOPING_ARCHETYPE_MATCH_MIN
        ]
        if strong_matches or core_matches:
            matched = strong_matches or core_matches
            return True, "strong_archetype:" + "+".join(matched)
        if cid in UNIVERSAL_REWARD_CARDS and card_score >= SHOP_PREMIUM_UNIVERSAL_MIN:
            return True, "premium_universal"
        return False, "not_strongly_aligned"

    floor = int(gs.get("floor", 0) or 0)
    early_foundation = (
        floor <= 8
        and (
            cid in UNIVERSAL_REWARD_CARDS
            and card_score >= 75
            or card.get("type") == "ATTACK"
            and nonstarter_attack_count(gs) < 2
            and CARD_SCORES.get(cid, 0) >= 60
            or any(
                cid in ARCHETYPE_CORE_CARDS.get(archetype, set())
                and CARD_SCORES.get(cid, 0) >= 65
                for archetype in ARCHETYPES
            )
        )
    )
    if early_foundation:
        return True, "early_foundation"
    if cid in UNIVERSAL_REWARD_CARDS and card_score >= SHOP_PREMIUM_UNIVERSAL_MIN:
        return True, "premium_universal"
    return False, "no_established_archetype"

def card_reward_skip_threshold(gs, profile=None):
    """Raise the bar as the deck and run mature to prevent reward bloat."""
    profile = profile or archetype_profile(gs)
    floor = int(gs.get("floor", 0) or 0)
    deck_size = len(gs.get("deck", []))
    threshold = 35
    if floor >= 17:
        threshold += 5
    if floor >= 34:
        threshold += 5
    if deck_size >= 20:
        threshold += 5
    if deck_size >= 25:
        threshold += 5
    if profile.get("current_archetypes"):
        threshold += 3

    # The first act still needs enough front-loaded damage to survive elites.
    if floor <= 8 and nonstarter_attack_count(gs) < 2:
        threshold = min(threshold, 35)
    return threshold


def codex_slow_power_penalty(card, gs):
    """Price a delayed Codex Power by its cost and immediate support."""
    if (
        str(gs.get("current_action") or "") != "CodexAction"
        or card.get("type") != "POWER"
    ):
        return 0
    cost = int(card.get("cost", 0) or 0)
    if cost < 2:
        return 0

    combat = gs.get("combat_state") or {}
    turn = int(combat.get("turn", 1) or 1)
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    penalty = 24 if cost == 2 else 42 + max(0, cost - 3) * 12
    if turn <= 2:
        penalty -= 8
    if "Mummified Hand" in relic_ids:
        penalty -= 8

    cid = card_id(card)
    deck_ids = [card_id(deck_card) for deck_card in gs.get("deck", [])]
    if cid == "Dark Embrace":
        repeatable_sources = sum(
            deck_id in REPEATABLE_EXHAUST_SOURCES for deck_id in deck_ids
        )
        active_engine = bool(
            combat_player_power_amount(gs, "Corruption")
            or combat_player_power_amount(gs, "Feel No Pain")
        )
        if repeatable_sources < 2 and not active_engine:
            penalty += 18
    elif cid == "Barricade" and barricade_support_score(gs) < 5:
        penalty += 18
    return max(0, penalty)


def temporary_combat_card_plan_impact(card, gs):
    """Return the exact base/candidate plans and whether the offered card is used."""
    combat = gs.get("combat_state") or {}
    if not combat.get("monsters"):
        return None
    try:
        base_plan = plan_turn(combat, gs)
        preview_card = dict(card)
        preview_uuid = (
            str(preview_card.get("uuid") or card_id(preview_card))
            + ":temporary-choice"
        )
        preview_card["uuid"] = preview_uuid
        preview_card["is_playable"] = True
        if (
            str(gs.get("current_action") or "") == "DiscoveryAction"
            and card.get("is_playable")
        ):
            # Attack/Skill/Power/Colorless potions and Discovery expose the
            # printed card cost on the choice screen, but the selected card is
            # added to hand at zero cost for this turn. Preview that real cost;
            # otherwise a free Flame Barrier looks unplayable beside attacks.
            preview_card["cost"] = 0
        preview = dict(combat)
        preview["hand"] = list(combat.get("hand") or []) + [preview_card]
        candidate_plan = plan_turn(preview, gs)

        model = build_model(preview, gs)
        for command in candidate_plan.commands:
            if command == "END":
                break
            parts = command.split()
            if len(parts) < 2:
                return base_plan, candidate_plan, False
            hand_index = int(parts[1]) - 1
            played = model.hand[hand_index]
            if played.uuid == preview_uuid:
                return base_plan, candidate_plan, True
            target_index = None
            if len(parts) >= 3:
                original_target = int(parts[2])
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            model = simulate_card(model, hand_index, target_index)
    except (IndexError, StopIteration, TypeError, ValueError):
        return None
    return base_plan, candidate_plan, False


def temporary_combat_card_improves_plan(card, gs):
    """Return whether a generated card is used by a strictly better live plan."""
    impact = temporary_combat_card_plan_impact(card, gs)
    return bool(
        impact
        and impact[2]
        and impact[1].score > impact[0].score
    )


def combat_card_choice_score(card, gs):
    score = card_reward_score(card, gs)
    combat = gs.get("combat_state") or {}
    monsters = [
        monster
        for monster in combat.get("monsters", [])
        if not monster.get("is_gone") and int(monster.get("current_hp", 0) or 0) > 0
    ]
    cid = card_id(card)
    score = max(score, COMBAT_TEMP_CARD_SCORES.get(cid, score))
    if card.get("type") == "POWER" and awakened_one_curiosity_active(gs):
        key_power_value = awakened_key_power_choice_value(card, gs)
        if key_power_value > 0:
            # v69: a supported engine Power is worth feeding Curiosity. This is
            # especially important for Power Potion / Codex choices that offer
            # Corruption, Dark Embrace, Feel No Pain, or the deck's main scaling.
            score += key_power_value
        else:
            # Optional unsupported Powers still lose value because they grant
            # permanent Strength without creating a functioning engine.
            score -= 120
    bronze_automaton = any(
        monster.get("id") == "BronzeAutomaton" for monster in monsters
    )
    long_boss = any(
        monster.get("id") in {
            "TheGuardian", "Champ", "Hexaghost", "TheCollector",
            "BronzeAutomaton",
        }
        for monster in monsters
    )
    transient = any(monster.get("id") == "Transient" for monster in monsters)
    early = int(combat.get("turn", 1) or 1) <= 4
    deck_ids = {card_id(deck_card) for deck_card in gs.get("deck", [])}
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    temporary_impact = None
    if (
        str(gs.get("screen_type") or "") == "CARD_REWARD"
        and str(gs.get("current_action") or "") == "DiscoveryAction"
        and card.get("is_playable")
    ):
        temporary_impact = temporary_combat_card_plan_impact(card, gs)
        if temporary_impact is not None:
            base_plan, candidate_plan, candidate_played = temporary_impact
            if not candidate_played:
                future_boss_control = bool(
                    cid == "Dark Shackles"
                    and long_boss
                    and early
                    and incoming_damage(combat) <= 0
                )
                if not future_boss_control:
                    # Most generated cards vanish after this turn. Dark Shackles
                    # is the exception on a quiet early boss turn: retaining it
                    # for the heavy attack is its actual tactical value.
                    score -= 100
            else:
                hp_saved = base_plan.hp_loss - candidate_plan.hp_loss
                control_gain = candidate_plan.score[2] - base_plan.score[2]
                plan_value = max(
                    -30,
                    min(120, hp_saved * 6 + control_gain * 2),
                )
                if transient:
                    # Generated cards disappear after this turn, and Transient
                    # converts immediate damage into block. Rank the potion's
                    # exact simulated line instead of letting permanent-deck
                    # archetype scores make Heavy Blade beat a free Dropkick
                    # that draws Spot Weakness and refunds its energy.
                    score = 80 + plan_value
                else:
                    score += plan_value
    if cid == "Impatience" and any(
        hand_card.get("type") == "ATTACK"
        for hand_card in combat.get("hand") or []
    ):
        # It draws nothing until every attack leaves hand. Do not value it as a
        # generic draw-three choice in attack-dense Ironclad turns.
        score -= 120
    has_corruption_engine = bool("Feel No Pain" in deck_ids or "Dead Branch" in relic_ids)
    if cid == "Corruption" and long_boss and early and not has_corruption_engine:
        score -= 120
    if cid == "Demon Form" and long_boss:
        score += 18
    slime_boss = any(monster.get("id") == "SlimeBoss" for monster in monsters)
    hexaghost = next(
        (monster for monster in monsters if monster.get("id") == "Hexaghost"),
        None,
    )
    if (
        cid == "Fire Breathing"
        and early
        and hexaghost is not None
        and int(hexaghost.get("current_hp", 0) or 0)
        > max(60, int(hexaghost.get("max_hp", 1) or 1) // 4)
    ):
        # Hexaghost supplies recurring Burns itself, so a generated Fire
        # Breathing already has fuel even when the permanent deck has none.
        # This is a full-fight damage engine, not an unsupported status Power.
        score += 70
    if cid == "Metallicize" and early and (long_boss or slime_boss):
        # Power Potion's Metallicize prevents damage every turn of a long
        # fight. In the logged 14-turn Slime Boss loss it was worth far more
        # than speculative status draw from Evolve.
        score += 40
    if (
        cid == "Dark Embrace"
        and bronze_automaton
        and int(combat.get("turn", 1) or 1) == 1
        and "Corruption" not in deck_ids
        and combat_player_power_amount(gs, "Corruption") <= 0
    ):
        # Two Second Winds make Dark Embrace useful, but without Corruption its
        # delayed draws do not outperform ten turns of guaranteed Metallicize
        # block in the Automaton fight.
        score -= 40

    strength = combat_player_power_amount(gs, "Strength")
    if cid == "Limit Break":
        # Nilry's Codex / potion card choices must not select a dead Limit
        # Break, and a real copy is only valuable after Strength exists.
        if strength <= 0:
            score -= 200
        else:
            score += min(60, strength * 8)
    hp = int((combat.get("player") or {}).get("current_hp", gs.get("current_hp", 1)) or 1)
    max_hp = max(1, int((combat.get("player") or {}).get("max_hp", gs.get("max_hp", hp)) or hp))
    if (
        cid == "Metallicize"
        and early
        and len(monsters) >= 2
        and hp / max_hp <= 0.35
        and any(
            monster.get("id") in {
                "Byrd", "Chosen", "Centurion", "Healer",
                "Shelled Parasite", "SphericGuardian",
            }
            for monster in monsters
        )
    ):
        # At critical reserve, a generated Metallicize is guaranteed block on
        # every remaining turn.  The logged Chosen/Byrd Power Potion ranked an
        # unsupported Barricade four points higher; Metallicize plus the one
        # known Defend instead survived Chosen's next 31-damage attack.
        score += 30
    if cid == "Deep Breath" and deep_breath_shuffle_is_harmful(gs, combat):
        score -= 120
    if cid == "Secret Weapon":
        draw_attacks = [
            draw_card
            for draw_card in combat.get("draw_pile") or []
            if draw_card.get("type") == "ATTACK"
        ]
        if not draw_attacks:
            score -= 100
        else:
            incoming = incoming_damage(combat)
            best_attack_quality = max(
                draw_order_card_quality(
                    gs, combat, draw_card, hp, incoming
                )
                for draw_card in draw_attacks
            )
            score = max(score, 52 + min(35, best_attack_quality))
            if any(card_id(draw_card) == "Reaper" for draw_card in draw_attacks):
                missing_hp = max_hp - hp
                score += (
                    35
                    + min(25, missing_hp // 2)
                    + min(30, max(0, strength) * 4)
                    + max(0, len(monsters) - 1) * 10
                )
            secret_weapon_improves = (
                bool(
                    temporary_impact
                    and temporary_impact[2]
                    and temporary_impact[1].score > temporary_impact[0].score
                )
                if temporary_impact is not None
                else temporary_combat_card_improves_plan(card, gs)
            )
            if secret_weapon_improves:
                score += 8
            else:
                # A generated Secret Weapon is not value by itself. If the
                # exact current plan cannot spend the fetched Attack this turn,
                # choose a directly playable option instead of discarding the
                # searched card at end of turn.
                score -= 140
    if cid == "Whirlwind":
        score += max(0, len(monsters) - 1) * 8
        if "Chemical X" in relic_ids:
            score += 30 + min(24, max(0, strength) * 3)
    if cid == "Bloodletting" and hp / max_hp < 0.45:
        score -= 45
    if cid == "Bludgeon" and int((combat.get("player") or {}).get("energy", 0) or 0) >= 3:
        score += 35
    score -= codex_slow_power_penalty(card, gs)
    return score


def strong_for_masked_bandits(gs):
    hp_ratio = (gs.get("current_hp", 0) or 0) / max(1, gs.get("max_hp", 1) or 1)
    gold = max(0, int(gs.get("gold", 0) or 0))
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    has_aoe = bool(deck_ids & {"Cleave", "Immolate", "Reaper", "Thunderclap", "Whirlwind"})
    defense = defensive_package_count(gs)
    ascension = int(gs.get("ascension_level", 0) or 0)
    if gold < 60:
        reserve_ratio = 0.94
    elif gold < 130:
        reserve_ratio = 0.88
    else:
        reserve_ratio = 0.80
    if "Reaper" in deck_ids and strength_source_count(gs) > 0:
        reserve_ratio -= 0.05
    if revive_reserve_hp(gs) > 0 and ascension < 18:
        reserve_ratio -= 0.04
    if ascension >= 18:
        repeatable_aoe = count_deck(gs, {"Cleave", "Thunderclap"}) >= 2
        premium_aoe = bool(deck_ids & {"Immolate", "Whirlwind"}) or bool(
            "Reaper" in deck_ids and strength_source_count(gs) > 0
        )
        if gold >= 130:
            reserve_ratio += 0.04
        if not (premium_aoe or repeatable_aoe) or defense < 3:
            return False
    # Paying three gold is almost free; Red Mask is not worth exposing an
    # 84%-HP run to three Act 2 attackers. As the protected purse grows, accept
    # the fight earlier, but only with AoE and a real defensive package.
    return hp_ratio >= reserve_ratio and has_aoe and defense >= 2


def strong_for_mysterious_sphere(gs):
    """Require enough reserve for the event's two Orb Walkers."""
    hp_ratio = (gs.get("current_hp", 0) or 0) / max(1, gs.get("max_hp", 1) or 1)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    offense_ready = bool(
        boss_strength_scaling_source_count(gs)
        or block_damage_engine_ready(gs)
        or "Fire Breathing" in deck_ids and status_source_count(gs) > 0
        or count_deck(gs, {"Perfected Strike"}) >= 3
    )
    defense_ready = defensive_package_count(gs) >= 3
    threshold = (
        0.86
        + route_danger_factor(gs) * 0.05
        - min(0.04, route_recovery_factor(gs) * 0.05)
    )
    ascension = int(gs.get("ascension_level", 0) or 0)
    if ascension >= 18:
        # A18+ Orb Walkers add five Strength every turn. Slow scaling such as
        # Demon Form does not make the optional fight safe: the logged A19 deck
        # entered at 70/75 with two Immolates, Whirlwind, Barricade and Reaper,
        # yet still lost 78 damage in four turns. Require both near-full life
        # and a repeatable block-to-damage engine (or an unused second life).
        threshold = max(threshold, 0.98)
        defense_ready = defensive_package_count(gs) >= 4
        durable_survival = bool(
            block_damage_engine_ready(gs) or revive_reserve_hp(gs) > 0
        )
        if not durable_survival:
            return False
    return hp_ratio >= threshold and offense_ready and defense_ready


def strong_for_colosseum(gs):
    """Only accept the optional second arena fight with a real health reserve."""
    hp_ratio = (gs.get("current_hp", 0) or 0) / max(1, gs.get("max_hp", 1) or 1)
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    has_aoe = bool(deck_ids & {"Cleave", "Immolate", "Reaper", "Thunderclap", "Whirlwind"})
    offense_ready = bool(
        boss_strength_scaling_source_count(gs)
        or block_damage_engine_ready(gs)
        or "Fire Breathing" in deck_ids and status_source_count(gs) > 0
        or count_deck(gs, {"Perfected Strike"}) >= 2
        or nonstarter_attack_count(gs) >= 5
    )
    return hp_ratio >= 0.78 and has_aoe and offense_ready and defensive_package_count(gs) >= 3


def card_reward_context(gs):
    return (
        gs.get("seed"),
        int(gs.get("act", 1) or 1),
        int(gs.get("floor", 0) or 0),
        str(gs.get("room_type") or ""),
    )


def decide_card_reward(state, gs):
    global CARD_REWARD_SKIPPED, CARD_REWARD_SKIPPED_CONTEXT, ORRERY_REWARD_TAKES
    cards = (gs.get("screen_state") or {}).get("cards", [])
    available = [command.lower() for command in state.get("available_commands", [])]

    def skip_command():
        if "skip" in available:
            return "SKIP"
        if "return" in available:
            return "RETURN"
        if "cancel" in available:
            return "CANCEL"
        return "STATE"

    if not cards:
        return skip_command()

    profile = archetype_profile(gs)
    combat = gs.get("combat_state") or {}
    in_live_combat = any(
        not monster.get("is_gone") and int(monster.get("current_hp", 0) or 0) > 0
        for monster in combat.get("monsters", [])
    )
    post_combat = is_post_combat_card_reward(gs)
    score_card = combat_card_choice_score if in_live_combat else card_reward_score
    scored = [(i, card, score_card(card, gs)) for i, card in enumerate(cards)]
    compatibility = {
        i: reward_archetype_compatibility(card, gs, profile)
        for i, card, _ in scored
    }
    threshold = card_reward_skip_threshold(gs, profile) if post_combat else None
    orrery_reward = bool(
        post_combat
        and "ShopRoom" in str(gs.get("room_type") or "")
        and any(relic.get("id") == "Orrery" for relic in gs.get("relics", []))
    )
    if orrery_reward:
        # Orrery presents five consecutive rewards. Treating every offer like
        # a normal hallway reward bloated the logged deck from 15 to 20 cards.
        # Start at premium quality and raise the bar after every accepted card.
        threshold = max(threshold, 70 + min(15, ORRERY_REWARD_TAKES * 5))

    reward_details = [
        {
            "card": card_id(card),
            "total": score,
            "archetype_bonus": archetype_card_bonus(card, gs, profile),
            "vector": {
                key: value
                for key, value in card_archetype_affinity(card).items()
                if value > 0
            },
            "compatible": compatibility[i]["compatible"],
            "fit": compatibility[i]["reason"],
        }
        for i, card, score in scored
    ]

    # Combat-generated choices are temporary cards.  Never apply permanent deck
    # purity rules and never poison the post-combat CARD_REWARD_SKIPPED flag.
    if in_live_combat or not post_combat:
        best = max(scored, key=lambda item: item[2])
        CARD_REWARD_SKIPPED = False
        CARD_REWARD_SKIPPED_CONTEXT = None
        log(
            f"card reward mode={'combat' if in_live_combat else 'noncombat'} "
            f"leader={profile['leader']} current={profile['current_archetypes']} "
            f"reward={reward_details} decision=choose:{best[0]}"
        )
        return f"CHOOSE {best[0]}"

    eligible = [item for item in scored if compatibility[item[0]]["compatible"]]
    can_skip = any(command in available for command in ("skip", "return", "cancel"))
    preserve_orrery_chain = bool(
        orrery_reward and ORRERY_REWARD_TAKES < 4
    )
    if preserve_orrery_chain:
        # CommunicationMod's SKIP closes the whole Orrery sequence rather than
        # only declining the visible trio. Pay a modest bridge-card tax during
        # the first four picks so later premium offers are actually revealed.
        candidate_pool = eligible or scored
        bridge_pick = max(candidate_pool, key=lambda item: item[2])
        if not eligible or bridge_pick[2] < threshold:
            CARD_REWARD_SKIPPED = False
            CARD_REWARD_SKIPPED_CONTEXT = None
            ORRERY_REWARD_TAKES += 1
            log(
                f"card reward mode=orrery leader={profile['leader']} "
                f"active={profile['active_archetypes']} supporting={profile.get('supporting_archetypes', [])} developing={profile['developing_archetypes']} "
                f"threshold={threshold} reward={reward_details} "
                f"decision=choose:{bridge_pick[0]} reason=preserve_remaining_orrery_rewards"
            )
            return f"CHOOSE {bridge_pick[0]}"
    if not eligible:
        CARD_REWARD_SKIPPED = can_skip
        CARD_REWARD_SKIPPED_CONTEXT = card_reward_context(gs) if can_skip else None
        decision = skip_command() if can_skip else f"CHOOSE {max(scored, key=lambda item: item[2])[0]}"
        log(
            f"card reward mode=post_combat leader={profile['leader']} "
            f"active={profile['active_archetypes']} supporting={profile.get('supporting_archetypes', [])} developing={profile['developing_archetypes']} "
            f"threshold={threshold} reward={reward_details} "
            f"decision={decision} reason=no_compatible_card"
        )
        return decision

    best = max(eligible, key=lambda item: item[2])
    if best[2] < threshold and can_skip:
        CARD_REWARD_SKIPPED = True
        CARD_REWARD_SKIPPED_CONTEXT = card_reward_context(gs)
        decision = skip_command()
        log(
            f"card reward mode=post_combat leader={profile['leader']} "
            f"active={profile['active_archetypes']} supporting={profile.get('supporting_archetypes', [])} developing={profile['developing_archetypes']} "
            f"threshold={threshold} reward={reward_details} "
            f"decision={decision} reason=below_threshold best={card_id(best[1])}:{best[2]}"
        )
        return decision

    CARD_REWARD_SKIPPED = False
    CARD_REWARD_SKIPPED_CONTEXT = None
    if orrery_reward:
        ORRERY_REWARD_TAKES += 1
    log(
        f"card reward mode={'orrery' if orrery_reward else 'post_combat'} leader={profile['leader']} "
        f"active={profile['active_archetypes']} supporting={profile.get('supporting_archetypes', [])} developing={profile['developing_archetypes']} "
        f"threshold={threshold} reward={reward_details} "
        f"decision=choose:{best[0]} reason={compatibility[best[0]]['reason']}"
    )
    return f"CHOOSE {best[0]}"


def decide_combat_reward(state, gs):
    global CARD_REWARD_SKIPPED, CARD_REWARD_SKIPPED_CONTEXT
    rewards = (gs.get("screen_state") or {}).get("rewards", [])
    potions = gs.get("potions", [])
    potion_slots_full = bool(potions) and all(
        normalized_potion_id(potion) != "Potion Slot" for potion in potions
    )

    def handle_reward_potion(index, reward):
        incoming = potion_from_reward(reward)
        incoming_id = normalized_potion_id(incoming)
        incoming_score = potion_score(incoming, gs, context="reward")
        if not potion_slots_full:
            log(
                f"potion reward take idx={index} potion={incoming_id} "
                f"score={incoming_score:.1f} slots_full=False"
            )
            return f"CHOOSE {index}"
        replacement = best_potion_replacement(gs, incoming)
        if replacement and command_available(state, "potion"):
            command = f"POTION discard {replacement['slot']}"
            if should_issue_potion_command(command, gs):
                log(
                    f"potion reward replace incoming={replacement['incoming_id']} "
                    f"incoming_score={replacement['incoming_score']:.1f} "
                    f"discard_slot={replacement['slot']} held={replacement['held_id']} "
                    f"held_score={replacement['held_score']:.1f}"
                )
                return command
            log(f"potion duplicate suppressed: {command}")
            return "WAIT 10" if command_available(state, "wait") else "STATE"
        held_scores = [
            f"{normalized_potion_id(p)}:{potion_score(p, gs, context='held'):.1f}"
            for p in potions
            if normalized_potion_id(p) != "Potion Slot"
        ]
        log(
            f"potion reward skip incoming={incoming_id} score={incoming_score:.1f} "
            f"held={held_scores}"
        )
        return None

    if CARD_REWARD_SKIPPED and CARD_REWARD_SKIPPED_CONTEXT != card_reward_context(gs):
        log(
            "card reward stale skip cleared "
            f"previous={CARD_REWARD_SKIPPED_CONTEXT} current={card_reward_context(gs)}"
        )
        CARD_REWARD_SKIPPED = False
        CARD_REWARD_SKIPPED_CONTEXT = None
    if CARD_REWARD_SKIPPED:
        for idx, reward in enumerate(rewards):
            reward_type = reward.get("reward_type")
            if reward_type == "POTION":
                potion_action = handle_reward_potion(idx, reward)
                if potion_action:
                    return potion_action
                continue
            if reward_type != "CARD":
                return f"CHOOSE {idx}"
        if command_available(state, "proceed"):
            CARD_REWARD_SKIPPED = False
            CARD_REWARD_SKIPPED_CONTEXT = None
            return "PROCEED"
    if rewards:
        for idx, reward in enumerate(rewards):
            rtype = reward.get("reward_type")
            if rtype == "POTION":
                potion_action = handle_reward_potion(idx, reward)
                if potion_action:
                    return potion_action
                continue
            if rtype in {"GOLD", "STOLEN_GOLD", "RELIC", "CARD"}:
                return f"CHOOSE {idx}"
        if command_available(state, "proceed"):
            return "PROCEED"
        return "CHOOSE 0"
    if command_available(state, "proceed"):
        return "PROCEED"
    if command_available(state, "return"):
        return "RETURN"
    return "STATE"

def has_sustain(gs):
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if relic_ids & {
        "Black Blood", "Eternal Feather", "Meal Ticket", "MealTicket",
        "Meat on the Bone",
    }:
        return True
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    if "Reaper" not in deck_ids:
        return False
    # Base Reaper heals only four per enemy and exhausts. It is useful tactical
    # recovery, but it cannot by itself replace every future campfire. Count it
    # as route sustain only after a reliable Strength engine raises that heal,
    # or Exhume gives the deck a second use in each combat.
    return bool(
        boss_strength_scaling_source_count(gs) > 0
        or "Exhume" in deck_ids
    )


def durable_coffee_sustain(gs):
    """Return recovery that can replace repeated campfire rests in Act 3."""
    relic_ids = _relic_ids(gs)
    if relic_ids & {"Black Blood", "Eternal Feather", "Meat on the Bone"}:
        return True
    if "Magic Flower" in relic_ids and "Burning Blood" in relic_ids:
        return True
    deck_ids = {card_id(card) for card in gs.get("deck", [])}
    if "Reaper" in deck_ids and (
        boss_strength_scaling_source_count(gs) > 0 or "Exhume" in deck_ids
    ):
        return True
    if (
        "Toy Ornithopter" in relic_ids
        and ("White Beast Statue" in relic_ids or "Alchemize" in deck_ids)
    ):
        return True
    if "Bird Faced Urn" in relic_ids and count_deck(
        gs, {"Barricade", "Brutality", "Combust", "Corruption", "Dark Embrace",
             "Demon Form", "Feel No Pain", "Fire Breathing", "Inflame",
             "Juggernaut", "Metallicize", "Rupture"}
    ) >= 2:
        return True
    return False


def average_deck_cost(gs):
    costs = []
    for card in gs.get("deck", []):
        cost = card.get("cost")
        if isinstance(cost, (int, float)) and cost >= 0 and card.get("type") not in {"STATUS", "CURSE"}:
            costs.append(float(cost))
    return sum(costs) / len(costs) if costs else 1.0


def boss_relic_score(relic, gs):
    relic_id = relic.get("id")
    score = float(BOSS_RELIC_SCORES.get(relic_id, 50) + archetype_relic_bonus(relic, gs))
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    ascension = int(gs.get("ascension_level", 0) or 0)
    deck = gs.get("deck", [])
    expensive_count = sum(
        isinstance(card.get("cost"), (int, float)) and card.get("cost") >= 2
        for card in deck
        if card.get("type") not in {"STATUS", "CURSE"}
    )
    if relic_id in {"Coffee Dripper", "Cursed Key"}:
        # The two logged A17 decks carried four or five 2+ cost cards but chose
        # sustain/Bell by one point and entered Act 2 on only three energy.
        # Full-time fourth energy is worth more as that bottleneck grows.
        score += min(10, max(0, expensive_count - 2) * 2)
    if (
        relic_id == "Fusion Hammer"
        and ascension >= 15
        and act == 1
        and floor >= 16
        and expensive_count >= 3
    ):
        # A high-ascension Act 2 deck with several two-cost cards needs a
        # fourth energy every hallway turn. The logged A17 Perfected Strike
        # deck tied Hammer with Calling Bell at 78, accepted the curse by list
        # order, then repeatedly stranded attacks and block on three energy.
        score += min(9, (expensive_count - 2) * 3)
    if (
        relic_id == "Ectoplasm"
        and act == 1
        and floor >= 16
    ):
        banked_gold = int(gs.get("gold", 0) or 0)
        if banked_gold >= 300:
            score += 24
        elif banked_gold >= 200:
            score += 16
        elif banked_gold >= 120:
            score += 8
        if banked_gold >= 200 and expensive_count >= 3:
            # Ectoplasm's lost future income is much less severe after Act 1
            # has already banked several purchases. In the logged A19 deck,
            # 391 gold plus Bash, Perfected Strike, and Impervious made fourth
            # energy worth more than Black Star; staying on three energy left
            # the recovered Impervious stranded during Automaton's attack.
            score += min(12, (expensive_count - 1) * 4)
    if relic_id == "Black Blood":
        if (
            act == 1
            and floor >= 16
            and not has_sustain(gs)
        ):
            # Upgrading Burning Blood adds six route HP after every Act 2
            # combat. The logged A15 deck had no other recovery, chose Sozu by
            # four points, and reached Collector with only 39 HP.
            score += 10
            if (
                ascension >= 17
                and act2_high_output_defense_count(gs) == 0
                and not long_boss_damage_ready(gs)
            ):
                # Without a heavy-hit answer, fourth energy does not prevent
                # Act 2 attrition by itself. The logged A17 Cursed Key deck
                # entered Automaton at 50 HP; Black Blood's extra six healing
                # over each of five fights would have survived Hyper Beam.
                score += 12
            if (
                ascension >= 20
                and act2_high_output_defense_count(gs) == 0
                and "SlaversCollar" in {
                    offered.get("id") or offered.get("name")
                    for offered in (gs.get("screen_state") or {}).get("relics", [])
                }
            ):
                # Collar only pays in elites and bosses. The logged A20 deck
                # chose it 96 to 90, met no Act 2 elite, and died after six
                # hallway combats. Black Blood's extra six HP after every one
                # of those fights is the more dependable survival resource.
                score += 10
    elif relic_id == "Calling Bell":
        if (
            ascension >= 15
            and act == 1
            and floor >= 16
            and curse_retention_value(gs) < 25
        ):
            # At high ascension, Bell's permanent curse also gives up the
            # opportunity to solve an energy bottleneck. The two logged A17
            # decks had no curse engine and selected it by only six points.
            score -= 8
        omamori_blocks_bell = any(
            (owned.get("id") or owned.get("name")) == "Omamori"
            and int(owned.get("counter", 0) or 0) > 0
            for owned in gs.get("relics", [])
        )
        offered_ids = {
            offered.get("id") or offered.get("name")
            for offered in (gs.get("screen_state") or {}).get("relics", [])
        }
        owned_ids = _relic_ids(gs)
        fragile_reaper_sustain = (
            any(card_id(deck_card) == "Reaper" for deck_card in deck)
            and not owned_ids & {
                "Black Blood", "Eternal Feather", "Meat on the Bone",
                "Magic Flower",
            }
        )
        if (
            ascension >= 17
            and act == 1
            and floor >= 16
            and omamori_blocks_bell
            and "Coffee Dripper" in offered_ids
            and fragile_reaper_sustain
        ):
            # Omamori removes Bell's only curse while Coffee permanently
            # removes rests. The logged deck treated one Reaper plus a
            # conditional Rupture line as complete sustain, chose Coffee by
            # six points, and arrived at Automaton on 31 HP. Prefer three
            # curse-free relics when that card loop is the only replacement.
            score += 12
    elif relic_id == "Coffee Dripper":
        if not has_sustain(gs):
            relic_ids = _relic_ids(gs)
            if "Burning Blood" in relic_ids:
                # Burning Blood is not enough to call the route fully sustained,
                # but after the inter-act heal its six HP per combat makes Coffee
                # materially less terminal than a deck with no recovery at all.
                score -= 32
            else:
                score -= 70
            if (
                ascension >= 17
                and act == 1
                and floor >= 16
                and act2_high_output_defense_count(gs) == 0
            ):
                # The A17 batch-17 deck had no route sustain and no card that
                # could absorb an Act 2 heavy hit. Burning Blood made Coffee
                # win by six points, but every later campfire was forced to
                # smith while the deck fell from 48 to 25 HP before Automaton.
                score -= 12
        if (
            ascension >= 17
            and act == 1
            and floor >= 16
            and has_sustain(gs)
            and not durable_coffee_sustain(gs)
            and act2_high_output_defense_count(gs) == 0
        ):
            # Meal Ticket and an unsupported Reaper can heal at isolated
            # checkpoints, but neither replaces repeated campfire rests. The
            # logged deck treated Meal Ticket as complete sustain, took Coffee,
            # then reached a forced Gremlin Leader elite at 34 HP with no card
            # capable of absorbing its multi-hit turn.
            score -= 24
        transition_heal_pending = (
            act == 1 and floor >= 16
            or act == 2 and floor >= 33
        )
        projected_hp_ratio = hp_ratio
        if transition_heal_pending:
            # A5+ heals 75% of missing HP after the boss. Score the inability to
            # rest from the health that actually enters the next act.
            projected_hp_ratio += (1.0 - projected_hp_ratio) * 0.75
        if projected_hp_ratio < 0.75:
            score -= 20
        if (
            ascension >= 17
            and act == 2
            and floor >= 33
            and hp_ratio < 0.60
            and "Fusion Hammer" in _relic_ids(gs)
            and not durable_coffee_sustain(gs)
        ):
            # Hammer has already removed smithing. Adding Coffee at low HP then
            # turns every normal Act 3 campfire into a blank node, while Meal
            # Ticket and base Burning Blood only cover isolated route damage.
            # The logged deck reached its final rest at 8 HP and could do
            # nothing before Time Eater killed it on turn two.
            score -= 50
    elif relic_id == "Velvet Choker":
        deck_ids = [card_id(card) for card in deck]
        owned_relics = _relic_ids(gs)
        exhaust_sources = sum(
            cid in REPEATABLE_EXHAUST_SOURCES
            or cid in MASS_EXHAUST_SOURCES
            or cid in ONE_SHOT_EXHAUST_SOURCES
            or bool(card.get("exhausts"))
            for cid, card in zip(deck_ids, deck)
        )
        throughput_ids = {
            "Battle Trance", "Bloodletting", "Burning Pact", "Dropkick",
            "Finesse", "Flash of Steel", "Offering", "Pommel Strike",
            "Seeing Red", "Shrug It Off",
        }
        throughput_cards = sum(cid in throughput_ids for cid in deck_ids)
        cheap_cards = sum(
            card.get("type") not in {"STATUS", "CURSE"}
            and isinstance(card.get("cost"), (int, float))
            and 0 <= card.get("cost") <= 1
            for card in deck
        )
        if "Dead Branch" in owned_relics:
            # Every exhaust can create another playable card. A six-card cap
            # blanks both that relic and the draw/energy used to reach it, so
            # this is a structural anti-synergy rather than a small drawback.
            score -= 24 + min(12, exhaust_sources * 3)
        if "Corruption" in deck_ids:
            score -= 24
        if (
            "Dark Embrace" in deck_ids
            and exhaust_sources >= 2
        ):
            score -= 12
        score -= min(12, deck_ids.count("Offering") * 8)
        if throughput_cards >= 3 and cheap_cards * 2 >= len(deck):
            score -= min(12, (throughput_cards - 2) * 3)
    elif relic_id == "Snecko Eye":
        average_cost = average_deck_cost(gs)
        if average_cost < 1.35:
            score -= 45
        elif average_cost >= 1.8:
            score += 12
    elif relic_id == "Philosopher's Stone":
        if (
            ascension >= 15
            and act == 1
            and floor >= 16
            and expensive_count >= 4
        ):
            # The A17 deck had six 2+ cost cards, no energy relic, and chose
            # flat-score Black Star by four points. It then could not combine
            # its expensive attacks, Weak, and block in the first Act 2 fight.
            score += min(12, (expensive_count - 2) * 3)
    elif relic_id == "SlaversCollar":
        draw_count = sum(card_id(card) in DRAW_SETUP_VALUES for card in deck)
        # Collar supplies the fourth energy exactly in the elite and boss
        # fights that decide a run. The A9 Champ deck had Impervious, Immolate,
        # Bash and four draw cards, yet Calling Bell won the old flat score and
        # the deck stayed on three energy through an eighteen-turn boss.
        score += min(18, expensive_count * 4)
        if expensive_count >= 2:
            score += min(8, draw_count * 2)
        if not long_boss_damage_ready(gs):
            score += 8
    elif relic_id == "Astrolabe":
        starter_count = count_deck(gs, {"Strike_R", "Defend_R"})
        if starter_count >= 6:
            score += min(18, (starter_count - 3) * 2)
        if not archetype_profile(gs).get("committed"):
            # Three upgraded transforms are especially valuable when Act 1
            # ended without a real engine and most starter cards remain.
            score += 8
    elif relic_id == "Pandora's Box":
        starter_count = count_deck(gs, {"Strike_R", "Defend_R"})
        starter_strikes = count_deck(gs, {"Strike_R"})
        starter_defends = count_deck(gs, {"Defend_R"})
        perfected_strikes = count_deck(gs, {"Perfected Strike"})
        if starter_count >= 6:
            # Transforming eight starter cards is a deck rebuild, not a flat
            # 62-point relic. The logged A10 deck kept all eight starters and
            # chose Collar, then had neither hallway energy nor real defense.
            score += min(36, (starter_count - 2) * 6)
        if not archetype_profile(gs).get("committed"):
            score += 8
        if perfected_strikes and starter_strikes >= 3:
            # Pandora removes the starter Strikes that make Perfected Strike a
            # dependable Act 2 damage package. Do not score that as a rebuild.
            score -= (
                8
                + starter_strikes * 4
                + min(8, max(0, perfected_strikes - 1) * 4)
            )
        if (
            ascension >= 17
            and act == 1
            and floor >= 16
            and starter_defends >= 3
            and act2_high_output_defense_count(gs) == 0
        ):
            # At high ascension, transforming every starter Defend is a large
            # variance bet when no Flame Barrier, Power Through, Impervious,
            # or equivalent anchor exists. The logged A17 deck lost all four
            # Defends, then had no affordable block on consecutive Act 2 turns.
            score -= 18 + max(0, starter_defends - 3) * 6
    elif relic_id == "Busted Crown":
        act = int(gs.get("act", 1) or 1)
        starter_count = count_deck(gs, {"Strike_R", "Defend_R"})
        if act <= 1:
            # Losing two thirds of future rewards is most damaging when Act 1
            # ends with an unfinished engine and most starter cards intact.
            score -= 10
            score -= min(18, max(0, starter_count - 4) * 3)
            if not long_boss_damage_ready(gs):
                score -= 24
        elif act == 2 and not long_boss_damage_ready(gs):
            score -= 15
    elif relic_id == "Runic Pyramid":
        clogged = sum(1 for card in gs.get("deck", []) if card.get("type") in {"STATUS", "CURSE"})
        score -= clogged * 12
        deck_ids = {card_id(card) for card in gs.get("deck", [])}
        relic_ids = {owned.get("id") for owned in gs.get("relics", [])}
        if "Unceasing Top" in relic_ids:
            # Pyramid prevents the hand from emptying, switching off Top's
            # draw engine in exactly the deck that paid a relic slot for it.
            score -= 35
        has_status_cleanup = bool(
            deck_ids & {"Fiend Fire", "Second Wind", "Sever Soul", "True Grit"}
            or "Medical Kit" in relic_ids
        )
        if status_source_count(gs) > 0 and not has_status_cleanup:
            # Retaining Power Through's Wounds without a cleanup card can fill
            # the hand permanently. This exact pairing starved v28 of defense
            # throughout the fatal Reptomancer fight.
            score -= 38
        deck = gs.get("deck", [])
        reliable_release = any(
            card_id(card) in {"Fiend Fire", "Second Wind", "Sever Soul"}
            or card_id(card) == "True Grit" and int(card.get("upgrades", 0) or 0) > 0
            for card in deck
        )
        draw_pressure = sum(
            card_id(card) in {"Battle Trance", "Burning Pact", "Offering", "Pommel Strike", "Shrug It Off"}
            for card in deck
        )
        attack_count = sum(card.get("type") == "ATTACK" for card in deck)
        expensive_count = sum(
            isinstance(card.get("cost"), (int, float)) and card.get("cost") >= 2
            for card in deck
            if card.get("type") not in {"STATUS", "CURSE"}
        )
        if (
            len(deck) >= 15
            and attack_count * 2 >= len(deck)
            and not reliable_release
            and (draw_pressure > 0 or expensive_count >= 3)
        ):
            # The one-turn planner cannot deliberately discard retained filler.
            # In a large attack-heavy hand, Pyramid therefore needs reliable
            # mass exhaust before it beats a clean relic or extra energy.
            score -= 20
    elif relic_id == "Sozu":
        if int(gs.get("ascension_level", 0) or 0) >= 15:
            defense_shortfall = defensive_package_shortfall(gs)
            if defense_shortfall:
                # Potions are the missing tactical block/damage package for a
                # thin high-ascension deck. The A17 Automaton run chose Sozu with
                # only Shrug, then reached Hyper Beam with no consumable answer.
                score -= min(24, 12 + defense_shortfall * 6)
            if not has_sustain(gs):
                score -= 8
        potions = gs.get("potions", [])
        empty_slots = sum(
            normalized_potion_id(potion) == "Potion Slot"
            for potion in potions
        )
        if (
            ascension >= 20
            and act == 1
            and floor >= 16
            and len(potions) >= 2
            and empty_slots == len(potions)
        ):
            # The first A20 run took Sozu with both slots empty, permanently
            # forfeiting every Act 2 potion before three forced fights drained
            # 62 HP. Price the full future opportunity, not only held potions.
            score -= 24 + min(12, empty_slots * 4)
        if any(relic.get("id") == "Toy Ornithopter" for relic in gs.get("relics", [])):
            score -= 35
        if any(relic.get("id") == "Potion Belt" for relic in gs.get("relics", [])):
            filled_slots = sum(
                normalized_potion_id(potion) != "Potion Slot"
                for potion in gs.get("potions", [])
            )
            potion_engine = bool(
                count_deck(gs, {"Alchemize"})
                or _relic_ids(gs) & {"White Beast Statue", "White Beast"}
            )
            # Empty slots are unrealized opportunity, not consumables being
            # destroyed. Keep a future-potion price, but charge heavily only
            # for potions already held or a repeatable potion engine.
            score -= (
                8
                + min(16, filled_slots * 4)
                + (12 if potion_engine else 0)
            )
    elif relic_id == "Runic Cube":
        deck_ids = [card_id(card) for card in gs.get("deck", [])]
        recurring_sources = sum(
            cid in {"Brutality", "Combust", "Pain"} for cid in deck_ids
        )
        reusable_sources = sum(
            cid in {"Bloodletting", "Hemokinesis"} for cid in deck_ids
        )
        if not recurring_sources and not reusable_sources:
            # Offering and J.A.X. trigger Cube only once per combat. Natural
            # enemy damage draws after the hit, too late to block it. The A9
            # Automaton deck owned only Offering, so Cube was effectively a
            # one-card bonus while Black Star was passed.
            score -= 24
        else:
            score += min(18, recurring_sources * 9 + reusable_sources * 5)
            if "Rupture" in deck_ids:
                score += 6
    elif relic_id == "Mark of Pain":
        deck_ids = [card_id(card) for card in gs.get("deck", [])]
        second_winds = deck_ids.count("Second Wind")
        if second_winds:
            # The two Wounds are block fuel for Second Wind, while the fourth
            # energy lets the deck defend and still advance the fight. The
            # logged A17 shell passed this package for two starter removals and
            # reached Automaton's Hyper Beam with no block in the exact draw.
            score += 14 + min(8, max(0, second_winds - 1) * 4)
        elif not any(cid in {"Evolve", "Fire Breathing"} for cid in deck_ids):
            score -= 22
    return score


def decide_boss_reward(gs):
    relics = (gs.get("screen_state") or {}).get("relics", [])
    if not relics:
        return "STATE"
    scored = [(i, r, boss_relic_score(r, gs)) for i, r in enumerate(relics)]
    i, _, _ = max(scored, key=lambda x: x[2])
    log(
        "boss relic reward "
        f"scores={[(relic.get('id'), round(score, 1)) for _, relic, score in scored]} "
        f"decision={i}"
    )
    return f"CHOOSE {i}"


def shop_route_value(current_gold, depth):
    """Value a shop using current gold plus modest expected income en route."""
    projected_gold = max(0, int(current_gold or 0)) + min(max(0, depth), 5) * 18
    if projected_gold < 75:
        return -2.0
    if projected_gold < 120:
        return -0.4
    if projected_gold < 175:
        return 1.1
    if projected_gold < 250:
        return 2.3
    return 3.3


def shop_conversion_route_bonus(current_gold, distance):
    """Value converting a full purse at a reachable shop before it stays idle."""
    gold_pressure = max(0.0, min(1.0, (int(current_gold or 0) - 175) / 100.0))
    proximity = max(0, 4 - int(distance or 0))
    return gold_pressure * proximity * 3.6


def elite_route_value(hp_ratio, specialization):
    """Dynamic elite-node value based on health and build focus.

    Healthy, focused decks are encouraged to take elites for relic tempo.
    Injured or unfocused decks treat the same elite as a liability.  The
    value is deliberately bounded so a single elite never overwhelms every
    other route consideration.
    """
    hp_ratio = max(0.0, min(1.0, float(hp_ratio)))
    specialization = max(0.0, min(1.0, float(specialization)))
    value = -2.0 + (hp_ratio - 0.55) * 8.0 + (specialization - 0.45) * 8.0
    return max(-8.0, min(6.0, value))


def route_recovery_factor(gs):
    """Estimate how safely hallway fights can convert into recovered HP."""
    factor = 0.0
    reapers = [card for card in gs.get("deck", []) if card_id(card) == "Reaper"]
    if reapers:
        # Reaper is potential sustain, not guaranteed healing: it still has to
        # be drawn, afforded, and amplified before the fight becomes lethal.
        # Its base damage is only modest recovery; most of the route credit is
        # unlocked by a reliable Strength source and a focused engine.
        factor += 0.14
        if any(int(card.get("upgrades", 0) or 0) > 0 for card in reapers):
            factor += 0.03
        # A second copy materially improves draw reliability, but does not
        # substitute for Strength scaling.
        factor += min(0.06, max(0, len(reapers) - 1) * 0.06)
        strength_sources = boss_strength_scaling_source_count(gs)
        factor += min(0.20, strength_sources * 0.10)
        specialization = archetype_specialization(gs)
        if strength_sources and specialization >= 0.72:
            factor += 0.49
        elif strength_sources and specialization >= 0.62:
            factor += 0.10

    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Black Blood" in relic_ids:
        factor += 0.24
    elif "Burning Blood" in relic_ids:
        factor += 0.12
    if "Meat on the Bone" in relic_ids and (gs.get("current_hp", 1) or 1) * 2 <= (gs.get("max_hp", 1) or 1):
        factor += 0.28
    if "Bird Faced Urn" in relic_ids and any(card.get("type") == "POWER" for card in gs.get("deck", [])):
        factor += 0.14
    if "Toy Ornithopter" in relic_ids and any(
        potion.get("id") != "Potion Slot" for potion in gs.get("potions", [])
    ):
        factor += 0.12
    return max(0.0, min(1.0, factor))


def route_danger_factor(gs):
    """Estimate route-level combat risk introduced by current relics."""
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    factor = 0.0
    if "Brimstone" in relic_ids:
        # Brimstone is excellent damage scaling, but every extra combat turn
        # also scales the enemy.  It must not make elite routes look safer just
        # because it contributes to the strength archetype score.
        factor += 0.45
    if "Sozu" in relic_ids:
        factor += 0.10
    if "Runic Dome" in relic_ids:
        factor += 0.14
    return max(0.0, min(1.0, factor))


def early_act1_reward_pressure(gs):
    """Value reliable card rewards while the opening deck is still unfinished."""
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    deck = gs.get("deck") or []
    if act != 1 or floor > 7 or not deck:
        return 0.0

    starter_ids = {"AscendersBane", "Strike_R", "Defend_R", "Bash"}
    drafted_cards = sum(
        1
        for card in deck
        if card_id(card) not in starter_ids
        and card.get("type") not in {"CURSE", "STATUS"}
    )
    reward_gap = max(0, 3 - drafted_cards)
    attack_gap = max(0, 2 - nonstarter_attack_count(gs))
    defense_gap = max(0, 1 - act1_defense_foundation_count(gs))
    stage = max(0.35, 1.0 - floor * 0.10)
    return min(
        2.6,
        (reward_gap * 0.45 + attack_gap * 0.55 + defense_gap * 0.35) * stage,
    )


def act2_elite_control_score(gs):
    """Measure debuffs that remain useful across all three Act 2 elites."""
    hard_control = count_deck(gs, {"Disarm", "Shockwave"})
    broad_control = count_deck(gs, {"Intimidate"})
    soft_control = count_deck(gs, {"Clothesline", "Uppercut"})
    return hard_control * 2.0 + broad_control * 1.5 + soft_control


def act2_elite_route_penalties(gs):
    """Price elite routes that the current act/build cannot reliably convert."""
    act = int(gs.get("act", 1) or 1)
    # A revive can rescue one lethal sequence, but spending it in an optional
    # hallway is much worse than carrying it into the boss. Count half of that
    # reserve for route aggression; raw HP and real recovery retain full value.
    hp_ratio = effective_hp_ratio(gs, revive_weight=0.50)
    if act == 3:
        # Giant Head and Reptomancer punish decks that are healthy but still
        # lack repeatable damage.  The v75 run entered Giant Head at full HP
        # with only 0.35 combat specialization and died with 179 HP remaining.
        # Full HP is not readiness by itself: apply a late-elite penalty when
        # the deck has neither focused combat output nor a long-boss engine.
        specialization = route_combat_specialization(gs)
        focus_gap = max(0.0, 0.55 - specialization) * 10.0
        engine_gap = 0.0 if long_boss_damage_ready(gs) else 3.5
        return 0.0, min(8.0, focus_gap + engine_gap)
    if act != 2:
        return 0.0, 0.0

    coverage = act2_swarm_control_score(gs)
    coverage_penalty = (1.0 - coverage) * 3.5
    ascension = int(gs.get("ascension_level", 0) or 0)
    if (
        ascension >= 18
        and act2_high_output_defense_count(gs) == 0
    ):
        # Book of Stabbing can erase an otherwise healthy run before the deck's
        # slower block comes online. High-ascension elite routes need a concrete
        # answer to repeated high-output turns.
        coverage_penalty += 2.1
    elite_control_score = act2_elite_control_score(gs)
    sustained_recovery = bool(
        count_deck(gs, {"Reaper"}) > 0
        and dedicated_strength_scaling_source_count(gs) > 0
    )
    if (
        ascension >= 18
        and hp_ratio < 0.80
        and act2_high_output_defense_count(gs) <= 1
        and elite_control_score < 2.0
        and not sustained_recovery
    ):
        # One Flame Barrier is not reliable coverage in a twenty-card deck,
        # especially against Slavers' 34-point opener. A lone single-target
        # Clothesline or Uppercut is not a full suppression package either.
        # Price the optional elite below a safe node until the deck has a second
        # burst block, hard/broad control, or Strength-backed Reaper sustain.
        coverage_penalty += 4.6
    if hp_ratio < 0.75:
        coverage_penalty += (0.75 - hp_ratio) * 6.0

    late_penalty = 0.0
    if not long_boss_damage_ready(gs):
        # Past the middle of Act 2, an extra relic is not worth reaching the
        # boss with neither a damage engine nor the HP to assemble one. The A8
        # status deck chose Book of Stabbing over an event at 55/80, lost 31
        # HP, and entered Champ with no repeatable scaling.
        late_penalty = 4.0 + max(0.0, 0.75 - hp_ratio) * 8.0
    return min(7.0, coverage_penalty), min(8.0, late_penalty)


def projected_route_hp(
    symbol, hp_ratio, rest_heals=True, specialization=0.0,
    recovery_factor=0.0, danger_factor=0.0, shop_heals=False,
    combats_since_rest=0, projected_floor=0,
):
    """Project HP after one route node for downstream route valuation."""
    hp_ratio = max(0.0, min(1.0, float(hp_ratio)))
    specialization = max(0.0, min(1.0, float(specialization)))
    recovery_factor = max(0.0, min(1.0, float(recovery_factor)))
    danger_factor = max(0.0, min(1.0, float(danger_factor)))
    combat_streak = max(0, int(combats_since_rest or 0))
    projected_floor = max(0, int(projected_floor or 0))
    if projected_floor >= 34:
        hallway_act_pressure, elite_act_pressure, event_risk = 0.07, 0.09, 0.04
    elif projected_floor >= 17:
        hallway_act_pressure, elite_act_pressure, event_risk = 0.05, 0.06, 0.03
    else:
        hallway_act_pressure, elite_act_pressure, event_risk = 0.00, 0.00, 0.01

    if symbol == "R" and rest_heals:
        return min(1.0, hp_ratio + 0.30)
    if symbol == "$" and shop_heals:
        return min(1.0, hp_ratio + 0.15)
    if symbol == "M":
        loss = (
            0.12
            + hallway_act_pressure
            + min(3, combat_streak) * 0.06
            + danger_factor * 0.07
            - specialization * 0.015
            - recovery_factor * 0.04
        )
        return max(0.0, hp_ratio - max(0.035, loss))
    if symbol == "E":
        loss = (
            0.30
            + elite_act_pressure
            + min(2, combat_streak) * 0.08
            + danger_factor * 0.15
            - specialization * 0.03
            - recovery_factor * 0.08
        )
        return max(0.0, hp_ratio - max(0.11, loss))
    if symbol == "?":
        # Events are not guaranteed safe: several Act 2 events can become
        # hallway fights. At critical HP, price a little extra uncertainty so
        # a distant question mark does not masquerade as a free recovery node.
        critical_uncertainty = 0.03 if hp_ratio < 0.20 else 0.0
        return max(0.0, hp_ratio - event_risk - critical_uncertainty)
    return hp_ratio


def act3_elite_entry_ready(
    gs, specialization=None, recovery_factor=None, danger_factor=None,
):
    """Require both a survivable reserve and a mature engine for Act 3 elites."""
    if int(gs.get("act", 1) or 1) != 3:
        return True
    if not long_boss_damage_ready(gs):
        return False

    specialization = (
        route_combat_specialization(gs)
        if specialization is None
        else max(0.0, min(1.0, float(specialization)))
    )
    recovery_factor = (
        route_recovery_factor(gs)
        if recovery_factor is None
        else max(0.0, min(1.0, float(recovery_factor)))
    )
    danger_factor = (
        route_danger_factor(gs)
        if danger_factor is None
        else max(0.0, min(1.0, float(danger_factor)))
    )
    projected_hp = projected_route_hp(
        "E",
        effective_hp_ratio(gs),
        specialization=specialization,
        recovery_factor=recovery_factor,
        danger_factor=danger_factor,
        projected_floor=int(gs.get("floor", 0) or 0) + 1,
    )
    required_hp = 0.48 - recovery_factor * 0.25 + danger_factor * 0.08
    required_specialization = (
        0.60 - recovery_factor * 0.10 + danger_factor * 0.08
    )
    return bool(
        projected_hp >= required_hp
        and specialization >= required_specialization
    )


def projected_combat_reserve_penalty(symbol, projected_hp_ratio):
    """Price routes that reach a fight before they reach their recovery."""
    reserve = {"M": 0.10, "E": 0.18}.get(symbol)
    if reserve is None:
        return 0.0
    projected_hp_ratio = max(0.0, min(1.0, float(projected_hp_ratio)))
    penalty = max(0.0, reserve - projected_hp_ratio) * 60.0
    if projected_hp_ratio <= 0.01:
        penalty += 4.0
    return penalty


def relic_route_adjustments(gs):
    """Return per-room utility contributed by the current relic collection."""
    relic_ids = canonical_relic_ids(gs)
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(
        1, gs.get("max_hp", 1) or 1
    )
    adjustments = {symbol: 0.0 for symbol in ("M", "E", "?", "R", "$", "T")}

    if "Black Star" in relic_ids:
        adjustments["E"] += 2.4
    if "PreservedInsect" in relic_ids:
        adjustments["E"] += 2.0
    if "Sling" in relic_ids:
        adjustments["E"] += 0.7
    if "SlaversCollar" in relic_ids:
        adjustments["E"] += 0.6

    if "Prayer Wheel" in relic_ids:
        adjustments["M"] += 1.0
    if "Question Card" in relic_ids:
        adjustments["M"] += 0.45
    if "Nloth's Gift" in relic_ids:
        adjustments["M"] += 0.45
    if "FaceOfCleric" in relic_ids:
        adjustments["M"] += 0.35
        adjustments["E"] += 0.35
    if "White Beast Statue" in relic_ids and "Sozu" not in relic_ids:
        empty_slots = sum(
            normalized_potion_id(potion) == "Potion Slot"
            for potion in gs.get("potions", [])
        )
        adjustments["M"] += 0.25 + min(0.50, empty_slots * 0.25)

    if "Juzu Bracelet" in relic_ids:
        adjustments["?"] += 0.9
    if "SsserpentHead" in relic_ids and "Ectoplasm" not in relic_ids:
        adjustments["?"] += 1.4
    tiny_counter = relic_counter(gs, "Tiny Chest")
    if tiny_counter >= 0:
        adjustments["?"] += 2.8 if tiny_counter >= 3 else 0.25 + tiny_counter * 0.15
    if "Golden Idol" in relic_ids and "Ectoplasm" not in relic_ids:
        adjustments["M"] += 0.25
        adjustments["E"] += 0.25
        adjustments["?"] += 0.15
    if "Bloody Idol" in relic_ids and "Ectoplasm" not in relic_ids:
        recovery_need = max(0.0, min(1.0, (0.75 - hp_ratio) / 0.50))
        for symbol in ("M", "E", "?"):
            adjustments[symbol] += 0.25 + recovery_need * 0.55

    if "Ancient Tea Set" in relic_ids:
        adjustments["R"] += 0.65
    if "Dream Catcher" in relic_ids:
        adjustments["R"] += 0.45
    if "Eternal Feather" in relic_ids and hp_ratio < 0.90:
        adjustments["R"] += min(1.2, len(gs.get("deck", [])) // 5 * 0.22)
    if "Girya" in relic_ids and relic_counter(gs, "Girya", 0) < 3:
        adjustments["R"] += 0.75
    if "Peace Pipe" in relic_ids:
        removable_junk = any(
            card.get("type") == "CURSE" or card_id(card) in {"Strike_R", "Defend_R"}
            for card in gs.get("deck", [])
        )
        adjustments["R"] += 0.9 if removable_junk else 0.25
    if "Shovel" in relic_ids:
        adjustments["R"] += 0.8

    if "Matryoshka" in relic_ids and relic_counter(gs, "Matryoshka", 0) > 0:
        adjustments["T"] += 1.6
    if "NlothsMask" in relic_ids:
        adjustments["T"] -= 2.0
    if "Cursed Key" in relic_ids and "Omamori" not in relic_ids:
        adjustments["T"] -= max(0.2, 1.2 - curse_retention_value(gs) / 35.0)

    if "The Courier" in relic_ids:
        adjustments["$"] += 0.8
    if "Membership Card" in relic_ids:
        adjustments["$"] += 1.1
    if "Smiling Mask" in relic_ids and any(
        card.get("type") == "CURSE" or card_id(card) in {"Strike_R", "Defend_R"}
        for card in gs.get("deck", [])
    ):
        adjustments["$"] += 0.55
    if "Ectoplasm" in relic_ids and int(gs.get("gold", 0) or 0) < 75:
        adjustments["$"] -= 1.2

    maw_bank = next(
        (
            relic for relic in gs.get("relics", [])
            if canonical_relic_id(relic.get("id") or relic.get("name")) == "MawBank"
        ),
        None,
    )
    if maw_bank is not None and _relic_is_available(maw_bank):
        for symbol in ("M", "E", "?", "R", "T"):
            adjustments[symbol] += 0.18
        adjustments["$"] -= 0.45

    return adjustments


def act1_relic_hunt_bonus(gs):
    """Return the per-elite value of taking early high-ascension risks."""
    if (
        int(gs.get("act", 1) or 1) != 1
        or int(gs.get("ascension_level", 0) or 0) < 18
    ):
        return 0.0
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(
        1, gs.get("max_hp", 1) or 1
    )
    if hp_ratio < 0.42:
        return 0.0

    floor = int(gs.get("floor", 0) or 0)
    bonus = 3.0
    if floor <= 8:
        bonus += 1.0
    if hp_ratio >= 0.70:
        bonus += 1.0
    if nonstarter_attack_count(gs) > 0:
        bonus += 0.75
    if act1_elite_offense_ready(gs):
        bonus += 0.75
    return min(6.5, bonus)


def route_value(
    symbol, depth, rest_heals=True, current_gold=0,
    hp_ratio=1.0, specialization=0.0, recovery_factor=0.0,
    danger_factor=0.0, projected_floor=0,
    elite_coverage_penalty=0.0, late_elite_penalty=0.0,
    development_pressure=0.0, act1_elite_bonus=0.0,
):
    hp_ratio = max(0.0, min(1.0, float(hp_ratio)))
    specialization = max(0.0, min(1.0, float(specialization)))
    recovery_factor = max(0.0, min(1.0, float(recovery_factor)))
    danger_factor = max(0.0, min(1.0, float(danger_factor)))
    injury = max(0.0, min(1.0, (0.72 - hp_ratio) / 0.52))
    immediacy = max(0.45, 1.0 - max(0, depth) * 0.12)

    if symbol == "$":
        value = shop_route_value(current_gold, depth)
        if current_gold >= 75:
            value += injury * immediacy * 0.8
    elif symbol == "E":
        effective_hp = max(0.0, min(1.0, hp_ratio + recovery_factor * 0.14 - danger_factor * 0.10))
        value = elite_route_value(effective_hp, specialization)
        value -= injury * immediacy * (1.8 - recovery_factor)
        value -= danger_factor * (0.8 + immediacy * 2.4)
        value -= max(0.0, elite_coverage_penalty)
        if projected_floor <= 16:
            value += max(0.0, float(act1_elite_bonus or 0.0))
        if projected_floor >= 27:
            value -= max(0.0, late_elite_penalty)
    elif symbol == "M":
        mitigated_risk = injury * (1.0 - recovery_factor * 0.75)
        value = (
            1.0
            + specialization * 1.3
            - mitigated_risk * immediacy * 5.2
            + recovery_factor * injury * immediacy * 2.4
            - danger_factor * (0.4 + immediacy * 1.4)
        )
        if projected_floor >= 4:
            late_pressure = (0.4 + injury * 0.8) * (1.0 - recovery_factor * 0.70)
            value -= late_pressure
        if projected_floor <= 7 and development_pressure > 0:
            healthy_enough = max(0.0, min(1.0, (hp_ratio - 0.45) / 0.35))
            value += development_pressure * immediacy * healthy_enough
    elif symbol == "?":
        value = 0.6 + injury * immediacy * 2.2 * (1.0 - recovery_factor * 0.45)
    elif symbol == "R":
        # A healthy campfire still has smith value; injury smoothly converts
        # more of the node's utility toward resting.
        value = 1.5 + injury * immediacy * 5.0 if rest_heals else 0.5
    elif symbol == "T":
        value = 1.0 + (1.0 - injury) * 0.3
    elif symbol == "B":
        value = 3.0
    else:
        value = 0.0
    return value


def immediate_route_adjustment(
    symbol, hp_ratio, recovery_factor=0.0, danger_factor=0.0,
    current_gold=0, rest_heals=True,
):
    """Continuously reweight the immediate node around the current HP reserve."""
    hp_ratio = max(0.0, min(1.0, float(hp_ratio)))
    recovery_factor = max(0.0, min(1.0, float(recovery_factor)))
    danger_factor = max(0.0, min(1.0, float(danger_factor)))
    low_hp_pressure = max(0.0, min(1.0, (0.68 - hp_ratio) / 0.48))
    sustain_relief = max(0.12, 1.0 - recovery_factor * 0.88)
    combat_pressure = low_hp_pressure * sustain_relief
    # Recovery permits a lower safety threshold, but it happens after the
    # attack card is drawn and the fight is survived. Keep an emergency band
    # where an immediately safe node beats gambling the current HP reserve.
    emergency_threshold = 0.52 - recovery_factor * 0.12 + danger_factor * 0.08
    emergency_pressure = max(
        0.0,
        min(1.0, (emergency_threshold - hp_ratio) / 0.18),
    )

    if symbol == "E":
        elite_reserve_pressure = max(
            0.0,
            min(1.0, (0.82 - hp_ratio) / 0.22),
        ) * max(0.15, 1.0 - recovery_factor) * 4.0
        return (
            -combat_pressure * (16.0 + danger_factor * 6.0)
            - emergency_pressure * 11.0
            - elite_reserve_pressure
        )
    if symbol == "M":
        return (
            -combat_pressure * (9.0 + danger_factor * 3.0)
            - emergency_pressure * 9.5
        )
    if symbol == "R":
        return combat_pressure * (4.5 if rest_heals else 0.8) + emergency_pressure * 3.0
    if symbol == "?":
        # At single-digit or near-single-digit HP, an unknown event is not a
        # genuinely safe node because it can roll a combat. Keep its normal
        # low-HP appeal, but remove the false +4 safety bonus seen at 8/87.
        uncertainty = max(
            0.0,
            min(1.0, (0.25 - hp_ratio) / 0.16),
        ) * (8.0 + danger_factor * 2.0)
        return combat_pressure * 2.2 + emergency_pressure * 2.0 - uncertainty
    if symbol == "$":
        return (
            combat_pressure * (1.8 if current_gold >= 75 else 0.8)
            + emergency_pressure * 1.5
        )
    if symbol == "T":
        return combat_pressure * 1.2 + emergency_pressure
    return 0.0


def route_metrics_from(
    node, node_map, current_floor=0, depth=0, seen=None,
    rest_heals=True, current_gold=0, hp_ratio=1.0, specialization=0.0,
    recovery_factor=0.0, danger_factor=0.0, shop_heals=False,
    elites_since_rest=0, combats_since_rest=0,
    elite_coverage_penalty=0.0, late_elite_penalty=0.0,
    development_pressure=0.0, relic_adjustments=None,
    act1_elite_bonus=0.0,
):
    if seen is None:
        seen = set()
    key = (node.get("x"), node.get("y"))
    if key in seen:
        return (99, 0, 99, -999.0)
    seen.add(key)

    symbol = node.get("symbol")
    elite_count = 1 if symbol == "E" else 0
    rest_count = 1 if symbol == "R" and rest_heals else 0
    projected_floor = current_floor + depth + 1
    late_monsters = 1 if symbol == "M" and projected_floor >= 4 else 0
    value = route_value(
        symbol, depth, rest_heals, current_gold=current_gold,
        hp_ratio=hp_ratio, specialization=specialization,
        recovery_factor=recovery_factor, danger_factor=danger_factor,
        projected_floor=projected_floor,
        elite_coverage_penalty=elite_coverage_penalty,
        late_elite_penalty=late_elite_penalty,
        development_pressure=development_pressure,
        act1_elite_bonus=act1_elite_bonus,
    )
    if relic_adjustments:
        value += float(relic_adjustments.get(symbol, 0.0) or 0.0)
    next_hp_ratio = projected_route_hp(
        symbol, hp_ratio, rest_heals=rest_heals,
        specialization=specialization, recovery_factor=recovery_factor,
        danger_factor=danger_factor, shop_heals=shop_heals,
        combats_since_rest=combats_since_rest,
        projected_floor=projected_floor,
    )
    value -= projected_combat_reserve_penalty(symbol, next_hp_ratio)
    if symbol == "E" and elites_since_rest:
        # Relic rewards have diminishing practical value when a route asks the
        # current HP pool to pay for several elites without a campfire reset.
        # This also prevents a distant chain of elites from overpowering a
        # safer route simply by adding every relic reward at full value.
        value -= elites_since_rest * (
            2.8 + danger_factor * 2.0 + max(0.0, 0.70 - hp_ratio) * 3.0
        )
    if symbol in {"M", "E"} and combats_since_rest:
        # Back-to-back fights are much more dangerous than the same node
        # count spread around campfires. Specialization can shorten those
        # fights, but it is not a substitute for actual recovery.
        value -= combats_since_rest * (
            1.4 + danger_factor * 1.4 + (1.0 - specialization) * 0.8
        )
    next_elites_since_rest = 0 if symbol == "R" else elites_since_rest + (1 if symbol == "E" else 0)
    next_combats_since_rest = (
        0
        if symbol == "R" or symbol == "$" and shop_heals
        else combats_since_rest + (1 if symbol in {"M", "E"} else 0)
    )
    children = node.get("children") or []
    if not children:
        return (elite_count, rest_count, late_monsters, value)

    child_metrics = []
    for child in children:
        nxt = node_map.get((child.get("x"), child.get("y")))
        if nxt:
            child_metrics.append(
                route_metrics_from(
                    nxt, node_map, current_floor, depth + 1, set(seen),
                    rest_heals, current_gold, next_hp_ratio, specialization,
                    recovery_factor, danger_factor, shop_heals,
                    next_elites_since_rest, next_combats_since_rest,
                    elite_coverage_penalty, late_elite_penalty,
                    development_pressure, relic_adjustments,
                    act1_elite_bonus,
                )
            )
    if not child_metrics:
        return (elite_count, rest_count, late_monsters, value)

    child_elites, child_rests, child_late_monsters, child_value = max(child_metrics, key=route_metric_key)
    return (elite_count + child_elites, rest_count + child_rests, late_monsters + child_late_monsters, value + child_value)


def route_metric_key(metrics):
    elite_count, rest_count, late_monsters, value = metrics
    # Monster danger is already priced continuously by health, recovery, build
    # focus, distance, and act depth. Keep counts only as tie-breakers.
    return (value, rest_count, -late_monsters, -elite_count)


def nearest_shop_distance(node, node_map, seen=None):
    """Return the fewest nodes to a shop, including the current node."""
    seen = set() if seen is None else set(seen)
    key = (node.get("x"), node.get("y"))
    if key in seen:
        return NO_ELITE_DISTANCE
    if node.get("symbol") == "$":
        return 1
    seen.add(key)
    distances = []
    for child in node.get("children") or []:
        child_node = node_map.get((child.get("x"), child.get("y")), child)
        distance = nearest_shop_distance(child_node, node_map, seen)
        if distance < NO_ELITE_DISTANCE:
            distances.append(1 + distance)
    return min(distances, default=NO_ELITE_DISTANCE)


NO_ELITE_DISTANCE = 10**9


def fastest_elite_from(node, node_map, seen=None):
    combat_count, _, floor_count = lament_elite_route_from(node, node_map, seen)
    return (combat_count, floor_count)


def lament_elite_route_from(node, node_map, seen=None):
    """Return combats, uncertain events, and floors to the nearest elite."""
    seen = set() if seen is None else set(seen)
    key = (node.get("x"), node.get("y"))
    if key in seen:
        return (NO_ELITE_DISTANCE, NO_ELITE_DISTANCE, NO_ELITE_DISTANCE)
    seen.add(key)

    symbol = node.get("symbol")
    if symbol == "E":
        return (1, 0, 1)

    combat_count = 1 if symbol == "M" else 0
    uncertain_events = 1 if symbol == "?" else 0
    best = (NO_ELITE_DISTANCE, NO_ELITE_DISTANCE, NO_ELITE_DISTANCE)
    for child in node.get("children") or []:
        child_node = node_map.get((child.get("x"), child.get("y")), child)
        child_combats, child_events, child_floors = lament_elite_route_from(
            child_node, node_map, set(seen)
        )
        if child_combats >= NO_ELITE_DISTANCE:
            continue
        best = min(
            best,
            (
                combat_count + child_combats,
                uncertain_events + child_events,
                1 + child_floors,
            ),
        )
    return best


def elite_approach_safety(node, node_map, seen=None, rest_heals=True):
    seen = set() if seen is None else set(seen)
    key = (node.get("x"), node.get("y"))
    if key in seen:
        return (-1, -NO_ELITE_DISTANCE, -NO_ELITE_DISTANCE)
    seen.add(key)

    symbol = node.get("symbol")
    if symbol == "E":
        return (0, 0, 0)

    children = node.get("children") or []
    if not children:
        return (NO_ELITE_DISTANCE, 0, NO_ELITE_DISTANCE)

    candidates = []
    for child in children:
        child_node = node_map.get((child.get("x"), child.get("y")), child)
        rests, neg_combats, floors = elite_approach_safety(
            child_node,
            node_map,
            set(seen),
            rest_heals=rest_heals,
        )
        if rests < 0:
            continue
        candidates.append(
            (
                rests + (1 if symbol == "R" and rest_heals else 0),
                neg_combats - (1 if symbol == "M" else 0),
                floors + 1,
            )
        )
    return max(candidates, default=(-1, -NO_ELITE_DISTANCE, -NO_ELITE_DISTANCE))


def forced_elite_before_recovery(gs, max_floors=3):
    """Return whether every plausible current route reaches an elite first."""
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    act_offset = {1: 0, 2: 17, 3: 34, 4: 51}.get(act, 0)
    current_y = floor - act_offset - 1
    node_map = {(node.get("x"), node.get("y")): node for node in gs.get("map", [])}
    current_nodes = [
        node
        for node in node_map.values()
        if node.get("y") == current_y and node.get("symbol") == "R"
    ]
    remembered = LAST_MAP_NODE or {}
    if (
        remembered.get("seed") == gs.get("seed")
        and remembered.get("act") == act
        and remembered.get("floor") == floor
        and remembered.get("symbol") == "R"
    ):
        chosen = (remembered.get("x"), remembered.get("y"))
        current_nodes = [
            node for node in current_nodes
            if (node.get("x"), node.get("y")) == chosen
        ]
    if not current_nodes:
        return False

    for node in current_nodes:
        choices = []
        for child in node.get("children") or []:
            child_node = node_map.get((child.get("x"), child.get("y")), child)
            choices.append(elite_approach_safety(child_node, node_map))
        if not choices:
            return False
        rests, _, floors = max(choices)
        if rests != 0 or floors > max_floors:
            return False
    return True


def remembered_current_map_node(gs):
    """Return the exact current map node selected on the preceding map screen."""
    remembered = LAST_MAP_NODE or {}
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    if (
        remembered.get("seed") != gs.get("seed")
        or remembered.get("act") != act
        or remembered.get("floor") != floor
    ):
        return None
    chosen = (remembered.get("x"), remembered.get("y"))
    return next(
        (
            node
            for node in gs.get("map", [])
            if (node.get("x"), node.get("y")) == chosen
        ),
        None,
    )


def combat_pressure_before_next_rest_from(node, node_map, seen=None):
    """Return the least combat load on any branch before the next campfire."""
    seen = set() if seen is None else set(seen)
    key = (node.get("x"), node.get("y"))
    if key in seen:
        return 99.0
    seen.add(key)

    symbol = node.get("symbol")
    if symbol == "R":
        return 0.0
    cost = 1.5 if symbol in {"E", "B"} else 1.0 if symbol == "M" else 0.25 if symbol == "?" else 0.0
    children = node.get("children") or []
    if not children:
        return cost
    child_costs = [
        combat_pressure_before_next_rest_from(
            node_map.get((child.get("x"), child.get("y")), child),
            node_map,
            set(seen),
        )
        for child in children
    ]
    return min(8.0, cost + min(child_costs, default=0.0))


def combat_pressure_before_next_rest(gs):
    """Estimate the safest available combat load after the current campfire."""
    node_map = {
        (node.get("x"), node.get("y")): node
        for node in gs.get("map", [])
    }
    current = remembered_current_map_node(gs)
    if current is not None and current.get("symbol") == "R":
        current_nodes = [current]
    else:
        act = int(gs.get("act", 1) or 1)
        floor = int(gs.get("floor", 0) or 0)
        act_offset = {1: 0, 2: 17, 3: 34, 4: 51}.get(act, 0)
        current_y = floor - act_offset - 1
        current_nodes = [
            node
            for node in node_map.values()
            if node.get("y") == current_y and node.get("symbol") == "R"
        ]

    pressures = []
    for current_node in current_nodes:
        branch_pressures = [
            combat_pressure_before_next_rest_from(
                node_map.get((child.get("x"), child.get("y")), child),
                node_map,
            )
            for child in current_node.get("children") or []
        ]
        if branch_pressures:
            pressures.append(min(branch_pressures))
    return min(pressures, default=0.0)


def immediate_next_room_is_forced(gs, symbol):
    """Return whether every child of the exact current node has ``symbol``."""
    current = remembered_current_map_node(gs)
    if current is None:
        return False
    node_map = {
        (node.get("x"), node.get("y")): node
        for node in gs.get("map", [])
    }
    children = [
        node_map.get((child.get("x"), child.get("y")), child)
        for child in current.get("children") or []
    ]
    return bool(children) and all(child.get("symbol") == symbol for child in children)


def node_forces_elite_within_rooms(node, node_map, max_rooms=2, seen=None):
    """Return whether every branch from one candidate hits an elite soon."""
    if max_rooms <= 0:
        return False
    seen = set() if seen is None else set(seen)
    key = (node.get("x"), node.get("y"))
    if key in seen:
        return False
    if node.get("symbol") == "E":
        return True
    if max_rooms <= 1:
        return False
    children = [
        node_map.get((child.get("x"), child.get("y")), child)
        for child in node.get("children") or []
    ]
    return bool(children) and all(
        node_forces_elite_within_rooms(
            child, node_map, max_rooms - 1, seen | {key}
        )
        for child in children
    )


def forced_elite_within_rooms(gs, max_rooms=2):
    """Return whether every visible branch reaches an elite within ``max_rooms``."""
    current = remembered_current_map_node(gs)
    if current is None or max_rooms <= 0:
        return False
    node_map = {
        (node.get("x"), node.get("y")): node
        for node in gs.get("map", [])
    }

    children = [
        node_map.get((child.get("x"), child.get("y")), child)
        for child in current.get("children") or []
    ]
    return bool(children) and all(
        node_forces_elite_within_rooms(child, node_map, max_rooms)
        for child in children
    )


def node_immediately_forces_combat(node, node_map):
    """Return whether every exit from ``node`` is an immediate combat."""
    children = [
        node_map.get((child.get("x"), child.get("y")), child)
        for child in node.get("children") or []
    ]
    return bool(children) and all(
        child.get("symbol") in {"M", "E", "B"} for child in children
    )


def remember_map_choice(gs, index, node):
    """Remember the actual node so the following room can inspect its route."""
    global LAST_MAP_NODE
    LAST_MAP_NODE = {
        "seed": gs.get("seed"),
        "act": int(gs.get("act", 1) or 1),
        "floor": int(gs.get("floor", 0) or 0) + 1,
        "symbol": node.get("symbol"),
        "x": node.get("x"),
        "y": node.get("y"),
    }
    return f"CHOOSE {index}"


def decide_map(gs):
    screen = gs.get("screen_state") or {}
    next_nodes = screen.get("next_nodes") or []
    if not next_nodes:
        return "CHOOSE 0"
    current_floor = int(gs.get("floor", 0) or 0)
    node_map = {(n.get("x"), n.get("y")): n for n in gs.get("map", [])}
    rest_heals = not any(relic.get("id") == "Coffee Dripper" for relic in gs.get("relics", []))
    current_gold = int(gs.get("gold", 0) or 0)
    raw_hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
    # A revive can rescue one lethal sequence, but spending it in an optional
    # hallway is much worse than carrying it into the boss. Count half of that
    # reserve for route aggression; raw HP and real recovery retain full value.
    hp_ratio = effective_hp_ratio(gs, revive_weight=0.50)
    profile = archetype_profile(gs)
    specialization = route_combat_specialization(gs, profile)
    recovery_factor = route_recovery_factor(gs)
    danger_factor = route_danger_factor(gs)
    development_pressure = early_act1_reward_pressure(gs)
    route_relic_modifiers = relic_route_adjustments(gs)
    act1_elite_bonus = act1_relic_hunt_bonus(gs)
    act = int(gs.get("act", 1) or 1)
    ascension = int(gs.get("ascension_level", 0) or 0)
    elite_coverage_penalty, late_elite_penalty = act2_elite_route_penalties(gs)
    shop_heals = any(relic.get("id") == "Meal Ticket" for relic in gs.get("relics", []))
    scored = []
    for i, node in enumerate(next_nodes):
        full_node = node_map.get((node.get("x"), node.get("y")), node)
        metrics = route_metrics_from(
            full_node, node_map, current_floor,
            rest_heals=rest_heals, current_gold=current_gold,
            hp_ratio=hp_ratio, specialization=specialization,
            recovery_factor=recovery_factor,
            danger_factor=danger_factor, shop_heals=shop_heals,
            elite_coverage_penalty=elite_coverage_penalty,
            late_elite_penalty=late_elite_penalty,
            development_pressure=development_pressure,
            relic_adjustments=route_relic_modifiers,
            act1_elite_bonus=act1_elite_bonus,
        )
        if (
            act == 1
            and current_floor <= 7
            and hp_ratio >= 0.55
            and development_pressure > 0
            and not act1_elite_offense_ready(gs)
        ):
            combat_distance, _, _ = lament_elite_route_from(full_node, node_map)
            if combat_distance < NO_ELITE_DISTANCE:
                reliable_rewards = max(0, combat_distance - 1)
                reward_gap = max(0, 2 - reliable_rewards)
                health_scale = max(0.0, min(1.0, (hp_ratio - 0.55) / 0.25))
                preparation_penalty = (
                    reward_gap * development_pressure * 10.0 * health_scale
                )
                if preparation_penalty:
                    metrics = (*metrics[:3], metrics[3] - preparation_penalty)
        scored.append((
            i,
            full_node,
            metrics,
        ))

    lament_counter = next(
        (int(relic.get("counter", 0) or 0) for relic in gs.get("relics", []) if relic.get("id") == "NeowsBlessing"),
        0,
    )
    if lament_counter > 0:
        lament_routes = []
        best_normal_value = max(metrics[3] for _, _, metrics in scored)
        for i, node, metrics in scored:
            combat_distance, uncertain_events, floor_distance = lament_elite_route_from(node, node_map)
            charge_risk = min(1, uncertain_events)
            route_is_close = metrics[3] >= best_normal_value - 2.0
            if combat_distance + charge_risk <= lament_counter and route_is_close:
                lament_routes.append(
                    (i, node, metrics, combat_distance, uncertain_events, floor_distance)
                )
        if lament_routes:
            i, node, metrics, combat_distance, uncertain_events, floor_distance = max(
                lament_routes,
                key=lambda x: (-x[3], *route_metric_key(x[2]), -x[5], -x[4]),
            )
            log(
                f"map lament choose {i} node=({node.get('x')},{node.get('y')}) {node.get('symbol')} "
                f"charges={lament_counter} combats={combat_distance} "
                f"events={uncertain_events} floors={floor_distance}"
            )
            return remember_map_choice(gs, i, node)
        fallback_scored = []
        for i, node, metrics in scored:
            combat_distance, uncertain_events, floor_distance = (
                lament_elite_route_from(node, node_map)
            )
            event_risk = min(3, uncertain_events) if combat_distance < NO_ELITE_DISTANCE else 0
            development_bonus = 0.0
            if (
                ascension >= 18
                and act == 1
                and current_floor <= 1
                and hp_ratio >= 0.82
                and metrics[0] >= 1
                and combat_distance == lament_counter + 1
                and 5 <= floor_distance <= 8
                and uncertain_events <= 2
                and metrics[3] >= best_normal_value - 6.0
            ):
                # When Lament falls one fight short, do not overreact by taking
                # a whole Act 1 route with no relic opportunity. At A18+ a
                # healthy starter can collect several rewards and a campfire
                # before this mid-act elite, which is much safer than entering
                # Slime Boss with only Burning Blood and starter-sized output.
                development_bonus = 5.0
            fallback_scored.append((
                metrics[3] - event_risk * 0.6 + development_bonus,
                i, node, metrics, event_risk, development_bonus,
            ))
        _, i, node, metrics, event_risk, development_bonus = max(
            fallback_scored,
            key=lambda x: (x[0], *route_metric_key(x[3])[1:]),
        )
        log(
            f"map lament fallback choose {i} node=({node.get('x')},{node.get('y')}) "
            f"{node.get('symbol')} charges={lament_counter} event_risk={event_risk} "
            f"development_bonus={development_bonus:.1f}"
        )
        return remember_map_choice(gs, i, node)

    critical_safety_threshold = (
        0.62 - recovery_factor ** 2 * 0.40 + danger_factor * 0.08
    )
    has_immediate_rest = rest_heals and any(
        node.get("symbol") == "R" for node in next_nodes
    )
    guaranteed_safe_threshold = (
        0.30
        + (0.05 if act >= 2 else 0.0)
        - recovery_factor * 0.12
        + danger_factor * 0.06
    )

    def is_guaranteed_safe_node(node):
        symbol = node.get("symbol")
        if symbol == "R":
            return rest_heals
        if symbol == "T":
            return True
        if symbol != "$":
            return False
        if not node_immediately_forces_combat(node, node_map):
            return True
        children = [
            node_map.get((child.get("x"), child.get("y")))
            for child in node.get("children", [])
        ]
        # A funded shop before one ordinary hallway still buys an immediate
        # chance to improve a critical run. It is not equivalent to walking
        # into a forced elite, and an unfunded shop cannot provide that bridge.
        return bool(
            current_gold >= 75
            and children
            and all(child and child.get("symbol") == "M" for child in children)
        )

    guaranteed_safe_indexes = {
        i
        for i, node, _ in scored
        if is_guaranteed_safe_node(node)
    }
    has_guaranteed_safe_node = bool(guaranteed_safe_indexes)
    act1_relic_hunt_window = bool(
        act1_elite_bonus > 0
        and raw_hp_ratio >= (
            0.68
            if current_floor <= 2 and nonstarter_attack_count(gs) == 0
            else 0.50
        )
    )
    early_act1_unready_elite = bool(
        bool(gs.get("deck"))
        and act == 1
        and current_floor < 8
        and not act1_elite_offense_ready(gs)
        and not act1_relic_hunt_window
        and any(node.get("symbol") != "E" for node in next_nodes)
    )
    late_act1_elite_threshold = (
        (0.58 if ascension >= 18 else 0.78)
        - recovery_factor * 0.08
        + danger_factor * 0.05
    )
    late_act1_unready_elite = bool(
        act == 1
        and current_floor >= 8
        and hp_ratio < late_act1_elite_threshold
        and not act1_boss_damage_ready(gs)
        and any(node.get("symbol") != "E" for node in next_nodes)
    )
    act3_elite_ready = act3_elite_entry_ready(
        gs,
        specialization=specialization,
        recovery_factor=recovery_factor,
        danger_factor=danger_factor,
    )
    act3_optional_elite_unready = bool(
        act == 3
        and any(node.get("symbol") == "E" for node in next_nodes)
        and any(node.get("symbol") != "E" for node in next_nodes)
        and not act3_elite_ready
    )
    late_act3_optional_elite = bool(
        act == 3
        and current_floor >= 44
        and recovery_factor < 0.35
        and any(node.get("symbol") != "E" for node in next_nodes)
    )
    fragile_act2_hallway_avoidance = bool(
        ascension >= 18
        and act == 2
        and hp_ratio < 0.90
        and recovery_factor < 0.35
        and any(node.get("symbol") == "?" for node in next_nodes)
        and (
            act2_high_output_defense_count(gs) < 2
            or act2_swarm_control_score(gs) < 1.5
        )
    )
    elite_survival_potions = {
        "AttackPotion", "Block Potion", "BloodPotion", "CultistPotion",
        "Dexterity Potion", "EssenceOfSteel", "ExplosivePotion",
        "FairyPotion", "FearPotion", "FirePotion", "GamblersBrew",
        "GhostInAJar", "HeartOfIron", "LiquidMemories", "SpeedPotion",
        "SteroidPotion", "Strength Potion", "Swift Potion", "Weak Potion",
    }
    carried_elite_survival_potion = any(
        normalized_potion_id(potion) in elite_survival_potions
        for potion in gs.get("potions", [])
    )
    strength_reaper_sustain = bool(
        count_deck(gs, {"Reaper"}) > 0
        and dedicated_strength_scaling_source_count(gs) > 0
    )
    strength_reaper_route_buffer = bool(
        strength_reaper_sustain and raw_hp_ratio >= 0.30
    )
    elite_control_score = act2_elite_control_score(gs)
    high_output_defense = act2_high_output_defense_count(gs)
    weak_act2_elite_package = bool(
        high_output_defense < 2
        and elite_control_score < 2.0
    )
    optional_elite_hp_gate = 0.92 if weak_act2_elite_package else 0.82
    act2_optional_elite_unready = bool(
        ascension >= 18
        and act == 2
        and any(node.get("symbol") == "E" for node in next_nodes)
        and any(node.get("symbol") != "E" for node in next_nodes)
        and raw_hp_ratio < optional_elite_hp_gate
        and revive_reserve_hp(gs) <= 0
        and not carried_elite_survival_potion
        and not strength_reaper_route_buffer
        and (
            weak_act2_elite_package
            or act2_swarm_control_score(gs) < 0.85
        )
    )
    forced_elite_route_indexes = {
        i
        for i, node, _ in scored
        if node_forces_elite_within_rooms(node, node_map, max_rooms=6)
    }
    avoidable_forced_elite_indexes = {
        i for i, _, _ in scored if i not in forced_elite_route_indexes
    }
    critical_act2_forced_elite_route_avoidance = bool(
        ascension >= 18
        and act == 2
        and raw_hp_ratio < 0.58
        and revive_reserve_hp(gs) <= 0
        and (weak_act2_elite_package or raw_hp_ratio < 0.35)
        and not strength_reaper_route_buffer
        and forced_elite_route_indexes
        and avoidable_forced_elite_indexes
    )
    act2_forced_elite_approach = bool(
        ascension >= 18
        and act == 2
        and forced_elite_route_indexes
        and len(forced_elite_route_indexes) == len(scored)
        and weak_act2_elite_package
        and revive_reserve_hp(gs) <= 0
        and not strength_reaper_route_buffer
    )

    def map_choice_key(item):
        i, node, metrics = item
        route_key = route_metric_key(metrics)
        immediate_adjustment = immediate_route_adjustment(
            node.get("symbol"), hp_ratio,
            recovery_factor=recovery_factor,
            danger_factor=danger_factor,
            current_gold=current_gold,
            rest_heals=rest_heals,
        )
        adjusted_value = route_key[0] + immediate_adjustment
        if fragile_act2_hallway_avoidance and node.get("symbol") == "M":
            # At A19 the logged 60/72 deck chose Chosen over a question mark by
            # only 0.25 route value, lost 24 HP, and then entered the forced
            # three-Cultist fight at half health. Apply only a small hallway
            # tax: it breaks close ties without overruling a route that reaches
            # recovery before a question-mark lane's forced elite.
            adjusted_value -= 1.50
        if hp_ratio < critical_safety_threshold and has_immediate_rest:
            # Immediate survival is a prerequisite for collecting a route's
            # distant campfires and relics. Strong Reaper recovery lowers this
            # threshold smoothly, while ordinary post-fight healing does not
            # make walking past a currently available campfire sensible.
            symbol = node.get("symbol")
            immediate_safety = 1 if symbol == "R" else 0
            return (immediate_safety, adjusted_value, *route_key[1:])
        if hp_ratio < guaranteed_safe_threshold and has_guaranteed_safe_node:
            # At critical reserve, reaching a shop, campfire, or chest this
            # floor comes before the route's distant value. This remains true
            # when the safe node later feeds into combat: the A17 run chose an
            # immediate Snake Plant over a shop at 17/75 and died before any of
            # the richer route could matter.
            immediate_safety = 1 if i in guaranteed_safe_indexes else 0
            return (immediate_safety, adjusted_value, *route_key[1:])
        if early_act1_unready_elite:
            # High HP alone does not make a starter-damage deck elite-ready.
            immediate_safety = 0 if node.get("symbol") == "E" else 1
            return (immediate_safety, adjusted_value, *route_key[1:])
        if late_act1_unready_elite:
            # One early elite can build tempo. A second, avoidable late-Act-1
            # elite is a poor purchase when the deck still lacks boss damage.
            immediate_safety = 0 if node.get("symbol") == "E" else 1
            return (immediate_safety, adjusted_value, *route_key[1:])
        if act2_forced_elite_approach:
            # When every visible Act 2 lane reaches an elite, the useful choice
            # is how many hallway fights must be paid before that relic fight.
            # The logged A19 run chose a three-combat approach with no control
            # over a two-combat event lane, reached the forced Slavers at 18 HP,
            # and died on the opener. Prefer recovery first, then fewer fights.
            rests, neg_combats, floors = elite_approach_safety(
                node, node_map, rest_heals=rest_heals
            )
            return (
                rests,
                neg_combats,
                adjusted_value,
                floors,
                *route_key[1:],
            )
        if critical_act2_forced_elite_route_avoidance:
            # At 35/75 the A19 status deck took the richer event lane, but every
            # continuation on that lane reached Book of Stabbing within six
            # rooms. A shop lane visibly avoided the elite. Compare complete
            # routes normally only after preserving that escape hatch.
            route_avoids_forced_elite = (
                1 if i in avoidable_forced_elite_indexes else 0
            )
            return (
                route_avoids_forced_elite,
                adjusted_value,
                *route_key[1:],
            )
        if act2_optional_elite_unready:
            # The logged A19 run rested to 62/82, then treated that reserve as
            # permission to enter optional Slavers with no potion, no revive,
            # one heavy block card, and only Cleave for swarm control. Prefer
            # any available non-elite setup room until one of those gaps closes.
            immediate_safety = 0 if node.get("symbol") == "E" else 1
            return (immediate_safety, adjusted_value, *route_key[1:])
        if act3_optional_elite_unready:
            # Batch 20 twice entered Giant Head from floor 39 instead of using
            # an adjacent rest. Both routes still fought an elite afterward,
            # so the non-elite node is a chance to build the HP reserve rather
            # than a blanket elite veto. Strong Reaper recovery lowers both
            # readiness requirements continuously.
            immediate_safety = 0 if node.get("symbol") == "E" else 1
            return (immediate_safety, adjusted_value, *route_key[1:])
        if late_act3_optional_elite:
            # A terminal Act 3 elite has almost no time left to repay its relic
            # reward. Only a proven recovery engine, such as Strength-scaled
            # Reaper, may justify taking it over an available ordinary node.
            immediate_safety = 0 if node.get("symbol") == "E" else 1
            return (immediate_safety, adjusted_value, *route_key[1:])
        if hp_ratio < caution_threshold:
            # Below the dynamic caution line, never let a distant campfire or
            # relic make an immediate elite look safer than another node.
            # Normal fights and noncombat nodes still compare their complete
            # routes, since a hallway leading straight to rest can be safer
            # than an event lane forced into an elite.
            symbol = node.get("symbol")
            immediate_safety = 0 if symbol == "E" else 1
            return (immediate_safety, adjusted_value, *route_key[1:])
        if current_gold < 175:
            return (adjusted_value, *route_key[1:])
        shop_distance = nearest_shop_distance(node, node_map)
        conversion_bonus = shop_conversion_route_bonus(current_gold, shop_distance)
        # Route utility remains decisive. On equivalent routes, convert a full
        # purse into a near-term relic opportunity instead of drifting through
        # another hallway fight.
        return (adjusted_value + conversion_bonus, -shop_distance, *route_key[1:])

    caution_threshold = 0.50 - recovery_factor * 0.18 + danger_factor * 0.12
    i, node, metrics = max(scored, key=map_choice_key)
    elite_count, rest_count, late_monsters, value = metrics
    immediate_adjustment = immediate_route_adjustment(
        node.get("symbol"), hp_ratio,
        recovery_factor=recovery_factor,
        danger_factor=danger_factor,
        current_gold=current_gold,
        rest_heals=rest_heals,
    )
    shop_distance = nearest_shop_distance(node, node_map)
    conversion_bonus = shop_conversion_route_bonus(current_gold, shop_distance)
    log(
        f"map choose {i} node=({node.get('x')},{node.get('y')}) {node.get('symbol')} "
        f"elites={elite_count} rests={rest_count} late_m={late_monsters} "
        f"value={value:.1f} immediate={immediate_adjustment:+.1f} "
        f"adjusted={value + immediate_adjustment:.1f} "
        f"hp={hp_ratio:.2f} raw_hp={raw_hp_ratio:.2f} "
        f"revive_hp={revive_reserve_hp(gs)} specialization={specialization:.2f} "
        f"recovery={recovery_factor:.2f} danger={danger_factor:.2f} "
        f"elite_penalty={elite_coverage_penalty:.1f}/{late_elite_penalty:.1f} "
        f"development={development_pressure:.2f} "
        f"act1_relic_hunt={act1_elite_bonus:.1f} "
        f"relic_route={route_relic_modifiers} "
        f"caution={caution_threshold:.2f} "
        f"fragile_act2_avoid={fragile_act2_hallway_avoidance} "
        f"forced_elite_route_avoid={critical_act2_forced_elite_route_avoidance} "
        f"forced_elite_approach={act2_forced_elite_approach} "
        f"act2_optional_elite_unready={act2_optional_elite_unready} "
        f"act2_elite_control={elite_control_score:.1f} "
        f"act3_elite_ready={act3_elite_ready} "
        f"terminal_elite_guard={late_act3_optional_elite} "
        f"elite_ready={act1_elite_offense_ready(gs)} "
        f"elite_now={elite_route_value(hp_ratio, specialization):.1f} "
        f"gold={current_gold} shop_now={shop_route_value(current_gold, 0):.1f} "
        f"shop_dist={shop_distance} shop_bonus={conversion_bonus:.1f}"
    )
    return remember_map_choice(gs, i, node)


def is_boss_campfire(gs):
    """Return whether the current rest site is the last one before an act boss."""
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    final_rest_floor = {1: 15, 2: 32, 3: 49, 4: 53}.get(act)
    return final_rest_floor is not None and floor >= final_rest_floor


def hexaghost_rest_net_gain(current_hp, max_hp):
    """Estimate HP gained after Hexaghost's six-hit Divider resolves."""
    max_hp = max(1, int(max_hp or 1))
    current_hp = max(0, min(max_hp, int(current_hp or 0)))
    rested_hp = min(max_hp, current_hp + int(max_hp * 0.30))

    def post_divider_hp(hp):
        damage_per_hit = hp // 12 + 1
        return hp - damage_per_hit * 6

    return post_divider_hp(rested_hp) - post_divider_hp(current_hp)


def decide_rest(state, gs):
    choices = gs.get("choice_list", [])
    raw_hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
    # A second life is real combat reserve, but it is discounted at campfires:
    # resting still preserves the revive for a later lethal hit.
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    current_hp = max(0, int(gs.get("current_hp", max_hp) or 0))
    hp_ratio = min(
        1.0,
        (current_hp + campfire_revive_reserve_hp(gs) * 0.65) / max_hp,
    )
    if not choices:
        return "PROCEED" if command_available(state, "proceed") else "STATE"

    profile = archetype_profile(gs)
    specialization = archetype_specialization(gs, profile)
    focused = specialization >= 0.72
    boss_campfire = is_boss_campfire(gs)
    boss_id = upcoming_boss_id(gs)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    late_act1_damage_emergency = (
        act == 1
        and 9 <= floor < 15
        and not act1_boss_damage_ready(gs)
    )

    # v5 thresholds:
    #   normal build: rest below 50%
    #   highly focused build: accept more risk and rest below 40%
    #   final campfire before a boss: rest below 70%
    rest_threshold = 0.70 if boss_campfire else 0.40 if focused else 0.50
    recovery_factor = route_recovery_factor(gs)
    combat_pressure = combat_pressure_before_next_rest(gs)
    danger_factor = route_danger_factor(gs)
    ascension = int(gs.get("ascension_level", 0) or 0)
    defense_shortfall = defensive_package_shortfall(gs)
    forced_elite = ascension >= 4 and forced_elite_before_recovery(gs)
    if boss_campfire and "slimeboss" in boss_id:
        # Slime Boss can turn one weak cleanup cycle into several attackers.
        # Unfocused decks need a larger reserve; mature engines and real
        # sustain continuously buy the threshold back toward the normal 70%.
        slime_threshold = 0.82 - specialization * 0.12 - recovery_factor * 0.08
        if ascension >= 18 and not slime_boss_aoe_ready(gs):
            # Without direct AoE, every extra HP on the split becomes several
            # incoming attacks. Buy one more ten-HP safety band at the final
            # A18+ campfire instead of taking a marginal fifth upgrade.
            slime_threshold += 0.09
        rest_threshold = max(rest_threshold, slime_threshold)
    guardian_cycle_unready = bool(
        defense_shortfall >= 2
        or (
            ascension >= 4
            and (
                nonstarter_defense_count(gs) < 3
                or not act1_boss_damage_ready(gs)
            )
        )
    )
    if boss_campfire and "theguardian" in boss_id and guardian_cycle_unready:
        # v71 smithed at 61/86 with only a modest defensive shell and died
        # while Guardian still had 104 HP. A4+ needs both repeated block and a
        # credible damage plan before 70% HP is treated as enough reserve.
        guardian_threshold = (
            0.80 - specialization * 0.06 - recovery_factor * 0.06
        )
        rest_threshold = max(rest_threshold, guardian_threshold)
    champ_cycle_unready = bool(
        act2_high_output_defense_count(gs) < 1
        or act2_transition_defense_count(gs) < 3
    )
    if boss_campfire and "champ" in boss_id and champ_cycle_unready:
        # Batch 15 smithed at 61/85 because two Fairy potions inflated effective
        # HP, then left Champ at 17 HP. Resting preserves those second lives and
        # buys another full post-Anger turn when the deck lacks a large block.
        champ_threshold = (
            0.80 - specialization * 0.04 - recovery_factor * 0.04
        )
        rest_threshold = max(rest_threshold, champ_threshold)
    if act >= 2 and not focused and not boss_campfire:
        # Act 2 elites can erase a half-health unfocused deck in one bad draw.
        # Reaper permits some aggression, but only discounts the threshold in
        # proportion to its realistic route recovery estimate.
        rest_threshold = max(rest_threshold, 0.58 - recovery_factor * 0.08)
    if ascension >= 4 and act >= 2 and not boss_campfire and combat_pressure >= 2.0:
        # Both A11 floor-31 losses began with a marginal smith immediately
        # before three or four forced Act 2 fights. Price that route attrition
        # at the campfire, while letting real sustain and focus buy back risk.
        pressure_threshold = (
            0.66
            + min(0.10, (combat_pressure - 2.0) * 0.04)
            + danger_factor * 0.04
            - recovery_factor * 0.06
            - min(0.02, specialization * 0.02)
        )
        rest_threshold = max(rest_threshold, pressure_threshold)
    if (
        ascension >= 17
        and act == 2
        and not boss_campfire
        and combat_pressure >= 2.5
    ):
        # The A17 run smithed at 57/85 before three consecutive Act 2 fights,
        # clearing the old threshold by only one percent. Those fights cost
        # 79 HP in total, so reserve another turn of health on dense routes.
        high_ascension_chain_threshold = (
            0.72
            + min(0.06, (combat_pressure - 2.5) * 0.04)
            + danger_factor * 0.04
            - recovery_factor * 0.05
            - min(0.02, specialization * 0.02)
        )
        rest_threshold = max(rest_threshold, high_ascension_chain_threshold)
    if act >= 2 and not boss_campfire and defensive_package_shortfall(gs) >= 2:
        # At 48/80 the logged deck smithed with only Shrug and Impervious as
        # real defense, then paid 28 HP to Gremlin Leader and died next floor.
        # Strong sustain can still buy the threshold back down dynamically.
        rest_threshold = max(rest_threshold, 0.64 - recovery_factor * 0.12)
    if act == 3 and not boss_campfire:
        # Act 3 hallway fights can chain into another hard fight before the
        # next fire. The batch-17 deck smithed at 46/80, then paid 22 HP to
        # Orb Walker and entered Spire Growth at 24 HP. Keep a route reserve
        # that proven sustain and specialization can continuously buy down.
        act3_route_reserve = (
            0.70
            - recovery_factor * 0.10
            - min(0.04, specialization * 0.04)
        )
        rest_threshold = max(rest_threshold, act3_route_reserve)
    if ascension >= 4 and floor >= 6 and defense_shortfall:
        # Offensive specialization cannot substitute for cards that prevent
        # damage. Scale the reserve upward as ascension rises, while allowing
        # proven sustain to buy part of that margin back.
        ascension_reserve = min(0.60, 0.50 + (ascension - 3) * 0.01)
        rest_threshold = max(
            rest_threshold,
            ascension_reserve - recovery_factor * 0.08,
        )
    if forced_elite:
        # A smith at 55/80 looked barely legal by the generic 68% threshold,
        # but the map had no recovery branch before Lagavulin. Keep a dynamic
        # reserve for that known bill while still crediting sustain and focus.
        unready_act1_elite = act == 1 and not act1_elite_offense_ready(gs)
        unready_act2_elite = (
            act == 2 and route_combat_specialization(gs, profile) < 0.55
        )
        if unready_act2_elite:
            insect_discount = 0.04 if any(
                relic.get("id") == "PreservedInsect"
                for relic in gs.get("relics", [])
            ) else 0.0
            elite_reserve = (
                0.88
                - recovery_factor * 0.06
                - min(0.03, specialization * 0.03)
                - insect_discount
            )
        else:
            elite_reserve = (
                (0.84 if act >= 3 else 0.82 if unready_act1_elite else 0.74)
                - recovery_factor * 0.08
                - min(0.04, specialization * 0.04)
            )
        rest_threshold = max(rest_threshold, elite_reserve)
    if (
        ascension >= 10
        and act == 1
        and forced_elite
        and combat_pressure >= 3.0
    ):
        # A15 smithed at 51/68 before Lagavulin, a hallway and a forced Nob.
        # Those fights cost 53 HP and every potion, leaving Hexaghost at 80 HP.
        # Price the complete chain rather than only the first elite.
        elite_chain_reserve = (
            0.84
            - recovery_factor * 0.06
            - min(0.03, specialization * 0.03)
        )
        rest_threshold = max(rest_threshold, elite_chain_reserve)
    if late_act1_damage_emergency:
        # A weak late-Act-1 deck often has another elite or hard hallway before
        # the final fire. Preserve enough HP to reach that last upgrade/rest.
        rest_threshold = max(rest_threshold, 0.68)

    revive_raw_floor = (
        0.58
        - recovery_factor * 0.10
        - min(0.04, specialization * 0.04)
        + min(0.04, combat_pressure * 0.02)
    )
    if _relic_ids(gs) & {"RegalPillow", "Regal Pillow"}:
        revive_raw_floor += 0.04
    preserve_revive = bool(
        act >= 2
        and not boss_campfire
        and campfire_revive_reserve_hp(gs) > 0
        and raw_hp_ratio < revive_raw_floor
    )

    before_hexaghost = boss_campfire and "hexaghost" in boss_id
    if before_hexaghost and "rest" in choices:
        net_gain = hexaghost_rest_net_gain(gs.get("current_hp"), gs.get("max_hp"))
        if hp_ratio < rest_threshold or net_gain >= 8:
            log(
                f"rest choose heal before Hexaghost hp={hp_ratio:.2f} "
                f"net_post_divider_gain={net_gain} specialization={specialization:.2f}"
            )
            return f"CHOOSE {choices.index('rest')}"

    if "rest" in choices and (
        hp_ratio < rest_threshold
        or boss_campfire and raw_hp_ratio < rest_threshold
        or preserve_revive
    ):
        log(
            f"rest choose heal hp={hp_ratio:.2f} raw_hp={raw_hp_ratio:.2f} revive_hp={revive_reserve_hp(gs)} threshold={rest_threshold:.2f} "
            f"boss_campfire={boss_campfire} specialization={specialization:.2f} "
            f"recovery={recovery_factor:.2f} combat_pressure={combat_pressure:.2f} "
            f"forced_elite={forced_elite} preserve_revive={preserve_revive} "
            f"revive_raw_floor={revive_raw_floor:.2f}"
        )
        return f"CHOOSE {choices.index('rest')}"

    if before_hexaghost and "smith" in choices:
        log(
            f"rest choose smith before Hexaghost hp={hp_ratio:.2f} "
            f"net_post_divider_gain="
            f"{hexaghost_rest_net_gain(gs.get('current_hp'), gs.get('max_hp'))} "
            f"specialization={specialization:.2f}"
        )
        return f"CHOOSE {choices.index('smith')}"

    normalized_choices = [str(choice).strip().lower() for choice in choices]
    special_rest_actions = {
        action for action in ("lift", "toke", "dig")
        if action in normalized_choices
    }
    if special_rest_actions:
        action_scores = {}
        if "smith" in normalized_choices:
            action_scores["smith"] = max(
                (
                    upgrade_card_score(card, gs, profile)
                    for card in gs.get("deck", [])
                    if int(card.get("upgrades", 0) or 0) <= 0
                ),
                default=20,
            )
        if "lift" in special_rest_actions and relic_counter(gs, "Girya", 0) < 3:
            strength_focus = profile.get("scores", {}).get("strength", 0)
            action_scores["lift"] = (
                70
                + min(18, strength_focus * 2)
                + min(9, strength_payoff_count(gs) * 3)
            )
        if "toke" in special_rest_actions:
            purge_value = max(
                (
                    purge_card_score(card, gs, profile)
                    for card in gs.get("deck", [])
                ),
                default=0,
            )
            action_scores["toke"] = 48 + max(0, purge_value) * 0.45
        if "dig" in special_rest_actions:
            dig_score = 68 if act <= 2 else 62
            if boss_campfire and (
                not long_boss_damage_ready(gs)
                or defensive_package_shortfall(gs) >= 2
            ):
                dig_score -= 18
            action_scores["dig"] = dig_score
        if action_scores:
            action = max(action_scores, key=action_scores.get)
            log(
                "rest relic action "
                f"scores={{{', '.join(f'{key}:{value:.1f}' for key, value in action_scores.items())}}} "
                f"decision={action} hp={hp_ratio:.2f}"
            )
            return f"CHOOSE {normalized_choices.index(action)}"

    if "smith" in choices:
        log(
            f"rest choose smith hp={hp_ratio:.2f} raw_hp={raw_hp_ratio:.2f} revive_hp={revive_reserve_hp(gs)} threshold={rest_threshold:.2f} "
            f"boss_campfire={boss_campfire} specialization={specialization:.2f} "
            f"recovery={recovery_factor:.2f} combat_pressure={combat_pressure:.2f} "
            f"forced_elite={forced_elite}"
        )
        return f"CHOOSE {choices.index('smith')}"
    return "CHOOSE 0"


def upgrade_card_score(card, gs, profile=None):
    profile = profile or archetype_profile(gs)
    cid = card_id(card)
    score = (
        UPGRADE_PRIORITY.get(cid, CARD_SCORES.get(cid, 20))
        + archetype_card_bonus(card, gs, profile) * 0.5
    )
    if cid in {"Evolve", "Fire Breathing"}:
        fuel = status_source_count(gs)
        if cid == "Fire Breathing":
            fuel += persistent_curse_count(gs)
        if fuel == 0:
            # The first payoff may sensibly speculate on enemy statuses, but a
            # scarce campfire upgrade must improve a card that works in every
            # upcoming fight until permanent fuel joins the deck.
            score -= 45
        elif cid == "Evolve" and fuel == 1:
            # One Wild Strike is enough to keep Evolve draftable, but not
            # enough for its upgrade to displace a large repeatable damage
            # upgrade immediately before Hexaghost.
            score -= 20
    return score


def _headbutt_future_card(raw_card, next_energy, relic_ids):
    """Rebuild a draw-pile card as it will be playable next turn."""
    future = dict(raw_card)
    cid = card_id(future)
    card_type = future.get("type") or ""
    try:
        cost = int(future.get("cost", 0) or 0)
    except (TypeError, ValueError):
        cost = 0
    future["cost"] = cost
    if card_type in {"ATTACK", "SKILL", "POWER"}:
        future["is_playable"] = cost < 0 or cost <= next_energy
    elif card_type == "STATUS":
        future["is_playable"] = cid == "Slimed" and cost <= next_energy
    elif card_type == "CURSE":
        future["is_playable"] = "Blue Candle" in relic_ids and cost <= next_energy
    else:
        future["is_playable"] = False
    future.setdefault("has_target", card_type == "ATTACK")
    future.setdefault("exhausts", False)
    future.setdefault("upgrades", 0)
    future.setdefault("uuid", f"headbutt-{cid}-{id(raw_card)}")
    return future


def _headbutt_future_monsters(combat, relic_ids):
    """Project deterministic enemy state that resets before the next draw."""
    projected_monsters = []
    for raw_monster in combat.get("monsters") or []:
        projected = dict(raw_monster)
        if (
            (raw_monster.get("id") or raw_monster.get("name")) == "Transient"
            and "ATTACK" in str(raw_monster.get("intent") or "")
        ):
            powers = [dict(power) for power in raw_monster.get("powers") or []]
            current_strength = sum(
                int(power.get("amount", 0) or 0)
                for power in powers
                if power.get("id") == "Strength"
            )
            current_shackled = sum(
                max(0, int(power.get("amount", 0) or 0))
                for power in powers
                if power.get("id") == "Shackled"
            )
            persistent_strength = current_strength + current_shackled
            try:
                current_base_damage = int(
                    raw_monster.get("move_base_damage", 0) or 0
                )
            except (TypeError, ValueError):
                current_base_damage = 0
            if current_base_damage <= 0:
                current_base_damage = max(
                    0,
                    int(raw_monster.get("move_adjusted_damage", 0) or 0)
                    - current_strength,
                )

            # Shifting restores all damage-based temporary Strength loss after
            # the attack, then Transient's next hit gains ten base damage.
            # Mercury Hourglass immediately applies three fresh Shifting block
            # at the start of the next turn.
            passive_damage = 3 if "Mercury Hourglass" in relic_ids else 0
            next_base_damage = current_base_damage + 10
            next_strength = persistent_strength - passive_damage
            projected["move_base_damage"] = next_base_damage
            projected["move_adjusted_damage"] = max(
                0, next_base_damage + next_strength
            )
            next_powers = []
            for power in powers:
                power_id = power.get("id")
                if power_id in {"Strength", "Shackled"}:
                    continue
                if power_id == "Fading":
                    power["amount"] = max(
                        0, int(power.get("amount", 0) or 0) - 1
                    )
                next_powers.append(power)
            if next_strength:
                next_powers.append({"id": "Strength", "amount": next_strength})
            if passive_damage:
                next_powers.append({"id": "Shackled", "amount": passive_damage})
            projected["powers"] = next_powers
        projected_monsters.append(projected)
    return projected_monsters


def headbutt_return_score(candidate, gs):
    """Score a Headbutt target by planning the fully known next draw window."""
    fallback = CARD_SCORES.get(
        card_id(candidate), 25 if candidate.get("type") == "ATTACK" else 10
    )
    combat = gs.get("combat_state") or {}
    try:
        current_model = build_model(combat, gs)
        next_energy = max(0, current_model.next_turn_energy)
        relic_ids = {
            relic.get("id") or relic.get("name")
            for relic in gs.get("relics", [])
        }
        draw_pile = list(combat.get("draw_pile") or [])
        natural_count = min(4, len(draw_pile))
        natural_draw = list(reversed(draw_pile[-natural_count:]))
        source_uuid = candidate.get("uuid")
        future_candidate = _headbutt_future_card(
            candidate, next_energy, relic_ids
        )
        future_hand = [future_candidate]
        future_hand.extend(
            _headbutt_future_card(raw, next_energy, relic_ids)
            for raw in natural_draw
        )

        candidate_uuid = future_candidate.get("uuid")
        candidate_removed = False
        future_discard = []
        for raw in combat.get("discard_pile") or []:
            same_card = (
                bool(source_uuid) and raw.get("uuid") == source_uuid
            ) or (
                not source_uuid
                and not candidate_removed
                and card_id(raw) == card_id(candidate)
                and int(raw.get("upgrades", 0) or 0)
                == int(candidate.get("upgrades", 0) or 0)
            )
            if same_card and not candidate_removed:
                candidate_removed = True
                continue
            future_discard.append(raw)

        future_combat = dict(combat)
        future_player = dict(combat.get("player") or {})
        future_player["energy"] = next_energy
        future_player["block"] = 0
        future_combat["player"] = future_player
        future_combat["hand"] = future_hand
        future_combat["draw_pile"] = (
            draw_pile[:-natural_count] if natural_count else draw_pile
        )
        future_combat["discard_pile"] = future_discard
        future_combat["monsters"] = _headbutt_future_monsters(
            combat, relic_ids
        )
        future_combat["turn"] = int(combat.get("turn", 0) or 0) + 1

        plan = plan_turn(future_combat, gs)
        model = build_model(future_combat, gs)
        planned_initial = model
        initial_enemy_total = sum(
            monster.hp + monster.block for monster in model.monsters
        )
        candidate_played = False
        for command in plan.commands:
            if command == "END":
                break
            parts = command.split()
            hand_index = int(parts[1]) - 1
            played = model.hand[hand_index]
            candidate_played = candidate_played or played.uuid == candidate_uuid
            target_index = None
            if len(parts) >= 3:
                original_target = int(parts[2])
                target_index = next(
                    index
                    for index, monster in enumerate(model.monsters)
                    if monster.original_index == original_target
                )
            model = simulate_card(model, hand_index, target_index)

        enemy_total = sum(
            monster.hp + monster.block
            for monster in model.monsters
            if monster.alive
        )
        progress = initial_enemy_total - enemy_total
        lethal = bool(model.monsters) and all(
            not monster.alive for monster in model.monsters
        )
        survives = plan.hp_loss < current_model.hp + current_model.revive_hp
        collector_swarm_control = 0
        alive_torches = [
            monster
            for monster in planned_initial.monsters
            if monster.alive and monster.monster_id == "TorchHead"
        ]
        if (
            candidate_played
            and survives
            and current_model.turn >= 4
            and len(alive_torches) >= 2
            and any(
                monster.alive and monster.monster_id == "TheCollector"
                for monster in planned_initial.monsters
            )
            and current_model.hp + current_model.revive_hp - plan.hp_loss
            >= max(18, int(current_model.max_hp * 0.22))
        ):
            after_by_index = {
                monster.original_index: monster for monster in model.monsters
            }
            torch_progress = 0
            torch_kills = 0
            for before in alive_torches:
                after = after_by_index.get(before.original_index)
                if after is None:
                    continue
                torch_progress += max(
                    0,
                    before.hp + before.block - after.hp - after.block,
                )
                torch_kills += int(not after.alive)
            # On the logged turn, returning one Defend saved five HP but left
            # two full Torch Heads alive. Returning Immolate put both in lethal
            # range and exposed a next-turn Collector kill.
            collector_swarm_control = torch_kills * 120 + torch_progress * 2
        setup_value = model.scaling + model.draw_value - model.future_risk
        return (
            int(survives),
            int(lethal),
            collector_swarm_control,
            -plan.hp_loss,
            progress,
            int(candidate_played),
            setup_value,
            int(candidate.get("upgrades", 0) or 0),
            fallback,
        )
    except (IndexError, StopIteration, TypeError, ValueError):
        return (
            0, 0, 0, -999, 0, 0, 0,
            int(candidate.get("upgrades", 0) or 0), fallback,
        )


def bottled_lightning_card_score(card):
    """Prefer reliable opening draw over conditional bottled skills."""
    cid = card_id(card)
    base = CARD_SCORES.get(cid, 10)
    draw_bonus = setup_draw_count(card) * 20
    conditional_penalty = 28 if cid == "Spot Weakness" else 0
    zero_cost_bonus = 5 if card_cost(card) == 0 else 0
    return base + draw_bonus + zero_cost_bonus - conditional_penalty


def decide_grid(state, gs):
    global GRID_SELECT_MODE
    ss = gs.get("screen_state") or {}
    if ss.get("confirm_up"):
        GRID_SELECT_MODE = None
        return "PROCEED" if command_available(state, "proceed") else "CHOOSE 0"
    cards = ss.get("cards", [])
    selected = ss.get("selected_cards", [])
    needed = int(ss.get("num_cards", 1) or 1)
    if len(selected) >= needed:
        GRID_SELECT_MODE = None
        return "PROCEED" if command_available(state, "proceed") else "CHOOSE 0"
    if not cards:
        return "STATE"
    selected_uuids = {card.get("uuid") for card in selected if card.get("uuid")}
    candidates = [(i, card) for i, card in enumerate(cards) if card.get("uuid") not in selected_uuids]
    if not candidates:
        return "PROCEED" if command_available(state, "proceed") else "STATE"
    relic_ids = {relic.get("id") or relic.get("name") for relic in gs.get("relics", [])}
    is_astrolabe_transform = (
        "Astrolabe" in relic_ids
        and needed == 3
        and gs.get("room_type") == "TreasureRoomBoss"
    )
    is_bottled_lightning_pick = (
        "Bottled Lightning" in relic_ids
        and needed == 1
        and not selected
        and not ss.get("for_purge")
        and not ss.get("for_transform")
        and not ss.get("for_upgrade")
        and GRID_SELECT_MODE is None
        and all(card.get("type") == "SKILL" for _, card in candidates)
    )
    is_library_pick = bool(
        GRID_SELECT_MODE is None
        and needed == 1
        and not selected
        and "EventRoom" in str(gs.get("room_type") or "")
        and len(cards) >= 10
        and not ss.get("for_purge")
        and not ss.get("for_transform")
        and not ss.get("for_upgrade")
    )
    if (
        ss.get("for_purge") or ss.get("for_transform")
        or ss.get("for_upgrade") or is_astrolabe_transform
    ):
        # Explicit live screen semantics outrank a Headbutt/Exhume hint left
        # behind when a killing blow skipped its combat selection prompt.
        GRID_SELECT_MODE = None
    profile = archetype_profile(gs)
    if GRID_SELECT_MODE == "exhume":
        combat = gs.get("combat_state") or {}
        ranked = []
        for i, candidate in candidates:
            try:
                score = exhume_card_score(candidate, combat, gs)
            except Exception:
                score = (
                    (),
                    0,
                    CARD_SCORES.get(
                        card_id(candidate),
                        25 if candidate.get("type") == "ATTACK" else 10,
                    ),
                    0,
                )
            ranked.append((i, candidate, score))
    elif GRID_SELECT_MODE == "headbutt":
        ranked = [
            (i, candidate, headbutt_return_score(candidate, gs))
            for i, candidate in candidates
        ]
    elif GRID_SELECT_MODE == "liquid_memories":
        combat = gs.get("combat_state") or {}
        ranked = [
            (i, c, liquid_memories_candidate_score(c, combat, gs))
            for i, c in candidates
        ]
    elif GRID_SELECT_MODE == "secret_weapon":
        combat = gs.get("combat_state") or {}
        ranked = [
            (i, c, secret_weapon_card_score(c, combat, gs))
            for i, c in candidates
            if c.get("type") == "ATTACK"
        ]
        if not ranked:
            GRID_SELECT_MODE = None
            return "STATE"
    elif is_bottled_lightning_pick:
        ranked = [
            (i, c, bottled_lightning_card_score(c))
            for i, c in candidates
        ]
    elif is_library_pick:
        contextual = [
            (i, c, card_reward_score(c, gs))
            for i, c in candidates
        ]
        eligible = [
            item
            for item in contextual
            if reward_archetype_compatibility(item[1], gs, profile)[
                "compatible"
            ]
        ]
        ranked = eligible or contextual
    elif ss.get("for_upgrade"):
        ranked = [
            (
                i,
                c,
                upgrade_card_score(c, gs, profile),
            )
            for i, c in candidates
        ]
    elif GRID_SELECT_MODE == "duplicate":
        ranked = [(i, c, duplicate_card_score(c, gs, profile)) for i, c in candidates]
    elif ss.get("for_purge") or GRID_SELECT_MODE == "purge" or ss.get("for_transform") or is_astrolabe_transform:
        ranked = [(i, c, purge_card_score(c, gs, profile)) for i, c in candidates]
    else:
        ranked = [(i, c, CARD_SCORES.get(card_id(c), 25 if c.get("type") == "ATTACK" else 10)) for i, c in candidates]
    i, _, _ = max(ranked, key=lambda x: x[2])
    if GRID_SELECT_MODE == "exhume":
        log(f"exhume retrieve card={card_id(cards[i])}")
    elif GRID_SELECT_MODE == "headbutt":
        selected_score = next(score for index, _, score in ranked if index == i)
        log(
            f"headbutt retrieve card={card_id(cards[i])} "
            f"score={selected_score}"
        )
    elif GRID_SELECT_MODE == "secret_weapon":
        selected_score = next(score for index, _, score in ranked if index == i)
        log(
            f"secret weapon retrieve card={card_id(cards[i])} "
            f"score={selected_score}"
        )
    elif is_library_pick:
        selected_score = next(score for index, _, score in ranked if index == i)
        selected_fit = reward_archetype_compatibility(
            cards[i], gs, profile
        )["reason"]
        log(
            f"library choose card={card_id(cards[i])} "
            f"score={selected_score} fit={selected_fit}"
        )
    GRID_SELECT_MODE = None
    return f"CHOOSE {i}"


def decide_hand_select(state, gs):
    global HAND_SELECT_MODE
    ss = gs.get("screen_state") or {}
    hand = ss.get("hand", [])
    selected = ss.get("selected", [])
    max_cards = int(ss.get("max_cards", 1) or 1)
    junk_ids = {"AscendersBane", "Burn", "Dazed", "Slimed", "Void", "Wound", "Clumsy", "Injury", "Doubt", "Shame", "Necronomicurse"}

    def finish_selection():
        available = {
            str(command).lower() for command in state.get("available_commands", [])
        }
        if available.intersection({"proceed", "继续"}):
            return "PROCEED"
        if available.intersection({"confirm", "确认"}):
            return "CONFIRM"
        return "STATE"

    if (
        isinstance(HAND_SELECT_MODE, dict)
        and HAND_SELECT_MODE.get("kind") == "dual_wield"
    ):
        if len(selected) >= max_cards or not hand:
            HAND_SELECT_MODE = None
            return finish_selection()
        desired_uuid = HAND_SELECT_MODE.get("uuid")
        matching = [
            index
            for index, candidate in enumerate(hand)
            if candidate.get("uuid") == desired_uuid
        ]
        if not matching:
            matching = [
                index
                for index, candidate in enumerate(hand)
                if card_id(candidate) == HAND_SELECT_MODE.get("card_id")
                and candidate.get("type") == HAND_SELECT_MODE.get("card_type")
                and int(candidate.get("upgrades", 0) or 0)
                == HAND_SELECT_MODE.get("upgrades")
            ]
        if not matching:
            matching = [
                index
                for index, candidate in enumerate(hand)
                if candidate.get("type") in {"ATTACK", "POWER"}
            ]
        if matching:
            chosen = matching[0]
            log(
                "dual wield copy target "
                f"card={card_id(hand[chosen])} index={chosen}"
            )
            HAND_SELECT_MODE = None
            return f"CHOOSE {chosen}"
        HAND_SELECT_MODE = None
        return finish_selection()

    if (
        HAND_SELECT_MODE is None
        and str(gs.get("current_action") or "")
        in {"ExhaustAction", "ExhaustSpecificCardAction"}
        and (max_cards <= 1 or not ss.get("can_pick_zero"))
    ):
        # Recover the selection context if the bot is restarted after playing
        # Burning Pact or True Grit+ but before their hand prompt is answered.
        # Optional multi-card prompts belong to Elixir and should instead use
        # the generic junk-only selection below.
        HAND_SELECT_MODE = "exhaust_one"
    if (
        isinstance(HAND_SELECT_MODE, dict)
        and HAND_SELECT_MODE.get("kind") == "gamblers_brew_exact"
    ):
        if len(selected) >= max_cards or not hand:
            HAND_SELECT_MODE = None
            return finish_selection()

        remaining_keys = list(HAND_SELECT_MODE.get("discard_keys") or [])
        for selected_card in selected:
            selected_key = _gamblers_brew_card_key(selected_card)
            if selected_key in remaining_keys:
                remaining_keys.remove(selected_key)
        if not remaining_keys:
            log(
                "gamblers brew exact keep cards="
                f"{[card_id(card) for card in hand]}"
            )
            HAND_SELECT_MODE = None
            return finish_selection()

        for index, card in enumerate(hand):
            if _gamblers_brew_card_key(card) in remaining_keys:
                log(f"gamblers brew exact discard card={card_id(card)}")
                return f"CHOOSE {index}"

        log(
            "gamblers brew exact targets unavailable keep cards="
            f"{[card_id(card) for card in hand]}"
        )
        HAND_SELECT_MODE = None
        return finish_selection()
    if HAND_SELECT_MODE in {"gamblers_brew", "gamblers_brew_all"}:
        if len(selected) >= max_cards or not hand:
            HAND_SELECT_MODE = None
            return finish_selection()

        if HAND_SELECT_MODE == "gamblers_brew_all":
            log(f"gamblers brew full discard card={card_id(hand[0])}")
            return "CHOOSE 0"

        combat = gs.get("combat_state") or {}
        player = combat.get("player") or {}
        energy = int(player.get("energy", 0) or 0)
        current_block = int(player.get("block", 0) or 0)
        current_hp = int(
            player.get("current_hp", gs.get("current_hp", 1)) or 1
        )
        urgent_pressure = (
            incoming_damage(combat) - current_block
            >= max(8, current_hp - 1)
        )
        active_power_ids = {
            power.get("id") or power.get("name")
            for power in player.get("powers", [])
            if int(power.get("amount", 0) or 0) != 0
        }
        has_attack = any(
            card.get("type") == "ATTACK" and card_cost(card) <= energy
            for card in hand
        )

        protected = set()
        if urgent_pressure:
            for index, card in enumerate(hand):
                cid = card_id(card)
                immediate_defense = (
                    cid in DRAW_ORDER_BLOCK_CARDS
                    or cid in DRAW_ORDER_CONTROL_CARDS
                    or cid == "Rage" and has_attack
                )
                if immediate_defense and card_cost(card) <= energy:
                    protected.add(index)

        def gamblers_discard_score(index, card):
            cid = card_id(card)
            if index in protected:
                return -1000
            if cid in junk_ids or card.get("type") in {"STATUS", "CURSE"}:
                return 1000
            if cid in {"Barricade", "Corruption"} and cid in active_power_ids:
                return 900
            if card_cost(card) > energy:
                return 600
            if card.get("type") == "ATTACK":
                return 300
            if card.get("type") == "POWER":
                return 180
            return 120

        ranked = [
            (i, card, gamblers_discard_score(i, card))
            for i, card in enumerate(hand)
        ]
        i, card, score = max(ranked, key=lambda item: item[2])
        if score > 0:
            log(
                "gamblers brew discard "
                f"card={card_id(card)} protected="
                f"{[card_id(hand[index]) for index in sorted(protected)]}"
            )
            return f"CHOOSE {i}"

        log(f"gamblers brew keep survival cards={[card_id(card) for card in hand]}")
        HAND_SELECT_MODE = None
        return finish_selection()
    if HAND_SELECT_MODE == "upgrade_one":
        if len(selected) >= max_cards:
            HAND_SELECT_MODE = None
            return finish_selection()
        if not hand:
            HAND_SELECT_MODE = None
            return finish_selection()

        combat = gs.get("combat_state") or {}
        player = combat.get("player") or {}
        current_block = int(player.get("block", 0) or 0)
        current_hp = int(
            player.get("current_hp", gs.get("current_hp", 1)) or 1
        )
        energy = int(player.get("energy", 0) or 0)
        unblocked = max(0, incoming_damage(combat) - current_block)
        urgent_block_pressure = unblocked >= max(10, int(current_hp * 0.25))

        def tactical_upgrade_score(card):
            cid = card_id(card)
            upgraded = dict(card)
            upgraded["upgrades"] = int(card.get("upgrades", 0) or 0) + 1
            base_score = UPGRADE_PRIORITY.get(cid, 35 if card.get("type") == "POWER" else 25)
            block_before = estimate_block(card, current_block)
            block_after = estimate_block(upgraded, current_block)
            block_gain = max(0, block_after - block_before)
            damage_gain = max(
                0,
                estimate_damage(upgraded, energy, current_block)
                - estimate_damage(card, energy, current_block),
            )
            affordable = int(card.get("cost", 0) or 0) <= energy
            score = base_score + damage_gain * 2
            if urgent_block_pressure and affordable and block_after > 0:
                # Armaments already spent one energy and supplied five Block.
                # Under a large live attack, improve the card that buys the
                # most of the current turn instead of blindly upgrading Strike.
                score += 100 + min(unblocked, block_after) * 3 + block_gain * 12
            elif affordable:
                score += block_gain * 4
            return score

        i, _, _ = max(
            (
                (i, card, tactical_upgrade_score(card))
                for i, card in enumerate(hand)
            ),
            key=lambda item: item[2],
        )
        return f"CHOOSE {i}"
    if HAND_SELECT_MODE == "exhaust_one":
        if len(selected) >= max_cards:
            HAND_SELECT_MODE = None
            return finish_selection()
        if not hand:
            HAND_SELECT_MODE = None
            return finish_selection()

        combat = gs.get("combat_state") or {}
        player = combat.get("player") or {}
        current_block = int(player.get("block", 0) or 0)
        current_hp = int(
            player.get("current_hp", gs.get("current_hp", 1)) or 1
        )
        unblocked = max(0, incoming_damage(combat) - current_block)
        urgent_block_pressure = unblocked >= max(10, int(current_hp * 0.25))
        live_block_cards = [
            card for card in hand if card_id(card) in DRAW_ORDER_BLOCK_CARDS
        ]
        protected_block_card = (
            live_block_cards[0]
            if urgent_block_pressure and len(live_block_cards) == 1
            else None
        )
        deck_attacks = sum(1 for card in gs.get("deck", []) if card.get("type") == "ATTACK")
        exhausted_attacks = sum(1 for card in combat.get("exhaust_pile", []) if card.get("type") == "ATTACK")
        if deck_attacks:
            remaining_attacks = max(0, deck_attacks - exhausted_attacks)
        else:
            remaining_attacks = sum(
                1
                for pile in (hand, combat.get("draw_pile", []), combat.get("discard_pile", []))
                for card in pile
                if card.get("type") == "ATTACK"
            )
        strength_payoff_ready = bool(
            combat_player_power_amount(gs, "Strength") > 0
            or any(
                card_id(deck_card) in {
                    "Demon Form", "Inflame", "Limit Break", "Rupture",
                    "Spot Weakness",
                }
                for deck_card in gs.get("deck", [])
            )
        )

        def exhaust_score(card):
            cid = card_id(card)
            if cid in junk_ids or card.get("type") in {"STATUS", "CURSE"}:
                return 1000
            if cid == "Sentinel":
                return 120
            if card is protected_block_card:
                return -300
            if cid == "Defend_R":
                return 90
            if card.get("type") == "ATTACK":
                if remaining_attacks <= MIN_EXHAUST_ATTACK_CORE:
                    return -200
                if cid == "Heavy Blade" and strength_payoff_ready:
                    # CARD_SCORES intentionally keeps an unsupported Heavy
                    # Blade modest for rewards. That number must not make the
                    # live exhaust prompt delete a Strength deck's payoff.
                    return -160
                if cid == "Strike_R":
                    return 95
                return max(0, 55 - CARD_SCORES.get(cid, 35) * 0.5)
            return 70 - CARD_SCORES.get(cid, 30) * 0.5

        i, _, _ = max(
            ((i, card, exhaust_score(card)) for i, card in enumerate(hand)),
            key=lambda item: item[2],
        )
        return f"CHOOSE {i}"
    if len(selected) >= max_cards:
        return finish_selection()
    if not hand:
        return finish_selection()
    def hand_select_score(card):
        cid = card_id(card)
        if cid in junk_ids or card.get("type") in {"STATUS", "CURSE"}:
            return 100
        if cid == "Strike_R":
            return 35
        if cid == "Defend_R":
            return 25
        return 10

    ranked = [(i, c, hand_select_score(c)) for i, c in enumerate(hand)]
    i, _, score = max(ranked, key=lambda x: x[2])
    if ss.get("can_pick_zero") and score < 80:
        return finish_selection()
    return f"CHOOSE {i}"


def reset_match_game(session=None):
    global MATCH_GAME_SESSION, MATCH_GAME_MEMORY, MATCH_GAME_MATCHED
    global MATCH_GAME_FIRST, MATCH_GAME_SECOND, MATCH_GAME_NEEDS_WAIT
    global MATCH_GAME_VOID_PAIR, MATCH_GAME_ATTEMPTED_PAIRS, MATCH_GAME_PICK_COUNTS
    MATCH_GAME_SESSION = session
    MATCH_GAME_MEMORY = {}
    MATCH_GAME_MATCHED = set()
    MATCH_GAME_FIRST = None
    MATCH_GAME_SECOND = None
    MATCH_GAME_NEEDS_WAIT = False
    MATCH_GAME_VOID_PAIR = None
    MATCH_GAME_ATTEMPTED_PAIRS = set()
    MATCH_GAME_PICK_COUNTS = {}


def begin_new_run_session():
    """Reset event memory that must never leak into a restarted run."""
    global RUN_SESSION_SERIAL, LAST_MAP_NODE, LAST_POLICY_ATTEMPT
    global HAND_SELECT_MODE, GRID_SELECT_MODE
    global SMOKE_BOMB_ESCAPE_PENDING
    global COMBAT_RELIC_MEMORY_KEY, COMBAT_RELIC_MEMORY
    RUN_SESSION_SERIAL += 1
    LAST_MAP_NODE = None
    LAST_POLICY_ATTEMPT = None
    HAND_SELECT_MODE = None
    GRID_SELECT_MODE = None
    SMOKE_BOMB_ESCAPE_PENDING = None
    COMBAT_RELIC_MEMORY_KEY = None
    COMBAT_RELIC_MEMORY = {}
    reset_match_game()


def match_game_pair_key(first, second):
    return tuple(sorted((int(first), int(second))))


def match_game_mark_pick(slot):
    MATCH_GAME_PICK_COUNTS[slot] = MATCH_GAME_PICK_COUNTS.get(slot, 0) + 1


def match_game_remember_visible(positions, labels):
    """Store revealed cards against their immutable 0-11 board positions."""
    for slot, label in zip(positions, labels):
        if match_game_slot(label) is not None:
            continue
        # A visible name proves this original position has already been flipped,
        # including after a process reload or in a backend frame we did not see.
        MATCH_GAME_PICK_COUNTS.setdefault(slot, 1)
        if MATCH_GAME_MEMORY.get(slot) == label:
            continue
        MATCH_GAME_MEMORY[slot] = label
        log(f"match game remember original_slot={slot} card={label}")


def match_game_untried_partner(first_slot, candidates):
    untried = [
        slot for slot in candidates
        if match_game_pair_key(first_slot, slot) not in MATCH_GAME_ATTEMPTED_PAIRS
    ]
    pool = untried or list(candidates)
    if not pool:
        return None
    return min(pool, key=lambda slot: (MATCH_GAME_PICK_COUNTS.get(slot, 0), slot))


def match_game_slot(label):
    match = re.fullmatch(r"card(\d+)", str(label).strip().lower())
    return int(match.group(1)) if match else None


def match_game_card_score(card_name, gs=None):
    normalized = re.sub(r"[^a-z0-9]", "", str(card_name).lower())
    if normalized in MATCH_GAME_CURSES:
        return -1000
    card_name_key = match_game_card_id(card_name)
    if card_name_key is not None:
        if gs is not None:
            # Match and Keep rewards are permanent cards.  Use the same
            # contextual score as a normal reward so an undeveloped deck can
            # recognize high-value archetype foundations instead of treating
            # every unknown-direction pair as disposable.
            return card_reward_score(
                {"id": card_name_key, "type": "UNKNOWN", "upgrades": 0}, gs
            )
        return CARD_SCORES.get(card_name_key, 30)
    return 30


def match_game_card_id(card_name):
    normalized = re.sub(r"[^a-z0-9]", "", str(card_name).lower())
    candidates = set(CARD_ARCHETYPE_SCORES) | set(CARD_SCORES) | set(UNIVERSAL_REWARD_CARDS)
    candidate_by_name = {
        re.sub(r"[^a-z0-9]", "", candidate.lower()): candidate
        for candidate in candidates
    }
    if normalized in candidate_by_name:
        return candidate_by_name[normalized]
    # Some CommunicationMod builds expose upgraded event cards as names such as
    # ``Inflame+1``.  Non-alphanumeric cleanup turns that into ``inflame1``;
    # remove only a trailing upgrade number and retry.
    without_upgrade = re.sub(r"\d+$", "", normalized)
    return candidate_by_name.get(without_upgrade)


def match_game_card_wanted(card_name, gs):
    """Use reward quality while allowing a directionless deck to develop."""
    normalized = re.sub(r"[^a-z0-9]", "", str(card_name).lower())
    if normalized in MATCH_GAME_CURSES:
        return False
    cid = match_game_card_id(card_name)
    profile = archetype_profile(gs)
    threshold = card_reward_skip_threshold(gs, profile)
    if cid is None:
        return (
            not profile.get("current_archetypes")
            and match_game_card_score(card_name, gs) >= threshold
        )

    card = {"id": cid, "type": "UNKNOWN", "upgrades": 0}
    contextual_score = card_reward_score(card, gs)
    if not profile.get("current_archetypes"):
        affinity = card_archetype_affinity(card)
        peak = max(affinity.values(), default=0)
        is_core = any(cid in ARCHETYPE_CORE_CARDS.get(name, set()) for name in ARCHETYPES)
        developmental_value = (
            is_core
            or peak >= 6
            or cid in UNIVERSAL_REWARD_CARDS
            or CARD_SCORES.get(cid, 0) >= 65
        )
        # With no established archetype, a free high-scoring foundation is a
        # chance to create the build, not a reason to abandon the whole event.
        return developmental_value and contextual_score >= threshold

    fit = reward_archetype_compatibility(card, gs, profile)
    return fit["compatible"] and contextual_score >= threshold


def match_game_known_void_pair(remaining_slots, gs, allow_attempted=False):
    """Find a remembered unwanted mismatch that can safely consume one try."""
    unwanted = [
        slot
        for slot in remaining_slots
        if MATCH_GAME_MEMORY.get(slot) is not None
        and not match_game_card_wanted(MATCH_GAME_MEMORY[slot], gs)
    ]
    for index, first in enumerate(unwanted):
        for second in unwanted[index + 1:]:
            pair_key = match_game_pair_key(first, second)
            if pair_key in MATCH_GAME_ATTEMPTED_PAIRS and not allow_attempted:
                continue
            if MATCH_GAME_MEMORY[first] != MATCH_GAME_MEMORY[second]:
                return first, second
    return None


def match_game_direct_void_command(state, remaining_slots, gs):
    """Leave an entirely unwanted revealed board when the backend permits it."""
    if not remaining_slots or any(slot not in MATCH_GAME_MEMORY for slot in remaining_slots):
        return None
    if any(match_game_card_wanted(MATCH_GAME_MEMORY[slot], gs) for slot in remaining_slots):
        return None
    if command_available(state, "return"):
        return "RETURN"
    if command_available(state, "proceed"):
        return "PROCEED"
    return None


def decide_match_game(state, gs):
    global MATCH_GAME_FIRST, MATCH_GAME_SECOND, MATCH_GAME_NEEDS_WAIT
    global MATCH_GAME_VOID_PAIR

    legacy_session = (gs.get("seed"), gs.get("act"), gs.get("floor"))
    session = (RUN_SESSION_SERIAL, *legacy_session)
    # Keep compatibility with manually seeded tests and old in-memory states,
    # while all real restarted runs use the run serial to prevent stale board
    # memory from leaking into an early Match and Keep event of the next run.
    if MATCH_GAME_SESSION not in {session, legacy_session}:
        reset_match_game(session)

    choices = [str(choice).strip().lower() for choice in gs.get("choice_list", [])]
    hidden_slots = [slot for slot in (match_game_slot(choice) for choice in choices) if slot is not None]
    is_board = bool(
        len(choices) > 1
        or hidden_slots
        or MATCH_GAME_MEMORY
        or MATCH_GAME_FIRST is not None
        or MATCH_GAME_SECOND is not None
    )
    if not is_board or len(choices) <= 1:
        if choices:
            return "CHOOSE 0"
        if command_available(state, "proceed"):
            return "PROCEED"
        return "STATE"

    remaining_slots = [slot for slot in range(12) if slot not in MATCH_GAME_MATCHED]

    if MATCH_GAME_SECOND is not None:
        attempted_first = MATCH_GAME_FIRST
        attempted_second = MATCH_GAME_SECOND
        if attempted_first is not None and attempted_second is not None:
            attempted_key = match_game_pair_key(attempted_first, attempted_second)
            MATCH_GAME_ATTEMPTED_PAIRS.add(attempted_key)
            # A deliberately mismatched void pair is useful only once. v71
            # kept the lock after a mismatch and selected the same two slots
            # again on the following attempt.
            if (
                MATCH_GAME_VOID_PAIR
                and attempted_key == match_game_pair_key(*MATCH_GAME_VOID_PAIR)
            ):
                MATCH_GAME_VOID_PAIR = None
        if len(choices) == len(remaining_slots):
            match_game_remember_visible(remaining_slots, choices)
        first_name = MATCH_GAME_MEMORY.get(MATCH_GAME_FIRST)
        second_name = MATCH_GAME_MEMORY.get(MATCH_GAME_SECOND)
        pair_removed = len(choices) == len(remaining_slots) - 2
        if pair_removed or first_name is not None and first_name == second_name:
            MATCH_GAME_MATCHED.update({MATCH_GAME_FIRST, MATCH_GAME_SECOND})
            if MATCH_GAME_VOID_PAIR and set(MATCH_GAME_VOID_PAIR) & MATCH_GAME_MATCHED:
                MATCH_GAME_VOID_PAIR = None
        MATCH_GAME_FIRST = None
        MATCH_GAME_SECOND = None
        MATCH_GAME_NEEDS_WAIT = True
        return "WAIT 30" if command_available(state, "wait") else "STATE"

    if MATCH_GAME_NEEDS_WAIT:
        MATCH_GAME_NEEDS_WAIT = False
        remaining_slots = [slot for slot in range(12) if slot not in MATCH_GAME_MATCHED]

    if MATCH_GAME_FIRST is not None:
        pickable_slots = [slot for slot in remaining_slots if slot != MATCH_GAME_FIRST]
        if len(choices) != len(pickable_slots):
            return "WAIT 30" if command_available(state, "wait") else "STATE"
        match_game_remember_visible(pickable_slots, choices)

        first_name = MATCH_GAME_MEMORY.get(MATCH_GAME_FIRST)
        known_different = [
            slot
            for slot in pickable_slots
            if MATCH_GAME_MEMORY.get(slot) is not None
            and MATCH_GAME_MEMORY.get(slot) != first_name
            and match_game_pair_key(MATCH_GAME_FIRST, slot)
            not in MATCH_GAME_ATTEMPTED_PAIRS
        ]
        first_wanted = first_name is not None and match_game_card_wanted(first_name, gs)
        known_mates = [
            slot
            for slot in pickable_slots
            if first_name is not None
            and first_wanted
            and MATCH_GAME_MEMORY.get(slot) == first_name
            and match_game_pair_key(MATCH_GAME_FIRST, slot)
            not in MATCH_GAME_ATTEMPTED_PAIRS
        ]
        unprobed = [
            slot for slot in pickable_slots
            if MATCH_GAME_PICK_COUNTS.get(slot, 0) == 0
        ]
        locked_void_target = None
        if MATCH_GAME_VOID_PAIR and MATCH_GAME_FIRST in MATCH_GAME_VOID_PAIR:
            locked_void_target = next(
                (
                    slot
                    for slot in MATCH_GAME_VOID_PAIR
                    if slot != MATCH_GAME_FIRST and slot in pickable_slots
                ),
                None,
            )
        if known_mates:
            # A remembered, archetype-compatible pair is always worth claiming,
            # even though both positions were necessarily probed before.
            target_slot = known_mates[0]
        elif locked_void_target is not None:
            # On the final attempt, complete the known mismatch selected below.
            # Blindly probing its partner can accidentally add an unwanted pair.
            target_slot = locked_void_target
        elif unprobed:
            # While scouting, never spend another flip on an old position. This
            # exposes up to ten distinct cards in the event's five attempts.
            target_slot = min(unprobed)
        elif first_name is not None and not first_wanted and known_different:
            # A curse or off-archetype card is deliberately mismatched against
            # a known different card. Exploring another hidden slot could
            # accidentally add an unwanted pair to the permanent deck.
            target_slot = known_different[0]
        else:
            different = [slot for slot in pickable_slots if MATCH_GAME_MEMORY.get(slot) != first_name]
            target_slot = match_game_untried_partner(
                MATCH_GAME_FIRST, different or pickable_slots
            )
        MATCH_GAME_SECOND = target_slot
        match_game_mark_pick(target_slot)
        log(
            f"match game second original_slot={target_slot} choice_index="
            f"{pickable_slots.index(target_slot)} first={MATCH_GAME_FIRST} "
            f"known={first_name is not None}"
        )
        return f"CHOOSE {pickable_slots.index(target_slot)}"

    if len(choices) != len(remaining_slots):
        return "WAIT 30" if command_available(state, "wait") else "STATE"
    match_game_remember_visible(remaining_slots, choices)

    known_pairs = []
    names = {}
    for slot in remaining_slots:
        name = MATCH_GAME_MEMORY.get(slot)
        if name is not None:
            names.setdefault(name, []).append(slot)
    for name, slots in names.items():
        if len(slots) >= 2 and match_game_card_wanted(name, gs):
            for index, first in enumerate(slots):
                for second in slots[index + 1:]:
                    if (
                        match_game_pair_key(first, second)
                        in MATCH_GAME_ATTEMPTED_PAIRS
                    ):
                        continue
                    known_pairs.append(
                        (match_game_card_score(name, gs), first, second)
                    )

    unprobed = [
        slot for slot in remaining_slots
        if MATCH_GAME_PICK_COUNTS.get(slot, 0) == 0
    ]
    known_wanted = [
        slot
        for slot in remaining_slots
        if MATCH_GAME_MEMORY.get(slot) is not None
        and match_game_card_wanted(MATCH_GAME_MEMORY[slot], gs)
    ]
    safe_void_pair = None
    if unprobed and not known_wanted:
        # Once the first blind pair has revealed only a curse/off-build card and
        # another unwanted card, two more unknown flips can accidentally add a
        # permanent curse. Reuse the known mismatch to void the event instead.
        # Repeated positions here are deliberate disposal, not fresh probing.
        safe_void_pair = match_game_known_void_pair(
            remaining_slots, gs, allow_attempted=True
        )
    final_attempt_void_pair = None
    if len(MATCH_GAME_ATTEMPTED_PAIRS) >= 4:
        final_attempt_void_pair = match_game_known_void_pair(remaining_slots, gs)

    if known_pairs:
        MATCH_GAME_VOID_PAIR = None
        _, target_slot, _ = max(known_pairs)
    elif unprobed and known_wanted:
        # Probe only one unknown position per attempt, anchored to a remembered
        # card the current build actually wants. An accidental match is then a
        # wanted reward rather than a curse or unrelated permanent card.
        MATCH_GAME_VOID_PAIR = None
        target_slot = max(
            known_wanted,
            key=lambda slot: (
                match_game_card_score(MATCH_GAME_MEMORY[slot], gs), -slot
            ),
        )
        log(
            "match game safe probe anchor "
            f"slot={target_slot} card={MATCH_GAME_MEMORY[target_slot]}"
        )
    elif final_attempt_void_pair is not None:
        # There is no sixth attempt on which newly discovered information can
        # be used. Spend the last try on a known mismatch instead of risking an
        # automatic off-build pair from two unseen positions.
        MATCH_GAME_VOID_PAIR = final_attempt_void_pair
        target_slot = MATCH_GAME_VOID_PAIR[0]
        log(
            "match game final attempt void by mismatching "
            f"{MATCH_GAME_MEMORY[MATCH_GAME_VOID_PAIR[0]]}/"
            f"{MATCH_GAME_MEMORY[MATCH_GAME_VOID_PAIR[1]]}"
        )
    elif safe_void_pair is not None:
        MATCH_GAME_VOID_PAIR = safe_void_pair
        target_slot = safe_void_pair[0]
        log(
            "match game early void by reusing mismatch "
            f"{MATCH_GAME_MEMORY[safe_void_pair[0]]}/"
            f"{MATCH_GAME_MEMORY[safe_void_pair[1]]}"
        )
    elif unprobed:
        # Exploration outranks the old deliberate-mismatch policy. Reusing a
        # known off-build position before all twelve slots have been considered
        # throws away information and can hide a valuable pair.
        MATCH_GAME_VOID_PAIR = None
        target_slot = min(unprobed)
    else:
        direct_void = match_game_direct_void_command(state, remaining_slots, gs)
        if direct_void:
            log("match game void: no curse-free archetype-compatible pair")
            return direct_void
        known_wanted = [
            slot
            for slot in remaining_slots
            if MATCH_GAME_MEMORY.get(slot) is not None
            and match_game_card_wanted(MATCH_GAME_MEMORY[slot], gs)
        ]
        if known_wanted:
            MATCH_GAME_VOID_PAIR = None
        elif MATCH_GAME_VOID_PAIR is None:
            MATCH_GAME_VOID_PAIR = match_game_known_void_pair(remaining_slots, gs)
            if MATCH_GAME_VOID_PAIR:
                log(
                    "match game void by mismatching "
                    f"{MATCH_GAME_MEMORY[MATCH_GAME_VOID_PAIR[0]]}/"
                    f"{MATCH_GAME_MEMORY[MATCH_GAME_VOID_PAIR[1]]}"
                )
        if MATCH_GAME_VOID_PAIR:
            target_slot = MATCH_GAME_VOID_PAIR[0]
        else:
            unwanted_known = [
                slot
                for slot in remaining_slots
                if MATCH_GAME_MEMORY.get(slot) is not None
                and not match_game_card_wanted(MATCH_GAME_MEMORY[slot], gs)
                and any(
                    MATCH_GAME_MEMORY.get(other) is not None
                    and MATCH_GAME_MEMORY.get(other) != MATCH_GAME_MEMORY.get(slot)
                    and match_game_pair_key(slot, other) not in MATCH_GAME_ATTEMPTED_PAIRS
                    for other in remaining_slots
                    if other != slot
                )
            ]
            if unwanted_known:
                # Once every slot has been explored, deliberately mismatch two
                # off-build cards rather than accepting an unwanted pair.
                target_slot = unwanted_known[0]
            else:
                target_slot = min(
                    remaining_slots,
                    key=lambda slot: (MATCH_GAME_PICK_COUNTS.get(slot, 0), slot),
                )
    MATCH_GAME_FIRST = target_slot
    match_game_mark_pick(target_slot)
    log(
        f"match game first original_slot={target_slot} choice_index="
        f"{remaining_slots.index(target_slot)} remembered={target_slot in MATCH_GAME_MEMORY}"
    )
    return f"CHOOSE {remaining_slots.index(target_slot)}"


def event_option_text(option):
    return " ".join(
        str(option.get(field) or "")
        for field in ("text", "label")
    ).strip().lower()


def neow_option_score(option, gs, option_count=4):
    """Score Neow's opening rewards instead of selecting a fixed list index."""
    text = event_option_text(option)
    compact = re.sub(r"\s+", " ", text)
    has_relic = "relic" in compact or "遗物" in compact
    boss_swap = has_relic and (
        "boss relic" in compact
        or "首领遗物" in compact
        or "初始遗物" in compact
        or "starting relic" in compact
    )
    rare_relic = has_relic and (
        "rare relic" in compact or "稀有遗物" in compact
    )
    common_relic = has_relic and (
        "common relic" in compact or "普通遗物" in compact
    )
    lament = bool(
        (
            ("first 3" in compact or "first three" in compact)
            and "1 hp" in compact
        )
        or (
            ("前3" in compact or "前三" in compact or "3场" in compact)
            and "1" in compact
            and ("生命" in compact or "血" in compact)
        )
        or "three_enemy_kill" in compact
    )

    if rare_relic:
        score, reason = 96.0, "rare_relic"
    elif common_relic:
        score, reason = 90.0, "common_relic"
    elif boss_swap:
        # Burning Blood is dependable, so a blind swap remains below a known
        # rare/common relic. It still beats a temporary Lament at A18+, where
        # the user's training objective explicitly accepts Act 1 variance for
        # permanent high-ascension power.
        score = 86.0 if int(gs.get("ascension_level", 0) or 0) >= 18 else 72.0
        reason = "boss_relic_swap"
    elif has_relic:
        score, reason = 84.0, "relic"
    elif lament:
        score = 66.0 if int(option_count or 0) <= 2 else 58.0
        reason = "neows_lament"
    elif (
        ("rare" in compact or "稀有" in compact)
        and ("card" in compact or "牌" in compact)
    ):
        score, reason = 80.0, "rare_card"
    elif "remove" in compact or "移除" in compact:
        score, reason = 72.0, "remove_card"
    elif "transform" in compact or "变化" in compact or "转换" in compact:
        score, reason = 70.0, "transform_card"
    elif "upgrade" in compact or "升级" in compact:
        score, reason = 64.0, "upgrade_card"
    elif "gold" in compact or "金币" in compact:
        score = 76.0 if "250" in compact else 64.0
        reason = "gold"
    elif "max hp" in compact or "最大生命" in compact:
        score, reason = 52.0, "max_hp"
    elif "potion" in compact or "药水" in compact:
        score, reason = 48.0, "potions"
    elif "card" in compact or "牌" in compact:
        score, reason = 54.0, "card"
    else:
        score, reason = 0.0, "unknown"

    relic_ids = _relic_ids(gs)
    curse_cost = "curse" in compact or "诅咒" in compact
    if curse_cost and not omamori_blocks_next_curse(gs):
        score -= 18.0
    if (
        ("lose" in compact or "失去" in compact)
        and ("max hp" in compact or "最大生命" in compact)
    ):
        score -= 16.0
    if (
        ("take" in compact and "damage" in compact)
        or ("受到" in compact and "伤害" in compact)
    ):
        score -= 10.0
    if (
        ("lose all" in compact and "gold" in compact)
        or "失去所有金币" in compact
    ):
        score -= 12.0
    elif ("lose" in compact and "gold" in compact) or "失去金币" in compact:
        score -= 6.0
    if reason == "boss_relic_swap" and "Black Blood" in relic_ids:
        score -= 8.0
    return score, reason


def event_paid_cost_kind(option):
    """Rank supported question-mark reward costs by the user's preference."""
    text = event_option_text(option)
    compact = re.sub(r"\s+", " ", text)
    max_hp_loss_patterns = (
        r"\b(?:lose|reduce|sacrifice)\b[^.!?;,，。！？；]{0,32}"
        r"\b(?:max(?:imum)?\s+(?:hp|health))\b",
        r"\b(?:max(?:imum)?\s+(?:hp|health))\b[^.!?;,，。！？；]{0,24}"
        r"\b(?:is\s+)?(?:lost|reduced)\b",
        r"(?:失去|损失|降低|减少)[^,，。！？；]{0,20}(?:最大生命值|最大生命)",
        r"(?:最大生命值|最大生命)[^,，。！？；]{0,16}(?:损失|降低|减少)",
    )
    curse_terms = ("curse", "cursed", "诅咒")
    if any(
        re.search(pattern, compact, re.IGNORECASE)
        for pattern in max_hp_loss_patterns
    ):
        return 0, "max_hp"
    if any(term in compact for term in curse_terms):
        return 2, "curse"
    # Do not classify "lose gold" or other generic payment text as HP loss.
    # CommunicationMod commonly emits forms such as "Lose 18 HP", "Take 12
    # Damage", or their Chinese equivalents.
    hp_patterns = (
        r"\blose\b.{0,24}\b\d+\s*(?:hp|health)\b",
        r"\b(?:take|suffer)\b.{0,24}\b\d+\s*(?:damage|hp)\b",
        r"\blose\s+(?:hp|health)\b",
        r"(?:失去|损失|扣除).{0,12}\d+.{0,6}(?:生命值|生命|点血|hp)",
        r"(?:受到|承受).{0,12}\d+.{0,6}(?:伤害|点伤害)",
    )
    if any(re.search(pattern, compact, re.IGNORECASE) for pattern in hp_patterns):
        return 1, "hp"
    return None


def preferred_paid_event_choice(options, enabled):
    ranked = []
    for fallback_index, option in enumerate(options):
        choice_index = option.get("choice_index", fallback_index)
        if option.get("disabled") or choice_index not in enabled:
            continue
        cost = event_paid_cost_kind(option)
        if cost is not None:
            ranked.append((cost[0], choice_index, cost[1]))
    # Only override generic event logic when the event genuinely presents a
    # choice between at least two supported paid costs. Refuse/leave choices
    # remain governed by their dedicated safety rules.
    if len(ranked) < 2 or len({item[0] for item in ranked}) < 2:
        return None
    return min(ranked, key=lambda item: (item[0], item[1]))


def forgotten_altar_choice(options, enabled, gs):
    """Choose between the altar's HP sacrifice and Decay dynamically."""
    if len(enabled) < 2:
        return None

    option_by_index = {
        option.get("choice_index", fallback_index): option
        for fallback_index, option in enumerate(options)
        if not option.get("disabled")
    }
    relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
    if "Golden Idol" in relic_ids and len(enabled) >= 3:
        # The first altar option trades Golden Idol for Bloody Idol. It has no
        # HP/curse marker, so the generic two-cost comparison used to ignore
        # it and take Decay at low HP. Prefer the unique unpriced option while
        # the required relic is present.
        offer_choices = [
            choice_index
            for choice_index in enabled
            if event_paid_cost_kind(option_by_index.get(choice_index, {})) is None
        ]
        if offer_choices:
            log("forgotten altar choose=golden_idol_offer")
            return offer_choices[0]
    hp_choices = [
        choice_index
        for choice_index in enabled
        if event_paid_cost_kind(option_by_index.get(choice_index, {})) == (1, "hp")
    ]
    curse_choices = [
        choice_index
        for choice_index in enabled
        if event_paid_cost_kind(option_by_index.get(choice_index, {})) == (2, "curse")
    ]
    sacrifice_index = hp_choices[0] if hp_choices else enabled[0]
    curse_index = curse_choices[0] if curse_choices else enabled[-1]
    sacrifice_text = event_option_text(option_by_index.get(sacrifice_index, {}))

    hp_loss_patterns = (
        r"\b(?:lose|take|suffer)\b[^.!?;,，。！？；]{0,16}?(\d+)"
        r"\s*(?:hp|health|damage)\b",
        r"(?:失去|损失|扣除|受到|承受)\s*(\d+)\s*点?\s*"
        r"(?:生命值|生命|点血|hp|伤害)",
    )
    max_hp_gain_patterns = (
        r"\bgain\b[^.!?;,，。！？；]{0,12}?(\d+)\s*"
        r"(?:max(?:imum)?\s+(?:hp|health))\b",
        r"(?:获得|增加)\s*(\d+)\s*点?\s*(?:最大生命值|最大生命)",
    )

    def first_amount(patterns, default):
        for pattern in patterns:
            match = re.search(pattern, sacrifice_text, re.IGNORECASE)
            if match:
                return int(match.group(1))
        return default

    hp_loss = first_amount(hp_loss_patterns, 20)
    max_hp_gain = first_amount(max_hp_gain_patterns, 5)
    hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    # Gaining max HP also raises current HP, so compare the real post-event
    # reserve rather than understating both the sacrifice and its denominator.
    projected_hp = max(0, hp - hp_loss + max_hp_gain)
    projected_max_hp = max_hp + max_hp_gain
    recovery = route_recovery_factor(gs)
    danger = route_danger_factor(gs)
    reserve_ratio = 0.55 - recovery * 0.08 + danger * 0.08
    if (
        int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
        and recovery < 0.30
    ):
        # The sacrifice is a 28-point net current-HP loss. Without dependable
        # sustain, preserve enough life for Act 2 hallways and the boss.
        reserve_ratio = max(reserve_ratio, 0.68)
    forced_elite_next = immediate_next_room_is_forced(gs, "E")
    if forced_elite_next:
        # Reaper is only prospective recovery; it cannot justify entering an
        # unavoidable Book of Stabbing fight at half health. Preserve a real
        # pre-combat reserve when no room exists between the event and elite.
        reserve_ratio = max(
            reserve_ratio,
            0.68 if int(gs.get("ascension_level", 0) or 0) >= 17 else 0.62,
        )
    curse_friendly = (
        curse_retention_value(gs) >= 25
        or "Omamori" in relic_ids
    )
    choose_curse = (
        curse_friendly
        or projected_hp < 24
        or projected_hp / max(1, projected_max_hp) < reserve_ratio
    )
    log(
        f"forgotten altar choose={'curse' if choose_curse else 'sacrifice'} "
        f"projected_hp={projected_hp}/{projected_max_hp} "
        f"reserve={reserve_ratio:.2f} recovery={recovery:.2f} "
        f"curse_friendly={curse_friendly} forced_elite_next={forced_elite_next}"
    )
    return curse_index if choose_curse else sacrifice_index


def falling_option_card(option, deck):
    """Return the concrete card named by one Falling event option."""
    text = " ".join(
        str(option.get(field) or "") for field in ("text", "label")
    ).lower()
    matches = []
    for card in deck:
        labels = {
            str(card.get("name") or "").strip(),
            str(card_id(card) or "").strip(),
        }
        for label in labels:
            if label and label.lower() in text:
                matches.append((len(label), card))
    return max(matches, key=lambda item: item[0])[1] if matches else None


def falling_card_keep_value(card, gs, profile=None):
    """Value preserving a card when Falling forces one of three losses."""
    cid = card_id(card)
    profile = profile or archetype_profile(gs)
    value = CARD_SCORES.get(cid, 25 if card.get("type") == "ATTACK" else 18)
    value += archetype_card_bonus(card, gs, profile)
    value += 8 * min(1, int(card.get("upgrades", 0) or 0))
    if cid in ARCHETYPE_CORE_CARDS.get(profile.get("leader"), set()):
        value += 12
    if cid in {"Impervious", "Disarm", "Shockwave", "Flame Barrier"}:
        value += 8 * max(1, defensive_package_shortfall(gs))
    return value


def preferred_falling_choice(options, enabled, gs):
    """Choose the least harmful of Falling's shown Skill/Power/Attack losses."""
    profile = archetype_profile(gs)
    candidates = []
    for fallback_index, option in enumerate(options):
        choice_index = option.get("choice_index", fallback_index)
        if option.get("disabled") or choice_index not in enabled:
            continue
        card = falling_option_card(option, gs.get("deck", []))
        if card is not None:
            candidates.append(
                (falling_card_keep_value(card, gs, profile), choice_index, card_id(card))
            )
    return min(candidates, key=lambda item: (item[0], item[1])) if candidates else None


def cursed_tome_elite_lookahead(gs):
    """Look farther ahead for high-ascension Act 2 Tome commitments."""
    return 3 if (
        int(gs.get("ascension_level", 0) or 0) >= 18
        and int(gs.get("act", 1) or 1) == 2
    ) else 2


def cursed_tome_reserve_ratio(gs):
    """Return the HP reserve required after paying the Tome's full cost."""
    current = remembered_current_map_node(gs)
    node_map = {
        (node.get("x"), node.get("y")): node
        for node in gs.get("map", [])
    }
    forced_combat = bool(
        current is not None
        and node_immediately_forces_combat(current, node_map)
    )
    forced_elite_soon = forced_elite_within_rooms(
        gs, max_rooms=cursed_tome_elite_lookahead(gs),
    )
    reserve = (
        0.47
        + (0.15 if forced_elite_soon else 0.11 if forced_combat else 0.0)
        + (0.02 if int(gs.get("act", 1) or 1) >= 2 else 0.0)
        + route_danger_factor(gs) * 0.06
        - route_recovery_factor(gs) * 0.08
    )
    if defensive_package_count(gs) < 3:
        reserve += 0.04
    return max(0.40, min(0.66, reserve)), forced_combat


def cursed_tome_choice(options, enabled, gs):
    """Read the Tome only when its complete HP bill preserves the route."""
    if len(enabled) <= 1:
        return enabled[0]

    option_by_index = {
        option.get("choice_index", fallback_index): option
        for fallback_index, option in enumerate(options)
        if not option.get("disabled")
    }
    costs = {}
    for choice_index in enabled:
        numbers = [
            int(value)
            for value in re.findall(
                r"\d+",
                event_option_text(option_by_index.get(choice_index, {})),
            )
        ]
        if numbers:
            costs[choice_index] = max(numbers)

    hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    reserve, forced_combat = cursed_tome_reserve_ratio(gs)
    forced_elite_soon = forced_elite_within_rooms(
        gs, max_rooms=cursed_tome_elite_lookahead(gs),
    )

    if len(costs) >= 2 and max(costs.values()) >= 10:
        continue_index = max(costs, key=lambda index: (costs[index], -index))
        stop_index = min(costs, key=lambda index: (costs[index], index))
        projected_hp = hp - costs[continue_index]
        keep_reading = projected_hp / max_hp >= reserve
        choice_index = continue_index if keep_reading else stop_index
        log(
            f"cursed tome final continue={keep_reading} "
            f"projected_hp={projected_hp}/{max_hp} reserve={reserve:.2f} "
            f"forced_combat={forced_combat} forced_elite_soon={forced_elite_soon}"
        )
        return choice_index

    # A15 raises the final payment from 10 to 15 HP. Budget every page before
    # entering the mandatory sequence, including that higher final bill.
    full_cost = 21 if int(gs.get("ascension_level", 0) or 0) >= 15 else 16
    projected_hp = hp - full_cost
    read_tome = projected_hp / max_hp >= reserve
    choice_index = enabled[0] if read_tome else enabled[-1]
    log(
        f"cursed tome read={read_tome} projected_hp={projected_hp}/{max_hp} "
        f"reserve={reserve:.2f} forced_combat={forced_combat} "
        f"forced_elite_soon={forced_elite_soon}"
    )
    return choice_index


def mind_bloom_choice(enabled, gs):
    """Balance the Act 3 boss fight against upgrades and the Normality offer."""
    war_index = 0 if 0 in enabled else None
    awake_index = 1 if 1 in enabled else None
    rich_index = 2 if 2 in enabled else None
    hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    hp_ratio = hp / max_hp
    ascension = int(gs.get("ascension_level", 0) or 0)
    upgradeable = sum(
        card.get("type") in {"ATTACK", "SKILL", "POWER"}
        and int(card.get("upgrades", 0) or 0) <= 0
        for card in gs.get("deck", [])
    )
    omamori_charges = relic_counter(gs, "Omamori")
    normalities = 2 if ascension >= 15 else 1
    rich_is_clean = rich_index is not None and omamori_charges >= normalities
    relic_ids = _relic_ids(gs)
    healing_assets = len(
        relic_ids
        & {
            "Bird Faced Urn", "Black Blood", "Blood Vial", "Bloody Idol",
            "Burning Blood", "Eternal Feather", "Meal Ticket", "MealTicket",
            "Meat on the Bone", "Toy Ornithopter",
        }
    ) + int(count_deck(gs, {"Reaper"}) > 0)
    recurring_self_damage = count_deck(
        gs, {"Bloodletting", "Brutality", "Combust", "Hemokinesis", "Pain"}
    )
    revive_reserve = revive_reserve_hp(gs)
    mark_sustain_trap = bool(
        "Coffee Dripper" in relic_ids
        and healing_assets > 0
        and (healing_assets >= 2 or recurring_self_damage > 0)
    )
    sustain_war_ready = bool(
        mark_sustain_trap
        and war_index is not None
        and hp_ratio >= 0.60
        and long_boss_damage_ready(gs)
        and defensive_package_shortfall(gs) <= 1
    )
    boss_control_ready = bool(
        act2_high_output_defense_count(gs) >= 1
        or count_deck(gs, {"Disarm"}) >= 2
        or relic_ids
        & {
            "FossilizedHelix", "Fossilized Helix", "Torii",
            "TungstenRod", "Tungsten Rod",
        }
    )
    healthy_sustain_war_ready = bool(
        war_index is not None
        and hp_ratio >= 0.85
        and healing_assets > 0
        and long_boss_damage_ready(gs)
        and boss_control_ready
    )
    war_ready = bool(
        war_index is not None
        and hp_ratio >= 0.72
        and long_boss_damage_ready(gs)
        and act2_high_output_defense_count(gs) >= 1
        and defensive_package_shortfall(gs) <= 1
    )
    mark_hp_floor = 0.98 if ascension >= 20 else 0.95 if ascension >= 17 else 0.92
    mark_upgrade_ready = bool(
        awake_index is not None
        and hp_ratio >= mark_hp_floor
        and upgradeable >= (16 if ascension >= 20 else 12)
        and healing_assets == 0
        and revive_reserve == 0
        and recurring_self_damage == 0
        and boss_control_ready
        and defensive_package_shortfall(gs) <= 1
        and (long_boss_damage_ready(gs) or upgradeable >= 18)
    )

    if rich_is_clean:
        choice_index = rich_index
        reason = "clean_rich"
    elif sustain_war_ready:
        # With Coffee Dripper, Mark of the Bloom removes every remaining route
        # back to usable HP. The logged A17 deck also blanked Burning Blood and
        # Meat on the Bone while recurring self-damage kept draining it. Take
        # the finite Act 1 boss fight when the deck can close it instead.
        choice_index = war_index
        reason = "avoid_coffee_mark_sustain_trap"
    elif healthy_sustain_war_ready:
        # Mark permanently blanks the recovery that makes a healthy Act 3 route
        # durable. With a concrete boss clock plus either strong mitigation or
        # repeated Strength reduction, pay the finite Act 1 fight instead.
        choice_index = war_index
        reason = "healthy_preserve_sustain"
    elif war_ready:
        choice_index = war_index
        reason = "healthy_war"
    elif mark_upgrade_ready:
        # Mark of the Bloom is permanent and also disables Reaper, campfires,
        # Burning Blood, Fairy in a Bottle, and Lizard Tail. Only trade all
        # future recovery for upgrades from a nearly full, self-sufficient run.
        choice_index = awake_index
        reason = "near_full_no_recovery_mass_upgrade"
    elif rich_index is not None and hp_ratio < 0.35:
        choice_index = rich_index
        reason = "critical_avoid_combat"
    elif war_index is not None:
        choice_index = war_index
        reason = "war_fallback"
    elif awake_index is not None:
        choice_index = awake_index
        reason = "awake_fallback"
    else:
        choice_index = enabled[0]
        reason = "enabled_fallback"

    log(
        f"mind bloom choose={choice_index} reason={reason} hp={hp}/{max_hp} "
        f"upgradeable={upgradeable} war_ready={war_ready} "
        f"mark_ready={mark_upgrade_ready} mark_hp_floor={mark_hp_floor:.2f} "
        f"sustain_war_ready={sustain_war_ready} healing_assets={healing_assets} "
        f"revive_reserve={revive_reserve} self_damage={recurring_self_damage} "
        f"omamori={omamori_charges}/{normalities}"
    )
    return choice_index


def sensory_stone_choice(enabled, gs):
    """Choose the largest memory count that preserves a usable HP reserve."""
    hp = max(0, int(gs.get("current_hp", 0) or 0))
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    relic_ids = _relic_ids(gs)
    healing_locked = bool(
        "Coffee Dripper" in relic_ids or relic_ids & MARK_OF_BLOOM_IDS
    )
    reserve_ratio = 0.48 if healing_locked else 0.30
    reserve_hp = max(28 if healing_locked else 18, int(max_hp * reserve_ratio))
    ranked = [(enabled[0], 1, 0)]
    if len(enabled) >= 2:
        ranked.append((enabled[1], 2, 5))
    if len(enabled) >= 3:
        ranked.append((enabled[2], 3, 10))
    affordable = [entry for entry in ranked if hp - entry[2] >= reserve_hp]
    choice_index, memories, hp_cost = (affordable or ranked[:1])[-1]
    log(
        f"sensory stone memories={memories} hp_cost={hp_cost} hp={hp}/{max_hp} "
        f"reserve={reserve_hp} healing_locked={healing_locked}"
    )
    return choice_index


def decide_event(state, gs):
    global GRID_SELECT_MODE
    event_id = ((gs.get("screen_state") or {}).get("event_id") or "").lower()
    legacy_match_session = (gs.get("seed"), gs.get("act"), gs.get("floor"))
    current_match_session = (RUN_SESSION_SERIAL, *legacy_match_session)
    current_choices = [str(choice).strip().lower() for choice in gs.get("choice_list", [])]
    has_match_slots = any(match_game_slot(choice) is not None for choice in current_choices)
    match_session_active = (
        MATCH_GAME_SESSION in {current_match_session, legacy_match_session}
        and (
            MATCH_GAME_FIRST is not None
            or MATCH_GAME_SECOND is not None
            or MATCH_GAME_MEMORY
            or MATCH_GAME_ATTEMPTED_PAIRS
        )
    )
    # CommunicationMod may omit event_id on intermediate Match and Keep states.
    # Continue routing those states through the memory solver instead of falling
    # back to generic CHOOSE 0.
    is_match_game = "match and keep" in event_id or has_match_slots or match_session_active
    is_masked_bandits = "masked" in event_id and "bandit" in event_id
    is_council_of_ghosts = "ghost" in event_id
    is_knowing_skull = "knowing" in event_id and "skull" in event_id
    is_mysterious_sphere = event_id == "mysterious sphere"
    is_colosseum = event_id == "colosseum"
    options = (gs.get("screen_state") or {}).get("options", [])
    enabled = [o.get("choice_index", i) for i, o in enumerate(options) if not o.get("disabled")]
    if not enabled and gs.get("choice_list") and not (is_masked_bandits and options):
        enabled = list(range(len(gs.get("choice_list"))))
    if not enabled:
        if command_available(state, "proceed"):
            return "PROCEED"
        if command_available(state, "return"):
            return "RETURN"
        return "STATE"
    if is_match_game:
        return decide_match_game(state, gs)
    if "neow" in event_id and len(enabled) > 1:
        scored = []
        fallback_choice = enabled[min(1, len(enabled) - 1)]
        for fallback_index, option in enumerate(options):
            choice_index = option.get("choice_index", fallback_index)
            if option.get("disabled") or choice_index not in enabled:
                continue
            score, reason = neow_option_score(option, gs, len(enabled))
            scored.append((score, choice_index == fallback_choice, choice_index, reason))
        if scored:
            score, _, choice_index, reason = max(scored)
            log(
                "neow reward "
                f"scores={[(item[2], round(item[0], 1), item[3]) for item in scored]} "
                f"decision={choice_index} reason={reason}"
            )
            return f"CHOOSE {choice_index}"
    if event_id == "facetrader" and len(enabled) > 1:
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        gold = max(0, int(gs.get("gold", 0) or 0))
        protect_reserve = bool(
            int(gs.get("ascension_level", 0) or 0) >= 15
            and (hp / max_hp < 0.60 or gold >= 300)
        )
        if protect_reserve:
            # Touch pays ten percent max HP for only fifty gold at A15+. The
            # logged A19 route already held 455 gold at 38/68 and was locked
            # into a hallway plus elite, so the payment had no survival value.
            log(
                f"face trader leave hp={hp}/{max_hp} gold={gold} "
                f"ascension={gs.get('ascension_level', 0)}"
            )
            return f"CHOOSE {enabled[-1]}"
    if event_id == "fountain of cleansing" and len(enabled) > 1:
        curses = persistent_curse_count(gs)
        keep_value = curse_retention_value(gs)
        should_cleanse = curses > 0 and keep_value < 25
        keywords = {"drink", "cleanse", "remove"} if should_cleanse else {
            "leave", "depart", "ignore",
        }
        for i, option in enumerate(options):
            if option.get("disabled"):
                continue
            if any(keyword in event_option_text(option) for keyword in keywords):
                choice_index = option.get("choice_index", i)
                break
        else:
            # Fountain is fixed as Drink then Leave. This also handles garbled
            # localized labels from the CommunicationMod event state.
            choice_index = enabled[0] if should_cleanse else enabled[-1]
        log(
            f"fountain cleanse={should_cleanse} persistent_curses={curses} "
            f"curse_value={keep_value} choice={choice_index}"
        )
        return f"CHOOSE {choice_index}"
    if event_id == "living wall" and len(enabled) > 1:
        act = int(gs.get("act", 1) or 1)
        floor = int(gs.get("floor", 0) or 0)
        upgradeable = [
            card for card in gs.get("deck", [])
            if card.get("type") in {"ATTACK", "SKILL", "POWER"}
            and int(card.get("upgrades", 0) or 0) <= 0
        ]
        if act == 1 and floor >= 12 and upgradeable:
            grow_keywords = {"grow", "upgrade"}
            grow_index = None
            for i, option in enumerate(options):
                if option.get("disabled"):
                    continue
                if any(keyword in event_option_text(option) for keyword in grow_keywords):
                    grow_index = option.get("choice_index", i)
                    break
            if grow_index is None:
                # Living Wall is fixed as Forget, Change, Grow. Localized text
                # can arrive garbled, so its final enabled option is reliable.
                grow_index = enabled[-1]
            log(
                f"living wall grow for Act 1 boss floor={floor} "
                f"hp={gs.get('current_hp')}/{gs.get('max_hp')} "
                f"upgradeable={len(upgradeable)} choice={grow_index}"
            )
            return f"CHOOSE {grow_index}"
    if event_id == "duplicator" and len(enabled) > 1:
        # The following grid has no transform/purge flag of its own. Carry the
        # event's semantics across the screen boundary so it ranks permanent
        # copies instead of falling back to static card values.
        GRID_SELECT_MODE = "duplicate"
        log("duplicator enter duplicate-scoring grid")
        return f"CHOOSE {enabled[0]}"
    if event_id.replace("'", "") == "nloth" and len(enabled) > 1:
        spent_relics = {
            "Astrolabe", "Calling Bell", "Empty Cage", "Pandora's Box",
            "Strawberry", "Pear", "Mango", "Old Coin", "Orrery",
            "Tiny House", "Cauldron", "DollysMirror", "Whetstone",
            "War Paint",
        }
        for fallback_index, option in enumerate(options):
            choice_index = option.get("choice_index", fallback_index)
            if option.get("disabled") or choice_index not in enabled:
                continue
            text = event_option_text(option)
            for relic in gs.get("relics", []):
                relic_id = relic.get("id")
                spent = relic_id in spent_relics or (
                    relic_id in {"NeowsBlessing", "WingedGreaves"}
                    and relic.get("counter") == 0
                )
                if spent and any(
                    str(relic.get(field) or "").lower() in text
                    for field in ("name", "id") if relic.get(field)
                ):
                    log(f"nloth trade spent relic={relic_id} choice={choice_index}")
                    return f"CHOOSE {choice_index}"
        # Unknown or still-useful relics retain their combat value. N'loth's
        # last option is Leave; never trade an unrecognized core relic.
        log("nloth preserve active relics")
        return f"CHOOSE {enabled[-1]}"
    if event_id == "wemeetagain" and len(enabled) > 1:
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        )
        valuable_combat_potions = [
            normalized_potion_id(potion)
            for potion in gs.get("potions", [])
            if normalized_potion_id(potion) != "Potion Slot"
            and potion_score(potion, gs, context="held") >= 40
        ]
        forced_elite_next = immediate_next_room_is_forced(gs, "E")
        late_act1_boss_prep = bool(
            int(gs.get("ascension_level", 0) or 0) >= 17
            and int(gs.get("act", 1) or 1) == 1
            and int(gs.get("floor", 0) or 0) >= 9
            and upcoming_boss_id(gs) in {
                "hexaghost", "theguardian", "guardian", "slimeboss",
            }
            and valuable_combat_potions
        )
        preserve_resources = bool(
            (
                int(gs.get("ascension_level", 0) or 0) >= 15
                and hp_ratio < 0.60
                and forced_elite_next
                and valuable_combat_potions
            )
            or late_act1_boss_prep
        )
        if preserve_resources:
            # We Meet Again's first option can donate the selected potion.
            # Event screens expose held potions as can_use=false, so inventory
            # presence, not combat usability, must drive this decision. Keep a
            # valuable late-Act-1 potion for the boss even at healthy raw HP.
            log(
                f"we meet again preserve combat resources hp={hp_ratio:.2f} "
                f"boss={upcoming_boss_id(gs)} late_boss={late_act1_boss_prep} "
                f"potions={valuable_combat_potions}"
            )
            return f"CHOOSE {enabled[-1]}"
    if event_id == "falling" and len(enabled) > 1:
        falling_choice = preferred_falling_choice(options, enabled, gs)
        if falling_choice is not None:
            keep_value, choice_index, lost_card = falling_choice
            log(
                f"falling choose={choice_index} lose={lost_card} "
                f"keep_value={keep_value}"
            )
            return f"CHOOSE {choice_index}"
    if "forgotten altar" in event_id and len(enabled) > 1:
        altar_choice = forgotten_altar_choice(options, enabled, gs)
        if altar_choice is not None:
            return f"CHOOSE {altar_choice}"
    if event_id == "cursed tome":
        return f"CHOOSE {cursed_tome_choice(options, enabled, gs)}"
    if event_id == "mindbloom" and len(enabled) > 1:
        return f"CHOOSE {mind_bloom_choice(enabled, gs)}"
    if event_id == "sensorystone" and len(enabled) > 1:
        return f"CHOOSE {sensory_stone_choice(enabled, gs)}"
    if event_id == "the moai head" and len(enabled) > 1:
        has_mark = bool(
            _relic_ids(gs) & MARK_OF_BLOOM_IDS
        )
        if has_mark:
            # Mark of the Bloom makes the full-heal option do nothing. Paying
            # 15 max HP for that zero healing was the second avoidable loss in
            # the same A17 run, so leave rather than feed the statue.
            log("moai leave: Mark of the Bloom blocks the offered healing")
            return f"CHOOSE {enabled[-1]}"
    if (
        event_id == "the mausoleum"
        and len(enabled) > 1
        and int(gs.get("ascension_level", 0) or 0) >= 15
    ):
        omamori_ready = any(
            (relic.get("id") or relic.get("name")) == "Omamori"
            and (
                relic.get("counter") is None
                or int(relic.get("counter", 0) or 0) > 0
            )
            for relic in gs.get("relics", [])
        )
        curse_value = curse_retention_value(gs)
        open_coffin = omamori_ready or curse_value >= 25
        choice_index = enabled[0] if open_coffin else enabled[-1]
        log(
            f"mausoleum open={open_coffin} ascension={gs.get('ascension_level', 0)} "
            f"omamori={omamori_ready} curse_value={curse_value}"
        )
        return f"CHOOSE {choice_index}"
    if event_id == "liars game" and len(enabled) > 1:
        relic_ids = {
            relic.get("id") or relic.get("name")
            for relic in gs.get("relics", [])
        }
        curse_friendly = (
            "Omamori" in relic_ids
            or curse_retention_value(gs) >= 25
        )
        log(
            f"liars game agree={curse_friendly} "
            f"curse_value={curse_retention_value(gs)}"
        )
        return f"CHOOSE {enabled[0] if curse_friendly else enabled[-1]}"
    if event_id == "mushrooms" and len(enabled) > 1:
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(
            1, gs.get("max_hp", 1) or 1
        )
        forced_elite_next = immediate_next_room_is_forced(gs, "E")
        ascension = int(gs.get("ascension_level", 0) or 0)
        standard_ready = (
            hp_ratio >= 0.72
            and act1_elite_offense_ready(gs)
            and defensive_package_shortfall(gs) <= 1
        )
        relic_hunt_ready = bool(
            ascension >= 18
            and int(gs.get("act", 1) or 1) == 1
            and hp_ratio >= 0.58
            and nonstarter_attack_count(gs) >= 2
            and defensive_package_shortfall(gs) <= 2
            and (
                act1_elite_offense_ready(gs)
                or act2_swarm_control_score(gs) >= 1.0
            )
        )
        ready_for_optional_fight = bool(
            (standard_ready or relic_hunt_ready) and not forced_elite_next
        )
        log(
            f"mushrooms fight={ready_for_optional_fight} hp={hp_ratio:.2f} "
            f"elite_ready={act1_elite_offense_ready(gs)} "
            f"relic_hunt={relic_hunt_ready} "
            f"forced_elite_next={forced_elite_next}"
        )
        return f"CHOOSE {enabled[0] if ready_for_optional_fight else enabled[-1]}"
    if "winding halls" in event_id and len(enabled) > 1:
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        missing_hp = max_hp - hp
        curse_value = curse_retention_value(gs)
        option_by_index = {
            option.get("choice_index", fallback_index): option
            for fallback_index, option in enumerate(options)
            if not option.get("disabled")
        }
        curse_choices = [
            choice_index
            for choice_index in enabled
            if event_paid_cost_kind(option_by_index.get(choice_index, {}))
            == (2, "curse")
        ]
        heal_index = curse_choices[0] if curse_choices else enabled[min(1, len(enabled) - 1)]
        take_cursed_heal = (
            missing_hp >= max(15, int(max_hp * 0.22))
            and (hp / max_hp <= 0.48 or curse_value >= 25)
        )
        choice_index = heal_index if take_cursed_heal else enabled[-1]
        log(
            f"winding halls heal={take_cursed_heal} hp={hp}/{max_hp} "
            f"curse_value={curse_value} choose={choice_index}"
        )
        return f"CHOOSE {choice_index}"
    if event_id == "addict" and len(enabled) > 1:
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        relic_ids = _relic_ids(gs)
        curse_value = curse_retention_value(gs)
        omamori_ready = omamori_blocks_next_curse(gs)
        key_reserves_future_curse = "Cursed Key" in relic_ids and not omamori_ready
        take_relic = bool(
            omamori_ready
            or curse_value >= 25
            or (
                not key_reserves_future_curse
                and persistent_curse_count(gs) == 0
                and hp / max_hp >= 0.60
            )
        )
        log(
            f"addict take_relic={take_relic} hp={hp}/{max_hp} "
            f"cursed_key={key_reserves_future_curse} "
            f"persistent_curses={persistent_curse_count(gs)} "
            f"curse_value={curse_value} omamori={omamori_ready}"
        )
        return f"CHOOSE {enabled[0] if take_relic else enabled[-1]}"
    paid_choice = preferred_paid_event_choice(options, enabled)
    if paid_choice is not None:
        _, choice_index, cost_kind = paid_choice
        log(
            f"event paid reward choose={choice_index} cost={cost_kind} "
            f"event={event_id or 'unknown'}"
        )
        return f"CHOOSE {choice_index}"
    if event_id == "big fish" and len(enabled) > 1:
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        missing_hp = max_hp - hp
        heal_index = enabled[0]
        max_hp_index = enabled[min(1, len(enabled) - 1)]
        box_index = enabled[-1]
        if missing_hp >= max(18, int(max_hp * 0.25)):
            # Banana heals one third of max HP. The logged A8 run chose the
            # relic box plus Regret at 22/88 immediately after Lagavulin, then
            # died two hallway fights later; the guaranteed 29 HP was worth
            # much more than a speculative relic there.
            return f"CHOOSE {heal_index}"
        relic_ids = {relic.get("id") for relic in gs.get("relics", [])}
        curse_friendly = "Omamori" in relic_ids or curse_retention_value(gs) >= 25
        aggressive_relic = bool(
            int(gs.get("ascension_level", 0) or 0) >= 18
            and int(gs.get("act", 1) or 1) == 1
            and int(gs.get("floor", 0) or 0) <= 10
            and hp / max_hp >= 0.78
        )
        return f"CHOOSE {box_index if curse_friendly or aggressive_relic else max_hp_index}"
    if is_mysterious_sphere and len(enabled) > 1:
        return f"CHOOSE {enabled[0] if strong_for_mysterious_sphere(gs) else enabled[-1]}"
    if is_colosseum and len(enabled) > 1:
        # After the mandatory Slavers fight, option zero leaves while option one
        # starts a substantially harder elite pair. The generic low-HP fallback
        # chooses the final option, which is exactly backwards for this event.
        return f"CHOOSE {enabled[-1] if strong_for_colosseum(gs) else enabled[0]}"
    if event_id == "dead adventurer" and len(enabled) > 1:
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
        ascension = int(gs.get("ascension_level", 0) or 0)
        high_ascension_relic_hunt = bool(
            ascension >= 18 and int(gs.get("act", 1) or 1) == 1
        )
        reserve_ratio = (
            0.58
            if high_ascension_relic_hunt
            else 0.62 + min(0.08, max(0, ascension - 9) * 0.02)
        )
        if ascension >= 10 and int(gs.get("floor", 0) or 0) >= 13:
            # A late extra elite sits directly in front of the Act 1 boss. The
            # logged A15 deck searched at 64/82, lost 49 HP to Lagavulin, and
            # had no route left to recover before Guardian.
            reserve_ratio += 0.10 if high_ascension_relic_hunt else 0.12
        if act2_high_output_defense_count(gs) == 0:
            reserve_ratio += 0.04
        ready_for_extra_elite = (
            hp_ratio >= reserve_ratio
            and nonstarter_attack_count(gs) >= (
                2 if high_ascension_relic_hunt else 3
            )
            and defensive_package_shortfall(gs) <= (
                2 if high_ascension_relic_hunt else 1
            )
            and (
                act1_boss_damage_ready(gs)
                or (
                    high_ascension_relic_hunt
                    and int(gs.get("floor", 0) or 0) < 10
                    and act1_elite_offense_ready(gs)
                )
            )
        )
        # Searching can immediately force another Act 1 elite. The logged A8
        # deck had already paid for Lagavulin and Gremlin Nob, then searched at
        # 34/80 with only Whirlwind and Sword Boomerang and died to a third
        # elite. At high ascension, also reserve more HP when the deck has no
        # burst-block answer; the A13 run searched at 58/88 after three elites,
        # paid another 28 HP, and entered Guardian with no route reserve.
        log(
            f"dead adventurer fight={ready_for_extra_elite} hp={hp_ratio:.2f} "
            f"reserve={reserve_ratio:.2f} ascension={ascension} "
            f"relic_hunt={high_ascension_relic_hunt} "
            f"high_block={act2_high_output_defense_count(gs)}"
        )
        return f"CHOOSE {enabled[0] if ready_for_extra_elite else enabled[-1]}"
    if "scrap ooze" in event_id and len(enabled) > 1:
        rummage_index = enabled[0]
        rummage_option = next(
            (
                option
                for i, option in enumerate(options)
                if option.get("choice_index", i) == rummage_index
            ),
            {},
        )
        option_text = " ".join(
            str(rummage_option.get(field) or "") for field in ("text", "label")
        )
        numbers = [int(value) for value in re.findall(r"\d+", option_text)]
        hp_cost = numbers[0] if numbers else 3
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        act = int(gs.get("act", 1) or 1)
        floor = int(gs.get("floor", 0) or 0)
        if (
            act == 1
            and int(gs.get("ascension_level", 0) or 0) >= 18
        ):
            # The relic permanently compounds future acts; in high-ascension
            # training an Act 1 miss is cheaper than entering Act 2 relic-poor.
            reserve_ratio = 0.50 if floor < 13 else 0.46
        elif act == 1 and floor < 10 and not act1_boss_damage_ready(gs):
            reserve_ratio = 0.70
        else:
            reserve_ratio = 0.55 if act == 1 and floor >= 10 else 0.50 if act >= 2 else 0.42
        reserve_hp = max(18, int(max_hp * reserve_ratio))
        if hp - hp_cost < reserve_hp:
            return f"CHOOSE {enabled[-1]}"
        return f"CHOOSE {rummage_index}"
    if event_id == "world of goop" and len(enabled) > 1:
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
        gold = int(gs.get("gold", 0) or 0)
        # The first option trades HP for more gold; the final option pays gold
        # instead. Do not spend a late-Act-1 health reserve to overfill a purse
        # that can already buy several meaningful shop items.
        pay_gold = hp_ratio < 0.60 or gold >= 250
        return f"CHOOSE {enabled[-1] if pay_gold else enabled[0]}"
    if event_id == "nest" and len(enabled) > 1:
        hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
        # Ritual Dagger is not worth paying six HP when the next hallway can
        # already be lethal. Take the gold while injured; scale when healthy.
        return f"CHOOSE {enabled[0] if hp_ratio < 0.50 else enabled[-1]}"
    if "back to basics" in event_id:
        basic_count = count_deck(gs, {"Strike_R", "Defend_R"})
        if basic_count >= 4 and 1 in enabled:
            return "CHOOSE 1"
        GRID_SELECT_MODE = "purge"
        return f"CHOOSE {enabled[0]}"
    if is_council_of_ghosts:
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        hp_ratio = hp / max_hp
        deck_ids = {card_id(card) for card in gs.get("deck", [])}
        corruption_bridge = bool(
            "Corruption" in deck_ids
            and act2_high_output_defense_count(gs) == 0
            and hp_ratio <= 0.55
        )
        accept_apparitions = bool(
            len(enabled) > 1
            and int(gs.get("act", 1) or 1) == 2
            and int(gs.get("ascension_level", 0) or 0) >= 15
            and (hp_ratio <= 0.35 or corruption_bridge)
        )
        if accept_apparitions:
            accept_keywords = {"accept", "embrace", "receive"}
            for i, option in enumerate(options):
                if option.get("disabled"):
                    continue
                text = event_option_text(option)
                if any(keyword in text for keyword in accept_keywords):
                    choice_index = option.get("choice_index", i)
                    break
            else:
                # Council of Ghosts always places Accept before Refuse; this
                # fallback also works when localized option text is garbled.
                choice_index = enabled[0]
            log(
                f"council of ghosts accept Apparitions hp={hp}/{max_hp} "
                f"corruption_bridge={corruption_bridge} "
                f"high_block={act2_high_output_defense_count(gs)} "
                f"choice={choice_index}"
            )
            return f"CHOOSE {choice_index}"
        safe_keywords = {"refuse", "decline", "leave", "depart", "escape", "return"}
        for i, option in enumerate(options):
            if option.get("disabled"):
                continue
            text = event_option_text(option)
            if any(keyword in text for keyword in safe_keywords):
                return f"CHOOSE {option.get('choice_index', i)}"
        return f"CHOOSE {enabled[-1]}"
    if is_knowing_skull:
        safe_keywords = {"refuse", "decline", "leave", "depart", "escape", "return"}
        for i, option in enumerate(options):
            if option.get("disabled"):
                continue
            text = event_option_text(option)
            if any(keyword in text for keyword in safe_keywords):
                return f"CHOOSE {option.get('choice_index', i)}"
        return f"CHOOSE {enabled[-1]}"
    if is_masked_bandits:
        should_fight = strong_for_masked_bandits(gs)
        keywords = {"fight", "refuse"} if should_fight else {"pay", "gold"}
        for i, option in enumerate(options):
            if option.get("disabled"):
                continue
            text = ((option.get("text") or "") + " " + (option.get("label") or "")).lower()
            if any(keyword in text for keyword in keywords):
                return f"CHOOSE {option.get('choice_index', i)}"
        fallback = enabled[min(1, len(enabled) - 1)] if should_fight else enabled[0]
        return f"CHOOSE {fallback}"
    hp_ratio = (gs.get("current_hp", 1) or 1) / max(1, gs.get("max_hp", 1) or 1)
    if "vampires" in event_id:
        strike_count = count_deck(gs, {"Strike_R"})
        has_perfected_strike = count_deck(gs, {"Perfected Strike"}) > 0
        relic_ids = _relic_ids(gs)
        if (
            len(enabled) > 1
            and strike_count >= 4
            and not has_perfected_strike
            and hp_ratio <= 0.60
            and "Blood Vial" in relic_ids
            and 1 in enabled
        ):
            # Five Bites replace the weakest starter attacks without paying
            # max HP when Blood Vial is available. This is immediate sustain
            # for an injured Act 2 deck, not just speculative deck cleanup.
            return "CHOOSE 1"
        if (
            hp_ratio <= 0.35
            and strike_count >= 3
            and not has_perfected_strike
            and 0 in enabled
        ):
            return "CHOOSE 0"
        return f"CHOOSE {enabled[-1]}"
    if "golden idol" in event_id:
        # On the consequence screen preferred_paid_event_choice already ranks
        # max-HP loss before HP loss before a curse. Keep option zero only for
        # the initial take/leave screen or incomplete option metadata.
        return f"CHOOSE {enabled[0]}"
    if "shining light" in event_id and len(enabled) > 1:
        max_hp = max(1, int(gs.get("max_hp", 1) or 1))
        hp = max(0, int(gs.get("current_hp", 0) or 0))
        ascension = int(gs.get("ascension_level", 0) or 0)
        hp_cost_percent = 30 if ascension >= 15 else 20
        hp_cost = max(1, (max_hp * hp_cost_percent + 99) // 100)
        projected_hp = hp - hp_cost
        late_act_one = int(gs.get("act", 1) or 1) == 1 and int(gs.get("floor", 0) or 0) >= 13
        reserve_ratio = 0.70 if late_act_one else (0.65 if ascension >= 15 else 0.45)
        if projected_hp / max_hp < reserve_ratio:
            return f"CHOOSE {enabled[-1]}"
    if hp_ratio < 0.35 and len(enabled) > 1:
        return f"CHOOSE {enabled[-1]}"
    return f"CHOOSE {enabled[0]}"


def decide_chest(state, gs):
    """Open a chest unless Cursed Key would exceed the deck's Curse budget."""
    if not command_available(state, "choose"):
        return "PROCEED" if command_available(state, "proceed") else "STATE"
    open_chest = cursed_key_chest_should_open(gs)
    log(
        f"chest open={open_chest} cursed_key={'Cursed Key' in _relic_ids(gs)} "
        f"persistent_curses={persistent_curse_count(gs)} "
        f"curse_value={curse_retention_value(gs)} "
        f"omamori={omamori_blocks_next_curse(gs)}"
    )
    if open_chest:
        return "CHOOSE 0"
    if command_available(state, "proceed"):
        return "PROCEED"
    exit_command = available_exit_command(state)
    return exit_command or "STATE"


def shop_engine_completion_bonus(card, gs):
    """Value a shop card that closes an already-started exhaust engine."""
    if card_id(card) != "Corruption" or count_deck(gs, {"Corruption"}):
        return 0
    deck = gs.get("deck", [])
    payoff_sources = min(
        2,
        sum(card_id(deck_card) in {"Dark Embrace", "Feel No Pain"} for deck_card in deck)
        + int("Dead Branch" in _relic_ids(gs)),
    )
    if payoff_sources <= 0:
        return 0
    skill_count = sum(
        deck_card.get("type") == "SKILL"
        and card_id(deck_card) not in {"AscendersBane"}
        for deck_card in deck
    )
    return 28 + payoff_sources * 10 + min(18, skill_count * 3)


def shop_tactical_survival_bonus(card, gs):
    """Price a shop card against a visible, otherwise uncovered damage check."""
    cid = card_id(card)
    act = int(gs.get("act", 1) or 1)
    floor = int(gs.get("floor", 0) or 0)
    ascension = int(gs.get("ascension_level", 0) or 0)
    relic_ids = _relic_ids(gs)

    dead_branch_panic_button = bool(
        cid in {"Panic Button", "PanicButton"}
        and ascension >= 18
        and act == 1
        and floor >= 9
        and upcoming_boss_id(gs) == "hexaghost"
        and "Dead Branch" in relic_ids
        and count_deck(gs, {"Panic Button", "PanicButton"}) == 0
        and act2_high_output_defense_count(gs) == 0
    )
    if dead_branch_panic_button:
        # Panic Button covers Hexaghost's burst turn, then exhausts into Dead
        # Branch. The A19 shop instead spent its last 75 gold purging Parasite
        # and died to a 36-damage turn with no block card in hand.
        return 36

    usable_potions = any(
        normalized_potion_id(potion) != "Potion Slot"
        and potion.get("can_use", True)
        for potion in gs.get("potions", [])
    )
    forced_elite_defense = bool(
        ascension >= 18
        and act == 2
        and floor >= 24
        and forced_elite_within_rooms(gs, max_rooms=2)
        and not usable_potions
        and act2_high_output_defense_count(gs) < 2
        and cid in {
            "Disarm", "Flame Barrier", "Ghostly", "Ghostly Armor",
            "Impervious", "Panic Button", "PanicButton", "Power Through",
            "Shockwave", "Shrug It Off",
        }
        and (cid != "Shrug It Off" or count_deck(gs, {cid}) < 4)
        and defensive_reward_usable(cid, gs)
    )
    if forced_elite_defense:
        # Full HP is not preparation for Slavers when every route reaches the
        # elite and both potion slots are empty. Buy immediate block/cycle over
        # a slower setup card; the A19 deck otherwise drew an all-attack hand
        # while Entangled and died from 23 HP.
        return 32 if cid == "Shrug It Off" else 38
    return 0


def decide_shop(state, gs):
    global SHOP_SESSION_TOKEN, SHOP_ENTRY_SENT, SHOP_SCREEN_SEEN, SHOP_EXIT_SENT, SHOP_CARD_PURCHASES, GRID_SELECT_MODE, ORRERY_REWARD_TAKES

    screen_type = (gs.get("screen_type") or "").upper()
    shop_choices = [str(choice).lower() for choice in gs.get("choice_list", [])]
    session_token = (gs.get("seed"), gs.get("act"), gs.get("floor"))
    if session_token != SHOP_SESSION_TOKEN:
        SHOP_SESSION_TOKEN = session_token
        SHOP_ENTRY_SENT = False
        SHOP_SCREEN_SEEN = False
        SHOP_EXIT_SENT = False
        SHOP_CARD_PURCHASES = 0
        ORRERY_REWARD_TAKES = 0

    if screen_type == "SHOP_SCREEN":
        SHOP_SCREEN_SEEN = True

    if screen_type == "SHOP_ROOM" or "shop" in shop_choices:
        if SHOP_SCREEN_SEEN:
            if not SHOP_EXIT_SENT:
                if command_available(state, "proceed"):
                    SHOP_EXIT_SENT = True
                    return "PROCEED"
                exit_command = available_exit_command(state)
                if exit_command:
                    SHOP_EXIT_SENT = True
                    return exit_command
            return "WAIT 30" if command_available(state, "wait") else "STATE"
        if not SHOP_ENTRY_SENT and command_available(state, "choose"):
            SHOP_ENTRY_SENT = True
            return f"CHOOSE {shop_choices.index('shop') if 'shop' in shop_choices else 0}"
        return "WAIT 30" if command_available(state, "wait") else "STATE"

    if command_available(state, "choose"):
        screen = gs.get("screen_state") or {}
        gold = int(gs.get("gold", 0) or 0)
        non_card_choices = []
        card_choices = []
        choice_index = 0

        profile = archetype_profile(gs)
        if screen.get("purge_available") and gold >= int(screen.get("purge_cost", 999) or 999):
            deck = gs.get("deck", [])
            best_purge = max((purge_card_score(card, gs, profile) for card in deck), default=0)
            purchase_value = 80 if best_purge >= 100 else 48 if best_purge >= 70 else 20
            purchase_value -= int(screen.get("purge_cost", 0) or 0) * 0.15
            non_card_choices.append((choice_index, purchase_value, "purge"))
            choice_index += 1

        for card in screen.get("cards", []):
            price = int(card.get("price", 999) or 999)
            if price <= gold:
                engine_completion_bonus = shop_engine_completion_bonus(card, gs)
                tactical_survival_bonus = shop_tactical_survival_bonus(card, gs)
                tactical_base_score = (
                    COMBAT_TEMP_CARD_SCORES.get(card_id(card), 0)
                    if tactical_survival_bonus
                    else 0
                )
                card_score = (
                    max(card_reward_score(card, gs), tactical_base_score)
                    + engine_completion_bonus
                    + tactical_survival_bonus
                )
                shop_card_minimum = card_reward_skip_threshold(gs, profile) + 7
                strong_fit, fit_reason = shop_card_purchase_fit(card, gs, profile, card_score)
                if card_score >= shop_card_minimum and strong_fit:
                    late_act1_boss_damage_exception = (
                        fit_reason == "premium_universal"
                        and int(gs.get("act", 1) or 1) == 1
                        and int(gs.get("floor", 0) or 0) >= 9
                        and card_id(card) in ACT1_BOSS_DAMAGE_CARDS
                        and not act1_boss_damage_ready(gs)
                    )
                    exceptional = card_score >= SHOP_EXCEPTIONAL_CARD_MIN and (
                        engine_completion_bonus > 0
                        or tactical_survival_bonus > 0
                        or fit_reason == "high_output_defense_need"
                        or fit_reason.startswith("strong_archetype:")
                        or (
                            fit_reason == "defensive_package_need"
                            and defensive_package_shortfall(gs) >= 2
                        )
                        or late_act1_boss_damage_exception
                    )
                    card_choices.append(
                        (
                            choice_index,
                            card_score - price * 0.25,
                            f"card:{card_id(card)}:{fit_reason}"
                            + (
                                f":engine_completion+{engine_completion_bonus}"
                                if engine_completion_bonus
                                else ""
                            )
                            + (
                                f":survival+{tactical_survival_bonus}"
                                if tactical_survival_bonus
                                else ""
                            ),
                            exceptional,
                        )
                    )
                choice_index += 1

        affordable_relics = []
        for relic in screen.get("relics", []):
            price = int(relic.get("price", 999) or 999)
            if price <= gold:
                relic_id = canonical_relic_id(
                    relic.get("id") or relic.get("name")
                )
                relic_score = (
                    SHOP_RELIC_BASE_SCORES.get(
                        relic_id,
                        BOSS_RELIC_SCORES.get(
                            relic_id, default_shop_score(relic_id)
                        ),
                    )
                    + archetype_relic_bonus(relic, gs, profile)
                    + shop_relic_context_bonus(relic, gs)
                    + SHOP_RELIC_PRIORITY_BONUS
                    - price * 0.15
                )
                relic_choice = (choice_index, relic_score, f"relic:{relic_id or 'unknown'}")
                non_card_choices.append(relic_choice)
                if relic_score >= 35:
                    affordable_relics.append(relic_choice)
                choice_index += 1

        potion_slots_full = bool(gs.get("potions")) and all(
            normalized_potion_id(potion) != "Potion Slot"
            for potion in gs.get("potions", [])
        )
        potion_gain_blocked = "Sozu" in _relic_ids(gs)
        emergency_potion_choices = []
        needs_elite_potion = (
            int(gs.get("current_hp", 1) or 1)
            < max(1, int(gs.get("max_hp", 1) or 1)) * 0.40
            and immediate_next_room_is_forced(gs, "E")
            and not any(
                normalized_potion_id(potion) != "Potion Slot"
                for potion in gs.get("potions", [])
            )
        )
        shop_potion_replacements = []
        for potion in screen.get("potions", []):
            price = int(potion.get("price", 999) or 999)
            if price <= gold:
                score = potion_score(potion, gs, context="shop")
                purchase_score = score - price * 0.20
                if not potion_gain_blocked:
                    if not potion_slots_full:
                        if needs_elite_potion and normalized_potion_id(potion) in {
                            "Block Potion", "SpeedPotion", "Energy Potion",
                            "GamblersBrew", "Swift Potion", "LiquidMemories",
                            "BloodPotion", "FairyPotion", "HeartOfIron",
                            "Weak Potion", "EntropicBrew", "BlessingOfTheForge",
                        }:
                            emergency_potion_choices.append(
                                (choice_index, purchase_score + 70,
                                 f"potion:{normalized_potion_id(potion)}:elite_reserve")
                            )
                        non_card_choices.append(
                            (
                                choice_index,
                                purchase_score,
                                f"potion:{normalized_potion_id(potion)}",
                            )
                        )
                    else:
                        replacement = best_potion_replacement(gs, potion)
                        if replacement:
                            # Price both the improvement over the held potion
                            # and the gold spent. This lets a premium defensive
                            # potion replace dead inventory without displacing a
                            # clearly stronger relic or card purchase.
                            replacement_value = (
                                replacement["incoming_score"]
                                - replacement["held_score"]
                                + 34
                                - price * 0.15
                            )
                            shop_potion_replacements.append(
                                (
                                    replacement_value,
                                    choice_index,
                                    potion,
                                    replacement,
                                    price,
                                )
                            )
                choice_index += 1

        card_purchase_limit = (
            2
            if int(gs.get("act", 1) or 1) == 1
            and len(gs.get("deck", [])) < 22
            else 1
        )
        if SHOP_CARD_PURCHASES >= card_purchase_limit:
            card_choices = []

        if emergency_potion_choices:
            choices = emergency_potion_choices
        elif affordable_relics and SHOP_CARD_PURCHASES:
            # After paying for one exceptional card, secure a worthwhile relic
            # before The Courier can keep refreshing more tempting cards.
            choices = affordable_relics
        elif affordable_relics:
            # Relics are the default shop investment. Only a genuinely strong
            # archetype card may compete while a worthwhile relic is affordable.
            # Routine potions wait until the relic purchase has resolved so a
            # pair of attractive bottles cannot consume the permanent upgrade.
            choices = affordable_relics + [
                choice[:3] for choice in card_choices if choice[3]
            ]
        else:
            choices = non_card_choices + [choice[:3] for choice in card_choices]

        best_regular_score = max((choice[1] for choice in choices), default=-999)
        if (
            shop_potion_replacements
            and not affordable_relics
            and command_available(state, "potion")
        ):
            replacement_value, potion_choice, potion, replacement, price = max(
                shop_potion_replacements,
                key=lambda item: item[0],
            )
            if replacement_value >= 35 and replacement_value >= best_regular_score - 2:
                command = f"POTION discard {replacement['slot']}"
                if should_issue_potion_command(command, gs):
                    log(
                        f"shop potion replace incoming={replacement['incoming_id']} "
                        f"incoming_score={replacement['incoming_score']:.1f} "
                        f"price={price} discard_slot={replacement['slot']} "
                        f"held={replacement['held_id']} "
                        f"held_score={replacement['held_score']:.1f} "
                        f"replacement_value={replacement_value:.1f}"
                    )
                    return command
                return "WAIT 10" if command_available(state, "wait") else "STATE"

        if choices:
            best_idx, best_score, best_kind = max(choices, key=lambda x: x[1])
            if best_score >= 35:
                if best_kind == "relic:DollysMirror":
                    GRID_SELECT_MODE = "duplicate"
                if best_kind.startswith("card:"):
                    SHOP_CARD_PURCHASES += 1
                log(f"shop buy idx={best_idx} kind={best_kind} score={best_score:.1f} gold={gold}")
                return f"CHOOSE {best_idx}"

    exit_command = available_exit_command(state)
    if exit_command:
        if screen_type == "SHOP_SCREEN":
            log(f"shop leave gold={int(gs.get('gold', 0) or 0)} no_purchase_over_threshold")
        return exit_command
    if command_available(state, "proceed"):
        return "PROCEED"
    return "STATE"


def decide(
    state,
    restart_on_loss=True,
    ascension=0,
    continue_after_victory=False,
):
    global HAND_SELECT_MODE, GRID_SELECT_MODE
    if state.get("error"):
        return "STATE"
    smoke_bomb_wait = smoke_bomb_escape_wait_command(state)
    if smoke_bomb_wait:
        return smoke_bomb_wait
    if not state.get("in_game"):
        # CommunicationMod can publish an early menu/loading state before the
        # START command is actually available.  Sending START during that
        # transitional state can leave the bot repeatedly requesting STATE at
        # the title screen, so wait until the command is advertised.
        if command_available(state, "start"):
            return f"START IRONCLAD {max(0, int(ascension))}"
        if command_available(state, "wait"):
            return "WAIT 30"
        return "STATE"
    if state.get("ready_for_command") is False:
        # CommunicationMod keeps PLAY/END advertised while queued actions are
        # resolving. Acting on those frames once queued two END commands and
        # skipped an entire combat turn.
        return "WAIT 10" if command_available(state, "wait") else "STATE"
    gs = state.get("game_state") or {}
    screen = gs.get("screen_type")
    room = gs.get("room_type")
    if screen in {"COMBAT_REWARD", "BOSS_REWARD", "MAP", "GAME_OVER"}:
        if GRID_SELECT_MODE in {
            "headbutt", "exhume", "liquid_memories", "secret_weapon",
        }:
            GRID_SELECT_MODE = None
        HAND_SELECT_MODE = None
    target_ascension = max(0, int(ascension))
    current_ascension = int(gs.get("ascension_level", 0) or 0)
    current_class = (gs.get("class") or "IRONCLAD").upper()

    if screen == "GAME_OVER":
        ss = gs.get("screen_state") or {}
        authoritative_run = (
            current_class == "IRONCLAD" and current_ascension == target_ascension
        )
        if (
            ss.get("victory")
            and authoritative_run
            and not continue_after_victory
        ):
            return None
        if not restart_on_loss and authoritative_run:
            return None
        if command_available(state, "proceed"):
            return "PROCEED"
        return "STATE"
    if current_class != "IRONCLAD" or current_ascension != target_ascension:
        # A launcher can inherit an autosave from a manual or older training
        # run. Never let that run consume this batch or satisfy its victory
        # gate; return to the menu and start the requested Ironclad ascension.
        if command_available(state, "abandon"):
            return "RESET_WRONG_RUN"
        return "WAIT 30" if command_available(state, "wait") else "STATE"
    if (
        int(gs.get("current_hp", 1) or 0) <= 0
        and room in {"MonsterRoom", "MonsterRoomElite", "MonsterRoomBoss"}
    ):
        # Death screens can briefly republish the old map/combat payload after
        # PROCEED.  It is not a playable zero-HP run and must not issue a map
        # choice before GAME_OVER settles again.
        if command_available(state, "abandon"):
            return "RECOVER_DEATH"
        return "WAIT 30" if command_available(state, "wait") else "STATE"
    room_phase = str(gs.get("room_phase") or "").upper()
    action_phase = str(gs.get("action_phase") or "").upper()
    if (
        room_phase == "COMBAT"
        and action_phase
        and action_phase != "WAITING_ON_USER"
        and screen not in {"HAND_SELECT", "GRID", "CARD_REWARD"}
    ):
        # Some action-queue frames are marked ready and briefly expose MAP or
        # END while the prior command is still resolving. Any command on that
        # frame can be queued for the following turn, including a duplicate END.
        return "WAIT 10" if command_available(state, "wait") else "STATE"
    if command_available(state, "play") or command_available(state, "end"):
        return decide_combat(state, game_state_with_relic_memory(gs))
    if screen == "CARD_REWARD":
        return decide_card_reward(state, gs)
    if screen == "COMBAT_REWARD":
        return decide_combat_reward(state, gs)
    if screen == "BOSS_REWARD":
        return decide_boss_reward(gs)
    if screen == "MAP":
        return decide_map(gs)
    if screen == "CHEST":
        return decide_chest(state, gs)
    if screen == "GRID":
        return decide_grid(state, gs)
    if screen == "HAND_SELECT":
        return decide_hand_select(state, gs)
    if screen in {"SHOP", "SHOP_ROOM", "SHOP_SCREEN"}:
        return decide_shop(state, gs)
    if room == "RestRoom":
        return decide_rest(state, gs)
    if room and "ShopRoom" in room:
        return decide_shop(state, gs)
    if command_available(state, "choose"):
        return decide_event(state, gs)
    if command_available(state, "proceed"):
        return "PROCEED"
    if command_available(state, "return"):
        return "RETURN"
    if command_available(state, "wait"):
        return "WAIT 30"
    return "STATE"


def summary(state):
    gs = state.get("game_state") or {}
    combat = gs.get("combat_state") or {}
    monsters = combat.get("monsters") or []
    alive = [f"{m.get('id')}:{m.get('current_hp')}" for m in monsters if not m.get("is_gone")]
    return f"act={gs.get('act')} floor={gs.get('floor')} hp={gs.get('current_hp')}/{gs.get('max_hp')} room={gs.get('room_type')} screen={gs.get('screen_type')} monsters={alive}"


def loss_state_token(gs):
    screen_state = gs.get("screen_state") or {}
    return (
        gs.get("seed"),
        int(gs.get("floor", 0) or 0),
        int(screen_state.get("score", 0) or 0),
    )


def terminal_state_token(gs):
    return loss_state_token(gs) + (
        bool((gs.get("screen_state") or {}).get("victory")),
    )


def inferred_act_from_floor(floor):
    """Recover the deepest act when a terminal payload has a stale act field."""
    floor = max(0, int(floor or 0))
    if floor >= 51:
        return 4
    if floor >= 34:
        return 3
    if floor >= 17:
        return 2
    return 1


def loss_counts_toward_review(gs, minimum_act=2, peak_act=None):
    reached_act = max(
        int(gs.get("act", 1) or 1),
        inferred_act_from_floor(gs.get("floor", 0)),
        int(peak_act or 1),
    )
    return reached_act >= max(1, int(minimum_act or 1)), reached_act


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=10000)
    parser.add_argument("--max-runs", type=int, default=50)
    parser.add_argument("--max-total-runs", type=int, default=0)
    parser.add_argument("--ascension", type=int, default=0)
    parser.add_argument("--review-loss-min-act", type=int, choices=range(1, 5), default=2)
    parser.add_argument("--initial-qualifying-losses", type=int, default=0)
    parser.add_argument("--restart-on-loss", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument(
        "--continue-after-victory",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    args = parser.parse_args()
    continue_after_victory = bool(
        args.continue_after_victory or args.max_total_runs > 0
    )
    session_id = time.strftime("%Y%m%d-%H%M%S")
    log(
        f"=== BOT SESSION START version={BOT_VERSION} session={session_id} "
        f"pid={os.getpid()} ascension={args.ascension} max_runs={args.max_runs} "
        f"max_total_runs={args.max_total_runs} "
        f"continue_after_victory={continue_after_victory} "
        f"review_loss_min_act={args.review_loss_min_act} "
        f"initial_qualifying_losses={args.initial_qualifying_losses} ==="
    )
    state = load_state()
    qualifying_losses = max(0, int(args.initial_qualifying_losses or 0))
    initial_gs = state.get("game_state") or {}
    run_active = bool(state.get("in_game"))
    terminal_seen = initial_gs.get("screen_type") == "GAME_OVER"
    run_peak_act = max(
        int(initial_gs.get("act", 1) or 1),
        inferred_act_from_floor(initial_gs.get("floor", 0)),
    )
    unexpected_menu_polls = 0
    initial_authoritative = (
        (initial_gs.get("class") or "IRONCLAD").upper() == "IRONCLAD"
        and int(initial_gs.get("ascension_level", 0) or 0) == args.ascension
    )
    last_seen_terminal = (
        terminal_state_token(initial_gs)
        if initial_gs.get("screen_type") == "GAME_OVER"
        and initial_authoritative
        else None
    )
    completed_runs = 0
    last_seen_loss = (
        loss_state_token(initial_gs)
        if initial_gs.get("screen_type") == "GAME_OVER"
        and not bool((initial_gs.get("screen_state") or {}).get("victory"))
        and initial_authoritative
        else None
    )

    def choose_command(current_state):
        kwargs = {
            "restart_on_loss": args.restart_on_loss,
            "ascension": args.ascension,
        }
        if continue_after_victory:
            kwargs["continue_after_victory"] = True
        return decide(current_state, **kwargs)

    for step in range(args.steps):
        gs = state.get("game_state") or {}
        screen = gs.get("screen_type")
        victory = bool((gs.get("screen_state") or {}).get("victory"))
        if state.get("in_game"):
            run_active = True
            unexpected_menu_polls = 0
        if screen == "GAME_OVER":
            terminal_seen = True
        authoritative_run = (
            (gs.get("class") or "IRONCLAD").upper() == "IRONCLAD"
            and int(gs.get("ascension_level", 0) or 0) == args.ascension
        )
        if authoritative_run:
            run_peak_act = max(
                run_peak_act,
                int(gs.get("act", 1) or 1),
                inferred_act_from_floor(gs.get("floor", 0)),
            )
        if screen == "GAME_OVER" and authoritative_run:
            terminal_token = terminal_state_token(gs)
            if terminal_token != last_seen_terminal:
                last_seen_terminal = terminal_token
                completed_runs += 1
                run_limit = (
                    str(args.max_total_runs)
                    if args.max_total_runs > 0
                    else "loop"
                )
                result = "victory" if victory else "loss"
                log(
                    f"test run completed result={result} "
                    f"completed_runs={completed_runs}/{run_limit} "
                    f"floor={gs.get('floor')} seed={gs.get('seed')}"
                )
        if (
            screen == "GAME_OVER"
            and not victory
            and authoritative_run
            and args.max_runs > 0
        ):
            loss_token = loss_state_token(gs)
            if loss_token != last_seen_loss:
                last_seen_loss = loss_token
                qualifies, reached_act = loss_counts_toward_review(
                    gs,
                    minimum_act=args.review_loss_min_act,
                    peak_act=run_peak_act,
                )
                if qualifies:
                    qualifying_losses += 1
                    log(
                        "loss quota counted "
                        f"reached_act={reached_act} floor={gs.get('floor')} "
                        f"qualifying_losses={qualifying_losses}/{args.max_runs}"
                    )
                else:
                    log(
                        "loss quota ignored "
                        f"reached_act={reached_act} floor={gs.get('floor')} "
                        f"minimum_act={args.review_loss_min_act}"
                    )
            if args.max_runs > 0 and qualifying_losses >= args.max_runs:
                print("STOP max-runs", qualifying_losses, summary(state))
                return 0
        if (
            screen == "GAME_OVER"
            and authoritative_run
            and args.max_total_runs > 0
            and completed_runs >= args.max_total_runs
        ):
            print("STOP max-total-runs", completed_runs, summary(state))
            return 0

        if should_guard_unexpected_menu(state, run_active, terminal_seen):
            unexpected_menu_polls += 1
            if unexpected_menu_polls <= UNEXPECTED_MENU_CONFIRM_POLLS:
                cmd = "STATE"
                log(
                    "unexpected main-menu frame while run active; "
                    f"confirmation={unexpected_menu_polls}/"
                    f"{UNEXPECTED_MENU_CONFIRM_POLLS}"
                )
            else:
                run_active = False
                terminal_seen = False
                unexpected_menu_polls = 0
                log(
                    "unexpected main menu confirmed; restarting without "
                    "counting a non-authoritative interruption "
                    f"qualifying_losses={qualifying_losses}"
                )
                cmd = choose_command(state)
        else:
            cmd = choose_command(state)
        if cmd is None:
            log(f"step={step} {summary(state)} cmd={cmd}")
            print("STOP", summary(state))
            return 0
        cmd = guard_duplicate_policy_command(cmd, state)
        arm_smoke_bomb_escape_guard(cmd, state)
        remember_combat_relic_play(cmd, gs)
        log(f"step={step} {summary(state)} cmd={cmd}")
        prepare_hand_select_mode(cmd, state)
        if isinstance(cmd, str) and cmd.startswith("START IRONCLAD"):
            begin_new_run_session()
            run_active = True
            terminal_seen = False
            run_peak_act = 1
            unexpected_menu_polls = 0
            log(
                f"=== RUN START REQUEST version={BOT_VERSION} "
                f"qualifying_losses={qualifying_losses} "
                f"run_serial={RUN_SESSION_SERIAL} ==="
            )
        if cmd in {"ABANDON_RUN", "RECOVER_DEATH", "RESET_WRONG_RUN"}:
            state = execute_policy_command(cmd, send_command)
            if not is_main_menu_state(state):
                print("STOP abandon-failed", summary(state))
                return 1
            if cmd == "ABANDON_RUN":
                log(
                    "abandoned run excluded from death quota "
                    f"peak_act={run_peak_act}"
                )
            run_active = False
            terminal_seen = False
            unexpected_menu_polls = 0
            continue
        state = execute_policy_command(cmd, send_command)
    print(summary(state))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
