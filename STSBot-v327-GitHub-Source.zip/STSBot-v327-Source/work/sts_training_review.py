"""Read authoritative run records and replay CommunicationMod decision frames."""

import argparse
import json
from pathlib import Path


def card_label(card):
    return str(card.get("id", "?")) + ("+" if card.get("upgrades", 0) else "")


def decision_frames(path):
    state = None
    with Path(path).open("rb") as stream:
        for line_number, raw_line in enumerate(stream, 1):
            try:
                line = raw_line.decode("utf-8")
            except UnicodeDecodeError:
                line = raw_line.decode("gb18030", errors="replace")
            if "DataWriter> Sending message: " in line:
                payload = line.split("Sending message: ", 1)[1]
                try:
                    state = json.loads(payload)
                except json.JSONDecodeError:
                    state = None
            elif "DataReader> Received message: " in line and state:
                command = line.split("Received message: ", 1)[1].strip()
                yield line_number, state, command


def review(path, seed=None, floor=None, detail=False, snapshot=False):
    previous_room = None
    previous_turn = None
    for line, state, command in decision_frames(path):
        gs = state.get("game_state") or {}
        if seed is not None and str(gs.get("seed")) != str(seed):
            continue
        if floor is not None and gs.get("floor") != floor:
            continue
        if command.startswith(("WAIT", "STATE", "KEY")):
            continue
        combat = gs.get("combat_state") or {}
        if snapshot:
            if "play" in state.get("available_commands", []):
                print(json.dumps(state, ensure_ascii=True))
                return
            continue
        room = (gs.get("seed"), gs.get("floor"))
        if room != previous_room:
            previous_room = room
            previous_turn = None
            print(f"\nseed={room[0]} floor={room[1]} room={gs.get('room_type')} "
                  f"hp={gs.get('current_hp')}/{gs.get('max_hp')}")
            if detail:
                print("deck=" + str([card_label(c) for c in gs.get("deck", [])]))
                print("relics=" + str([r.get("id") for r in gs.get("relics", [])]))
        if command.startswith(("PLAY", "END", "POTION")) and combat:
            turn = combat.get("turn")
            if turn != previous_turn:
                previous_turn = turn
                player = combat.get("player") or {}
                monsters = [
                    {key: m.get(key) for key in (
                        "id", "current_hp", "block", "intent",
                        "move_adjusted_damage", "move_hits", "powers",
                    )}
                    for m in combat.get("monsters", []) if not m.get("is_gone")
                ]
                print(f"turn={turn} player=" + json.dumps(player, ensure_ascii=True))
                print("monsters=" + json.dumps(monsters, ensure_ascii=True))
                print("hand=" + str([(card_label(c), c.get("cost")) for c in combat.get("hand", [])]))
                print("top5=" + str([card_label(c) for c in reversed(combat.get("draw_pile", [])[-5:])]))
                print("potions=" + str([p.get("id") for p in gs.get("potions", [])]))
            parts = command.split()
            label = ""
            if parts[0] == "PLAY" and len(parts) >= 2:
                hand = combat.get("hand", [])
                index = int(parts[1]) - 1
                if 0 <= index < len(hand):
                    label = card_label(hand[index])
            print(f"  line={line} {command} {label}")
        elif detail or gs.get("screen_type") == "GAME_OVER":
            screen = gs.get("screen_state") or {}
            offers = {
                key: screen[key] for key in (
                    "cards", "relics", "next_nodes", "event_id", "victory", "score"
                ) if key in screen
            }
            print(f"  line={line} {gs.get('screen_type')} {command} "
                  + json.dumps(offers, ensure_ascii=True))


def outcome(path):
    run = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    print(json.dumps({"file": str(path), **{
        key: run.get(key) for key in (
            "seed_played", "ascension_level", "victory", "floor_reached",
            "killed_by", "score", "master_deck", "relics", "damage_taken",
            "card_choices", "event_choices", "path_per_floor", "current_hp_per_floor",
            "items_purchased", "item_purchase_floors", "items_purged",
            "campfire_choices", "boss_relics",
        )
    }}, ensure_ascii=True, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-log", type=Path)
    parser.add_argument("--seed")
    parser.add_argument("--floor", type=int)
    parser.add_argument("--detail", action="store_true")
    parser.add_argument("--snapshot", action="store_true")
    parser.add_argument("--run", type=Path, action="append", default=[])
    args = parser.parse_args()
    for path in args.run:
        outcome(path)
    if args.game_log:
        review(args.game_log, args.seed, args.floor, args.detail, args.snapshot)


if __name__ == "__main__":
    main()
