from dataclasses import dataclass, replace
from math import ceil
from typing import Optional

from sts_relic_rules import (
    canonical_relic_id,
    relic_counter,
    relic_ids as canonical_relic_ids,
)


ATTACK_DAMAGE = {
    "Strike_R": (6, 3),
    "Bash": (8, 2),
    "Pommel Strike": (9, 1),
    "Anger": (6, 2),
    "Clothesline": (12, 2),
    "Headbutt": (9, 3),
    "Iron Wave": (5, 2),
    "Cleave": (8, 3),
    "Thunderclap": (4, 3),
    "Uppercut": (13, 0),
    "Carnage": (20, 8),
    "Hemokinesis": (15, 5),
    "Wild Strike": (12, 5),
    "Bludgeon": (32, 10),
    "Immolate": (21, 7),
    "Feed": (10, 2),
    "Reaper": (4, 1),
    "Heavy Blade": (14, 0),
    "Rampage": (8, 0),
    "Sever Soul": (16, 6),
    "Blood for Blood": (18, 4),
    "Swift Strike": (7, 3),
}

MULTI_HIT = {
    "Twin Strike": (5, 2, 2),
}

BLOCK_VALUE = {
    "Defend_R": (5, 3),
    "Shrug It Off": (8, 3),
    "Sentinel": (5, 3),
    "Flame Barrier": (12, 4),
    "Power Through": (15, 5),
    "Impervious": (30, 10),
    "PanicButton": (30, 10),
    "Ghostly Armor": (10, 3),
    "Armaments": (5, 0),
    "True Grit": (7, 2),
    "Iron Wave": (5, 2),
    "Finesse": (2, 2),
}

OPENING_BURST_BLOCK_CARDS = {"Impervious", "PanicButton"}

AOE_ATTACKS = {"Cleave", "Thunderclap", "Whirlwind", "Immolate", "Reaper"}
SPLIT_SLIME_IDS = {"SlimeBoss", "AcidSlime_L", "SpikeSlime_L"}
DRAW_VALUES = {
    "Adrenaline": (2, 0),
    "Battle Trance": (3, 1),
    "Burning Pact": (2, 1),
    "Deep Breath": (1, 1),
    "Dropkick": (1, 0),
    "Finesse": (1, 0),
    "Flash of Steel": (1, 0),
    "Impatience": (2, 0),
    "Master of Strategy": (3, 1),
    "Pommel Strike": (1, 1),
    "Shrug It Off": (1, 0),
    "Thinking Ahead": (2, 0),
    "Warcry": (1, 1),
}

# Armaments+ upgrades cards already in hand. These upgrades reduce the live
# cost as well as changing damage, block, draw, or debuff values.
UPGRADE_COST_REDUCTION_CARDS = {
    "Barricade", "Blood for Blood", "Body Slam", "Corruption",
    "Dark Embrace", "Entrench", "Havoc", "Infernal Blade", "Seeing Red",
}

ARMAMENTS_UPGRADE_PRIORITY = {
    "Bash": 80,
    "Armaments": 78,
    "Offering": 76,
    "Inflame": 74,
    "Demon Form": 72,
    "Evolve": 72,
    "Pommel Strike": 70,
    "Fire Breathing": 70,
    "Shrug It Off": 68,
    "Power Through": 68,
    "True Grit": 66,
    "Uppercut": 64,
    "Disarm": 62,
    "Shockwave": 60,
    "Perfected Strike": 58,
    "Whirlwind": 58,
    "Defend_R": 20,
    "Strike_R": 5,
}

SAFE_POWER_VALUES = {
    "Barricade": 14,
    "Corruption": 16,
    "Dark Embrace": 11,
    "Demon Form": 22,
    "Evolve": 9,
    "Feel No Pain": 11,
    "Fire Breathing": 9,
    "Inflame": 12,
    "Juggernaut": 12,
    "Metallicize": 10,
    "Rupture": 8,
    "Sadistic Nature": 8,
}

# Curiosity is a cost, not a reason to leave a functioning engine unplayed.
# These values are only awarded when the deck actually supports the Power.
AWAKENED_KEY_POWER_VALUES = {
    "Corruption": 46,
    "Dark Embrace": 38,
    "Feel No Pain": 38,
    "Demon Form": 42,
    "Barricade": 38,
    "Juggernaut": 32,
    "Fire Breathing": 32,
    "Evolve": 28,
    "Inflame": 30,
    "Rupture": 30,
    "Metallicize": 18,
}

STATUS_ENGINE_SOURCES = {
    "Power Through", "Wild Strike", "Reckless Charge", "Immolate",
    "Injury", "Wound", "Burn", "Dazed",
}

ENERGY_RELIC_IDS = {
    "Busted Crown", "Coffee Dripper", "Cursed Key", "Ectoplasm",
    "Fusion Hammer", "Mark of Pain", "Philosopher's Stone", "Runic Dome",
    "Sozu", "Velvet Choker",
}

MUMMIFIED_HAND_IDS = {"Mummified Hand", "MummifiedHand"}

# Mummified Hand checks both a card's base cost and its current turn cost.
# CommunicationMod only exposes the current cost, so retain the native and
# upgraded zero-cost exceptions that Snecko can temporarily make expensive.
NATIVE_ZERO_COST_CARD_IDS = {
    "Anger", "Bandage Up", "Blind", "Bloodletting", "Clash",
    "Dark Shackles", "Deep Breath", "Dramatic Entrance", "Enlightenment",
    "Finesse", "Flash of Steel", "Flex", "Forethought",
    "Good Instincts", "Impatience", "J.A.X.", "Master of Strategy",
    "Offering", "Panacea", "Purity", "Secret Technique", "Secret Weapon",
    "Swift Strike", "Thinking Ahead", "Trip", "Violence", "Warcry",
}
UPGRADED_ZERO_COST_CARD_IDS = {
    "Body Slam", "Discovery", "Havoc", "Infernal Blade", "Madness",
    "Seeing Red",
}

SELF_DAMAGE_ENGINE_SOURCES = {
    "Bloodletting", "Brutality", "Combust", "Hemokinesis",
    "Offering", "J.A.X.", "Pain",
}

FIEND_FIRE_CORE_EXHAUST_VALUES = {
    # Fiend Fire's displayed damage does not include the opportunity cost of
    # deleting the rest of the hand.  Preserve engines, recovery and the cards
    # that make the next cycle functional unless the attack really ends the
    # fight or removes immediate lethal damage.
    "Demon Form": 70,
    "Ghostly": 70,
    "Corruption": 68,
    "Reaper": 62,
    "Immolate": 60,
    "Dark Embrace": 58,
    "Feel No Pain": 58,
    "Fire Breathing": 55,
    "Evolve": 48,
    "Offering": 48,
    "Double Tap": 46,
    "Impervious": 45,
    "Power Through": 42,
    "Heavy Blade": 42,
    "Whirlwind": 42,
    "Feed": 40,
    "Limit Break": 38,
    "Spot Weakness": 34,
    "Dark Shackles": 34,
    "Disarm": 32,
    "Shockwave": 30,
    "Bash": 28,
    "Flame Barrier": 28,
    "Uppercut": 26,
    "Pommel Strike": 20,
    "Second Wind": 44,
    "Cleave": 16,
}

SECOND_WIND_CORE_EXHAUST_VALUES = {
    "Offering": 45,
    "Ghostly": 45,
    "Corruption": 36,
    "Demon Form": 36,
    "Dark Embrace": 30,
    "Feel No Pain": 30,
    "Impervious": 30,
    "Shockwave": 28,
    "Disarm": 28,
    "Limit Break": 28,
    "Battle Trance": 18,
    "Burning Pact": 16,
}

BRONZE_STASIS_KEY_CARDS = {
    "Corruption", "Demon Form", "Disarm", "Fiend Fire", "Ghostly", "Immolate", "Impervious",
    "Offering", "Power Through", "Reaper", "Shockwave", "Spot Weakness",
}
BRONZE_PREBEAM_RELEASE_CARDS = {"Corruption", "Disarm", "Immolate"}

NONSTACKING_POWER_IDS = {"Barricade", "Corruption"}

BARRICADE_SUPPORT_WEIGHTS = {
    "Impervious": 3,
    "Entrench": 3,
    "Power Through": 2,
    "Flame Barrier": 2,
    "Second Wind": 2,
    "Shrug It Off": 1,
    "Ghostly Armor": 1,
    "Body Slam": 1,
}

RISKY_POWER_HP_THRESHOLDS = {
    "Berserk": 0.70,
    "Brutality": 0.50,
    "Combust": 0.45,
}

LONG_BOSS_IDS = {"TheGuardian", "Champ", "Hexaghost", "TheCollector"}
STRIKE_CARD_IDS = {
    "Strike_R", "Perfected Strike", "Pommel Strike", "Swift Strike",
    "Twin Strike", "Wild Strike",
}
REPEATABLE_EXHAUST_SOURCES = {"Burning Pact", "True Grit", "Havoc"}
MASS_EXHAUST_SOURCES = {"Corruption", "Second Wind", "Fiend Fire", "Sever Soul"}
ONE_SHOT_EXHAUST_SOURCES = {
    "Offering", "Impervious", "Disarm", "Shockwave", "Intimidate", "Exhume",
    "Ghostly",
}


REVIVE_POTION_IDS = {"FairyPotion", "Fairy in a Bottle"}
REVIVE_RELIC_IDS = {"Lizard Tail", "LizardTail"}
MARK_OF_BLOOM_IDS = {"Mark of the Bloom", "MarkOfTheBloom"}

ORANGE_PELLETS_DEBUFF_IDS = {
    "Bias", "Confusion", "Constricted", "Draw Reduction", "Entangled",
    "Frail", "Hex", "No Block", "No Draw", "Vulnerable", "Weakened",
}
ORANGE_ATTACK = 1
ORANGE_SKILL = 2
ORANGE_POWER = 4


def _canonical_potion_id(potion):
    raw = (potion or {}).get("id") or (potion or {}).get("name") or ""
    key = "".join(ch for ch in str(raw).lower() if ch.isalnum())
    if key in {"fairypotion", "fairyinabottle"}:
        return "FairyPotion"
    return str(raw)


def _revive_reserve_hp(gs):
    gs = gs or {}
    relic_ids = {
        relic.get("id") or relic.get("name") or ""
        for relic in gs.get("relics", [])
    }
    if relic_ids & MARK_OF_BLOOM_IDS:
        return 0
    max_hp = max(1, int(gs.get("max_hp", 1) or 1))
    sacred_bark = bool(relic_ids & {"SacredBark", "Sacred Bark"})
    reserve = sum(
        max(1, int(max_hp * (0.60 if sacred_bark else 0.30)))
        for potion in gs.get("potions", [])
        if _canonical_potion_id(potion) == "FairyPotion"
    )
    for relic in gs.get("relics", []):
        rid = relic.get("id") or relic.get("name") or ""
        if rid not in REVIVE_RELIC_IDS:
            continue
        if relic.get("used_up") or relic.get("usedUp") or relic.get("grayscale"):
            continue
        counter = relic.get("counter")
        # CommunicationMod exposes an unused Lizard Tail as -1 and changes it
        # to -2 after revival. Other adapters may use zero for the spent state.
        if counter == 0 or (
            isinstance(counter, (int, float)) and counter <= -2
        ):
            continue
        reserve += max(1, int(max_hp * 0.50))
    return reserve


def _power_amount(powers, power_id):
    for pid, amount in powers:
        if pid == power_id:
            return amount
    return 0


def _imminent_exploder(monster):
    return (
        monster.monster_id == "Exploder"
        and (
            "EXPLODE" in monster.intent
            or 0 < _power_amount(monster.powers, "Explosive") <= 1
        )
    )


def _quiet_snake_plant_weak_credit(monster, weak_amount):
    if monster.monster_id != "SnakePlant" or "ATTACK" in monster.intent:
        return 0
    # One Weak charge expires on the current non-attack turn. Each remaining
    # charge prevents roughly two damage on all three hits of the next attack.
    return max(0, weak_amount - 1) * 6


def _quiet_chosen_shockwave_credit(monster, weak_amount):
    if monster.monster_id != "Chosen" or "ATTACK" in monster.intent:
        return 0
    # One charge expires on Hex. The remaining Weak and Vulnerable cover the
    # next pressure turns, when spending two energy on Shockwave is hardest.
    return max(0, weak_amount - 1) * 5


def power_amount(powers, power_id):
    return _power_amount(powers, power_id)


def _set_power(powers, power_id, amount):
    values = [(pid, value) for pid, value in powers if pid != power_id]
    if amount:
        values.append((power_id, amount))
    return tuple(sorted(values))


@dataclass(frozen=True)
class CardState:
    card_id: str
    card_type: str
    cost: int
    upgrades: int
    has_target: bool
    is_playable: bool
    exhausts: bool
    ethereal: bool
    uuid: str


@dataclass(frozen=True)
class MonsterState:
    original_index: int
    monster_id: str
    hp: int
    max_hp: int
    initial_hp: int
    block: int
    initial_block: int
    intent: str
    damage: int
    hits: int
    initial_intent: str
    initial_damage: int
    initial_hits: int
    initial_flight: int
    initial_artifact: int
    powers: tuple
    stasis_card: Optional[CardState] = None

    @property
    def alive(self):
        return self.hp > 0


@dataclass(frozen=True)
class CombatModel:
    hp: int
    max_hp: int
    initial_hp: int
    revive_hp: int
    initial_revive_hp: int
    block: int
    energy: int
    player_powers: tuple
    monsters: tuple
    hand: tuple
    draw_pile: tuple
    exhaust_pile: tuple
    initial_enemy_hp: int
    initial_persistent_block: int
    initial_guardian_curl_block: int
    turn: int
    drawable_cards: int
    pocketwatch_counter: int
    velvet_choker_counter: int
    initial_incoming: int
    initial_strength: int
    initial_block: int
    next_turn_energy: int
    act: int
    ascension: int
    initial_time_warp: int
    known_next_attack_damage: int = 0
    double_boss_reserve: bool = False
    runic_cube: bool = False
    has_boot: bool = False
    paper_frog: bool = False
    chemical_x: bool = False
    orichalcum: bool = False
    calipers: bool = False
    charons_ashes: bool = False
    pen_nib_counter: int = -1
    pen_nib_ready: bool = False
    commands: tuple = ()
    self_damage: int = 0
    scaling: int = 0
    statuses_added: int = 0
    draw_value: int = 0
    future_risk: int = 0
    slime_split_hp: int = 0
    slime_debuff_scaling: int = 0
    strength_debuff_scaling: int = 0
    junk_exhausted: int = 0
    risky_power_credit: int = 0
    champ_race: bool = False
    champ_forced_release: bool = False
    persistent_block_race: bool = False
    delay_corruption: bool = False
    conserve_exhaust_defense: bool = False
    strike_cards: int = 0
    attack_cards: int = 0
    exhaust_power_ready: bool = False
    barricade_support: int = 0
    offensive_scaling: int = 0
    limit_break_timing_credit: int = 0
    exhaust_power_scaling: int = 0
    status_aoe_setup_credit: int = 0
    resource_risk: int = 0
    feed_max_hp_gain: int = 0
    reaper_scaling_reserve: bool = False
    time_eater_haste_guard: bool = False
    status_power_ready: bool = False
    self_damage_power_ready: bool = False
    curse_exhaust_payoff_ready: bool = False
    awakened_key_power_credit: int = 0
    awakened_curiosity_risk: int = 0
    bronze_orb_cleanup_credit: int = 0
    initial_support_hp: int = 0
    initial_support_block_available: bool = False
    initial_burst_block_available: bool = False
    support_cleanup_encounter: bool = False
    brimstone_race: bool = False
    combust_hp_loss: int = 0
    mummified_hand: bool = False
    mummified_hand_credit: int = 0
    abacus: bool = False
    art_of_war: bool = False
    attacks_played: int = 0
    bird_faced_urn: bool = False
    blue_candle: bool = False
    centennial_puzzle_available: bool = False
    champion_belt: bool = False
    dead_branch: bool = False
    gremlin_horn: bool = False
    hand_drill: bool = False
    happy_flower_counter: int = -1
    healing_disabled: bool = False
    ice_cream: bool = False
    incense_burner_counter: int = -1
    ink_bottle_counter: int = -1
    kunai_counter: int = -1
    letter_opener_counter: int = -1
    magic_flower: bool = False
    necronomicon: bool = False
    necronomicon_available: bool = False
    nunchaku_counter: int = -1
    orange_pellets: bool = False
    orange_pellets_mask: int = 0
    ornamental_fan_counter: int = -1
    random_card_credit: int = 0
    red_skull: bool = False
    self_forming_clay: bool = False
    self_forming_clay_block: int = 0
    shuriken_counter: int = -1
    stone_calendar_ready: bool = False
    strange_spoon: bool = False
    strike_dummy: bool = False
    sundial_counter: int = -1
    torii: bool = False
    tungsten_rod: bool = False
    unceasing_top: bool = False

    @property
    def strength(self):
        return _power_amount(self.player_powers, "Strength")

    @property
    def dexterity(self):
        return _power_amount(self.player_powers, "Dexterity")

    @property
    def weak(self):
        return bool(_power_amount(self.player_powers, "Weakened"))

    @property
    def frail(self):
        return bool(_power_amount(self.player_powers, "Frail"))

    @property
    def incoming(self):
        intangible = bool(_power_amount(self.player_powers, "IntangiblePlayer"))
        attack_damage = sum(
            (
                max(1, monster.hits)
                if intangible
                else max(0, monster.damage) * max(1, monster.hits)
            )
            for monster in self.monsters
            if monster.alive and "ATTACK" in monster.intent
        )
        # CommunicationMod reports the final Exploder countdown as UNKNOWN
        # with Explosive=1. Its 30 damage is neither an ATTACK nor reducible by
        # Weak, but it still lands at end of turn unless the Exploder dies.
        return attack_damage + sum(
            1 if intangible else 30
            for monster in self.monsters
            if monster.alive and _imminent_exploder(monster)
        )


@dataclass(frozen=True)
class TurnPlan:
    commands: tuple
    hp_loss: int
    score: tuple


def _parse_powers(raw_powers):
    return tuple(
        sorted(
            (
                power.get("id") or power.get("name") or "",
                int(power.get("amount", 0) or 0),
            )
            for power in raw_powers or []
        )
    )


def _card_state_from_raw(raw, index, prefix, initial_energy):
    card_type = raw.get("type") or ""
    cost = int(raw.get("cost", 0) or 0)
    # CommunicationMod can mark a card false solely because its current cost
    # exceeds current energy. Energy generation inside the same search may make
    # it legal later, so retain only genuine rule restrictions.
    energy_limited = (
        card_type in {"ATTACK", "SKILL", "POWER"}
        and cost >= 0
        and cost > initial_energy
    )
    # CommunicationMod reports every card outside the hand as unplayable.
    # Draw-pile cards become legal once drawn, so preserve their visible order
    # and let the simulated post-draw hand evaluate them normally.
    drawable_card = prefix in {"draw", "stasis"} and card_type in {
        "ATTACK", "SKILL", "POWER"
    }
    return CardState(
        card_id=raw.get("id") or raw.get("name") or "",
        card_type=card_type,
        cost=cost,
        upgrades=int(raw.get("upgrades", 0) or 0),
        has_target=bool(raw.get("has_target")),
        is_playable=(
            bool(raw.get("is_playable", True))
            or energy_limited
            or drawable_card
        ),
        exhausts=bool(raw.get("exhausts")),
        ethereal=bool(raw.get("ethereal")),
        uuid=raw.get("uuid") or f"{prefix}-{raw.get('id', '')}-{index}",
    )


def _stasis_card_from_raw(raw_monster, index, initial_energy):
    for power in raw_monster.get("powers") or []:
        if (power.get("id") or power.get("name")) != "Stasis":
            continue
        held = power.get("card") or {}
        if held:
            return _card_state_from_raw(
                held, index, "stasis", initial_energy
            )
    return None


def _exhaust_power_engine_ready(gs, player_powers):
    deck = (gs or {}).get("deck", [])
    deck_ids = [
        raw.get("id") or raw.get("name") or ""
        for raw in deck
    ]
    relic_ids = {
        raw.get("id") or raw.get("name") or ""
        for raw in (gs or {}).get("relics", [])
    }
    active_ids = {
        raw.get("id") or raw.get("name") or ""
        for raw in player_powers or []
    }
    if "Corruption" in active_ids or "Corruption" in deck_ids:
        return True
    if relic_ids & {"Dead Branch", "CharonsAshes", "Charon's Ashes"}:
        return True
    if set(deck_ids) & (
        REPEATABLE_EXHAUST_SOURCES
        | (MASS_EXHAUST_SOURCES - {"Corruption", "Second Wind"})
    ):
        return True
    status_sources = {
        "Power Through", "Wild Strike", "Reckless Charge", "Immolate",
        "Injury", "Wound", "Burn", "Dazed",
    }
    if "Second Wind" in deck_ids and any(
        card_id in status_sources or raw.get("type") in {"STATUS", "CURSE"}
        for card_id, raw in zip(deck_ids, deck)
    ):
        return True
    return sum(card_id in ONE_SHOT_EXHAUST_SOURCES for card_id in deck_ids) >= 3


def _awakened_curiosity_live(model):
    return any(
        monster.monster_id == "AwakenedOne"
        and monster.alive
        and _power_amount(monster.powers, "Curiosity") > 0
        for monster in model.monsters
    )


def _awakened_active_power_count(model):
    """Estimate how many persistent card Powers are already online."""
    tracked = (
        set(SAFE_POWER_VALUES)
        | set(AWAKENED_KEY_POWER_VALUES)
        | set(RISKY_POWER_HP_THRESHOLDS)
    )
    return sum(
        _power_amount(model.player_powers, power_id) != 0
        for power_id in tracked
    )


def _awakened_cultist_clearance_pending(model):
    """Return whether current attacks can work on both opening Cultists."""
    living_cultists = [
        monster for monster in model.monsters
        if monster.monster_id == "Cultist" and monster.alive
    ]
    if len(living_cultists) < 2:
        return False
    playable_attack = any(
        card.card_type == "ATTACK"
        and card.is_playable
        and _card_cost(card, model) <= model.energy
        for card in model.hand
    )
    # Same-turn replanning happens after every command. Keep the opening target
    # lock after those attacks leave the hand, or Demon Form immediately regains
    # its setup credit while both damaged Cultists are still alive.
    cultist_progress = any(
        monster.hp < monster.initial_hp for monster in living_cultists
    )
    return playable_attack or cultist_progress


def _awakened_key_power_value(model, card):
    """Return setup credit for a supported engine Power against Awakened One."""
    if card.card_type != "POWER" or not _awakened_curiosity_live(model):
        return 0
    if _power_amount(model.player_powers, card.card_id) != 0:
        return 0

    value = AWAKENED_KEY_POWER_VALUES.get(card.card_id, 0)
    if value <= 0:
        return 0
    if (
        card.card_id in {"Corruption", "Dark Embrace", "Feel No Pain"}
        and not model.exhaust_power_ready
    ):
        return 0
    if (
        card.card_id in {"Evolve", "Fire Breathing"}
        and not model.status_power_ready
    ):
        return 0
    if model.brimstone_race and card.card_id in {"Evolve", "Fire Breathing"}:
        # Brimstone already gives Awakened One Strength every round. Feeding
        # Curiosity for a slow status payoff compounds that clock too quickly.
        return 0
    if (
        model.brimstone_race
        and card.card_id in {"Demon Form", "Inflame", "Rupture"}
    ):
        # Brimstone is already the Strength engine. Spending another draw and
        # energy on redundant scaling also gives Awakened One permanent
        # Curiosity Strength, so it receives no key-Power setup credit.
        return 0
    if (
        card.card_id in {"Barricade", "Juggernaut"}
        and model.barricade_support < 2
    ):
        return 0
    if card.card_id == "Rupture" and not model.self_damage_power_ready:
        return 0
    if card.card_id == "Demon Form":
        # Demon Form is worth feeding Curiosity only while there is enough fight
        # left for its Strength to matter.
        living_boss = next(
            (
                monster for monster in model.monsters
                if monster.monster_id == "AwakenedOne" and monster.alive
            ),
            None,
        )
        if living_boss is None or living_boss.hp <= max(70, living_boss.max_hp // 4):
            return 0
        if _awakened_cultist_clearance_pending(model):
            # The logged A16 opener spent three of six energy on Demon Form
            # while both Cultists were still alive. Their first attack cycle
            # consumed the HP reserve before the Strength engine could repay
            # Curiosity. Clear one Cultist whenever this hand can make progress;
            # a no-attack hand may still use the genuine setup window.
            return 0

    hp_ratio = model.hp / max(1, model.max_hp)
    active_powers = _awakened_active_power_count(model)
    # One supported engine Power can justify Curiosity while healthy. Once an
    # engine is online, optional follow-up Powers rapidly lose value; at low HP
    # they receive no speculative setup credit at all.
    if hp_ratio < 0.25 or hp_ratio < 0.45 and active_powers:
        return 0
    if active_powers >= 2:
        value //= 4
    elif active_powers == 1:
        value //= 2
    if hp_ratio < 0.55:
        value //= 2
    return value + 2 * min(card.upgrades, 1)


def _awakened_optional_power_uses_reserved_curiosity(model, hand_index):
    """Reserve first-phase Curiosity for a supported engine Power."""
    card = model.hand[hand_index]
    if card.card_type != "POWER" or not _awakened_curiosity_live(model):
        return False
    if _awakened_key_power_value(model, card) > 0:
        return False
    if card.card_id not in RISKY_POWER_HP_THRESHOLDS:
        # Supported engine Powers can lose long-term score at low HP while
        # still enabling immediate Feel No Pain, Dark Embrace, or Corruption
        # interactions in the current hand. Leave those to the exact planner;
        # this reservation is for optional side-effect setup.
        return False

    if card.card_id == "Combust":
        combust_damage = 5 + 2 * min(card.upgrades, 1)
        if any(monster.alive and monster.hp <= combust_damage for monster in model.monsters):
            return False

    if _awakened_active_power_count(model) > 0:
        return True
    return any(
        index != hand_index
        and candidate.is_playable
        and _card_cost(candidate, model) <= model.energy
        and _awakened_key_power_value(model, candidate) > 0
        for index, candidate in enumerate(model.hand)
    )


def _relic_available(gs, relic_id):
    wanted = canonical_relic_id(relic_id)
    for relic in (gs or {}).get("relics", []):
        current = canonical_relic_id(relic.get("id") or relic.get("name"))
        if current != wanted:
            continue
        return not bool(
            relic.get("used_up")
            or relic.get("usedUp")
            or relic.get("grayscale")
        )
    return False


def build_model(combat, gs=None):
    player = combat.get("player") or {}
    initial_energy = int(player.get("energy", 0) or 0)
    raw_monsters = combat.get("monsters") or []
    monsters = []
    for index, raw in enumerate(raw_monsters):
        if raw.get("is_gone") or raw.get("half_dead") or int(raw.get("current_hp", 0) or 0) <= 0:
            continue
        powers = _parse_powers(raw.get("powers"))
        monsters.append(
            MonsterState(
                original_index=index,
                monster_id=raw.get("id") or raw.get("name") or "",
                hp=int(raw.get("current_hp", 0) or 0),
                max_hp=int(raw.get("max_hp", raw.get("current_hp", 0)) or 0),
                initial_hp=int(raw.get("current_hp", 0) or 0),
                block=int(raw.get("block", 0) or 0),
                initial_block=int(raw.get("block", 0) or 0),
                intent=raw.get("intent") or "",
                damage=int(raw.get("move_adjusted_damage", -1) or -1),
                hits=max(1, int(raw.get("move_hits", 1) or 1)),
                initial_intent=raw.get("intent") or "",
                initial_damage=int(raw.get("move_adjusted_damage", -1) or -1),
                initial_hits=max(1, int(raw.get("move_hits", 1) or 1)),
                initial_flight=max(0, _power_amount(powers, "Flight")),
                initial_artifact=max(0, _power_amount(powers, "Artifact")),
                powers=powers,
                stasis_card=_stasis_card_from_raw(
                    raw, index, initial_energy
                ),
            )
        )
    hand = tuple(
        _card_state_from_raw(raw, index, "hand", initial_energy)
        for index, raw in enumerate(combat.get("hand") or [])
    )
    # CommunicationMod exposes the bottom of the pile first and the next card
    # at the end. Keep that orientation so deterministic draws pop from here.
    draw_pile = tuple(
        _card_state_from_raw(raw, index, "draw", initial_energy)
        for index, raw in enumerate(combat.get("draw_pile") or [])
    )
    exhaust_pile = tuple(
        _card_state_from_raw(raw, index, "exhaust", initial_energy)
        for index, raw in enumerate(combat.get("exhaust_pile") or [])
    )
    hp = int(player.get("current_hp", (gs or {}).get("current_hp", 1)) or 1)
    combust_hp_loss = next(
        (
            max(1, int(raw.get("misc", 1) or 1))
            for raw in player.get("powers", [])
            if (raw.get("id") or raw.get("name")) == "Combust"
            and int(raw.get("amount", 0) or 0) > 0
        ),
        0,
    )
    slime_split_hp = max(
        (
            monster.hp
            for monster in monsters
            if monster.monster_id in SPLIT_SLIME_IDS
            and monster.hp <= monster.max_hp // 2
        ),
        default=0,
    )
    champ_race = any(
        monster.monster_id == "Champ" and monster.hp <= monster.max_hp // 2
        for monster in monsters
    )
    initial_persistent_block = sum(
        monster.block
        for monster in monsters
        if (
            _power_amount(monster.powers, "Barricade")
            or _power_amount(monster.powers, "Plated Armor")
        )
    )
    initial_guardian_curl_block = sum(
        monster.block
        for monster in monsters
        if monster.monster_id == "TheGuardian" and _power_amount(monster.powers, "Sharp Hide")
    )
    deck_ids = {raw.get("id") or raw.get("name") for raw in (gs or {}).get("deck", [])}
    relic_ids = canonical_relic_ids(gs or {})
    relic_memory = (gs or {}).get("_bot_relic_memory") or {}
    pocketwatch_counter = next(
        (
            int(raw.get("counter", 0) or 0)
            for raw in (gs or {}).get("relics", [])
            if (raw.get("id") or raw.get("name")) == "Pocketwatch"
        ),
        -1,
    )
    velvet_choker_counter = next(
        (
            int(raw.get("counter", 0) or 0)
            for raw in (gs or {}).get("relics", [])
            if (raw.get("id") or raw.get("name")) == "Velvet Choker"
        ),
        -1,
    )
    pen_nib_counter = next(
        (
            int(raw.get("counter", -1) or 0)
            for raw in (gs or {}).get("relics", [])
            if (raw.get("id") or raw.get("name")) == "Pen Nib"
        ),
        -1,
    )
    visible_card_ids = {
        raw.get("id") or raw.get("name") or ""
        for pile in (
            combat.get("hand") or [],
            combat.get("draw_pile") or [],
            combat.get("discard_pile") or [],
            combat.get("exhaust_pile") or [],
        )
        for raw in pile
    }
    all_known_card_ids = deck_ids | visible_card_ids
    available_card_ids = {
        raw.get("id") or raw.get("name") or ""
        for pile in (
            combat.get("hand") or [],
            combat.get("draw_pile") or [],
            combat.get("discard_pile") or [],
        )
        for raw in pile
    }
    active_power_ids = {
        raw.get("id") or raw.get("name") or ""
        for raw in player.get("powers", [])
        if int(raw.get("amount", 0) or 0) != 0
    }
    corruption_payoffs = {"Feel No Pain", "Dark Embrace"}
    corruption_payoff_waiting = any(
        (raw.get("id") or raw.get("name")) in corruption_payoffs
        for raw in combat.get("hand", [])
    )
    corruption_payoff_active = bool(
        active_power_ids & corruption_payoffs
        or "Dead Branch" in relic_ids
    )
    combat_turn = max(1, int(combat.get("turn", 1) or 1))
    early_long_boss = any(
        (
            monster.monster_id in LONG_BOSS_IDS
            or monster.monster_id == "BronzeAutomaton"
        )
        and monster.hp > int(monster.max_hp * 0.45)
        for monster in monsters
    ) and combat_turn <= 4
    early_nemesis_resource_race = any(
        monster.alive
        and monster.monster_id == "Nemesis"
        and monster.hp > monster.max_hp // 2
        for monster in monsters
    ) and combat_turn <= 4
    champ_deep_first_phase = any(
        monster.monster_id == "Champ"
        and monster.hp > int(monster.max_hp * 0.65)
        for monster in monsters
    )
    long_boss_resource_race = any(
        monster.alive
        and (
            (
                monster.monster_id in LONG_BOSS_IDS
                or monster.monster_id == "BronzeAutomaton"
            )
            and monster.hp > monster.max_hp // 2
            or monster.monster_id in {"GiantHead", "GremlinLeader"}
            or (
                monster.monster_id == "Nemesis"
                and monster.hp > monster.max_hp // 2
            )
        )
        for monster in monsters
    ) and "Dead Branch" not in relic_ids
    quiet_spiker_resource_race = (
        any(monster.monster_id == "Spiker" for monster in monsters)
        and not any("ATTACK" in monster.intent for monster in monsters)
    )
    player_max_hp = int(player.get("max_hp", (gs or {}).get("max_hp", hp)) or hp)
    revive_state = dict(gs or {})
    revive_state.setdefault("max_hp", player_max_hp)
    revive_reserve = _revive_reserve_hp(revive_state)
    energy_relics = sum(
        (raw.get("id") or raw.get("name")) in ENERGY_RELIC_IDS
        for raw in (gs or {}).get("relics", [])
    )
    slavers_collar = any(
        (raw.get("id") or raw.get("name")) == "SlaversCollar"
        for raw in (gs or {}).get("relics", [])
    )
    next_turn_energy = 3 + energy_relics
    if slavers_collar and any(
        monster.monster_id in {
            "BookOfStabbing", "BronzeAutomaton", "Champ", "GremlinLeader",
            "GremlinNob", "Hexaghost", "Lagavulin", "SlimeBoss",
            "Sentry", "TheCollector", "TheGuardian",
        }
        for monster in monsters
    ):
        next_turn_energy += 1
    next_turn_energy += max(0, _power_amount(_parse_powers(player.get("powers")), "Berserk"))
    model = CombatModel(
        hp=hp,
        max_hp=player_max_hp,
        initial_hp=hp,
        revive_hp=revive_reserve,
        initial_revive_hp=revive_reserve,
        block=int(player.get("block", 0) or 0),
        energy=initial_energy,
        player_powers=_parse_powers(player.get("powers")),
        monsters=tuple(monsters),
        hand=hand,
        draw_pile=draw_pile,
        exhaust_pile=exhaust_pile,
        initial_enemy_hp=sum(monster.hp for monster in monsters),
        initial_support_hp=sum(
            monster.hp
            for monster in monsters
            if monster.monster_id in {"Healer", "Mystic"}
        ),
        initial_support_block_available=any(
            hand_card.card_id in BLOCK_VALUE
            and hand_card.is_playable
            and max(0, hand_card.cost) <= initial_energy
            for hand_card in hand
        ),
        initial_burst_block_available=any(
            hand_card.card_id in OPENING_BURST_BLOCK_CARDS
            and hand_card.is_playable
            and max(0, hand_card.cost) <= initial_energy
            for hand_card in hand
        ),
        support_cleanup_encounter=(
            any(
                (raw.get("id") or raw.get("name")) in {"Healer", "Mystic"}
                and (
                    raw.get("is_gone")
                    or raw.get("half_dead")
                    or int(raw.get("current_hp", 0) or 0) <= 0
                )
                for raw in raw_monsters
            )
            and any(
                (raw.get("id") or raw.get("name")) not in {"Healer", "Mystic"}
                and not raw.get("is_gone")
                and not raw.get("half_dead")
                and int(raw.get("current_hp", 0) or 0) > 0
                for raw in raw_monsters
            )
        ),
        initial_persistent_block=initial_persistent_block,
        initial_guardian_curl_block=initial_guardian_curl_block,
        turn=max(1, int(combat.get("turn", 1) or 1)),
        drawable_cards=len(combat.get("draw_pile") or []) + len(combat.get("discard_pile") or []),
        pocketwatch_counter=pocketwatch_counter,
        velvet_choker_counter=velvet_choker_counter,
        pen_nib_counter=pen_nib_counter,
        pen_nib_ready=bool(
            _power_amount(_parse_powers(player.get("powers")), "Pen Nib")
        ),
        initial_incoming=sum(
            max(0, monster.damage) * max(1, monster.hits)
            for monster in monsters
            if monster.alive and "ATTACK" in monster.intent
        ) + sum(
            30
            for monster in monsters
            if monster.alive and _imminent_exploder(monster)
        ),
        initial_strength=_power_amount(
            _parse_powers(player.get("powers")), "Strength"
        ),
        initial_block=int(player.get("block", 0) or 0),
        next_turn_energy=max(initial_energy, next_turn_energy),
        act=int((gs or {}).get("act", 1) or 1),
        ascension=int((gs or {}).get("ascension_level", 0) or 0),
        double_boss_reserve=(
            int((gs or {}).get("ascension_level", 0) or 0) >= 20
            and int((gs or {}).get("act", 1) or 1) == 3
            and int((gs or {}).get("floor", 0) or 0) == 50
        ),
        runic_cube=bool(relic_ids & {"Runic Cube", "RunicCube"}),
        has_boot="Boot" in relic_ids,
        paper_frog=bool(relic_ids & {"Paper Frog", "PaperFrog"}),
        chemical_x="Chemical X" in relic_ids,
        orichalcum="Orichalcum" in relic_ids,
        calipers="Calipers" in relic_ids,
        charons_ashes=bool(
            relic_ids & {"CharonsAshes", "Charon's Ashes"}
        ),
        initial_time_warp=max(
            (
                _power_amount(monster.powers, "Time Warp")
                for monster in monsters
                if monster.monster_id == "TimeEater"
            ),
            default=0,
        ),
        slime_split_hp=slime_split_hp,
        champ_race=champ_race,
        persistent_block_race=initial_persistent_block > 0,
        delay_corruption=(
            (
                early_long_boss
                or early_nemesis_resource_race
                or champ_deep_first_phase
            )
            and not corruption_payoff_active
            and (
                corruption_payoff_waiting
                or "Feel No Pain" not in deck_ids
            )
        ),
        conserve_exhaust_defense=(
            long_boss_resource_race or quiet_spiker_resource_race
        ),
        strike_cards=sum(
            1
            for raw in (gs or {}).get("deck", [])
            if (raw.get("id") or raw.get("name")) in STRIKE_CARD_IDS
        ),
        attack_cards=sum(
            1
            for pile in (
                combat.get("hand") or [],
                combat.get("draw_pile") or [],
                combat.get("discard_pile") or [],
            )
            for raw in pile
            if raw.get("type") == "ATTACK"
        ),
        exhaust_power_ready=_exhaust_power_engine_ready(gs, player.get("powers")),
        barricade_support=sum(
            BARRICADE_SUPPORT_WEIGHTS.get(raw.get("id") or raw.get("name"), 0)
            for raw in (gs or {}).get("deck", [])
        ),
        time_eater_haste_guard=any(
            monster.monster_id == "TimeEater"
            and monster.hp > monster.max_hp // 2
            for monster in monsters
        ),
        status_power_ready=bool(
            all_known_card_ids & STATUS_ENGINE_SOURCES
            or any(
                raw.get("type") == "STATUS"
                or (
                    raw.get("type") == "CURSE"
                    and (raw.get("id") or raw.get("name")) != "AscendersBane"
                )
                for pile in (
                    combat.get("hand") or [],
                    combat.get("draw_pile") or [],
                    combat.get("discard_pile") or [],
                )
                for raw in pile
            )
        ),
        self_damage_power_ready=bool(
            all_known_card_ids & SELF_DAMAGE_ENGINE_SOURCES
        ),
        curse_exhaust_payoff_ready=bool(
            active_power_ids & {"Rupture", "Feel No Pain", "Dark Embrace"}
            or relic_ids & {
                "CharonsAshes", "Charon's Ashes", "Runic Cube",
                "Self Forming Clay",
            }
        ),
        reaper_scaling_reserve=(
            "Reaper" in available_card_ids
            and (
                bool(
                    available_card_ids
                    & {"Demon Form", "Inflame", "Spot Weakness"}
                )
                or "Demon Form" in active_power_ids
                or (
                    "Limit Break" in available_card_ids
                    and _power_amount(_parse_powers(player.get("powers")), "Strength") > 0
                )
            )
            and (
                (
                    "Runic Pyramid" in relic_ids
                    and any(monster.max_hp >= 180 for monster in monsters)
                )
                or any(
                    monster.monster_id == "BookOfStabbing"
                    for monster in monsters
                )
                or any(
                    monster.monster_id == "Champ"
                    and monster.hp > monster.max_hp // 2
                    for monster in monsters
                )
                or (
                    "Demon Form" in active_power_ids
                    and sum(monster.alive for monster in monsters) >= 2
                )
                or (
                    sum(monster.alive for monster in monsters) >= 2
                    and hp >= int(player_max_hp * 0.45)
                    and hp - sum(
                        max(0, monster.damage) * max(1, monster.hits)
                        for monster in monsters
                        if monster.alive and "ATTACK" in monster.intent
                    ) >= max(10, int(player_max_hp * 0.15))
                    and any(
                        known.card_id in {"Demon Form", "Inflame"}
                        for known in draw_pile[-2:]
                    )
                )
            )
        ),
        brimstone_race="Brimstone" in relic_ids,
        combust_hp_loss=combust_hp_loss,
        mummified_hand=bool(relic_ids & MUMMIFIED_HAND_IDS),
        abacus="TheAbacus" in relic_ids,
        art_of_war="Art of War" in relic_ids,
        attacks_played=max(0, int(relic_memory.get("attacks_played", 0) or 0)),
        bird_faced_urn="Bird Faced Urn" in relic_ids,
        blue_candle="Blue Candle" in relic_ids,
        centennial_puzzle_available=_relic_available(
            gs, "Centennial Puzzle"
        ),
        champion_belt="Champion Belt" in relic_ids,
        dead_branch="Dead Branch" in relic_ids,
        gremlin_horn="Gremlin Horn" in relic_ids,
        hand_drill="HandDrill" in relic_ids,
        happy_flower_counter=relic_counter(gs or {}, "Happy Flower"),
        healing_disabled="Mark of the Bloom" in relic_ids,
        ice_cream="Ice Cream" in relic_ids,
        incense_burner_counter=relic_counter(gs or {}, "Incense Burner"),
        ink_bottle_counter=relic_counter(gs or {}, "InkBottle"),
        kunai_counter=relic_counter(gs or {}, "Kunai"),
        letter_opener_counter=relic_counter(gs or {}, "LetterOpener"),
        magic_flower="Magic Flower" in relic_ids,
        necronomicon="Necronomicon" in relic_ids,
        necronomicon_available=(
            "Necronomicon" in relic_ids
            and not bool(relic_memory.get("necronomicon_used"))
        ),
        nunchaku_counter=relic_counter(gs or {}, "Nunchaku"),
        orange_pellets="OrangePellets" in relic_ids,
        orange_pellets_mask=max(
            0, int(relic_memory.get("orange_pellets_mask", 0) or 0)
        ),
        ornamental_fan_counter=relic_counter(gs or {}, "Ornamental Fan"),
        red_skull="Red Skull" in relic_ids,
        self_forming_clay="Self Forming Clay" in relic_ids,
        shuriken_counter=relic_counter(gs or {}, "Shuriken"),
        stone_calendar_ready=(
            "StoneCalendar" in relic_ids
            and (
                relic_counter(gs or {}, "StoneCalendar") == 7
                or max(1, int(combat.get("turn", 1) or 1)) == 7
            )
        ),
        strange_spoon="Strange Spoon" in relic_ids,
        strike_dummy="StrikeDummy" in relic_ids,
        sundial_counter=relic_counter(gs or {}, "Sundial"),
        torii="Torii" in relic_ids,
        tungsten_rod="TungstenRod" in relic_ids,
        unceasing_top="Unceasing Top" in relic_ids,
    )
    return replace(
        model,
        known_next_attack_damage=_known_next_turn_attack_damage(model),
        champ_forced_release=_champ_hold_is_untenable(model),
    )


def adjusted_attack(
    base,
    strength,
    weak,
    vulnerable,
    strength_multiplier=1,
    vulnerable_multiplier=1.5,
):
    value = max(0, base + strength * strength_multiplier)
    if weak:
        value *= 0.75
    if vulnerable:
        value *= vulnerable_multiplier
    return max(0, int(value))


def adjusted_block(base, dexterity, frail):
    value = max(0, base + dexterity)
    if frail:
        value *= 0.75
    return max(0, int(value))


def _apply_recoil(hp, block, amount):
    """Apply attack-triggered recoil through block and return HP damage."""
    amount = max(0, int(amount or 0))
    blocked = min(block, amount)
    block -= blocked
    hp_damage = min(hp, amount - blocked)
    return hp - hp_damage, block, hp_damage


def _apply_hp_damage_with_revive(hp, revive_hp, amount):
    """Apply one damage packet and trigger at most one available second life."""
    amount = max(0, int(amount or 0))
    if amount < hp:
        return hp - amount, revive_hp, amount, False
    hp_lost = hp
    if revive_hp > 0:
        return revive_hp, 0, hp_lost, True
    return 0, 0, hp_lost, False


def _apply_recoil_with_buffer_and_revive(
    hp, block, revive_hp, player_powers, amount, tungsten_rod=False,
):
    amount = max(0, int(amount or 0))
    blocked = min(block, amount)
    block -= blocked
    unblocked = amount - blocked
    if tungsten_rod and unblocked > 0:
        unblocked -= 1
    buffer = max(0, _power_amount(player_powers, "Buffer"))
    if unblocked > 0 and buffer > 0:
        return (
            hp,
            block,
            revive_hp,
            _set_power(player_powers, "Buffer", buffer - 1),
            0,
            False,
        )
    hp, revive_hp, hp_damage, revived = _apply_hp_damage_with_revive(
        hp, revive_hp, unblocked
    )
    return hp, block, revive_hp, player_powers, hp_damage, revived


def _card_cost(card, model):
    energy = model.energy
    if card.card_type == "SKILL" and _power_amount(model.player_powers, "Corruption"):
        return 0
    if card.cost < 0:
        return energy if card.card_id == "Whirlwind" else 0
    return max(0, card.cost)


def _upgrade_card_in_hand(card, model):
    if card.upgrades > 0:
        return card
    cost = card.cost
    if (
        card.card_id in UPGRADE_COST_REDUCTION_CARDS
        and cost > 0
        and not _power_amount(model.player_powers, "Confusion")
    ):
        cost -= 1
    return replace(card, upgrades=1, cost=cost)


def _armaments_upgrade_target_index(model):
    """Mirror the live Armaments prompt with emphasis on this turn's survival."""
    candidates = [
        (index, card)
        for index, card in enumerate(model.hand)
        if card.upgrades <= 0 and card.card_type not in {"STATUS", "CURSE"}
    ]
    if not candidates:
        return None

    unblocked = max(0, model.incoming - model.block)
    urgent_block_pressure = unblocked >= max(10, int(model.hp * 0.25))

    def score(candidate):
        upgraded = _upgrade_card_in_hand(candidate, model)
        value = ARMAMENTS_UPGRADE_PRIORITY.get(
            candidate.card_id,
            35 if candidate.card_type == "POWER" else 25,
        )
        affordable = _card_cost(candidate, model) <= model.energy
        upgraded_affordable = _card_cost(upgraded, model) <= model.energy

        block_before = block_after = 0
        if candidate.card_id in BLOCK_VALUE:
            base, upgrade = BLOCK_VALUE[candidate.card_id]
            block_before = adjusted_block(
                base + upgrade * min(candidate.upgrades, 1),
                model.dexterity,
                model.frail,
            )
            block_after = adjusted_block(
                base + upgrade,
                model.dexterity,
                model.frail,
            )
        block_gain = max(0, block_after - block_before)

        damage_gain = 0
        if candidate.card_type == "ATTACK":
            before_base, before_hits, before_strength = _base_attack(
                candidate, model
            )
            after_base, after_hits, after_strength = _base_attack(upgraded, model)
            before_damage = (
                before_base + max(0, model.strength) * before_strength
            ) * before_hits
            after_damage = (
                after_base + max(0, model.strength) * after_strength
            ) * after_hits
            damage_gain = max(0, after_damage - before_damage)
        value += damage_gain * 2

        if urgent_block_pressure and affordable and block_after > 0:
            value += (
                100
                + min(unblocked, block_after) * 3
                + block_gain * 12
            )
        elif affordable:
            value += block_gain * 4
        if upgraded_affordable and not affordable:
            value += 80
        if candidate.card_id in DRAW_VALUES:
            base_draw, upgrade_draw = DRAW_VALUES[candidate.card_id]
            value += upgrade_draw * 12
        return value

    return max(candidates, key=lambda item: score(item[1]))[0]


def dual_wield_target_index(model, hand_index=None):
    """Choose the same Attack/Power for search simulation and the live prompt."""
    candidates = [
        (index, candidate)
        for index, candidate in enumerate(model.hand)
        if index != hand_index
        and candidate.card_type in {"ATTACK", "POWER"}
        and not (
            candidate.card_id in NONSTACKING_POWER_IDS
            and _power_amount(model.player_powers, candidate.card_id)
        )
    ]
    if not candidates:
        return None

    dual_cost = 0
    if hand_index is not None and 0 <= hand_index < len(model.hand):
        dual_cost = _card_cost(model.hand[hand_index], model)
    remaining_energy = max(0, model.energy - dual_cost)
    living = [monster for monster in model.monsters if monster.alive]

    def score(candidate):
        cost = _card_cost(candidate, model)
        affordable = cost <= remaining_energy
        if candidate.card_type == "POWER":
            value = SAFE_POWER_VALUES.get(candidate.card_id, 7) * 6
            if affordable:
                value += 35
            if candidate.card_id in {"Demon Form", "Inflame", "Rupture"}:
                value += 12
            return value - cost * 3

        energy_spent = remaining_energy if candidate.card_id == "Whirlwind" else cost
        base, hits, strength_multiplier = _base_attack(
            candidate, model, energy_spent=energy_spent
        )
        vulnerable = any(
            _power_amount(monster.powers, "Vulnerable") for monster in living
        )
        damage = adjusted_attack(
            base,
            model.strength,
            model.weak,
            vulnerable,
            strength_multiplier,
            1.75 if model.paper_frog else 1.5,
        ) * hits
        if candidate.card_id in AOE_ATTACKS:
            damage *= max(1, len(living))
        value = damage * 4
        if affordable:
            value += 40
        else:
            value -= cost * 8
        if candidate.card_id in {"Feed", "Reaper"}:
            value += 18
        return value

    return max(candidates, key=lambda item: (score(item[1]), -item[0]))[0]


def _base_attack(card, model, energy_spent=None):
    strike_bonus = (
        3 if model.strike_dummy and card.card_id in STRIKE_CARD_IDS else 0
    )
    if card.card_id == "Body Slam":
        return model.block, 1, 1
    if card.card_id == "Fiend Fire":
        # Fiend Fire attacks once for every other card currently in hand.
        # ``model`` is already the post-play state, so the Fiend Fire itself
        # has been removed and must not be counted as an extra hit. Power
        # Through's Wounds are tracked compactly in ``statuses_added`` but are
        # still real cards in hand for this attack.
        return (
            7 + 3 * min(card.upgrades, 1),
            len(model.hand) + model.statuses_added,
            1,
        )
    if card.card_id == "Perfected Strike":
        bonus = 2 + min(card.upgrades, 1)
        return 6 + bonus * model.strike_cards + strike_bonus, 1, 1
    if card.card_id == "Pummel":
        return 2, 4 + min(card.upgrades, 1), 1
    if card.card_id == "Whirlwind":
        hits = model.energy if energy_spent is None else energy_spent
        if model.chemical_x:
            hits += 2
        return 5 + 3 * min(card.upgrades, 1), max(0, hits), 1
    if card.card_id == "Sword Boomerang":
        return 3, 3 + min(card.upgrades, 1), 1
    if card.card_id in MULTI_HIT:
        base, upgrade, hits = MULTI_HIT[card.card_id]
        return base + upgrade * min(card.upgrades, 1) + strike_bonus, hits, 1
    base, upgrade = ATTACK_DAMAGE.get(card.card_id, (7, 3))
    strength_multiplier = 3 + 2 * min(card.upgrades, 1) if card.card_id == "Heavy Blade" else 1
    return (
        base + upgrade * min(card.upgrades, 1) + strike_bonus,
        1,
        strength_multiplier,
    )


def _mummified_original_cost_is_positive(card):
    if card.card_id in NATIVE_ZERO_COST_CARD_IDS:
        return False
    if (
        card.upgrades > 0
        and card.card_id in UPGRADED_ZERO_COST_CARD_IDS
    ):
        return False
    return card.cost > 0


def _mummified_free_card_is_playable(card, model):
    if card.is_playable:
        return True
    if card.card_type not in {"ATTACK", "SKILL", "POWER"}:
        return False
    if (
        card.card_type == "ATTACK"
        and _power_amount(model.player_powers, "Entangled") > 0
    ):
        return False
    if (
        card.card_id in NONSTACKING_POWER_IDS
        and _power_amount(model.player_powers, card.card_id) != 0
    ):
        return False
    if card.card_id == "Limit Break" and model.strength <= 0:
        return False
    # CommunicationMod marks cards above the current energy as unplayable.
    # Once their cost becomes zero that energy-only restriction disappears.
    return card.cost > model.energy


def _mummified_hand_candidates(model):
    if not model.mummified_hand or model.velvet_choker_counter >= 6:
        return ()
    return tuple(
        (index, card)
        for index, card in enumerate(model.hand)
        if _mummified_original_cost_is_positive(card)
        and _card_cost(card, model) > 0
    )


def _mummified_candidate_value(card, model):
    """Estimate one random Mummified Hand outcome without inventing its RNG."""
    cost = min(4, _card_cost(card, model))
    if cost <= 0 or not _mummified_free_card_is_playable(card, model):
        return 0

    value = 18 + cost * 12
    if cost > model.energy:
        value += 10
    if card.card_id in BLOCK_VALUE:
        base, upgrade = BLOCK_VALUE[card.card_id]
        block = adjusted_block(
            base + upgrade * min(card.upgrades, 1),
            model.dexterity,
            model.frail,
        )
        missing = max(0, model.incoming - model.block)
        value += min(18, block) + min(block, missing) * 2
    elif card.card_type == "ATTACK":
        base, hits, strength_multiplier = _base_attack(card, model)
        damage = max(
            0,
            base + model.strength * strength_multiplier,
        ) * hits
        value += min(24, damage)
    elif card.card_type == "POWER":
        # A free second Power can trigger the relic again, so Power chains are
        # materially better than an equal-cost ordinary card.
        value += 12 + SAFE_POWER_VALUES.get(card.card_id, 6) * 2
    if card.card_id in DRAW_VALUES:
        base_draw, upgrade_draw = DRAW_VALUES[card.card_id]
        value += (base_draw + upgrade_draw * min(card.upgrades, 1)) * 7
    return min(96, value)


def _trigger_mummified_hand(model):
    candidates = _mummified_hand_candidates(model)
    if not candidates:
        return model

    outcome_values = [
        _mummified_candidate_value(card, model)
        for _, card in candidates
    ]
    expected_credit = sum(outcome_values) // len(outcome_values)
    if any(outcome_values):
        expected_credit = max(18, expected_credit)

    hand = model.hand
    if len(candidates) == 1:
        # With one legal target there is no hidden RNG. Model the exact free
        # card; the live bot will still replan after the Power resolves.
        index, target = candidates[0]
        hand = list(hand)
        hand[index] = replace(
            target,
            cost=0,
            is_playable=_mummified_free_card_is_playable(target, model),
        )
        hand = tuple(hand)

    return replace(
        model,
        hand=hand,
        mummified_hand_credit=(
            model.mummified_hand_credit + expected_credit
        ),
    )


def _projected_next_turn_energy(model):
    """Include deterministic relic energy that becomes available next turn."""
    energy = max(0, model.next_turn_energy)
    if model.ice_cream:
        energy += max(0, model.energy)
    if model.art_of_war and model.attacks_played == 0:
        energy += 1
    if model.happy_flower_counter >= 0 and model.happy_flower_counter % 3 == 2:
        energy += 1
    return energy


def _art_of_war_future_credit(model):
    """Value the conditional energy without making attacks categorically lose."""
    if not model.art_of_war or model.attacks_played > 0:
        return 0

    # One delayed energy is useful, but normally worth less than even a basic
    # attack now. Exact draw order can raise the value slightly when that extra
    # energy unlocks known damage, while the cap prevents repeatedly passing
    # zero-cost or ordinary attacks just to keep the relic lit.
    with_relic = _known_next_turn_attack_damage(
        model, require_full=False
    )
    without_relic = _known_next_turn_attack_damage(
        replace(model, art_of_war=False), require_full=False
    )
    unlocked_damage = max(0, with_relic - without_relic)
    return 3 + min(2, unlocked_damage // 6)


def _known_next_turn_attack_damage(
    model, natural_draw=5, target=None, require_full=True
):
    """Return an energy-aware damage ceiling for the exact next draw window.

    CommunicationMod exposes the full ordered draw pile.  We only forecast a
    natural turn when all five cards are known; a pending shuffle deliberately
    receives no credit.  Corruption plus Dark Embrace can expose more known
    cards, so follow that deterministic replacement-draw chain up to hand cap.
    """
    if (
        not model.monsters
        or require_full and len(model.draw_pile) < natural_draw
    ):
        return 0

    ordered = list(reversed(model.draw_pile))
    visible = min(natural_draw, len(ordered))
    corruption = bool(_power_amount(model.player_powers, "Corruption"))
    dark_embrace = max(0, _power_amount(model.player_powers, "Dark Embrace"))
    processed = 0
    while processed < visible and visible < min(10, len(ordered)):
        candidate = ordered[processed]
        extra_draws = 0
        if corruption and dark_embrace and candidate.card_type == "SKILL":
            extra_draws += dark_embrace
        if dark_embrace and candidate.card_id in {"Burning Pact", "True Grit"}:
            extra_draws += dark_embrace
        if candidate.card_id in DRAW_VALUES:
            base_draw, upgrade_draw = DRAW_VALUES[candidate.card_id]
            extra_draws += base_draw + upgrade_draw * min(candidate.upgrades, 1)
        visible = min(10, len(ordered), visible + extra_draws)
        processed += 1

    target = target or next(
        (monster for monster in model.monsters if monster.alive), None
    )
    if target is None:
        return 0
    weak = _power_amount(model.player_powers, "Weakened") > 1
    vulnerable = _power_amount(target.powers, "Vulnerable") > 1
    energy = _projected_next_turn_energy(model)
    best = [0] * (energy + 1)
    for candidate in ordered[:visible]:
        if candidate.card_type != "ATTACK" or not candidate.is_playable:
            continue
        if candidate.card_id == "Body Slam":
            continue
        options = []
        if candidate.card_id == "Whirlwind" or candidate.cost < 0:
            minimum_spend = 0 if (
                candidate.card_id == "Whirlwind" and model.chemical_x
            ) else 1
            for spent in range(minimum_spend, energy + 1):
                base, hits, multiplier = _base_attack(
                    candidate, model, energy_spent=spent
                )
                damage = adjusted_attack(
                    base,
                    model.strength,
                    weak,
                    vulnerable,
                    multiplier,
                    1.75 if model.paper_frog else 1.5,
                ) * hits
                options.append((spent, damage))
        else:
            cost = max(0, candidate.cost)
            if cost <= energy:
                if candidate.card_id == "Fiend Fire":
                    base = 7 + 3 * min(candidate.upgrades, 1)
                    hits = max(0, visible - 1)
                    multiplier = 1
                else:
                    base, hits, multiplier = _base_attack(candidate, model)
                damage = adjusted_attack(
                    base,
                    model.strength,
                    weak,
                    vulnerable,
                    multiplier,
                    1.75 if model.paper_frog else 1.5,
                ) * hits
                if model.charons_ashes:
                    if candidate.card_id == "Fiend Fire":
                        # Fiend Fire exhausts every other visible card and then
                        # exhausts itself, so every card in this hand triggers
                        # Charon's Ashes once.
                        damage += 3 * visible
                    elif candidate.exhausts:
                        damage += 3
                options.append((cost, damage))
        previous = list(best)
        for cost, damage in options:
            for spent in range(cost, energy + 1):
                best[spent] = max(best[spent], previous[spent - cost] + damage)
    return max(best, default=0)


def _known_later_turn_block_capacity(
    model, draw_offset, natural_draw=5, require_full=True, follow_draw=True
):
    """Return an energy-aware block ceiling after skipping a known draw."""
    required_cards = max(0, draw_offset) + natural_draw
    if not model.draw_pile or (
        require_full and len(model.draw_pile) < required_cards
    ):
        return None

    ordered = list(reversed(model.draw_pile))[max(0, draw_offset) :]
    if not ordered:
        return None
    visible = min(natural_draw, len(ordered))
    processed = 0
    while processed < visible and visible < min(10, len(ordered)):
        candidate = ordered[processed]
        if follow_draw and candidate.card_id in DRAW_VALUES:
            base_draw, upgrade_draw = DRAW_VALUES[candidate.card_id]
            visible = min(
                10,
                len(ordered),
                visible + base_draw + upgrade_draw * min(candidate.upgrades, 1),
            )
        processed += 1

    energy = _projected_next_turn_energy(model)
    best = [0] * (energy + 1)
    for candidate in ordered[:visible]:
        if not candidate.is_playable:
            continue
        if candidate.card_id in BLOCK_VALUE:
            base, upgrade = BLOCK_VALUE[candidate.card_id]
            block = adjusted_block(
                base + upgrade * min(candidate.upgrades, 1),
                model.dexterity,
                model.frail,
            )
        elif candidate.card_id == "Metallicize":
            block = 3 + min(candidate.upgrades, 1)
        else:
            continue
        cost = max(0, candidate.cost)
        if (
            candidate.card_type == "SKILL"
            and _power_amount(model.player_powers, "Corruption")
        ):
            cost = 0
        if cost > energy:
            continue
        previous = list(best)
        for spent in range(cost, energy + 1):
            best[spent] = max(best[spent], previous[spent - cost] + block)
    return max(best, default=0)


def _known_next_turn_block_capacity(
    model, natural_draw=5, require_full=True, follow_draw=True
):
    """Return an energy-aware block ceiling for the exact next draw."""
    return _known_later_turn_block_capacity(
        model,
        0,
        natural_draw=natural_draw,
        require_full=require_full,
        follow_draw=follow_draw,
    )


def _damage_monster(monster, damage):
    blocked = min(monster.block, damage)
    hp_damage = max(0, damage - blocked)
    return replace(monster, block=monster.block - blocked, hp=max(0, monster.hp - hp_damage)), hp_damage


def _apply_damage_transition(model, before, after):
    hp_damage = max(0, before.hp - after.hp)
    future_risk = model.future_risk
    slime_split_hp = model.slime_split_hp
    if before.monster_id == "TheGuardian":
        mode_shift = _power_amount(before.powers, "Mode Shift")
        if mode_shift > 0:
            remaining = mode_shift - hp_damage
            powers = _set_power(after.powers, "Mode Shift", max(0, remaining))
            if remaining <= 0:
                powers = _set_power(powers, "Sharp Hide", max(3, _power_amount(powers, "Sharp Hide")))
                after = replace(after, block=after.block + 20, intent="BUFF", damage=-1, hits=1, powers=powers)
            else:
                after = replace(after, powers=powers)
    elif before.monster_id in SPLIT_SLIME_IDS:
        split_threshold = before.max_hp // 2
        if before.hp > split_threshold >= after.hp:
            after = replace(after, intent="BUFF", damage=-1, hits=1)
            if before.monster_id == "SlimeBoss":
                model = replace(
                    model,
                    scaling=max(0, model.scaling - model.slime_debuff_scaling),
                    slime_debuff_scaling=0,
                )
        if after.hp <= split_threshold:
            slime_split_hp = after.hp
    elif before.monster_id == "Champ":
        projected_transition_hp = model.hp - max(
            0,
            model.incoming - _projected_end_turn_block(model),
        )
        high_ascension_reserve_ready = (
            model.ascension < 18
            or projected_transition_hp
            >= max(18, int(model.max_hp * 0.25))
        )
        if before.hp > before.max_hp // 2 >= after.hp:
            known_deep_followthrough = (
                "ATTACK" in before.initial_intent
                and model.known_next_attack_damage > 0
                and after.hp - model.known_next_attack_damage
                <= int(before.max_hp * 0.34)
                and high_ascension_reserve_ready
            )
            if model.champ_forced_release or known_deep_followthrough:
                # Once survival forces the phase transition, commit to the
                # damage race. A fully known next hand that can push Champ
                # below roughly one third HP is also a concrete transition
                # plan: crossing now replaces the next first-phase move with
                # Anger instead of waiting through another debuff cycle.
                model = replace(model, champ_race=True)
            else:
                future_risk += 15 + max(0, 45 - model.hp)
        safe_phase_hp = int(before.max_hp * 0.38)
        desperate_burst = (
            model.hp <= 12
            and (
                model.strength >= 10
                or after.hp <= int(before.max_hp * 0.45)
            )
        )
        if (
            after.hp <= safe_phase_hp
            and (
                model.ascension < 18
                or high_ascension_reserve_ready
                or model.champ_forced_release
            )
        ) or desperate_burst:
            model = replace(model, champ_race=True)
    elif before.monster_id == "Transient" and before.damage >= 0:
        # Shifting removes one point of this turn's attack for every point of
        # unblocked damage.  Damage is therefore also Transient-specific block.
        after = replace(after, damage=max(0, before.damage - hp_damage))
    if (
        before.monster_id == "BronzeOrb"
        and before.alive
        and not after.alive
    ):
        if _power_amount(before.powers, "Stasis") != 0:
            # Stasis returns its exact card immediately. Keep it in the search
            # so killing an Orb can unlock and play Fiend Fire, Impervious, or
            # another visible answer with the energy that remains this turn.
            returned = before.stasis_card
            returned_hand = model.hand
            if returned is not None and len(returned_hand) < 10:
                returned = replace(
                    returned,
                    is_playable=(
                        returned.card_type in {"ATTACK", "SKILL", "POWER"}
                    ),
                )
                returned_hand = returned_hand + (returned,)
            returned_available = returned is not None and returned in returned_hand
            release_value = 2
            if (
                returned_available
                and _card_cost(returned, model) <= model.energy
            ):
                # The returned card only has immediate tactical value when the
                # remaining energy can actually use it.  The A16 Automaton log
                # paid nine HP to recover a two-cost Impervious with one energy,
                # then discarded it at end of turn.
                release_value += model.energy * 4 + _known_draw_value(returned, model)
            model = replace(
                model,
                hand=returned_hand,
                draw_value=model.draw_value + release_value,
            )

        living_orbs_before = sum(
            monster.monster_id == "BronzeOrb" and monster.alive
            for monster in model.monsters
        )
        critical_reserve = model.initial_hp <= max(18, int(model.max_hp * 0.22))
        orb_is_attacking = (
            "ATTACK" in before.intent
            and max(0, before.damage) * max(1, before.hits) > 0
        )
        cheap_cleanup = before.hp <= 4
        urgent_cleanup = before.hp <= 10 and (critical_reserve or orb_is_attacking)
        if living_orbs_before == 1 and (cheap_cleanup or urgent_cleanup):
            # A lone healthy orb should not distract from the Automaton race,
            # but the v75 log left a 7-HP orb alive at 13 HP and then died with
            # it still contributing damage / retaining Stasis.  At critical
            # reserve, or when that orb is itself attacking, a one-card cleanup
            # is real control rather than repeated nonlethal chip.
            model = replace(
                model,
                bronze_orb_cleanup_credit=(
                    model.bronze_orb_cleanup_credit
                    + (190 if urgent_cleanup else 140)
                ),
            )
    if (
        before.monster_id == "FungiBeast"
        and before.alive
        and not after.alive
    ):
        spore_cloud = max(0, _power_amount(before.powers, "Spore Cloud"))
        if spore_cloud:
            player_powers = model.player_powers
            artifact = max(0, _power_amount(player_powers, "Artifact"))
            if artifact:
                player_powers = _set_power(player_powers, "Artifact", artifact - 1)
            else:
                already_vulnerable = _power_amount(player_powers, "Vulnerable") > 0
                player_powers = _set_power(
                    player_powers,
                    "Vulnerable",
                    _power_amount(player_powers, "Vulnerable") + spore_cloud,
                )
                if not already_vulnerable:
                    # CommunicationMod's move damage is already adjusted for
                    # player debuffs. Spore Cloud lands immediately on death,
                    # so every other current attacker must be rescaled now.
                    monsters = tuple(
                        replace(monster, damage=int(monster.damage * 1.5))
                        if (
                            monster.original_index != before.original_index
                            and monster.alive
                            and monster.damage > 0
                            and "ATTACK" in monster.intent
                        )
                        else monster
                        for monster in model.monsters
                    )
                    model = replace(model, monsters=monsters)
            model = replace(model, player_powers=player_powers)
    if before.alive and not after.alive and model.gremlin_horn:
        other_enemy_alive = any(
            monster.original_index != before.original_index and monster.alive
            for monster in model.monsters
        )
        if other_enemy_alive:
            model = replace(model, energy=model.energy + 1)
            model = _draw_cards(model, 1)
    return replace(model, future_risk=future_risk, slime_split_hp=slime_split_hp), after


def _trigger_charons_ashes(model, exhaust_count=1):
    """Apply one three-damage AoE trigger for each exhausted card."""
    if not model.charons_ashes or exhaust_count <= 0:
        return model
    result = model
    for _ in range(exhaust_count):
        for index in range(len(result.monsters)):
            before = result.monsters[index]
            if not before.alive:
                continue
            after, _ = _damage_monster(before, 3)
            result, after = _apply_damage_transition(result, before, after)
            monsters = list(result.monsters)
            monsters[index] = after
            result = replace(result, monsters=tuple(monsters))
    return result


def _trigger_dead_branch(model, exhaust_count=1):
    """Value random Dead Branch cards without inventing their identities."""
    if not model.dead_branch or exhaust_count <= 0:
        return model
    available_slots = max(0, 10 - len(model.hand))
    generated = min(max(0, exhaust_count), available_slots)
    if generated <= 0:
        return model
    return replace(
        model,
        random_card_credit=min(48, model.random_card_credit + generated * 6),
        draw_value=model.draw_value + generated,
    )


def _trigger_exhaust_relics(model, exhaust_count=1):
    result = _trigger_charons_ashes(model, exhaust_count)
    return _trigger_dead_branch(result, exhaust_count)


def _trigger_relic_aoe(model, damage):
    """Apply non-Attack relic damage to every living enemy."""
    result = model
    for index in range(len(result.monsters)):
        before = result.monsters[index]
        if not before.alive:
            continue
        after, _ = _damage_monster(before, damage)
        result, after = _apply_damage_transition(result, before, after)
        monsters = list(result.monsters)
        monsters[index] = after
        result = replace(result, monsters=tuple(monsters))
    return result


def _trigger_juggernaut(model, trigger_count=1):
    """Apply conservative random-target Juggernaut damage for block gains."""
    amount = max(0, _power_amount(model.player_powers, "Juggernaut"))
    if amount <= 0:
        return model
    for _ in range(max(0, trigger_count)):
        living = [
            index
            for index, monster in enumerate(model.monsters)
            if monster.alive
        ]
        if not living:
            break
        # The live target is random. Hitting the most durable enemy prevents
        # the search from promising a convenient minion kill that is not
        # guaranteed, while still valuing damage that always occurs.
        target_index = max(
            living,
            key=lambda index: (
                model.monsters[index].hp + model.monsters[index].block,
                model.monsters[index].hp,
            ),
        )
        monsters = list(model.monsters)
        before = monsters[target_index]
        after, _ = _damage_monster(before, amount)
        model, after = _apply_damage_transition(model, before, after)
        monsters = list(model.monsters)
        monsters[target_index] = after
        model = replace(model, monsters=tuple(monsters))
    return model


def _apply_attack_to_target(
    model, target_index, base, hits, strength_multiplier=1,
    damage_multiplier=1,
):
    monsters = list(model.monsters)
    monster = monsters[target_index]
    before_attack = monster
    sharp_hide = max(0, _power_amount(monster.powers, "Sharp Hide"))
    thorns = max(0, _power_amount(monster.powers, "Thorns"))
    hp = model.hp
    block = model.block
    revive_hp = model.revive_hp
    player_powers = model.player_powers
    self_damage = model.self_damage
    if monster.alive and sharp_hide:
        hp, block, revive_hp, player_powers, loss, _ = (
            _apply_recoil_with_buffer_and_revive(
                hp, block, revive_hp, player_powers, sharp_hide,
                model.tungsten_rod,
            )
        )
        self_damage += loss
    vulnerable = bool(_power_amount(monster.powers, "Vulnerable"))
    damage = adjusted_attack(
        base,
        model.strength,
        model.weak,
        vulnerable,
        strength_multiplier,
        1.75 if model.paper_frog else 1.5,
    ) * max(1, damage_multiplier)
    slow = max(0, _power_amount(monster.powers, "Slow"))
    if slow:
        damage = int(damage * (1.0 + slow * 0.10))
    intangible = bool(_power_amount(monster.powers, "Intangible"))
    angry = max(0, _power_amount(monster.powers, "Angry"))
    total_hp_damage = 0
    for _ in range(hits):
        if not monster.alive:
            break
        if thorns:
            hp, block, revive_hp, player_powers, loss, _ = (
                _apply_recoil_with_buffer_and_revive(
                    hp, block, revive_hp, player_powers, thorns,
                    model.tungsten_rod,
                )
            )
            self_damage += loss
        flight = _power_amount(monster.powers, "Flight")
        hit_damage = int(damage * 0.5) if flight > 0 else damage
        if intangible:
            hit_damage = min(hit_damage, 1)
        # The Boot raises positive HP damage after block, never zero damage.
        unblocked = max(0, hit_damage - monster.block)
        if model.has_boot and 0 < unblocked < 5:
            hit_damage += 5 - unblocked
        monster, hp_damage = _damage_monster(monster, hit_damage)
        total_hp_damage += hp_damage
        if hp_damage > 0 and monster.alive and angry:
            strength = max(0, _power_amount(monster.powers, "Strength"))
            weakened = bool(_power_amount(monster.powers, "Weakened"))
            damage_gain = int(angry * 0.75) if weakened else angry
            monster = replace(
                monster,
                damage=(
                    monster.damage + damage_gain
                    if "ATTACK" in monster.intent and monster.damage >= 0
                    else monster.damage
                ),
                powers=_set_power(
                    monster.powers, "Strength", strength + angry
                ),
            )
        if flight > 0 and hp_damage > 0:
            remaining_flight = flight - 1
            powers = _set_power(monster.powers, "Flight", max(0, remaining_flight))
            if remaining_flight <= 0:
                monster = replace(monster, intent="STUN", damage=-1, hits=1, powers=powers)
            else:
                monster = replace(monster, powers=powers)
        if not monster.alive:
            break
    curl_up = max(0, _power_amount(monster.powers, "Curl Up"))
    if monster.alive and total_hp_damage > 0 and curl_up:
        # Curl Up queues its block after the attack's damage actions. It does
        # not protect against a lethal hit or trigger on fully blocked damage.
        monster = replace(
            monster, block=monster.block + curl_up,
            powers=_set_power(monster.powers, "Curl Up", 0),
        )
    model = replace(
        model,
        hp=hp,
        revive_hp=revive_hp,
        block=block,
        player_powers=player_powers,
        self_damage=self_damage,
    )
    model, monster = _apply_damage_transition(model, before_attack, monster)
    monsters = list(model.monsters)
    if (
        model.hand_drill
        and before_attack.block > 0
        and monster.alive
        and monster.block <= 0
    ):
        monster = _apply_vulnerable_with_belt(model, monster, 2)
    if monster.alive and total_hp_damage >= 0 and _power_amount(monster.powers, "Malleable"):
        amount = _power_amount(monster.powers, "Malleable")
        monster = replace(
            monster,
            block=monster.block + amount,
            powers=_set_power(monster.powers, "Malleable", amount + 1),
        )
    monsters[target_index] = monster
    return replace(
        model,
        hp=hp,
        revive_hp=revive_hp,
        block=block,
        monsters=tuple(monsters),
    )


def _apply_monster_power(monster, power_id, amount):
    artifact = _power_amount(monster.powers, "Artifact")
    artifact_blocks = (
        amount > 0 and power_id in {"Weakened", "Vulnerable"}
    ) or (
        amount < 0 and power_id == "Strength"
    )
    if artifact > 0 and artifact_blocks:
        powers = _set_power(monster.powers, "Artifact", artifact - 1)
        return replace(monster, powers=powers)
    old = _power_amount(monster.powers, power_id)
    powers = _set_power(monster.powers, power_id, old + amount)
    damage = monster.damage
    if power_id == "Weakened" and old <= 0 and damage > 0:
        damage = int(damage * 0.75)
    elif power_id == "Strength" and amount < 0 and damage >= 0:
        damage = max(0, damage + amount)
    return replace(monster, powers=powers, damage=damage)


def _apply_vulnerable_with_belt(model, monster, amount):
    """Apply Vulnerable and Champion Belt's Weak only when it lands."""
    before = _power_amount(monster.powers, "Vulnerable")
    result = _apply_monster_power(monster, "Vulnerable", amount)
    if (
        model.champion_belt
        and _power_amount(result.powers, "Vulnerable") > before
    ):
        result = _apply_monster_power(result, "Weakened", 1)
    return result


def _apply_attack_instance_followup(model, card, target_index):
    """Resolve effects that repeat when Double Tap or Necronomicon replays."""
    result = model
    target_index = target_index or 0
    if card.card_id == "Thunderclap":
        return replace(
            result,
            monsters=tuple(
                _apply_vulnerable_with_belt(result, monster, 1)
                if monster.alive
                else monster
                for monster in result.monsters
            ),
        )
    if target_index >= len(result.monsters):
        return result

    monsters = list(result.monsters)
    target = monsters[target_index]
    if target.alive and card.card_id == "Bash":
        monsters[target_index] = _apply_vulnerable_with_belt(
            result, target, 2 + min(card.upgrades, 1)
        )
        return replace(result, monsters=tuple(monsters))
    if target.alive and card.card_id in {"Clothesline", "Uppercut"}:
        weak_amount = (
            2 + min(card.upgrades, 1)
            if card.card_id == "Clothesline"
            else 1 + min(card.upgrades, 1)
        )
        future_weak_credit = _quiet_snake_plant_weak_credit(
            target, weak_amount
        )
        target = _apply_monster_power(target, "Weakened", weak_amount)
        if card.card_id == "Uppercut":
            target = _apply_vulnerable_with_belt(
                result, target, 1 + min(card.upgrades, 1)
            )
        monsters[target_index] = target
        return replace(
            result,
            monsters=tuple(monsters),
            risky_power_credit=(
                result.risky_power_credit + future_weak_credit
            ),
        )
    if card.card_id == "Iron Wave":
        base_block, upgrade = BLOCK_VALUE["Iron Wave"]
        gained = adjusted_block(
            base_block + upgrade * min(card.upgrades, 1),
            result.dexterity,
            result.frail,
        )
        result = replace(result, block=result.block + gained)
        return _trigger_juggernaut(result)
    if card.card_id == "Hemokinesis":
        before = result.self_damage
        rupture = max(0, _power_amount(result.player_powers, "Rupture"))
        result = _lose_player_hp(result, 2)
        if result.self_damage > before and rupture:
            result = _add_player_power(result, "Strength", rupture)
            result = replace(
                result,
                scaling=result.scaling + rupture * 4,
                offensive_scaling=result.offensive_scaling + rupture * 4,
            )
    return result


def _add_player_power(model, power_id, amount):
    old = _power_amount(model.player_powers, power_id)
    return replace(model, player_powers=_set_power(model.player_powers, power_id, old + amount))


def _heal_player(model, amount):
    amount = max(0, int(amount or 0))
    if amount <= 0 or model.healing_disabled:
        return model
    if model.magic_flower:
        amount = int(amount * 1.5)
    old_hp = model.hp
    result = replace(model, hp=min(model.max_hp, model.hp + amount))
    if (
        model.red_skull
        and old_hp * 2 <= model.max_hp
        and result.hp * 2 > result.max_hp
    ):
        result = _add_player_power(result, "Strength", -3)
    return result


def _lose_player_hp(model, amount):
    amount = max(0, int(amount or 0))
    if model.tungsten_rod and amount > 0:
        amount -= 1
    player_powers = model.player_powers
    buffer = max(0, _power_amount(player_powers, "Buffer"))
    if amount > 0 and buffer > 0:
        return replace(
            model,
            player_powers=_set_power(player_powers, "Buffer", buffer - 1),
        )
    hp, revive_hp, lost, _ = _apply_hp_damage_with_revive(
        model.hp, model.revive_hp, amount
    )
    result = replace(
        model,
        hp=hp,
        revive_hp=revive_hp,
        self_damage=model.self_damage + lost,
    )
    if (
        lost > 0
        and model.red_skull
        and model.hp * 2 > model.max_hp
        and result.hp * 2 <= result.max_hp
    ):
        result = _add_player_power(result, "Strength", 3)
    if lost > 0 and model.centennial_puzzle_available:
        result = replace(result, centennial_puzzle_available=False)
        result = _draw_cards(result, 3)
    if lost > 0 and model.runic_cube:
        result = _draw_cards(result, 1)
    if lost > 0 and model.self_forming_clay:
        result = replace(
            result,
            self_forming_clay_block=result.self_forming_clay_block + 3,
        )
    return result


def _clear_orange_pellets_debuffs(model):
    powers = tuple(
        (power_id, amount)
        for power_id, amount in model.player_powers
        if power_id not in ORANGE_PELLETS_DEBUFF_IDS
        and not (power_id in {"Strength", "Dexterity"} and amount < 0)
    )
    return replace(model, player_powers=tuple(sorted(powers)))


def _trigger_card_play_relics(model, card):
    """Resolve relics that count the card itself, not duplicated effects."""
    result = model

    if result.ink_bottle_counter >= 0:
        counter = result.ink_bottle_counter + 1
        if counter >= 10:
            result = replace(result, ink_bottle_counter=0)
            result = _draw_cards(result, 1)
        else:
            result = replace(result, ink_bottle_counter=counter)

    if card.card_type == "ATTACK":
        result = replace(result, attacks_played=result.attacks_played + 1)
        if result.nunchaku_counter >= 0:
            counter = result.nunchaku_counter + 1
            if counter >= 10:
                result = replace(
                    result, nunchaku_counter=0, energy=result.energy + 1
                )
            else:
                result = replace(result, nunchaku_counter=counter)
        if result.kunai_counter >= 0:
            counter = result.kunai_counter + 1
            if counter >= 3:
                result = _add_player_power(
                    replace(result, kunai_counter=0), "Dexterity", 1
                )
                result = replace(result, scaling=result.scaling + 5)
            else:
                result = replace(result, kunai_counter=counter)
        if result.shuriken_counter >= 0:
            counter = result.shuriken_counter + 1
            if counter >= 3:
                result = _add_player_power(
                    replace(result, shuriken_counter=0), "Strength", 1
                )
                result = replace(
                    result,
                    scaling=result.scaling + 6,
                    offensive_scaling=result.offensive_scaling + 6,
                )
            else:
                result = replace(result, shuriken_counter=counter)
        if result.ornamental_fan_counter >= 0:
            counter = result.ornamental_fan_counter + 1
            if counter >= 3:
                result = replace(
                    result,
                    ornamental_fan_counter=0,
                    block=result.block + 4,
                )
                result = _trigger_juggernaut(result)
            else:
                result = replace(result, ornamental_fan_counter=counter)
    elif card.card_type == "SKILL" and result.letter_opener_counter >= 0:
        counter = result.letter_opener_counter + 1
        if counter >= 3:
            result = _trigger_relic_aoe(
                replace(result, letter_opener_counter=0), 5
            )
        else:
            result = replace(result, letter_opener_counter=counter)

    if card.card_type == "POWER" and result.bird_faced_urn:
        result = _heal_player(result, 2)

    if result.orange_pellets:
        card_bit = {
            "ATTACK": ORANGE_ATTACK,
            "SKILL": ORANGE_SKILL,
            "POWER": ORANGE_POWER,
        }.get(card.card_type, 0)
        if card_bit:
            mask = result.orange_pellets_mask | card_bit
            if mask == ORANGE_ATTACK | ORANGE_SKILL | ORANGE_POWER:
                result = _clear_orange_pellets_debuffs(
                    replace(result, orange_pellets_mask=0)
                )
            else:
                result = replace(result, orange_pellets_mask=mask)

    if (
        result.unceasing_top
        and not result.hand
        and result.random_card_credit <= 0
        and result.drawable_cards > 0
        and not _power_amount(result.player_powers, "No Draw")
    ):
        result = _draw_cards(result, 1)
    return result


def _known_draw_value(card, model):
    """Return compact quality credit for a card whose identity is known."""
    if card.card_type in {"STATUS", "CURSE"}:
        status_engine = (
            _power_amount(model.player_powers, "Evolve")
            or _power_amount(model.player_powers, "Fire Breathing")
        )
        return 1 if status_engine else 0
    if card.card_id in {"Adrenaline", "Offering", "Seeing Red"}:
        return 2
    return 1


def _draw_cards(model, requested):
    """Draw known top cards exactly, then value any post-shuffle draws generically."""
    requested = max(0, int(requested or 0))
    if (
        requested <= 0
        or model.drawable_cards <= 0
        or _power_amount(model.player_powers, "No Draw")
    ):
        return model

    drawn_count = min(
        requested,
        model.drawable_cards,
        max(0, 10 - len(model.hand)),
    )
    if drawn_count <= 0:
        return model

    known_count = min(drawn_count, len(model.draw_pile))
    known_cards = tuple(reversed(model.draw_pile[-known_count:])) if known_count else ()
    unknown_count = drawn_count - known_count
    draw_credit = sum(_known_draw_value(card, model) for card in known_cards)
    draw_credit += unknown_count
    result = replace(
        model,
        hand=model.hand + known_cards,
        draw_pile=model.draw_pile[:-known_count] if known_count else model.draw_pile,
        drawable_cards=model.drawable_cards - drawn_count,
        draw_value=model.draw_value + draw_credit,
    )
    if unknown_count > 0:
        if result.abacus:
            result = replace(result, block=result.block + 6)
            result = _trigger_juggernaut(result)
        if result.sundial_counter >= 0:
            counter = result.sundial_counter + 1
            if counter >= 3:
                result = replace(
                    result, sundial_counter=0, energy=result.energy + 2
                )
            else:
                result = replace(result, sundial_counter=counter)
    return result


def _advance_time_warp(model):
    """Apply Time Eater's card counter and forced turn at twelve cards."""
    monsters = list(model.monsters)
    forced_end = False
    for index, monster in enumerate(monsters):
        if monster.monster_id != "TimeEater" or not monster.alive:
            continue
        count = _power_amount(monster.powers, "Time Warp") + 1
        if count < 12:
            monsters[index] = replace(
                monster,
                powers=_set_power(monster.powers, "Time Warp", count),
            )
            continue

        powers = _set_power(monster.powers, "Time Warp", 0)
        powers = _set_power(powers, "Strength", _power_amount(powers, "Strength") + 2)
        damage = monster.damage
        if damage >= 0 and "ATTACK" in monster.intent:
            if _power_amount(model.player_powers, "IntangiblePlayer"):
                damage_gain = 0
            else:
                multiplier = 0.75 if _power_amount(monster.powers, "Weakened") else 1.0
                if _power_amount(model.player_powers, "Vulnerable"):
                    multiplier *= 1.5
                # The displayed move damage already includes Weak/Vulnerable,
                # but Time Warp adds two base Strength before those modifiers
                # are reapplied. Round the incremental risk upward because the
                # hidden base damage determines where the game's floors land.
                damage_gain = int(ceil(2 * multiplier))
            damage += damage_gain
        monsters[index] = replace(monster, damage=damage, powers=powers)
        forced_end = True

    if forced_end:
        # The twelfth card immediately ends the player turn.  Emptying the
        # modeled hand prevents the search from planning commands the game can
        # never execute after that card.
        return replace(model, monsters=tuple(monsters), hand=(), energy=0)
    return replace(model, monsters=tuple(monsters))


def _trigger_awakened_curiosity(model):
    """Apply Awakened One's first-phase penalty when a Power is played."""
    monsters = list(model.monsters)
    future_risk = model.future_risk
    awakened_curiosity_risk = model.awakened_curiosity_risk
    intangible = bool(_power_amount(model.player_powers, "IntangiblePlayer"))
    for index, monster in enumerate(monsters):
        curiosity = max(0, _power_amount(monster.powers, "Curiosity"))
        if monster.monster_id != "AwakenedOne" or not monster.alive or curiosity <= 0:
            continue
        powers = _set_power(
            monster.powers,
            "Strength",
            _power_amount(monster.powers, "Strength") + curiosity,
        )
        damage = monster.damage
        if damage >= 0 and "ATTACK" in monster.intent and not intangible:
            damage += curiosity
        monsters[index] = replace(monster, damage=damage, powers=powers)
        # Curiosity's Strength persists after this turn, including when
        # Intangible currently caps the displayed attack at one. Repeated
        # Powers and low HP make that permanent Strength increasingly costly.
        hp_ratio = model.hp / max(1, model.max_hp)
        active_powers = _awakened_active_power_count(model)
        extra_risk = 2 + max(0, active_powers - 1) * 4
        if hp_ratio < 0.45:
            extra_risk += 8
        if hp_ratio < 0.25:
            extra_risk += 12
        future_risk += curiosity * 2
        awakened_curiosity_risk += curiosity * extra_risk
    return replace(
        model,
        monsters=tuple(monsters),
        future_risk=future_risk,
        awakened_curiosity_risk=awakened_curiosity_risk,
    )


def _advance_slow(model):
    """Apply Giant Head's per-card Slow stack before the card resolves."""
    monsters = list(model.monsters)
    for index, monster in enumerate(monsters):
        if monster.monster_id == "GiantHead" and monster.alive:
            amount = max(0, _power_amount(monster.powers, "Slow")) + 1
            monsters[index] = replace(
                monster,
                powers=_set_power(monster.powers, "Slow", amount),
            )
    return replace(model, monsters=tuple(monsters))


def _havoc_target_index(model, card):
    alive = [
        index for index, monster in enumerate(model.monsters) if monster.alive
    ]
    if not alive:
        return None
    if len(alive) == 1:
        return alive[0]
    if card.card_id == "Spot Weakness":
        attacking = [
            index
            for index in alive
            if "ATTACK" in model.monsters[index].intent
        ]
        if attacking:
            return max(
                attacking,
                key=lambda index: (
                    model.monsters[index].damage
                    * max(1, model.monsters[index].hits),
                    model.monsters[index].hp,
                ),
            )
    # Havoc cannot choose a target. Model a durable target so the search does
    # not promise a convenient random minion kill.
    return max(
        alive,
        key=lambda index: (
            model.monsters[index].hp + model.monsters[index].block,
            model.monsters[index].hp,
        ),
    )


def _exhaust_unplayable_havoc_top(model, card):
    """Resolve Havoc exhausting a Status, Curse, or otherwise illegal top card."""
    feel_no_pain = _power_amount(model.player_powers, "Feel No Pain")
    dark_embrace = max(0, _power_amount(model.player_powers, "Dark Embrace"))
    result = replace(
        model,
        hand=model.hand[:-1],
        exhaust_pile=model.exhaust_pile + (card,),
        block=model.block + feel_no_pain,
        junk_exhausted=model.junk_exhausted
        + int(card.card_type in {"STATUS", "CURSE"}),
        attack_cards=model.attack_cards - int(card.card_type == "ATTACK"),
    )
    result = _trigger_exhaust_relics(result)
    return _draw_cards(result, dark_embrace)


def _resolve_havoc_top_card(model):
    """Play the exact visible top card for zero energy, then exhaust it."""
    if not model.draw_pile:
        return model

    top = model.draw_pile[-1]
    commands = model.commands
    forced_top = replace(
        top,
        cost=0,
        is_playable=True,
        exhausts=top.exhausts or top.card_type != "POWER",
    )
    prepared = replace(
        model,
        hand=model.hand + (forced_top,),
        draw_pile=model.draw_pile[:-1],
        drawable_cards=max(0, model.drawable_cards - 1),
    )

    if top.card_type in {"STATUS", "CURSE"}:
        resolved = _exhaust_unplayable_havoc_top(prepared, top)
    else:
        target_index = (
            _havoc_target_index(prepared, forced_top)
            if forced_top.has_target
            else None
        )
        try:
            if forced_top.has_target and target_index is None:
                raise ValueError("Havoc top card has no legal target")
            resolved = simulate_card(
                prepared,
                len(prepared.hand) - 1,
                target_index,
            )
        except ValueError:
            resolved = _exhaust_unplayable_havoc_top(prepared, top)

    resource_risk = 0
    if (
        not top.exhausts
        and top.card_type not in {"POWER", "STATUS", "CURSE"}
    ):
        core_value = max(
            FIEND_FIRE_CORE_EXHAUST_VALUES.get(top.card_id, 0),
            SECOND_WIND_CORE_EXHAUST_VALUES.get(top.card_id, 0),
        )
        if core_value:
            resource_risk = min(24, max(4, core_value // 3))
        else:
            resource_risk = 5 if top.card_type == "ATTACK" else 3
    return replace(
        resolved,
        commands=commands,
        future_risk=resolved.future_risk + resource_risk,
        resource_risk=resolved.resource_risk + resource_risk,
    )


def _restored_exhaust_card(card):
    return replace(
        card,
        is_playable=card.card_type in {"ATTACK", "SKILL", "POWER"},
    )


def _exhume_static_value(model, card):
    if card.card_id == "Exhume":
        return -10000
    if card.card_id in BLOCK_VALUE:
        base, upgrade = BLOCK_VALUE[card.card_id]
        block = adjusted_block(
            base + upgrade * min(card.upgrades, 1),
            model.dexterity,
            model.frail,
        )
        missing_block = max(0, model.incoming - model.block)
        value = block + min(block, missing_block) * 3
        if missing_block >= model.hp and block >= missing_block:
            value += 500
        if card.card_id == "Flame Barrier":
            value += sum(
                4 * max(1, monster.hits)
                for monster in model.monsters
                if monster.alive and "ATTACK" in monster.intent
            )
        return value
    if card.card_type == "ATTACK":
        base, hits, strength_multiplier = _base_attack(card, model)
        damage = max(0, base + model.strength * strength_multiplier) * hits
        if card.card_id in AOE_ATTACKS:
            damage *= max(1, sum(monster.alive for monster in model.monsters))
        return damage * 2
    if card.card_id in {"Offering", "Adrenaline", "Seeing Red"}:
        return 90
    if card.card_id in {"Shockwave", "Disarm", "Dark Shackles"}:
        return 75
    if card.card_id in {"Limit Break", "Spot Weakness"}:
        return 65
    if card.card_type == "POWER":
        return SAFE_POWER_VALUES.get(card.card_id, 10) * 3
    return 10 + DRAW_VALUES.get(card.card_id, (0, 0))[0] * 12


def _exhume_candidate_score(model, candidate, exhaust_index=None):
    """Score the best immediate use of one card returned by Exhume."""
    if candidate.card_id == "Exhume":
        return ((-1,), -10000)
    restored = _restored_exhaust_card(candidate)
    exhaust_pile = model.exhaust_pile
    if exhaust_index is not None and 0 <= exhaust_index < len(exhaust_pile):
        exhaust_pile = (
            exhaust_pile[:exhaust_index] + exhaust_pile[exhaust_index + 1 :]
        )
    prepared = replace(
        model,
        hand=model.hand + (restored,),
        exhaust_pile=exhaust_pile,
    )
    best_score = _evaluate(prepared).score
    played_immediately = 0
    if restored.is_playable and _card_cost(restored, prepared) <= prepared.energy:
        targets = range(len(prepared.monsters)) if restored.has_target else (None,)
        for target_index in targets:
            if target_index is not None and not prepared.monsters[target_index].alive:
                continue
            try:
                resolved = simulate_card(
                    prepared, len(prepared.hand) - 1, target_index
                )
            except ValueError:
                continue
            score = _evaluate(resolved).score
            if score > best_score:
                best_score = score
                played_immediately = 1
    return (
        best_score,
        played_immediately,
        _exhume_static_value(prepared, restored),
        -max(0, _card_cost(restored, prepared) - prepared.energy),
    )


def exhume_card_score(raw_card, combat, gs=None):
    """Return a comparable live-grid score for an Exhume candidate."""
    model = build_model(combat or {}, gs)
    candidate = _card_state_from_raw(
        raw_card or {}, 0, "exhume-choice", model.energy
    )
    candidate_uuid = candidate.uuid
    exhaust_index = next(
        (
            index
            for index, exhausted in enumerate(model.exhaust_pile)
            if exhausted.uuid == candidate_uuid
        ),
        None,
    )
    if exhaust_index is None:
        exhaust_index = next(
            (
                index
                for index, exhausted in enumerate(model.exhaust_pile)
                if exhausted.card_id == candidate.card_id
                and exhausted.upgrades == candidate.upgrades
            ),
            None,
        )
    return _exhume_candidate_score(model, candidate, exhaust_index)


def _resolve_exhume(model):
    candidates = [
        (index, card)
        for index, card in enumerate(model.exhaust_pile)
        if card.card_id != "Exhume"
    ]
    if not candidates:
        raise ValueError("Exhume has no retrievable card")
    exhaust_index, retrieved = max(
        candidates,
        key=lambda item: _exhume_candidate_score(model, item[1], item[0]),
    )
    return replace(
        model,
        hand=model.hand + (_restored_exhaust_card(retrieved),),
        exhaust_pile=(
            model.exhaust_pile[:exhaust_index]
            + model.exhaust_pile[exhaust_index + 1 :]
        ),
    )


def _secret_weapon_candidate_score(model, candidate, draw_index=None):
    """Score an exact draw-pile Attack after Secret Weapon retrieves it."""
    if candidate.card_type != "ATTACK":
        return ((-1,), 0, -10000, -10000)

    retrieved = replace(candidate, is_playable=True)
    draw_pile = model.draw_pile
    if draw_index is not None and 0 <= draw_index < len(draw_pile):
        draw_pile = draw_pile[:draw_index] + draw_pile[draw_index + 1 :]
    prepared = replace(
        model,
        hand=model.hand + (retrieved,),
        draw_pile=draw_pile,
        drawable_cards=max(
            0,
            model.drawable_cards - int(draw_index is not None),
        ),
    )
    best_score = _evaluate(prepared).score
    played_immediately = 0
    if retrieved.is_playable and _card_cost(retrieved, prepared) <= prepared.energy:
        targets = range(len(prepared.monsters)) if retrieved.has_target else (None,)
        for target_index in targets:
            if (
                target_index is not None
                and not prepared.monsters[target_index].alive
            ):
                continue
            try:
                resolved = simulate_card(
                    prepared, len(prepared.hand) - 1, target_index
                )
            except ValueError:
                continue
            score = _evaluate(resolved).score
            if score > best_score:
                best_score = score
                played_immediately = 1
    return (
        best_score,
        played_immediately,
        _exhume_static_value(prepared, retrieved),
        -max(0, _card_cost(retrieved, prepared) - prepared.energy),
    )


def secret_weapon_card_score(raw_card, combat, gs=None):
    """Return a live-grid score for one Attack offered by Secret Weapon."""
    model = build_model(combat or {}, gs)
    candidate = _card_state_from_raw(
        raw_card or {}, 0, "secret-weapon-choice", model.energy
    )
    candidate_uuid = candidate.uuid
    draw_index = next(
        (
            index
            for index, draw_card in enumerate(model.draw_pile)
            if draw_card.uuid == candidate_uuid
        ),
        None,
    )
    if draw_index is None:
        draw_index = next(
            (
                index
                for index, draw_card in enumerate(model.draw_pile)
                if draw_card.card_id == candidate.card_id
                and draw_card.upgrades == candidate.upgrades
            ),
            None,
        )
    return _secret_weapon_candidate_score(model, candidate, draw_index)


def _resolve_secret_weapon(model):
    candidates = [
        (index, card)
        for index, card in enumerate(model.draw_pile)
        if card.card_type == "ATTACK"
    ]
    if not candidates:
        raise ValueError("Secret Weapon requires an Attack in the draw pile")
    draw_index, retrieved = max(
        candidates,
        key=lambda item: _secret_weapon_candidate_score(
            model, item[1], item[0]
        ),
    )
    return replace(
        model,
        hand=model.hand + (replace(retrieved, is_playable=True),),
        draw_pile=(
            model.draw_pile[:draw_index]
            + model.draw_pile[draw_index + 1 :]
        ),
        drawable_cards=max(0, model.drawable_cards - 1),
    )


def _project_fiend_fire_attack(model, hand_index, target_index):
    """Project Fiend Fire's targeted damage without resolving its exhaust payoff."""
    card = model.hand[hand_index]
    cost = _card_cost(card, model)
    projected = replace(
        model,
        energy=model.energy - cost,
        hand=model.hand[:hand_index] + model.hand[hand_index + 1 :],
    )
    base, hits, strength_multiplier = _base_attack(
        card, projected, energy_spent=cost
    )
    damage_multiplier = 2 if model.pen_nib_ready else 1
    # Double Tap queues a second Fiend Fire after the first resolution has
    # already exhausted the original hand. The duplicate therefore cannot
    # repeat the first play's full hit count.
    projected = _apply_attack_to_target(
        projected,
        target_index,
        base,
        hits,
        strength_multiplier,
        damage_multiplier,
    )
    return projected


def _fiend_fire_has_safe_free_attack_first(model, hand_index, target_index):
    """Keep zero-cost attack damage instead of needlessly exhausting it."""
    direct = _project_fiend_fire_attack(model, hand_index, target_index)
    if direct.monsters[target_index].alive or direct.hp <= 0:
        return False

    fiend_uuid = model.hand[hand_index].uuid
    for candidate_index, candidate in enumerate(model.hand):
        if (
            candidate_index == hand_index
            or candidate.card_id == "Fiend Fire"
            or candidate.card_type != "ATTACK"
            or not candidate.has_target
            or not candidate.is_playable
            or _card_cost(candidate, model) != 0
        ):
            continue
        try:
            after_free = simulate_card(model, candidate_index, target_index)
        except ValueError:
            continue
        if after_free.hp <= 0:
            continue
        if not after_free.monsters[target_index].alive:
            return True
        next_fiend_index = next(
            (
                index
                for index, remaining in enumerate(after_free.hand)
                if remaining.uuid == fiend_uuid
            ),
            None,
        )
        if next_fiend_index is None:
            continue
        if _card_cost(after_free.hand[next_fiend_index], after_free) > after_free.energy:
            continue
        after_sequence = _project_fiend_fire_attack(
            after_free, next_fiend_index, target_index
        )
        if after_sequence.hp > 0 and not after_sequence.monsters[target_index].alive:
            return True
    return False


def _bronze_random_attack_should_precede(model, hand_index, target_index):
    """Resolve Sword Boomerang before spending a Stasis Orb finisher."""
    if target_index is None or model.pen_nib_ready:
        return False
    card = model.hand[hand_index]
    if (
        card.card_type != "ATTACK"
        or not card.has_target
        or card.card_id
        in {
            "Bash", "Clothesline", "Fiend Fire", "Sword Boomerang",
            "Uppercut",
        }
    ):
        return False
    key_orbs = [
        monster
        for monster in model.monsters
        if monster.alive
        and monster.monster_id == "BronzeOrb"
        and monster.stasis_card is not None
        and _bronze_stasis_priority(monster) >= 3
    ]
    if not key_orbs or sum(monster.alive for monster in model.monsters) <= 1:
        return False

    sword = next(
        (
            candidate
            for index, candidate in enumerate(model.hand)
            if index != hand_index
            and candidate.card_id == "Sword Boomerang"
            and candidate.is_playable
        ),
        None,
    )
    if sword is None:
        return False
    sword_cost = _card_cost(sword, model)
    card_cost = _card_cost(card, model)
    if sword_cost > model.energy or card_cost > model.energy - sword_cost:
        return False

    base, hits, strength_multiplier = _base_attack(
        card, model, energy_spent=card_cost
    )
    projected = _apply_attack_to_target(
        model, target_index, base, hits, strength_multiplier
    )
    # A guaranteed kill is already actionable information. Ordinary chip can
    # wait until the random hits reveal which target now has a clean finish.
    return projected.monsters[target_index].alive


def simulate_card(model, hand_index, target_index=None):
    card = model.hand[hand_index]
    cost = _card_cost(card, model)
    if not card.is_playable or cost > model.energy:
        raise ValueError("card is not playable")
    if model.velvet_choker_counter >= 6:
        raise ValueError("Velvet Choker has reached its six-card limit")
    if (
        card.card_id == "Berserk"
        and _power_amount(model.player_powers, "Artifact") <= 0
    ):
        projected_incoming = model.incoming
        if (
            _power_amount(model.player_powers, "Vulnerable") <= 0
            and _power_amount(model.player_powers, "IntangiblePlayer") <= 0
        ):
            projected_incoming = sum(
                int(max(0, monster.damage) * 1.5) * max(1, monster.hits)
                for monster in model.monsters
                if monster.alive and "ATTACK" in monster.intent
            )
        current_hit = max(
            0,
            projected_incoming - _projected_end_turn_block(model),
        )
        severe_hit = max(18, int(model.max_hp * 0.24))
        critical_reserve = max(12, int(model.max_hp * 0.22))
        if current_hit >= severe_hit and model.hp - current_hit <= critical_reserve:
            # Berserk's future energy cannot repay a current hit that leaves the
            # run at critical reserve. Batch 98 extended Vulnerable before a
            # 26-damage Chosen attack and fell from 31 HP to five.
            raise ValueError("Berserk would cross the post-hit reserve")
    if card.card_id == "Double Tap" and not any(
        index != hand_index
        and candidate.card_type == "ATTACK"
        and candidate.is_playable
        and _card_cost(candidate, model) <= model.energy - cost
        for index, candidate in enumerate(model.hand)
    ):
        # Double Tap expires at end of turn. Playing it without an affordable
        # attack only consumes energy that can still become Block this turn.
        raise ValueError("Double Tap requires an affordable attack in hand")
    if card.card_id == "Demon Form" and _awakened_curiosity_live(model):
        current_hit = max(
            0,
            model.incoming - _projected_end_turn_block(model),
        )
        critical_reserve = max(18, int(model.max_hp * 0.25))
        if (
            current_hit >= max(18, int(model.max_hp * 0.22))
            and model.hp - current_hit < critical_reserve
        ):
            # Demon Form is too slow when Awakened One's current attack already
            # consumes the reserve. Curiosity also strengthens every hit: the
            # logged A19 line spent three of five energy at 37 HP, raised 8x4
            # to 10x4, and lost the damage race before the first useful tick.
            raise ValueError("reserve HP before feeding Awakened One Curiosity")
    if _awakened_optional_power_uses_reserved_curiosity(model, hand_index):
        raise ValueError("reserve Awakened One Curiosity for supported engine")
    if (
        card.card_id == "AscendersBane"
        and card.card_type == "CURSE"
        and not model.curse_exhaust_payoff_ready
    ):
        # Ascender's Bane already exhausts itself at end of turn. Blue Candle
        # should not spend one HP merely to remove it a few seconds earlier
        # unless the HP loss or exhaust triggers an immediate payoff.
        raise ValueError("preserve HP while Ascender's Bane will auto-exhaust")
    if (
        card.card_id in NONSTACKING_POWER_IDS
        and _power_amount(model.player_powers, card.card_id) != 0
    ):
        raise ValueError("non-stacking power is already active")
    if card.card_id == "Limit Break" and model.strength <= 0:
        raise ValueError("Limit Break requires positive Strength")
    if card.card_id == "Burning Pact" and len(model.hand) <= 1:
        raise ValueError("Burning Pact requires another card to exhaust")
    dual_wield_target = None
    if card.card_id == "Dual Wield":
        dual_wield_index = dual_wield_target_index(model, hand_index)
        if dual_wield_index is None:
            raise ValueError("Dual Wield requires an Attack or Power in hand")
        dual_wield_target = model.hand[dual_wield_index]
    if card.card_id == "Exhume" and not any(
        exhausted.card_id != "Exhume" for exhausted in model.exhaust_pile
    ):
        raise ValueError("Exhume requires a card in the exhaust pile")
    if card.card_id == "Secret Weapon" and not any(
        draw_card.card_type == "ATTACK" for draw_card in model.draw_pile
    ):
        raise ValueError("Secret Weapon requires an Attack in the draw pile")
    if (
        card.card_id == "Sword Boomerang"
        and model.pen_nib_ready
        and sum(monster.alive for monster in model.monsters) > 1
        and any(
            candidate.card_type == "ATTACK"
            and candidate.has_target
            and candidate.card_id != "Sword Boomerang"
            and candidate.is_playable
            and _card_cost(candidate, model) <= model.energy
            for candidate in model.hand
        )
    ):
        raise ValueError("preserve Pen Nib for a deterministic target")
    if _bronze_random_attack_should_precede(
        model, hand_index, target_index
    ):
        # The bot replans after every live card. Let the random hits land first,
        # then spend deterministic attacks only if the observed Orb HP warrants
        # them; otherwise keep enough energy to block the current Orb attack.
        raise ValueError("observe Sword Boomerang before Stasis Orb finishers")
    if card.card_id == "Disarm" and target_index is not None:
        target = model.monsters[target_index]
        if (
            target.monster_id in {"AcidSlime_L", "SpikeSlime_L"}
            and "ATTACK" not in target.intent
        ):
            quiet_large_slimes = [
                (index, monster)
                for index, monster in enumerate(model.monsters)
                if monster.alive
                and monster.monster_id in {"AcidSlime_L", "SpikeSlime_L"}
                and "ATTACK" not in monster.intent
            ]
            if len(quiet_large_slimes) >= 2:
                durable_index, _ = max(
                    quiet_large_slimes,
                    key=lambda item: (
                        item[1].hp,
                        item[1].monster_id == "SpikeSlime_L",
                        -item[1].original_index,
                    ),
                )
                if target_index != durable_index:
                    # Large Slimes erase Strength loss when they split. Put the
                    # permanent debuff on the healthier, unfocused body; ties
                    # favor Spike while attacks continue focusing Acid.
                    raise ValueError("preserve Disarm on the later-splitting Slime")
    if (
        card.card_id == "Fiend Fire"
        and target_index is not None
        and _fiend_fire_has_safe_free_attack_first(
            model, hand_index, target_index
        )
    ):
        raise ValueError("play safe zero-cost attack before lethal Fiend Fire")
    if (
        card.card_id == "Fiend Fire"
        and target_index is not None
        and _power_amount(model.monsters[target_index].powers, "Intangible")
    ):
        target = model.monsters[target_index]
        exhaust_count = max(0, len(model.hand) - 1)
        lethal = target.hp + target.block <= exhaust_count
        feel_no_pain = max(
            0, _power_amount(model.player_powers, "Feel No Pain")
        )
        payoff_block = (exhaust_count + 1) * feel_no_pain
        current_loss = max(0, model.incoming - model.block)
        emergency_defense = (
            current_loss >= model.hp
            and max(0, current_loss - payoff_block) < model.hp
        )
        dark_embrace = bool(
            _power_amount(model.player_powers, "Dark Embrace")
        )
        junk_count = sum(
            candidate.card_type in {"STATUS", "CURSE"}
            for index, candidate in enumerate(model.hand)
            if index != hand_index
        )
        engine_cleanup = (
            dark_embrace
            and junk_count >= max(2, exhaust_count - 1)
        )
        if not (lethal or emergency_defense or engine_cleanup):
            # Nemesis's Intangible caps every Fiend Fire hit at one. Do not
            # delete the draw, defense and attack package for a few points of
            # chip unless the play ends the fight or creates real survival.
            raise ValueError("preserve Fiend Fire hand against Intangible")
    immediate_hp_cost = {
        "Bloodletting": 3,
        "J.A.X.": 3,
        "Offering": 6,
    }.get(card.card_id, 0)
    if immediate_hp_cost >= model.hp and model.revive_hp <= 0:
        raise ValueError("immediate self-damage would end the run")
    if (
        card.card_id == "J.A.X."
        and model.revive_hp <= 0
        and model.hp <= max(16, int(model.max_hp * 0.25))
        and max(0, model.incoming - model.block) >= model.hp
    ):
        # At 16/68 against Book of Stabbing, J.A.X. turned a surviving Flame
        # Barrier line into exact lethal. Its Strength is future value; when
        # the visible attack already kills, preserve the three HP for block.
        raise ValueError("critical incoming damage requires HP before J.A.X.")
    if (
        card.card_id == "J.A.X."
        and model.revive_hp <= 0
        and model.turn >= 7
        and (model.turn - 1) % 6 + 1 == 1
        and model.incoming <= model.block
        and model.hp <= max(24, int(model.max_hp * 0.35))
        and any(
            monster.monster_id == "BronzeAutomaton"
            and monster.alive
            and monster.hp > max(72, int(monster.max_hp * 0.24))
            for monster in model.monsters
        )
    ):
        # Automaton's post-Hyper-Beam stun is followed by a Strength-boosted
        # double hit. The A19 line reached that free turn at 15 HP and paid
        # three more for J.A.X.; even its known Power Through plus Shrug draw
        # could no longer survive the next attack. Preserve the raw HP unless
        # the boss is already in a genuine finishing window.
        raise ValueError("preserve post-beam HP before Automaton follow-up")
    conservation_risk = 0
    pain_triggers = sum(
        candidate.card_id == "Pain" for candidate in model.hand
    )
    will_exhaust = card.exhausts or (
        card.card_type == "SKILL" and bool(_power_amount(model.player_powers, "Corruption"))
    )
    if model.conserve_exhaust_defense and will_exhaust and card.card_id in BLOCK_VALUE:
        base_block, upgrade_block = BLOCK_VALUE[card.card_id]
        block_gain = (
            0
            if _power_amount(model.player_powers, "No Block")
            else adjusted_block(
                base_block + upgrade_block * min(card.upgrades, 1),
                model.dexterity,
                model.frail,
            )
        )
        block_needed = max(0, model.incoming - model.block)
        wasted_block = max(0, block_gain - block_needed)
        if wasted_block:
            # Exhausted block is finite against long bosses. Keep Impervious
            # and Corruption-powered Defends for turns that actually attack.
            conservation_risk = 6 + wasted_block
    tempo_risk = 0
    if card.card_id == "Demon Form":
        attacking_thieves = sum(
            monster.alive
            and monster.monster_id in {"Looter", "Mugger"}
            and "ATTACK" in monster.intent
            for monster in model.monsters
        )
        unblocked = max(0, model.incoming - model.block)
        has_immediate_attack = any(
            index != hand_index
            and candidate.card_type == "ATTACK"
            and candidate.is_playable
            and _card_cost(candidate, model) <= model.energy
            for index, candidate in enumerate(model.hand)
        )
        if (
            has_immediate_attack
            and attacking_thieves >= 2
            and unblocked >= max(16, int(model.max_hp * 0.18))
        ):
            # Three energy of delayed Strength is expensive when several
            # enemies are already attacking. The A16 thief pair took another
            # full attack cycle after Demon Form displaced Sword Boomerang.
            tempo_risk = 12 + max(0, unblocked - int(model.max_hp * 0.15))
        if (
            _awakened_curiosity_live(model)
            and _awakened_cultist_clearance_pending(model)
        ):
            tempo_risk = max(tempo_risk, 30)
    command_index = hand_index + 1
    if card.has_target:
        if target_index is None:
            raise ValueError("target required")
        target_command = model.monsters[target_index].original_index
        command = f"PLAY {command_index} {target_command}"
    else:
        command = f"PLAY {command_index}"
    awakened_key_value = _awakened_key_power_value(model, card)
    result = replace(
        model,
        energy=model.energy - cost,
        hand=model.hand[:hand_index] + model.hand[hand_index + 1 :],
        commands=model.commands + (command,),
        future_risk=model.future_risk + conservation_risk + tempo_risk,
        resource_risk=model.resource_risk + tempo_risk,
        pocketwatch_counter=(
            model.pocketwatch_counter + 1
            if model.pocketwatch_counter >= 0
            else -1
        ),
        velvet_choker_counter=(
            model.velvet_choker_counter + 1
            if model.velvet_choker_counter >= 0
            else -1
        ),
    )
    if pain_triggers:
        rupture = max(0, _power_amount(result.player_powers, "Rupture"))
        result = _lose_player_hp(result, pain_triggers)
        if rupture:
            result = _add_player_power(
                result, "Strength", rupture * pain_triggers
            )
            result = replace(
                result,
                scaling=result.scaling + rupture * pain_triggers * 4,
                offensive_scaling=(
                    result.offensive_scaling + rupture * pain_triggers * 4
                ),
            )
    result = _advance_slow(result)

    if card.card_id == "Dual Wield" and dual_wield_target is not None:
        copy_count = min(
            1 + min(card.upgrades, 1),
            max(0, 10 - len(result.hand)),
        )
        copies = tuple(
            replace(
                dual_wield_target,
                uuid=(
                    f"{dual_wield_target.uuid}:dual:"
                    f"{len(model.commands)}:{copy_index}"
                ),
            )
            for copy_index in range(copy_count)
        )
        result = replace(result, hand=result.hand + copies)

    if card.card_id == "Exhume":
        result = _resolve_exhume(result)

    if card.card_id == "Secret Weapon":
        result = _resolve_secret_weapon(result)

    if card.card_id == "Burning Pact":
        unblocked = max(0, result.incoming - result.block)
        urgent_block_pressure = unblocked >= max(10, int(result.hp * 0.25))
        live_block_cards = [
            candidate
            for candidate in result.hand
            if candidate.card_id in BLOCK_VALUE
            and candidate.is_playable
            and max(0, candidate.cost) <= result.energy
        ]
        protected_block_uuid = (
            live_block_cards[0].uuid
            if urgent_block_pressure and len(live_block_cards) == 1
            else None
        )

        def exhaust_priority(candidate):
            if candidate.card_type in {"STATUS", "CURSE"}:
                return 1000
            if candidate.card_id == "Sentinel":
                return 120
            if candidate.uuid == protected_block_uuid:
                # Burning Pact is allowed to cycle under pressure, but not by
                # consuming the only card that can reduce the current hit.
                return -300
            if candidate.card_id == "Defend_R":
                return 90
            if candidate.card_type == "ATTACK":
                if result.attack_cards <= 4:
                    return -200
                if candidate.card_id == "Strike_R":
                    return 95
                return 20
            if candidate.card_type == "POWER":
                return -150
            return 55

        exhaust_index = max(
            range(len(result.hand)),
            key=lambda index: exhaust_priority(result.hand[index]),
        )
        exhausted = result.hand[exhaust_index]
        if exhausted.card_type in {"STATUS", "CURSE"}:
            exhaust_risk = 0
        elif exhausted.card_id == "Defend_R":
            exhaust_risk = 0
        elif exhausted.card_id == "Strike_R":
            exhaust_risk = 4
        elif exhausted.card_type == "ATTACK":
            exhaust_risk = 24
        elif exhausted.card_type == "POWER":
            exhaust_risk = 30
        else:
            exhaust_risk = 8
        hand = result.hand[:exhaust_index] + result.hand[exhaust_index + 1 :]
        feel_no_pain = _power_amount(result.player_powers, "Feel No Pain")
        dark_embrace_draw = max(
            0, _power_amount(result.player_powers, "Dark Embrace")
        )
        result = replace(
            result,
            hand=hand,
            exhaust_pile=result.exhaust_pile + (exhausted,),
            block=result.block + feel_no_pain,
            energy=result.energy + ((2 + min(exhausted.upgrades, 1)) if exhausted.card_id == "Sentinel" else 0),
            future_risk=result.future_risk + exhaust_risk,
            junk_exhausted=result.junk_exhausted + int(exhausted.card_type in {"STATUS", "CURSE"}),
            attack_cards=result.attack_cards - int(exhausted.card_type == "ATTACK"),
        )
        result = _trigger_exhaust_relics(result)
        result = _draw_cards(result, dark_embrace_draw)

    if card.card_type == "ATTACK":
        base, hits, strength_multiplier = _base_attack(card, result, energy_spent=cost)
        vigor = max(0, _power_amount(result.player_powers, "Vigor"))
        if vigor:
            result = replace(
                result,
                player_powers=_set_power(result.player_powers, "Vigor", 0),
            )
        pen_nib_double = model.pen_nib_ready
        if pen_nib_double:
            result = replace(
                result,
                pen_nib_counter=0 if model.pen_nib_counter >= 0 else -1,
                pen_nib_ready=False,
            )
        elif model.pen_nib_counter >= 0:
            if model.pen_nib_counter >= 8:
                result = replace(
                    result, pen_nib_counter=9, pen_nib_ready=True
                )
            else:
                result = replace(
                    result, pen_nib_counter=model.pen_nib_counter + 1
                )
        damage_multiplier = 2 if pen_nib_double else 1
        if pen_nib_double and card.has_target and target_index is not None:
            target_state = model.monsters[target_index]
            vulnerable = bool(_power_amount(target_state.powers, "Vulnerable"))
            projected_damage = adjusted_attack(
                base + vigor, model.strength, model.weak, vulnerable,
                strength_multiplier,
                1.75 if model.paper_frog else 1.5,
            ) * damage_multiplier
            if _power_amount(target_state.powers, "Intangible"):
                projected_damage = min(projected_damage, 1)
            projected_damage *= hits
            if projected_damage >= target_state.hp + target_state.block:
                # When several targeted attacks consume Pen Nib for a kill,
                # preserve the energy needed for block, recovery or a second
                # target. This keeps a one-cost guaranteed orb kill ahead of
                # an equally lethal two-cost Bash.
                result = replace(
                    result,
                    risky_power_credit=result.risky_power_credit
                    + max(0, model.energy - cost) * 8,
                    bronze_orb_cleanup_credit=(
                        result.bronze_orb_cleanup_credit
                        + (
                            max(0, model.energy - cost) * 50
                            if target_state.monster_id == "BronzeOrb"
                            else 0
                        )
                    ),
                )
        rage_block = max(0, _power_amount(result.player_powers, "Rage"))
        if rage_block:
            # Rage triggers once per attack card, not once per hit. Compute the
            # attack first so Body Slam does not count block generated by itself.
            result = replace(result, block=result.block + rage_block)
        double_tap_triggered = (
            _power_amount(result.player_powers, "Double Tap") > 0
        )
        necronomicon_triggered = (
            result.necronomicon_available and card.cost >= 2
        )
        if necronomicon_triggered:
            result = replace(result, necronomicon_available=False)
        duplicate_plays = int(double_tap_triggered) + int(
            necronomicon_triggered
        )
        attack_plays = 1 + (
            duplicate_plays if card.card_id != "Fiend Fire" else 0
        )
        if card.card_id in AOE_ATTACKS:
            hp_before_reaper = result.hp
            hp_damage_dealt = 0
            for play_index in range(attack_plays):
                instance_base = base + (vigor if play_index == 0 else 0)
                for index, monster_state in enumerate(result.monsters):
                    if monster_state.alive:
                        hp_before = result.monsters[index].hp
                        result = _apply_attack_to_target(
                            result, index, instance_base, hits, strength_multiplier,
                            damage_multiplier,
                        )
                        hp_damage_dealt += hp_before - result.monsters[index].hp
                result = _apply_attack_instance_followup(
                    result, card, target_index
                )
            if card.card_id == "Reaper":
                result = _heal_player(result, hp_damage_dealt)
                healing = result.hp - hp_before_reaper
                if model.reaper_scaling_reserve and result.strength < 3:
                    projected_without = model.hp - max(
                        0, model.incoming - model.block
                    )
                    projected_with = result.hp - max(
                        0, result.incoming - result.block
                    )
                    removed_attacker = any(
                        before.alive
                        and "ATTACK" in before.intent
                        and not after.alive
                        for before, after in zip(model.monsters, result.monsters)
                    )
                    emergency_heal = (
                        projected_without <= 0 < projected_with
                        or (
                            model.hp <= int(model.max_hp * 0.28)
                            and healing >= 6
                        )
                        or removed_attacker
                        or not any(monster.alive for monster in result.monsters)
                    )
                    if not emergency_heal:
                        # Pyramid can bank Reaper until the visible Strength
                        # package turns one exhaust into a real reset. The A10
                        # Automaton run spent it for five HP on turn one, then
                        # reached ten Strength with three targets and no heal.
                        reserve_risk = 52 + (3 - result.strength) * 6
                        result = replace(
                            result,
                            future_risk=result.future_risk + reserve_risk,
                            resource_risk=result.resource_risk + reserve_risk,
                        )
        elif card.card_id == "Sword Boomerang" and sum(
            monster_state.alive for monster_state in result.monsters
        ) > 1:
            # Sword Boomerang cannot choose a target. Stacking every simulated
            # hit on monster zero invented guaranteed Byrd knockdowns that the
            # live card's random hits did not deliver. Spread the modeled hits
            # across living enemies so a plan never relies on that false
            # control; single-enemy fights still receive every hit normally.
            hit_index = 0
            for play_index in range(attack_plays):
                instance_base = base + (vigor if play_index == 0 else 0)
                for _ in range(hits):
                    living_indices = [
                        index
                        for index, monster_state in enumerate(result.monsters)
                        if monster_state.alive
                    ]
                    if not living_indices:
                        break
                    random_target = living_indices[
                        hit_index % len(living_indices)
                    ]
                    result = _apply_attack_to_target(
                        result, random_target, instance_base, 1,
                        strength_multiplier, damage_multiplier,
                    )
                    hit_index += 1
                result = _apply_attack_instance_followup(
                    result, card, target_index
                )
        else:
            for play_index in range(attack_plays):
                result = _apply_attack_to_target(
                    result, target_index or 0,
                    base + (vigor if play_index == 0 else 0), hits,
                    strength_multiplier, damage_multiplier,
                )
                result = _apply_attack_instance_followup(
                    result, card, target_index
                )
        if card.card_id == "Feed" and target_index is not None:
            target_before = model.monsters[target_index]
            target_after = result.monsters[target_index]
            feed_fatal = (
                target_before.alive
                and not target_after.alive
                and not _power_amount(target_before.powers, "Minion")
            )
            if feed_fatal:
                max_hp_gain = 3 + min(card.upgrades, 1)
                result = replace(
                    result,
                    hp=result.hp + max_hp_gain,
                    max_hp=result.max_hp + max_hp_gain,
                    feed_max_hp_gain=(
                        result.feed_max_hp_gain + max_hp_gain
                    ),
                )
        if (
            target_index is not None
            and cost == 0
            and target_index < len(model.monsters)
            and model.monsters[target_index].monster_id == "BronzeOrb"
        ):
            orb_damage = max(
                0,
                model.monsters[target_index].hp
                - result.monsters[target_index].hp,
            )
            if orb_damage:
                # Free targeted attacks can make orb progress without giving up
                # the energy needed for the Automaton race. Keep this credit
                # bounded so paid, nonlethal orb chip still loses to boss damage.
                result = replace(
                    result,
                    bronze_orb_cleanup_credit=(
                        result.bronze_orb_cleanup_credit
                        + min(24, orb_damage * 2)
                    ),
                )
        if double_tap_triggered:
            charges = _power_amount(result.player_powers, "Double Tap")
            result = replace(result, player_powers=_set_power(result.player_powers, "Double Tap", charges - 1))
        if card.card_id == "Bash" and result.monsters[target_index or 0].alive:
            already_vulnerable = bool(
                _power_amount(
                    model.monsters[target_index or 0].powers, "Vulnerable"
                )
            )
            if (
                result.monsters[target_index or 0].monster_id == "Hexaghost"
                and result.turn <= 3
                and not already_vulnerable
            ):
                # On Divider, Bash+Defend loses only two immediate damage
                # versus two Strikes+Defend, while Vulnerable pays off across
                # the following race. Keep that future value visible.
                result = replace(
                    result,
                    scaling=result.scaling + 6 + 2 * min(card.upgrades, 1),
                )
        if card.card_id == "Sever Soul":
            exhausted_cards = tuple(
                remaining
                for remaining in result.hand
                if remaining.card_type != "ATTACK"
            )
            if exhausted_cards:
                kept_hand = tuple(
                    remaining
                    for remaining in result.hand
                    if remaining.card_type == "ATTACK"
                )
                feel_no_pain = max(
                    0, _power_amount(result.player_powers, "Feel No Pain")
                )
                dark_embrace = max(
                    0, _power_amount(result.player_powers, "Dark Embrace")
                )
                block_cards_lost = sum(
                    adjusted_block(
                        BLOCK_VALUE[exhausted.card_id][0]
                        + BLOCK_VALUE[exhausted.card_id][1]
                        * min(exhausted.upgrades, 1),
                        result.dexterity,
                        result.frail,
                    )
                    for exhausted in exhausted_cards
                    if exhausted.card_id in BLOCK_VALUE
                )
                core_exhaust = sum(
                    SECOND_WIND_CORE_EXHAUST_VALUES.get(
                        exhausted.card_id, 0
                    )
                    for exhausted in exhausted_cards
                )
                unplayed_power_cost = sum(
                    max(
                        18,
                        SAFE_POWER_VALUES.get(exhausted.card_id, 8) * 2,
                    )
                    for exhausted in exhausted_cards
                    if exhausted.card_type == "POWER"
                )
                incoming_gap = max(0, result.incoming - result.block)
                defense_cost = min(block_cards_lost, incoming_gap) * 3
                junk_count = sum(
                    exhausted.card_type in {"STATUS", "CURSE"}
                    for exhausted in exhausted_cards
                )
                resource_risk = max(
                    0,
                    core_exhaust
                    + unplayed_power_cost
                    + defense_cost
                    - junk_count * 10,
                )
                result = replace(
                    result,
                    hand=kept_hand,
                    exhaust_pile=(
                        result.exhaust_pile + exhausted_cards
                    ),
                    block=(
                        result.block
                        + len(exhausted_cards) * feel_no_pain
                    ),
                    junk_exhausted=(
                        result.junk_exhausted + junk_count
                    ),
                    future_risk=result.future_risk + resource_risk,
                    resource_risk=result.resource_risk + resource_risk,
                )
                result = _trigger_exhaust_relics(
                    result, len(exhausted_cards)
                )
                result = _draw_cards(
                    result,
                    len(exhausted_cards) * dark_embrace,
                )
        if card.card_id == "Fiend Fire":
            exhausted_cards = result.hand
            synthetic_statuses = result.statuses_added
            exhaust_count = len(exhausted_cards) + synthetic_statuses
            exhausted_attacks = sum(c.card_type == "ATTACK" for c in exhausted_cards)
            feel_no_pain = _power_amount(result.player_powers, "Feel No Pain")
            dark_embrace = max(
                0, _power_amount(result.player_powers, "Dark Embrace")
            )
            drawn = exhaust_count * dark_embrace
            living_enemies = [monster for monster in result.monsters if monster.alive]
            resource_risk = 0
            if living_enemies:
                core_exhaust = sum(
                    FIEND_FIRE_CORE_EXHAUST_VALUES.get(exhausted.card_id, 0)
                    for exhausted in exhausted_cards
                )
                unplayed_power_cost = sum(
                    max(18, SAFE_POWER_VALUES.get(exhausted.card_id, 8) * 3)
                    for exhausted in exhausted_cards
                    if exhausted.card_type == "POWER"
                )
                attack_shortage = max(
                    0,
                    5 - max(0, result.attack_cards - exhausted_attacks),
                )
                block_cards_lost = sum(
                    BLOCK_VALUE.get(exhausted.card_id, (0, 0))[0]
                    + BLOCK_VALUE.get(exhausted.card_id, (0, 0))[1]
                    * min(exhausted.upgrades, 1)
                    for exhausted in exhausted_cards
                    if exhausted.card_id in BLOCK_VALUE
                )
                junk_count = synthetic_statuses + sum(
                    exhausted.card_type in {"STATUS", "CURSE"}
                    for exhausted in exhausted_cards
                )
                useful_exhaust_count = max(0, exhaust_count - junk_count)
                killed_current_threat = sum(
                    max(0, before.damage) * max(1, before.hits)
                    for before, after in zip(model.monsters, result.monsters)
                    if before.alive and "ATTACK" in before.intent and not after.alive
                )
                if len(living_enemies) >= 2:
                    # A one-target burst is not worth deleting the rest of the
                    # damage engine while several enemies are still scaling,
                    # unless the burst removes meaningful damage immediately.
                    # Pure Status/Curse fuel deletes no future resource, and an
                    # active Dark Embrace immediately replaces those cards.
                    if useful_exhaust_count:
                        resource_risk = (
                            core_exhaust
                            + unplayed_power_cost
                            + attack_shortage * 8
                            + 35 * (len(living_enemies) - 1)
                            - killed_current_threat * 4
                        )
                        targeted_automaton_orb = bool(
                            target_index is not None
                            and target_index < len(model.monsters)
                            and model.monsters[target_index].monster_id
                            == "BronzeOrb"
                        )
                        healthy_automaton = next(
                            (
                                monster
                                for monster in living_enemies
                                if monster.monster_id == "BronzeAutomaton"
                                and monster.hp
                                > max(72, int(monster.max_hp * 0.55))
                            ),
                            None,
                        )
                        prevented_lethal = (
                            max(0, model.incoming - model.block) >= model.hp
                            and max(0, result.incoming - result.block)
                            < result.hp
                        )
                        fire_breathing = max(
                            0,
                            _power_amount(
                                result.player_powers, "Fire Breathing"
                            ),
                        )
                        if (
                            synthetic_statuses
                            and fire_breathing
                            and not prevented_lethal
                        ):
                            # Power Through's compact Wounds have not been
                            # drawn yet, so they have not triggered an active
                            # Fire Breathing. Burning them immediately is a
                            # real loss of queued AoE, not free junk removal.
                            resource_risk += min(
                                96,
                                synthetic_statuses
                                * fire_breathing
                                * min(2, len(living_enemies)),
                            )
                        if (
                            targeted_automaton_orb
                            and healthy_automaton is not None
                            and not prevented_lethal
                        ):
                            # The logged A17 opener exhausted Heavy Blade+ and
                            # the rest of the hand to remove an unstolen Orb
                            # while Automaton still had 273 HP. Orb control is
                            # temporary; the long-boss damage engine is not.
                            resource_risk += 80 + core_exhaust // 2
                else:
                    enemy = living_enemies[0]
                    enemy_fraction = enemy.hp / max(1, enemy.max_hp)
                    incoming_gap = max(0, result.incoming - result.block)
                    defense_cost = min(block_cards_lost, incoming_gap) * 2
                    attack_package_cost = max(0, exhausted_attacks - 1) * 20
                    if (
                        exhausted_attacks >= 2
                        and not dark_embrace
                        and not feel_no_pain
                        and enemy_fraction > 0.35
                    ):
                        attack_package_cost += 18
                    # Single-target fights still punish deleting the whole
                    # future engine when the burst neither kills nor reaches a
                    # true finishing window. This was the main v72 failure:
                    # Fiend Fire was repeatedly treated as free damage even
                    # while it burned powers, recovery and the remaining attack
                    # package against long fights.
                    if enemy_fraction > 0.18:
                        resource_risk = (
                            int(core_exhaust * 0.75)
                            + unplayed_power_cost
                            + attack_shortage * 6
                            + defense_cost
                            + attack_package_cost
                        )
                        if (
                            enemy.monster_id in LONG_BOSS_IDS
                            and result.turn <= 6
                            and enemy_fraction > 0.35
                        ):
                            resource_risk += 28
                    # Statuses and curses are genuine fuel; active exhaust
                    # powers also recover part of the cost, but never erase
                    # the price of deleting an unplayed core Power.
                    resource_risk = max(
                        0,
                        resource_risk
                        - junk_count * 10
                        - (18 if dark_embrace else 0)
                        - (12 if feel_no_pain else 0),
                    )
                    resource_risk = max(
                        0,
                        resource_risk - killed_current_threat * 4,
                    )
                    true_finish_window = (
                        enemy_fraction <= 0.22
                        or (
                            enemy.monster_id in LONG_BOSS_IDS
                            and result.turn >= 7
                            and enemy_fraction <= 0.35
                        )
                    )
                    removed_lethal_attacker = (
                        killed_current_threat > 0
                        and result.incoming < result.initial_hp
                    )
                    protected_desperation_exhaust = any(
                        exhausted.card_id in {
                            "Flame Barrier", "Ghostly Armor", "Impervious",
                            "Offering", "Power Through", "Reaper",
                        }
                        for exhausted in exhausted_cards
                    )
                    damage_committed = max(
                        0,
                        result.initial_enemy_hp
                        - sum(
                            remaining.hp
                            for remaining in result.monsters
                            if remaining.alive
                        ),
                    )
                    quiet_snake_plant_burst = bool(
                        enemy.monster_id == "SnakePlant"
                        and result.turn <= 2
                        and result.initial_incoming == 0
                        and "ATTACK" not in enemy.initial_intent
                        and result.initial_hp <= int(result.max_hp * 0.70)
                        and enemy_fraction <= 0.55
                        and damage_committed >= 30
                        and not protected_desperation_exhaust
                    )
                    critical_solo_burst = bool(
                        result.initial_hp
                        <= max(18, int(result.max_hp * 0.25))
                        and result.incoming > result.block
                        and max(0, result.incoming - result.block) < result.hp
                        and enemy_fraction <= 0.55
                        and damage_committed
                        >= max(25, int(enemy.max_hp * 0.35))
                        and not protected_desperation_exhaust
                    )
                    automaton_cycle_burst = (
                        enemy.monster_id == "BronzeAutomaton"
                        and result.turn >= 7
                        and (
                            (
                                result.initial_hp <= 15
                                and result.initial_revive_hp > 0
                                and max(0, result.incoming - result.block)
                                >= result.initial_hp
                                and len(result.draw_pile) >= 8
                            )
                            or (
                                enemy.intent == "STUN"
                                and result.incoming == 0
                                and result.initial_revive_hp <= 0
                                and result.initial_hp
                                <= max(6, int(result.max_hp * 0.08))
                                and _power_amount(
                                    result.player_powers, "Buffer"
                                ) <= 0
                                and _power_amount(
                                    result.player_powers, "IntangiblePlayer"
                                ) <= 0
                            )
                        )
                    )
                    last_chance_boss_race = (
                        automaton_cycle_burst
                        or (
                            result.initial_hp <= 15
                            and enemy.monster_id in LONG_BOSS_IDS
                            and result.turn >= 5
                            and enemy_fraction <= 0.60
                            and result.incoming == 0
                        )
                    )
                    if quiet_snake_plant_burst or critical_solo_burst:
                        # Snake Plant's free debuff opener is often the only
                        # clean chance to front-load Fiend Fire before repeated
                        # 24/27-damage turns. At a critical reserve, preserving
                        # ordinary future cards is likewise worthless if a
                        # conservative line leaves a healthy solo attacker for
                        # the next turn. Keep true recovery and burst-block
                        # cards protected, then commit a surviving near-finish.
                        resource_risk = 0
                    elif last_chance_boss_race:
                        # A quiet late-boss turn, an Automaton turn that must
                        # consume a revive, or its post-Hyper-Beam stun at only
                        # a few raw HP may be the last useful Fiend Fire window.
                        # Future cards have no value when the next fixed-cycle
                        # attack cannot be survived, so commit the retained hand.
                        resource_risk = 0
                    elif true_finish_window:
                        # Near a real finish, future-cycle cards have sharply
                        # less time to repay their draw cost.  Discount rather
                        # than erase the price so Fiend Fire still avoids
                        # burning Reaper, powers, or the last defensive answer
                        # for ordinary chip damage.
                        resource_risk = int(resource_risk * 0.35)
                    elif removed_lethal_attacker:
                        resource_risk = int(resource_risk * 0.50)
                    elif result.initial_hp <= max(1, result.incoming):
                        # If Fiend Fire did not remove the lethal attacker,
                        # destroying the hand does not solve the current turn.
                        # Keep most of the resource cost visible instead of the
                        # v73 behaviour that treated a desperate race as free.
                        resource_risk = int(resource_risk * 0.85)

                    automaton = next(
                        (
                            monster
                            for monster in living_enemies
                            if monster.monster_id == "BronzeAutomaton"
                        ),
                        None,
                    )
                    if (
                        automaton is not None
                        and not automaton_cycle_burst
                        and automaton.hp > max(72, int(automaton.max_hp * 0.24))
                    ):
                        # Bronze Automaton is a fixed-cycle resource race.  In
                        # v75, Fiend Fire deleted Pommel Strike, Rampage, Twin
                        # Strike and another Fiend Fire while the boss still had
                        # 170 HP; the deck then ran out of damage before the next
                        # cycle. Preserve the future attack/block package unless
                        # this burst reaches a genuine finish or has an active
                        # Dark Embrace / Feel No Pain engine to repay the loss.
                        automaton_risk = (
                            48
                            + int(core_exhaust * 0.55)
                            + exhausted_attacks * 10
                            + min(35, block_cards_lost)
                        )
                        if dark_embrace:
                            automaton_risk -= 22
                        if feel_no_pain:
                            automaton_risk -= 16
                        resource_risk += max(18, automaton_risk)

                    initial_living = sum(monster.alive for monster in model.monsters)
                    if (
                        initial_living >= 2
                        and len(living_enemies) == 1
                        and living_enemies[0].monster_id in LONG_BOSS_IDS
                        and living_enemies[0].hp > int(living_enemies[0].max_hp * 0.35)
                        and core_exhaust > 0
                    ):
                        # Killing a Cultist/Torch Head is useful, but not when
                        # the price is Immolate, Double Tap or another engine
                        # card and the boss still has most of its health.
                        resource_risk += 35 + core_exhaust // 2

                    darklings_before = sum(
                        monster.monster_id == "Darkling" and monster.alive
                        for monster in model.monsters
                    )
                    darklings_after = sum(
                        monster.monster_id == "Darkling" and monster.alive
                        for monster in result.monsters
                    )
                    if 0 < darklings_after < darklings_before:
                        # Darklings revive unless every remaining Darkling is
                        # down together.  The logged v74 run exhausted nine
                        # useful cards to remove one Darkling, which returned
                        # two turns later.  Treat that as temporary damage, not
                        # a real kill, unless it was required to survive now.
                        prevented_lethal = (
                            model.incoming - model.block >= model.initial_hp
                            and result.incoming - result.block < result.initial_hp
                        )
                        resource_risk += (
                            35 if prevented_lethal
                            else 110 + core_exhaust // 2
                        )
                champ_before = next(
                    (
                        monster for monster in model.monsters
                        if monster.monster_id == "Champ" and monster.alive
                    ),
                    None,
                )
                champ_after = next(
                    (
                        monster for monster in result.monsters
                        if monster.monster_id == "Champ" and monster.alive
                    ),
                    None,
                )
                if (
                    champ_before is not None
                    and champ_after is not None
                    and champ_before.hp > champ_before.max_hp // 2
                    and champ_after.hp > champ_after.max_hp // 2
                    and champ_after.hp - champ_after.max_hp // 2
                    > max(
                        18,
                        int(champ_after.max_hp * 0.04),
                        result.known_next_attack_damage,
                    )
                    and not model.champ_forced_release
                    and max(0, model.incoming - model.block) < model.hp
                ):
                    # Fiend Fire is itself a one-shot phase-transition resource,
                    # even when it only exhausts junk. Spending it at 88% boss
                    # HP left the logged A16 deck without its planned burst. A
                    # known next hand that can cross the remaining distance is
                    # already a concrete transition plan and stays exempt.
                    phase_distance = champ_after.hp - champ_after.max_hp // 2
                    resource_risk += 36 + min(24, phase_distance // 8)
                reptomancer = next(
                    (
                        monster
                        for monster in result.monsters
                        if monster.monster_id == "Reptomancer" and monster.alive
                    ),
                    None,
                )
                if (
                    reptomancer is not None
                    and result.turn >= 4
                    and result.initial_hp <= int(result.max_hp * 0.45)
                    and reptomancer.hp
                    <= max(72, int(reptomancer.max_hp * 0.38))
                    and reptomancer.initial_hp - reptomancer.hp >= 50
                ):
                    # Reptomancer can refill the board immediately. At low HP,
                    # a late Fiend Fire that puts the boss inside one normal
                    # attack draw is a real commitment window; preserving the
                    # exhausted hand above that finish is false future value.
                    resource_risk = min(resource_risk, 30)
            visible_unblocked = max(0, model.incoming - model.block)
            projected_fnp_block = exhaust_count * feel_no_pain
            projected_unblocked = max(
                0, result.incoming - result.block - projected_fnp_block
            )
            fnp_damage_prevented = max(
                0, visible_unblocked - projected_unblocked
            )
            threatened_reserve = (
                model.initial_hp - visible_unblocked
                <= max(18, int(model.max_hp * 0.25))
            )
            if (
                feel_no_pain
                and threatened_reserve
                and fnp_damage_prevented >= max(6, int(model.max_hp * 0.08))
            ):
                # Fiend Fire is a burst block card once Feel No Pain is active.
                # The A17 Collector line valued the exhausted hand above 21
                # visible block, kept Regret, and fell to 16 instead of taking
                # the defensive exhaust window. Preserve a residual future
                # cost, but do not charge for the same hand above current HP.
                resource_risk = int(resource_risk * 0.25)

            if target_index is not None and target_index < len(model.monsters):
                before_target = model.monsters[target_index]
                after_target = result.monsters[target_index]
                burst_progress = max(
                    0,
                    before_target.hp + before_target.block
                    - after_target.hp - after_target.block,
                )
                if (
                    before_target.monster_id == "SnakePlant"
                    and "ATTACK" not in before_target.initial_intent
                    and model.initial_hp <= max(18, int(model.max_hp * 0.30))
                    and burst_progress >= max(
                        18, int(before_target.max_hp * 0.22)
                    )
                ):
                    # At critical HP the debuff turn is the last safe damage
                    # window before Snake Plant's three-hit attack. Future
                    # Strikes are not worth preserving above a real burst now.
                    resource_risk = min(resource_risk, 8)
            result = replace(
                result,
                block=result.block + exhaust_count * feel_no_pain,
                hand=(),
                exhaust_pile=result.exhaust_pile + exhausted_cards,
                statuses_added=0,
                junk_exhausted=result.junk_exhausted
                + synthetic_statuses
                + sum(c.card_type in {"STATUS", "CURSE"} for c in exhausted_cards),
                attack_cards=max(0, result.attack_cards - exhausted_attacks),
                future_risk=result.future_risk + resource_risk,
                resource_risk=result.resource_risk + resource_risk,
            )
            result = _trigger_exhaust_relics(result, exhaust_count)
            result = _draw_cards(result, drawn)

    if card.card_id in BLOCK_VALUE and card.card_id != "Iron Wave":
        base, upgrade = BLOCK_VALUE[card.card_id]
        gained = (
            0
            if _power_amount(result.player_powers, "No Block")
            else adjusted_block(
                base + upgrade * min(card.upgrades, 1),
                result.dexterity,
                result.frail,
            )
        )
        result = replace(result, block=result.block + gained)
        result = _trigger_juggernaut(result)
        if card.card_id == "PanicButton":
            result = _add_player_power(result, "No Block", 2)
        if card.card_id == "Flame Barrier":
            result = _add_player_power(
                result,
                "Flame Barrier",
                4 + 2 * min(card.upgrades, 1),
            )
        if card.card_id == "Armaments":
            free_lagavulin_setup = any(
                monster.alive
                and monster.monster_id == "Lagavulin"
                and monster.intent in {"SLEEP", "DEBUG"}
                for monster in result.monsters
            )
            if card.upgrades > 0:
                # Armaments+ upgrades every other card in hand. Damage, block
                # and cost reductions must all be visible this turn.
                upgraded_count = sum(
                    remaining.upgrades <= 0
                    and remaining.card_type not in {"STATUS", "CURSE"}
                    for remaining in result.hand
                )
                result = replace(
                    result,
                    hand=tuple(
                        _upgrade_card_in_hand(remaining, result)
                        for remaining in result.hand
                    ),
                    scaling=result.scaling
                    + (
                        min(24, upgraded_count * 6)
                        if free_lagavulin_setup
                        else 0
                    ),
                )
            else:
                upgrade_index = _armaments_upgrade_target_index(result)
                if upgrade_index is not None:
                    upgraded_hand = list(result.hand)
                    upgraded_hand[upgrade_index] = _upgrade_card_in_hand(
                        upgraded_hand[upgrade_index], result
                    )
                    result = replace(
                        result,
                        hand=tuple(upgraded_hand),
                        # An in-combat upgrade survives future reshuffles. On a
                        # free sleep turn it is real setup even though Block
                        # itself expires before Lagavulin attacks.
                        scaling=result.scaling
                        + (12 if free_lagavulin_setup else 0),
                    )
        if card.card_id == "True Grit" and result.hand:
            def preservation_value(candidate):
                if candidate.card_type in {"STATUS", "CURSE"}:
                    return -100
                if candidate.card_id == "Fiend Fire":
                    return 100
                if candidate.card_id in FIEND_FIRE_CORE_EXHAUST_VALUES:
                    return FIEND_FIRE_CORE_EXHAUST_VALUES[candidate.card_id]
                if candidate.card_type == "POWER":
                    return SAFE_POWER_VALUES.get(candidate.card_id, 10) * 3
                if candidate.card_type == "ATTACK":
                    attack_base, attack_hits, multiplier = _base_attack(candidate, result)
                    value = attack_base * attack_hits + max(0, result.strength) * multiplier * attack_hits
                    if candidate.card_id in AOE_ATTACKS:
                        value *= max(1, sum(monster.alive for monster in result.monsters))
                    return value
                if candidate.card_id in BLOCK_VALUE:
                    block_base, block_upgrade = BLOCK_VALUE[candidate.card_id]
                    return block_base + block_upgrade * min(candidate.upgrades, 1)
                return 8 + DRAW_VALUES.get(candidate.card_id, (0, 0))[0] * 5

            def controlled_exhaust_priority(candidate):
                if candidate.card_type in {"STATUS", "CURSE"}:
                    return 1000
                if candidate.card_id == "Sentinel":
                    return 120
                if candidate.card_id == "Defend_R":
                    return 90
                if candidate.card_type == "ATTACK":
                    if result.attack_cards <= 4:
                        return -200
                    return 95 if candidate.card_id == "Strike_R" else 20
                if candidate.card_type == "POWER":
                    return -150
                return 55

            if card.upgrades > 0:
                exhaust_index = max(
                    range(len(result.hand)),
                    key=lambda index: controlled_exhaust_priority(result.hand[index]),
                )
            else:
                # The live game picks randomly. Model the most damaging legal
                # outcome so a plan cannot promise safety using a follow-up card
                # that True Grit may remove before the bot replans.
                exhaust_index = max(
                    range(len(result.hand)),
                    key=lambda index: preservation_value(result.hand[index]),
                )
            exhausted = result.hand[exhaust_index]
            hand = result.hand[:exhaust_index] + result.hand[exhaust_index + 1 :]
            feel_no_pain = _power_amount(result.player_powers, "Feel No Pain")
            dark_embrace = max(
                0, _power_amount(result.player_powers, "Dark Embrace")
            )
            drawn = dark_embrace
            if exhausted.card_type in {"STATUS", "CURSE"}:
                exhaust_risk = 0
            elif exhausted.card_id == "Defend_R":
                exhaust_risk = 0
            elif exhausted.card_id == "Strike_R":
                exhaust_risk = 4
            elif exhausted.card_type == "ATTACK":
                exhaust_risk = 24
            elif exhausted.card_type == "POWER":
                exhaust_risk = 30
            else:
                exhaust_risk = 8
            if (
                exhausted.card_id == "Double Tap"
                and not any(
                    candidate.card_type == "ATTACK"
                    for candidate in result.hand
                )
            ):
                # With no attack in hand, Double Tap has no value this turn.
                # Do not spend more HP preserving it than True Grit blocks now.
                exhaust_risk = 2
            no_play_hp = model.hp - max(0, model.incoming - model.block)
            with_block_hp = model.hp - max(0, result.incoming - result.block)
            chosen_hex_defense = bool(
                _power_amount(model.player_powers, "Hex")
                and any(
                    monster.monster_id == "Chosen" and monster.alive
                    for monster in model.monsters
                )
                and max(0, model.incoming - model.block)
                >= max(12, int(model.max_hp * 0.18))
                and no_play_hp <= int(model.max_hp * 0.45)
                and with_block_hp > no_play_hp
            )
            if chosen_hex_defense:
                # Once Burning Pact exposes upgraded True Grit under a heavy
                # Chosen attack, spending a replaceable attack is cheaper than
                # carrying the HP loss into every later Hex-clogged cycle.
                exhaust_risk = min(exhaust_risk, 8)
            if (
                no_play_hp <= max(5, int(model.max_hp * 0.10))
                and with_block_hp > no_play_hp
            ):
                # At lethal range the random exhaust is still modeled by
                # removing the most valuable follow-up from hand. Do not also
                # price that lost card above Block that keeps this turn alive.
                exhaust_risk = min(exhaust_risk, 4)
            result = replace(
                result,
                hand=hand,
                exhaust_pile=result.exhaust_pile + (exhausted,),
                block=result.block + feel_no_pain,
                energy=result.energy
                + ((2 + min(exhausted.upgrades, 1)) if exhausted.card_id == "Sentinel" else 0),
                future_risk=result.future_risk + exhaust_risk,
                junk_exhausted=result.junk_exhausted
                + int(exhausted.card_type in {"STATUS", "CURSE"}),
                attack_cards=result.attack_cards - int(exhausted.card_type == "ATTACK"),
            )
            result = _trigger_exhaust_relics(result)
            result = _draw_cards(result, drawn)

    if (
        card.card_id == "Entrench"
        and not _power_amount(result.player_powers, "No Block")
    ):
        # Entrench is dynamic Block and cannot live in BLOCK_VALUE. It was
        # previously treated as an effectless skill, including when Mummified
        # Hand reduced it to zero during the logged Time Eater fight.
        result = replace(result, block=result.block * 2)
        result = _trigger_juggernaut(result)

    if card.card_type == "CURSE":
        hp_before_candle = result.hp
        self_damage_before = result.self_damage
        rupture = _power_amount(result.player_powers, "Rupture")
        result = _lose_player_hp(result, 1)
        loss = max(0, result.self_damage - self_damage_before)
        aggressive_credit = (
            loss
            if hp_before_candle >= max(15, int(result.max_hp * 0.35))
            else 0
        )
        if loss and rupture:
            result = _add_player_power(result, "Strength", rupture)
        result = replace(
            result,
            scaling=result.scaling + rupture * 4,
            risky_power_credit=result.risky_power_credit + aggressive_credit,
        )
    elif card.card_id == "Ghostly":
        # Council of Ghosts exposes Apparition under its internal card ID. One
        # stack caps each incoming damage packet at one for this turn.
        result = _add_player_power(result, "IntangiblePlayer", 1)
    elif card.card_id == "Second Wind":
        exhausted_cards = tuple(c for c in result.hand if c.card_type != "ATTACK")
        exhaust_count = len(exhausted_cards) + result.statuses_added
        if exhaust_count:
            block_per_card = adjusted_block(5 + 2 * min(card.upgrades, 1), result.dexterity, result.frail)
            feel_no_pain = _power_amount(result.player_powers, "Feel No Pain")
            dark_embrace = max(
                0, _power_amount(result.player_powers, "Dark Embrace")
            )
            drawn = exhaust_count * dark_embrace
            junk_exhausted = sum(c.card_type in {"STATUS", "CURSE"} for c in exhausted_cards)
            sentinel_energy = sum(
                2 + min(exhausted.upgrades, 1)
                for exhausted in exhausted_cards
                if exhausted.card_id == "Sentinel"
            )
            core_exhaust_risk = sum(
                SECOND_WIND_CORE_EXHAUST_VALUES.get(
                    exhausted.card_id,
                    SAFE_POWER_VALUES.get(exhausted.card_id, 0) * 2
                    if exhausted.card_type == "POWER"
                    else 0,
                )
                for exhausted in exhausted_cards
            )
            if result.incoming <= result.block:
                # A quiet cleanup may exhaust junk, but deleting a reusable
                # block card for temporary Block that immediately disappears
                # is still a future defensive cost. The logged A16 support
                # turn spent Second Wind on Defend plus Injury even though
                # ordinary attacks already killed the Healer for zero damage.
                core_exhaust_risk += sum(
                    adjusted_block(
                        BLOCK_VALUE[exhausted.card_id][0]
                        + BLOCK_VALUE[exhausted.card_id][1]
                        * min(exhausted.upgrades, 1),
                        result.dexterity,
                        result.frail,
                    )
                    * 2
                    for exhausted in exhausted_cards
                    if exhausted.card_id in BLOCK_VALUE
                    and exhausted.card_type not in {"STATUS", "CURSE"}
                )
            hexaghost_pre_inferno = bool(
                model.turn >= 8
                and (model.turn - 1) % 7 == 0
                and any(
                    monster.alive and monster.monster_id == "Hexaghost"
                    for monster in model.monsters
                )
            )
            if hexaghost_pre_inferno:
                # The single hit immediately before Inferno is intentionally
                # modest. Do not permanently consume the reusable defense that
                # must answer next turn's six-hit burst merely to cover it now.
                core_exhaust_risk += sum(
                    adjusted_block(
                        BLOCK_VALUE[exhausted.card_id][0]
                        + BLOCK_VALUE[exhausted.card_id][1]
                        * min(exhausted.upgrades, 1),
                        result.dexterity,
                        result.frail,
                    )
                    * 2
                    for exhausted in exhausted_cards
                    if exhausted.card_id in BLOCK_VALUE
                    and exhausted.card_type not in {"STATUS", "CURSE"}
                )
                core_exhaust_risk += sum(
                    30
                    for exhausted in exhausted_cards
                    if exhausted.card_id == "Second Wind"
                )
            projected_block = result.block + exhaust_count * (
                block_per_card + feel_no_pain
            )
            current_unblocked = max(0, model.incoming - model.block)
            projected_unblocked = max(0, result.incoming - projected_block)
            avoids_effective_lethal = (
                current_unblocked >= model.hp + model.revive_hp
                and projected_unblocked < result.hp + result.revive_hp
            )
            avoids_spending_revive = (
                model.revive_hp > 0
                and current_unblocked >= model.hp
                and projected_unblocked < result.hp
            )
            emergency_second_wind = (
                model.hp <= max(24, int(model.max_hp * 0.40))
                and (avoids_effective_lethal or avoids_spending_revive)
            )
            if emergency_second_wind:
                # In the logged A11 Pyramid fight, preserving two setup Powers
                # was priced above 14 avoidable HP even though Second Wind+
                # could fully block a lethal hit and leave Body Slam in hand.
                # At critical HP those Powers have no future value if the run
                # dies, so survival takes precedence over exhaust preservation.
                core_exhaust_risk = 0
            result = replace(
                result,
                block=projected_block,
                energy=result.energy + sentinel_energy,
                hand=tuple(c for c in result.hand if c.card_type == "ATTACK"),
                exhaust_pile=result.exhaust_pile + exhausted_cards,
                statuses_added=0,
                junk_exhausted=result.junk_exhausted + junk_exhausted + result.statuses_added,
                future_risk=result.future_risk + core_exhaust_risk,
                resource_risk=result.resource_risk + core_exhaust_risk,
            )
            result = _trigger_exhaust_relics(result, exhaust_count)
            result = _draw_cards(result, drawn)
    elif card.card_id == "Power Through":
        result = replace(result, statuses_added=result.statuses_added + 2)
    elif card.card_id in {"Wild Strike", "Reckless Charge"}:
        # These attacks shuffle a dead draw into the known future cycle. That
        # cost is delayed rather than visible in the current hand, so price it
        # separately from Power Through's immediately available Wounds. Keep
        # short hallway races unchanged; on Automaton the shuffled status can
        # land exactly in the known Hyper Beam draw cycle.
        if any(
            monster_state.alive
            and monster_state.monster_id == "BronzeAutomaton"
            for monster_state in result.monsters
        ):
            shuffled_status_risk = 4
            if result.hp <= int(result.max_hp * 0.50):
                shuffled_status_risk += 8
            if len(result.draw_pile) <= 10:
                shuffled_status_risk += 4
            if _power_amount(result.player_powers, "Evolve") > 0:
                shuffled_status_risk -= 10
            if _power_amount(result.player_powers, "Fire Breathing") > 0:
                shuffled_status_risk -= 6
            result = replace(
                result,
                future_risk=(
                    result.future_risk + max(0, shuffled_status_risk)
                ),
            )
    elif card.card_id == "Shockwave":
        amount = 3 + 2 * min(card.upgrades, 1)
        living_count = sum(monster_state.alive for monster_state in result.monsters)
        future_weak_credit = sum(
            _quiet_snake_plant_weak_credit(monster_state, amount)
            for monster_state in result.monsters
            if monster_state.alive
        )
        future_chosen_control = sum(
            _quiet_chosen_shockwave_credit(monster_state, amount)
            for monster_state in result.monsters
            if monster_state.alive
        )
        result = replace(
            result,
            monsters=tuple(
                _apply_vulnerable_with_belt(
                    result,
                    _apply_monster_power(
                        monster_state, "Weakened", amount
                    ),
                    amount,
                )
                if monster_state.alive
                else monster_state
                for monster_state in result.monsters
            ),
            scaling=(
                result.scaling
                + amount * min(3, living_count)
                + future_chosen_control
            ),
            risky_power_credit=result.risky_power_credit + future_weak_credit,
        )
    elif card.card_id == "Intimidate":
        amount = 1 + min(card.upgrades, 1)
        result = replace(
            result,
            monsters=tuple(
                _apply_monster_power(monster_state, "Weakened", amount)
                if monster_state.alive
                else monster_state
                for monster_state in result.monsters
            ),
        )
    elif card.card_id in {"Trip", "Blind"}:
        power_id = "Vulnerable" if card.card_id == "Trip" else "Weakened"
        target_indices = (
            range(len(result.monsters))
            if card.upgrades > 0
            else (target_index,)
        )
        monsters = list(result.monsters)
        applied_total = 0
        future_weak_credit = 0
        for index in target_indices:
            if index is None or not monsters[index].alive:
                continue
            before = _power_amount(monsters[index].powers, power_id)
            if power_id == "Weakened":
                future_weak_credit += _quiet_snake_plant_weak_credit(
                    monsters[index], 2
                )
            if power_id == "Vulnerable":
                monsters[index] = _apply_vulnerable_with_belt(
                    result, monsters[index], 2
                )
            else:
                monsters[index] = _apply_monster_power(
                    monsters[index], power_id, 2
                )
            applied_total += max(
                0,
                _power_amount(monsters[index].powers, power_id) - before,
            )
        # Their immediate attack/defense effects are modeled above. This
        # bounded credit also keeps a free two-turn debuff on a quiet boss turn.
        setup_value = applied_total * (4 if card.card_id == "Trip" else 3)
        result = replace(
            result,
            monsters=tuple(monsters),
            scaling=result.scaling + setup_value,
            risky_power_credit=(
                result.risky_power_credit + future_weak_credit
            ),
        )
    elif card.card_id == "Disarm" and target_index is not None:
        amount = 2 + min(card.upgrades, 1)
        monsters = list(result.monsters)
        monster = monsters[target_index]
        old_artifact = _power_amount(monster.powers, "Artifact")
        debuff_landed = False
        slime_is_splitting = (
            monster.monster_id in SPLIT_SLIME_IDS
            and monster.hp <= monster.max_hp // 2
        )
        if not slime_is_splitting:
            old_strength = _power_amount(monster.powers, "Strength")
            monsters[target_index] = _apply_monster_power(
                monster, "Strength", -amount
            )
            debuff_landed = (
                _power_amount(monsters[target_index].powers, "Strength")
                == old_strength - amount
            )
        # Splitting Slimes remove themselves at the end of the turn, and their
        # debuffs do not transfer to the children. Keep Disarm in the draw cycle
        # instead of exhausting it on a departing body.
        quiet_swarm_setup = (
            model.initial_incoming == 0
            and sum(candidate.alive for candidate in model.monsters) >= 2
        )
        setup_value = 0
        if not slime_is_splitting and debuff_landed:
            if monster.max_hp >= 60:
                setup_value = amount * 7
            elif quiet_swarm_setup:
                # A small enemy can still attack for several turns in a swarm.
                # With no current incoming damage, spare energy on permanent
                # Strength reduction is worth more than ending immediately.
                setup_value = amount * 4
        elif (
            not slime_is_splitting
            and monster.monster_id == "BronzeAutomaton"
            and model.turn <= 2
            and old_artifact == 1
            and _power_amount(monsters[target_index].powers, "Artifact") == 0
        ):
            # Clearing the last Artifact makes the next Disarm stick before
            # Hyper Beam; this setup has value even though Strength did not move.
            setup_value = 2
        champ_cleanse_pending = (
            monster.monster_id == "Champ"
            and (
                monster.initial_hp > monster.max_hp // 2
                or (
                    monster.hp <= monster.max_hp // 2
                    and "BUFF" in monster.intent
                )
            )
        )
        prior_disarm_spent = any(
            exhausted.card_id == "Disarm"
            for exhausted in result.exhaust_pile
        )
        champ_reserve_risk = (
            48 if champ_cleanse_pending and prior_disarm_spent else 0
        )
        result = replace(
            result,
            monsters=tuple(monsters),
            scaling=result.scaling + setup_value,
            future_risk=result.future_risk + champ_reserve_risk,
            slime_debuff_scaling=(
                result.slime_debuff_scaling
                + (setup_value if monster.monster_id == "SlimeBoss" else 0)
            ),
            strength_debuff_scaling=(
                result.strength_debuff_scaling
                + (setup_value if monster.monster_id != "SlimeBoss" else 0)
            ),
        )
    elif card.card_id == "Dark Shackles" and target_index is not None:
        # Dark Shackles retains until the dangerous turn, then removes 9/15
        # Strength for that turn. The search only evaluates the current enemy
        # action, so the end-of-turn Strength restoration is intentionally not
        # part of this state.
        amount = 9 + 6 * min(card.upgrades, 1)
        monsters = list(result.monsters)
        monster = monsters[target_index]
        monsters[target_index] = _apply_monster_power(
            monster, "Strength", -amount
        )
        hexaghost_reserve_risk = 0
        projected_without_shackles = model.initial_hp - max(
            0, model.initial_incoming - model.initial_block
        )
        if (
            monster.monster_id == "Hexaghost"
            and monster.initial_hits <= 1
            and model.initial_incoming <= 9
            and projected_without_shackles
            >= max(12, int(model.max_hp * 0.16))
            and monster.hp > max(30, int(monster.max_hp * 0.20))
        ):
            # Shackles is a one-use answer to Divider/Inferno. Spending it on
            # the logged six-damage Tackle prevented trivial chip, then left
            # the 4x6 turn uncovered. Keep it in the discard cycle while the
            # current single hit leaves a real reserve.
            hexaghost_reserve_risk = 42
        result = replace(
            result,
            monsters=tuple(monsters),
            future_risk=result.future_risk + hexaghost_reserve_risk,
            resource_risk=result.resource_risk + hexaghost_reserve_risk,
        )
    elif card.card_id == "Spot Weakness" and target_index is not None:
        target = result.monsters[target_index]
        if target.alive and "ATTACK" in target.intent:
            amount = 3 + min(card.upgrades, 1)
            result = _add_player_power(result, "Strength", amount)
            setup_value = 12 + 3 * min(card.upgrades, 1)
            result = replace(
                result,
                scaling=result.scaling + setup_value,
                offensive_scaling=result.offensive_scaling + setup_value,
            )
    elif card.card_id == "Limit Break":
        current_strength = result.strength
        result = _add_player_power(result, "Strength", current_strength)
        setup_value = max(8, current_strength * 6)
        remaining_enemy_hp = sum(
            monster.hp + monster.block
            for monster in result.monsters
            if monster.alive
        )
        if (
            card.upgrades > 0
            and model.initial_strength > 0
            and remaining_enemy_hp >= 45
        ):
            # Limit Break+ cycles back instead of exhausting. Doubling even one
            # or two Strength early therefore compounds with later copies and
            # every attack drawn before the next cycle. Reward the first useful
            # doubling without waiting for a large Strength stack. The bonus
            # falls with preceding actions, so immediate Strength sources still
            # go first when they make the actual doubling larger.
            actions_before = max(0, len(result.commands) - 1)
            setup_value = max(setup_value, 22) + max(
                0, 3 - actions_before
            ) * 2
        early_act2_credit = 0
        imminent_strength_source = any(
            held.card_id in {
                "Demon Form", "Flex", "Inflame", "J.A.X.",
                "Rupture", "Spot Weakness",
            }
            for held in (*model.hand, *model.draw_pile[-5:])
            if held.uuid != card.uuid
        )
        single_strength_long_fight_commitment = bool(
            card.upgrades <= 0
            and current_strength == 1
            and remaining_enemy_hp >= 90
            and not _power_amount(model.player_powers, "Demon Form")
            and not imminent_strength_source
        )
        preserve_critical_book_control = bool(
            current_strength == 1
            and model.initial_hp < int(model.max_hp * 0.40)
            and any(
                monster.alive and monster.monster_id == "BookOfStabbing"
                for monster in model.monsters
            )
            and any(
                held.is_playable
                and held.card_id in {"Shockwave", "Uppercut"}
                for held in model.hand
            )
        )
        if card.upgrades > 0:
            act2_min_enemy_hp = 30 if current_strength == 1 else 24
            act2_min_attacks = 1
        elif current_strength >= 3:
            act2_min_enemy_hp = 28
            act2_min_attacks = 1
        elif current_strength == 2:
            act2_min_enemy_hp = 40
            act2_min_attacks = 1
        else:
            act2_min_enemy_hp = 45
            act2_min_attacks = 3
        projected_unblocked = max(0, result.incoming - result.block)
        safe_act2_investment = (
            result.hp - projected_unblocked
            >= max(8, int(result.max_hp * 0.18))
        )
        if (
            model.act == 2
            and current_strength > 0
            and remaining_enemy_hp >= act2_min_enemy_hp
            and model.attack_cards >= act2_min_attacks
            and safe_act2_investment
            and not preserve_critical_book_control
        ):
            # Do not wait for a large stack in Act 2. At two Strength the extra
            # damage already repays itself across a long hallway fight, while an
            # upgraded copy or a larger stack deserves an even earlier window.
            # One Strength on an exhausting copy remains the narrow exception.
            actions_before = max(0, len(result.commands) - 1)
            early_act2_credit = min(
                48,
                12
                + current_strength * 4
                + min(12, model.attack_cards * 2)
                + max(0, 3 - actions_before) * 2
                + (14 if single_strength_long_fight_commitment else 0),
            )
            if card.upgrades <= 0 and current_strength == 1:
                early_act2_credit -= 3
            setup_value = max(setup_value, early_act2_credit)
        result = replace(
            result,
            scaling=result.scaling + setup_value,
            offensive_scaling=result.offensive_scaling + setup_value,
            limit_break_timing_credit=(
                result.limit_break_timing_credit + early_act2_credit
            ),
        )
    elif card.card_id == "Double Tap":
        result = _add_player_power(result, "Double Tap", 1 + min(card.upgrades, 1))
    elif card.card_id == "Metamorphosis":
        # The concrete random attacks are exposed by CommunicationMod only
        # after the card resolves, so do not invent cards or their draw order.
        # Credit the three future zero-cost attacks conservatively instead;
        # the next live state then lets the normal planner use their real IDs.
        generated_attacks = 3
        upgrade_quality = min(card.upgrades, 1)
        result = replace(
            result,
            scaling=(
                result.scaling
                + generated_attacks * (4 + upgrade_quality)
            ),
            offensive_scaling=(
                result.offensive_scaling
                + generated_attacks * (3 + upgrade_quality)
            ),
            draw_value=result.draw_value + generated_attacks,
        )
    elif card.card_id == "The Bomb":
        living_enemies = [
            monster for monster in result.monsters if monster.alive
        ]
        delayed_targets = len(living_enemies)
        if any(
            monster.monster_id == "SlimeBoss"
            and monster.hp > monster.max_hp // 2
            for monster in living_enemies
        ):
            # A turn-one Bomb normally lands after the boss has split, so its
            # delayed AoE reaches both large Slimes rather than only the body
            # currently exposed by CommunicationMod.
            delayed_targets = max(2, delayed_targets)
        setup_value = int(40 * delayed_targets * 0.75)
        result = replace(
            result,
            scaling=result.scaling + setup_value // 2,
            offensive_scaling=result.offensive_scaling + setup_value,
        )
    elif card.card_id == "Rage":
        result = _add_player_power(result, "Rage", 3 + 2 * min(card.upgrades, 1))
    elif card.card_id == "Inflame":
        result = _add_player_power(result, "Strength", 2 + min(card.upgrades, 1))
        result = _add_player_power(result, "Inflame", 1)
    elif card.card_id == "Barricade":
        result = _add_player_power(result, "Barricade", 1)
    elif card.card_id == "Demon Form":
        result = _add_player_power(
            result, "Demon Form", 2 + min(card.upgrades, 1)
        )
    elif card.card_id == "Evolve":
        result = _add_player_power(result, "Evolve", 1 + min(card.upgrades, 1))
    elif card.card_id == "Fire Breathing":
        amount = 6 + 4 * min(card.upgrades, 1)
        result = _add_player_power(result, "Fire Breathing", amount)
        # Only cards that can be drawn in the next natural hand are actionable
        # setup value. A Curse already in hand was drawn before this Power, and
        # a Curse buried below the next five cards is too slow for a short swarm
        # race. Counting both made the logged A17 Gremlin Gang opener spend one
        # of three energy here instead of blocking twenty incoming damage.
        next_draw_window = result.draw_pile[-5:]
        known_triggers = sum(
            candidate.card_type in {"STATUS", "CURSE"}
            for candidate in next_draw_window
        ) + max(0, result.statuses_added)
        living_enemies = sum(monster.alive for monster in result.monsters)
        result = replace(
            result,
            status_aoe_setup_credit=(
                result.status_aoe_setup_credit
                + amount
                * min(3, living_enemies)
                * min(2, known_triggers)
            ),
        )
    elif card.card_id == "Sadistic Nature":
        result = _add_player_power(
            result, "Sadistic Nature", 5 + 2 * min(card.upgrades, 1)
        )
    elif card.card_id == "Rupture":
        result = _add_player_power(result, "Rupture", 1 + min(card.upgrades, 1))
    elif card.card_id == "Flex":
        result = _add_player_power(result, "Strength", 2 + 2 * min(card.upgrades, 1))
    elif card.card_id == "Feel No Pain":
        result = _add_player_power(result, "Feel No Pain", 3 + min(card.upgrades, 1))
    elif card.card_id == "Dark Embrace":
        result = _add_player_power(result, "Dark Embrace", 1)
    elif card.card_id == "Juggernaut":
        result = _add_player_power(result, "Juggernaut", 5 + 2 * min(card.upgrades, 1))
    elif card.card_id == "Corruption":
        result = _add_player_power(result, "Corruption", 1)
        payoff_active = any(
            _power_amount(result.player_powers, power_id)
            for power_id in {"Feel No Pain", "Dark Embrace"}
        )
        if result.delay_corruption and not payoff_active:
            payoff_stranded = any(
                remaining.card_id in {"Feel No Pain", "Dark Embrace"}
                for remaining in result.hand
            )
            result = replace(
                result,
                future_risk=result.future_risk + (160 if payoff_stranded else 90),
            )
    elif card.card_id == "Metallicize":
        amount = 3 + min(card.upgrades, 1)
        result = _add_player_power(result, "Metallicize", amount)
    elif card.card_id == "Berserk":
        vulnerable_turns = 2 - min(card.upgrades, 1)
        artifact = max(0, _power_amount(result.player_powers, "Artifact"))
        if artifact:
            result = replace(
                result,
                player_powers=_set_power(
                    result.player_powers, "Artifact", artifact - 1
                ),
            )
        else:
            already_vulnerable = (
                _power_amount(result.player_powers, "Vulnerable") > 0
            )
            result = _add_player_power(
                result, "Vulnerable", vulnerable_turns
            )
            if not already_vulnerable:
                result = replace(
                    result,
                    monsters=tuple(
                        replace(monster, damage=int(monster.damage * 1.5))
                        if (
                            monster.alive
                            and monster.damage > 0
                            and "ATTACK" in monster.intent
                        )
                        else monster
                        for monster in result.monsters
                    ),
                )
            result = replace(
                result,
                future_risk=result.future_risk + 2 * vulnerable_turns,
            )
        result = replace(
            result,
            scaling=result.scaling + 10 + 2 * min(card.upgrades, 1),
        )
        result = _add_player_power(result, "Berserk", 1)
    elif card.card_id == "Brutality":
        result = _add_player_power(result, "Brutality", 1)
        result = replace(
            result, scaling=result.scaling + 9, future_risk=result.future_risk + 1
        )
    elif card.card_id == "Combust":
        living_enemies = sum(monster.alive for monster in result.monsters)
        setup_value = 8 + 3 * max(0, living_enemies - 1)
        result = _add_player_power(
            result, "Combust", 5 + 2 * min(card.upgrades, 1)
        )
        result = replace(
            result,
            scaling=result.scaling + setup_value,
            offensive_scaling=result.offensive_scaling + setup_value,
            future_risk=result.future_risk + 1,
            combust_hp_loss=result.combust_hp_loss + 1,
        )
    elif card.card_id == "Adrenaline":
        result = replace(
            result,
            energy=result.energy + 1 + min(card.upgrades, 1),
        )
    elif card.card_id == "Bloodletting":
        loss = min(3, result.hp)
        rupture = _power_amount(result.player_powers, "Rupture")
        if loss and rupture:
            result = _add_player_power(result, "Strength", rupture)
        result = _lose_player_hp(result, 3)
        result = replace(
            result,
            energy=result.energy + 2 + min(card.upgrades, 1),
            scaling=result.scaling + rupture * 4,
            offensive_scaling=result.offensive_scaling + rupture * 4,
        )
    elif card.card_id == "Offering":
        requested = 3 + 2 * min(card.upgrades, 1)
        result = _lose_player_hp(result, 6)
        result = replace(
            result,
            energy=result.energy + 2,
        )
        result = _draw_cards(result, requested)
    elif card.card_id == "Seeing Red":
        result = replace(result, energy=result.energy + 2 + min(card.upgrades, 1))
    elif card.card_id == "J.A.X.":
        loss = min(3, result.hp)
        aggressive_credit = loss if result.hp >= max(15, int(result.max_hp * 0.35)) else 0
        result = _add_player_power(
            result, "Strength", 2 + min(card.upgrades, 1)
        )
        result = _lose_player_hp(result, 3)
        result = replace(
            result,
            scaling=result.scaling + 10,
            offensive_scaling=(
                result.offensive_scaling + aggressive_credit * 3
            ),
            risky_power_credit=result.risky_power_credit + aggressive_credit,
        )

    if card.card_id == "Havoc":
        result = _resolve_havoc_top_card(result)

    if card.card_type == "POWER":
        result = _trigger_mummified_hand(result)

    if card.card_type == "POWER" and card.card_id in SAFE_POWER_VALUES:
        power_value = SAFE_POWER_VALUES[card.card_id]
        if card.card_id == "Rupture" and not result.self_damage_power_ready:
            power_value = 0
        if card.card_id in {"Dark Embrace", "Feel No Pain"} and not result.exhaust_power_ready:
            # Preserve immediate same-turn exhaust interactions, but do not
            # award speculative long-fight setup credit to a payoff backed by
            # only one or two single-use exhaust cards.
            power_value = 0
        if card.card_id == "Barricade":
            # Barricade has little future value when the deck cannot produce
            # excess block. Keep full setup credit on a genuinely spare turn,
            # but do not let it replace a second Defend during Divider.
            if result.incoming > result.block:
                power_value = min(power_value, 2 + result.barricade_support * 4)
        result = replace(
            result,
            scaling=result.scaling + power_value + 2 * min(card.upgrades, 1),
            offensive_scaling=result.offensive_scaling
            + (
                power_value + 2 * min(card.upgrades, 1)
                if card.card_id in {
                    "Demon Form", "Inflame", "Rupture", "Sadistic Nature",
                }
                else 0
            ),
            exhaust_power_scaling=result.exhaust_power_scaling
            + (
                power_value + 2 * min(card.upgrades, 1)
                if card.card_id in {"Corruption", "Dark Embrace", "Feel No Pain"}
                else 0
            ),
        )
    if card.card_type == "POWER" and awakened_key_value:
        result = replace(
            result,
            awakened_key_power_credit=(
                result.awakened_key_power_credit + awakened_key_value
            ),
        )
    if card.card_type == "POWER":
        result = _trigger_awakened_curiosity(result)
    if card.card_type == "POWER" and card.card_id in RISKY_POWER_HP_THRESHOLDS:
        hp_ratio = result.hp / max(1, result.max_hp)
        if hp_ratio >= RISKY_POWER_HP_THRESHOLDS[card.card_id]:
            credit = 10 + 2 * min(card.upgrades, 1) if card.card_id == "Berserk" else 3
            result = replace(result, risky_power_credit=result.risky_power_credit + credit)
    if card.card_id in DRAW_VALUES and result.drawable_cards > 0:
        base_draw, upgrade_draw = DRAW_VALUES[card.card_id]
        requested = base_draw + upgrade_draw * min(card.upgrades, 1)
        draw_allowed = True
        if card.card_id == "Impatience":
            draw_allowed = not any(
                hand_card.card_type == "ATTACK" for hand_card in result.hand
            )
        if card.card_id == "Dropkick":
            draw_allowed = bool(
                target_index is not None
                and target_index < len(model.monsters)
                and _power_amount(model.monsters[target_index].powers, "Vulnerable")
            )
            if draw_allowed:
                result = replace(result, energy=result.energy + 1)
        if card.card_id == "Deep Breath":
            # Its shuffle destroys the visible order before drawing.
            result = replace(result, draw_pile=())
        if draw_allowed:
            result = _draw_cards(result, requested)
        if card.card_id == "Battle Trance":
            result = _add_player_power(result, "No Draw", 1)
    exhausts = card.exhausts or card.card_type == "CURSE" or (
        card.card_type == "SKILL" and bool(_power_amount(result.player_powers, "Corruption"))
    )
    if exhausts:
        result = replace(result, exhaust_pile=result.exhaust_pile + (card,))
        result = _trigger_exhaust_relics(result)
    if exhausts and _power_amount(result.player_powers, "Feel No Pain"):
        result = replace(result, block=result.block + _power_amount(result.player_powers, "Feel No Pain"))
        result = _trigger_juggernaut(result)
    if exhausts and _power_amount(result.player_powers, "Dark Embrace"):
        result = _draw_cards(
            result,
            max(0, _power_amount(result.player_powers, "Dark Embrace")),
        )
    if exhausts and card.card_type in {"STATUS", "CURSE"}:
        result = replace(result, junk_exhausted=result.junk_exhausted + 1)
    if exhausts and card.card_type == "ATTACK":
        result = replace(result, attack_cards=max(0, result.attack_cards - 1))
    if card.card_type == "SKILL":
        monsters = list(result.monsters)
        future_risk = result.future_risk
        for index, monster in enumerate(monsters):
            enrage = (
                max(
                    _power_amount(monster.powers, "Enrage"),
                    _power_amount(monster.powers, "Anger"),
                )
                if monster.monster_id == "GremlinNob" and monster.alive
                else 0
            )
            if enrage:
                strength = _power_amount(monster.powers, "Strength") + enrage
                damage_gain = enrage
                if monster.damage >= 0 and _power_amount(result.player_powers, "Vulnerable"):
                    damage_gain = int(enrage * 1.5)
                monsters[index] = replace(
                    monster,
                    damage=monster.damage + damage_gain if monster.damage >= 0 else monster.damage,
                    powers=_set_power(monster.powers, "Strength", strength),
                )
                future_risk += damage_gain
        result = replace(result, monsters=tuple(monsters), future_risk=future_risk)
    if card.card_type != "ATTACK" and _power_amount(result.player_powers, "Hex"):
        # Chosen's Hex puts a Dazed into the draw pile for every non-attack.
        # Price the future clog so optional setup does not quietly bury the
        # next cycle, while survival block can still win on immediate HP.
        hex_risk = 8
        if (
            card.card_id in DRAW_VALUES
            and model.drawable_cards > 0
            and max(
                0,
                model.incoming - _projected_end_turn_block(model),
            ) >= max(12, int(model.max_hp * 0.18))
        ):
            # Under a heavy live attack, a known defensive draw is worth taking
            # even though Hex adds one Dazed. Batch 98 left Burning Pact unused
            # with True Grit and Shrug visible on top, then paid 18 HP.
            hex_risk = 3
        if (
            _power_amount(result.player_powers, "Evolve")
            or _power_amount(result.player_powers, "Fire Breathing")
        ):
            # A real status engine partially converts the extra Dazed into
            # draw or damage, but it is still not completely free.
            hex_risk = 3
        if (
            card.card_id in {"Dark Embrace", "Feel No Pain"}
            and _power_amount(result.player_powers, "Corruption")
        ):
            # These powers convert the already-free, exhausting skills into
            # draw or block. One Dazed is not worth declining the whole engine.
            hex_risk = 0
        result = replace(result, future_risk=result.future_risk + hex_risk)
    result = _trigger_card_play_relics(result, card)
    return _advance_time_warp(result)


def _end_turn_damage(model):
    def adjusted_loss(amount):
        amount = max(0, int(amount or 0))
        if model.tungsten_rod and amount > 0:
            amount -= 1
        return amount

    damage = adjusted_loss(model.combust_hp_loss)
    damage += adjusted_loss(
        _power_amount(model.player_powers, "Constricted")
    )
    # An active Brutality ticks before the next hand can be played. A line that
    # ends at one HP is therefore already lethal even if this enemy turn is
    # completely blocked.
    if _power_amount(model.player_powers, "Brutality") > 0:
        damage += adjusted_loss(1)
    damage += sum(
        adjusted_loss(2) for card in model.hand if card.card_id == "Decay"
    )
    regret_copies = sum(card.card_id == "Regret" for card in model.hand)
    if regret_copies:
        # Each Regret loses HP equal to the complete retained hand, including
        # itself. This is especially important with Runic Pyramid: the logged
        # Collector defense line appeared seven HP safer than it really was.
        damage += sum(
            adjusted_loss(len(model.hand)) for _ in range(regret_copies)
        )
    return damage


def _end_turn_ethereal_exhaust_block(model):
    """Return Feel No Pain block from Ethereal cards left in hand."""
    feel_no_pain = max(0, _power_amount(model.player_powers, "Feel No Pain"))
    if feel_no_pain <= 0:
        return 0
    return feel_no_pain * sum(card.ethereal for card in model.hand)


def _projected_end_turn_block(model):
    """Return block available after end-of-turn powers and exhausts resolve."""
    metallicize = max(0, _power_amount(model.player_powers, "Metallicize"))
    projected = model.block + metallicize + _end_turn_ethereal_exhaust_block(model)
    if model.orichalcum and projected == 0:
        projected = 6
    return projected


def _projected_calipers_retained_block(model):
    """Return Block that survives enemy damage and Calipers' 15-Block loss."""
    if not model.calipers or not any(monster.alive for monster in model.monsters):
        return 0
    block = _projected_end_turn_block(model)
    intangible = bool(_power_amount(model.player_powers, "IntangiblePlayer"))
    packets = []
    packets.extend(
        4 if card.upgrades > 0 else 2
        for card in model.hand
        if card.card_id == "Burn"
    )
    for monster in model.monsters:
        if not monster.alive:
            continue
        if "ATTACK" in monster.intent and monster.damage > 0:
            packet = min(monster.damage, 1) if intangible else monster.damage
            packets.extend([packet] * max(1, monster.hits))
        if _imminent_exploder(monster):
            packets.append(1 if intangible else 30)
    block_after_damage = max(0, block - sum(packets))
    return max(0, block_after_damage - 15)


def _calipers_retained_block_credit(model):
    """Value only the portion of a Calipers bank likely to prevent damage."""
    retained = _projected_calipers_retained_block(model)
    if retained <= 0:
        return 0

    hp_ratio = model.initial_hp / max(1, model.max_hp)
    current_turn_is_covered = model.initial_incoming <= model.initial_block
    support_stall = bool(
        any(
            monster.alive and monster.monster_id in {"Healer", "Mystic"}
            for monster in model.monsters
        )
        and sum(monster.alive for monster in model.monsters) >= 2
    )
    if current_turn_is_covered:
        spire_growth_constrict_bridge = bool(
            hp_ratio < 0.25
            and _power_amount(model.player_powers, "Constricted") == 0
            and any(
                monster.alive
                and monster.monster_id == "Serpent"
                and "STRONG_DEBUFF" in monster.intent
                for monster in model.monsters
            )
        )
        if spire_growth_constrict_bridge:
            # Spire Growth applies Constricted before its first attack. At
            # critical HP, bank only enough Block to bridge that known 10/12 HP
            # end-turn packet; this remains bounded so Calipers does not resume
            # stacking Block in ordinary quiet turns.
            constrict_damage = 12 if model.ascension >= 17 else 10
            complete_bridge_credit = (
                constrict_damage * 2
                if retained >= constrict_damage
                else 0
            )
            return min(retained, constrict_damage) * 3 + complete_bridge_credit
        if hp_ratio < 0.35 and support_stall:
            # Damage into an active healer is often temporary. At critical HP,
            # one bounded bank can bridge the next Centurion/Healer attack.
            return min(retained, 36) * 3
        if hp_ratio < 0.30 and any(
            monster.alive and monster.monster_id == "Champ"
            for monster in model.monsters
        ):
            # Champ's quiet turns are the only safe window for an exhaustible
            # Impervious once the life bar is already in Execute range. Credit
            # one 25-Block bridge, but cap it there so Calipers does not resume
            # stacking every available block card instead of progressing phase.
            return min(retained, 25) * 3
        # Without a concrete next-turn threat, speculative Block must not beat
        # attacks or permanent setup merely because Calipers can retain a few
        # points. This was the source of repeated all-block Darkling turns.
        return 0

    strongest_visible_attack = max(
        (
            max(0, monster.damage) * max(1, monster.hits)
            for monster in model.monsters
            if monster.alive and "ATTACK" in monster.intent
        ),
        default=0,
    )
    reserve_target = 4 if hp_ratio >= 0.70 else 8 if hp_ratio >= 0.40 else 12
    future_block_target = min(
        reserve_target,
        max(4, strongest_visible_attack),
    )
    # One retained Block is worth at most one point of immediate damage. Do not
    # multiply it merely because HP is low: current-turn survival is already
    # scored first, while the next intent remains unknown.
    return min(retained, future_block_target)


def _incoming_damage_packets_after_block(model):
    """Resolve block and Buffer while preserving individual enemy hits."""
    projected_block = _projected_end_turn_block(model)
    buffer = max(0, _power_amount(model.player_powers, "Buffer"))
    intangible = bool(_power_amount(model.player_powers, "IntangiblePlayer"))
    block = max(0, projected_block)
    packets = []
    if any(monster.alive for monster in model.monsters):
        # Burn resolves at the end of the player's turn, before the enemies
        # act. It is ordinary damage and consumes retained Block; upgraded
        # Burns deal four. Keeping it in the later HP-loss bucket discarded
        # leftover Block and made a logged Hexaghost line appear both
        # survivable and impossible to improve with another Defend. Decay is
        # separate HP loss and remains in _end_turn_damage.
        packets.extend(
            (4 if card.upgrades > 0 else 2, False)
            for card in model.hand
            if card.card_id == "Burn"
        )
    for monster in model.monsters:
        if not monster.alive:
            continue
        if "ATTACK" in monster.intent and monster.damage > 0:
            packets.extend(
                [(monster.damage, True)] * max(1, monster.hits)
            )
        if _imminent_exploder(monster):
            packets.append((30, False))

    hp_packets = []
    for packet, enemy_attack in packets:
        if intangible:
            packet = min(packet, 1)
        blocked = min(block, packet)
        block -= blocked
        unblocked = packet - blocked
        if enemy_attack and model.torii and 0 < unblocked <= 5:
            unblocked = 1
        if model.tungsten_rod and unblocked > 0:
            unblocked -= 1
        if unblocked <= 0:
            continue
        if buffer > 0:
            buffer -= 1
        else:
            hp_packets.append(unblocked)
    return tuple(hp_packets)


def _incoming_damage_after_block(model):
    return sum(_incoming_damage_packets_after_block(model))


def _strategic_threat(monster):
    if monster.monster_id == "BronzeOrb":
        # Orbs steal key cards, add damage, and remain alive through Hyper Beam.
        # Clearing them is more urgent than incidental damage to Automaton.
        support = 48
    else:
        # Healers can erase an entire attack card's progress and keep their
        # partner alive long enough to kill a low-HP run. Torch Heads are still
        # urgent, but do not heal and therefore receive a smaller support tag.
        if monster.monster_id in {"Healer", "Mystic"}:
            support = 65
        elif monster.monster_id == "TorchHead":
            support = 42
        else:
            support = 0
    if monster.monster_id == "BanditLeader":
        scaling = 18
    elif monster.monster_id == "Donu":
        # Donu permanently raises both bosses' Strength every other turn.
        # Removing it first sharply lowers the remaining damage race.
        scaling = 70
    elif monster.monster_id == "Cultist":
        scaling = 60
    elif monster.monster_id == "GremlinWizard":
        # It spends two quiet turns charging, then deals 30. Treat the future
        # burst as present danger so short swarm logic kills it before it fires.
        scaling = 70
    elif (
        monster.monster_id in {"AcidSlime_M", "SpikeSlime_M"}
        and "DEBUFF" in monster.intent
    ):
        # A medium Slime that is licking this turn attacks on the following
        # cycle. At low HP, focusing only the currently attacking Jaw Worm can
        # leave two lethal attackers next turn; make progress on the setup
        # threat visible before its displayed intent turns red.
        scaling = 24
    elif monster.monster_id == "FungiBeast":
        # Fungi Beast gains five Strength every buff cycle. In the mixed
        # Shelled Parasite encounter its modest displayed attack concealed the
        # fact that leaving it alive made every later draw dramatically worse.
        strength = max(0, _power_amount(monster.powers, "Strength"))
        scaling = 16 + strength * 5
        if "BUFF" in monster.intent:
            scaling += 24
    elif monster.monster_id in {"Chosen", "BookOfStabbing"}:
        scaling = 20
    else:
        scaling = 0
    return support + scaling


def _target_threat(monster):
    attack = max(0, monster.damage) * max(1, monster.hits) if "ATTACK" in monster.intent else 0
    if _imminent_exploder(monster):
        attack += 30
    return _strategic_threat(monster) + attack


def _bronze_stasis_priority(monster):
    card = monster.stasis_card
    if card is None:
        return 0
    if card.card_id in BRONZE_STASIS_KEY_CARDS:
        return 4
    if (
        card.card_id in BLOCK_VALUE
        or card.card_id in DRAW_VALUES
        or card.card_type == "POWER"
    ):
        return 3
    if card.card_type == "ATTACK":
        return 2
    return 1


def _bronze_imminent_prebeam_stasis(monster, model):
    """Return whether an Orb will steal a card just before Hyper Beam."""
    cycle_turn = (max(1, model.turn) - 1) % 6 + 1
    return bool(
        monster.monster_id == "BronzeOrb"
        and cycle_turn == 5
        and "DEBUFF" in monster.initial_intent
        and "ATTACK" not in monster.initial_intent
        and monster.stasis_card is None
    )


def _bronze_stasis_card_is_unspent(monster, model):
    card = monster.stasis_card
    return bool(
        card is not None
        and any(hand_card.uuid == card.uuid for hand_card in model.hand)
    )


def _bronze_delayed_stasis_recovery(monster, model):
    """Return whether an Orb kill recovered a card too late to help this turn."""
    cycle_turn = (max(1, model.turn) - 1) % 6 + 1
    return bool(
        not monster.alive
        and cycle_turn in {4, 5}
        and "ATTACK" not in monster.intent
        and _bronze_stasis_card_is_unspent(monster, model)
    )


def _bronze_delayed_stasis_progress(monster, model):
    cycle_turn = (max(1, model.turn) - 1) % 6 + 1
    return bool(
        cycle_turn in {4, 5}
        and "ATTACK" not in monster.intent
        and (
            monster.alive
            or _bronze_stasis_card_is_unspent(monster, model)
        )
    )


def _automaton_hyper_beam_reserve_risk(model, end_effective_hp):
    """Price HP spent immediately before Automaton's known Hyper Beam turn."""
    automaton = next(
        (
            monster
            for monster in model.monsters
            if monster.monster_id == "BronzeAutomaton" and monster.alive
        ),
        None,
    )
    if automaton is None:
        return 0

    cycle_turn = (max(1, model.turn) - 1) % 6 + 1
    early_high_ascension_reserve = (
        model.ascension >= 18 and cycle_turn in {2, 3}
    )
    if cycle_turn not in {4, 5} and not early_high_ascension_reserve:
        return 0
    if automaton.hp <= max(45, model.known_next_attack_damage):
        return 0

    # Automaton buffs on turns three and five before the first Hyper Beam.
    # Earlier turns must reserve for both buffs; turn four/five only has the
    # final four Strength still pending.
    future_strength = 8 if cycle_turn in {2, 3} else 4
    beam_damage = (
        50
        + max(0, _power_amount(automaton.powers, "Strength"))
        + future_strength
    )
    if cycle_turn == 5:
        known_block = _known_next_turn_block_capacity(model)
        assumed_block = 24 if known_block is None else min(32, known_block)
        prebeam_chip = 0
    elif cycle_turn == 4:
        # Turn five consumes one known hand before Hyper Beam. Pocketwatch can
        # make that hand eight cards, so use its post-candidate counter to find
        # the actual five cards left for turn six instead of assuming 24 block.
        next_draw_size = 8 if 0 <= model.pocketwatch_counter <= 3 else 5
        known_block = _known_later_turn_block_capacity(model, next_draw_size)
        assumed_block = 24 if known_block is None else min(32, known_block)
        prebeam_chip = 0
    else:
        # At A18+, spending Offering and J.A.X. on turn two can look like free
        # setup while it consumes the exact reserve needed three turns later.
        # Forecast the beam hand when enough cards are exposed; pending shuffles
        # use a conservative twelve-block shell plus a small allowance for the
        # intervening Automaton/Orb attacks.
        draw_offset = (5 - cycle_turn) * 5
        known_block = _known_later_turn_block_capacity(
            model, draw_offset
        )
        assumed_block = 12 if known_block is None else min(32, known_block)
        prebeam_chip = 5 if cycle_turn == 2 else 3
    required_hp = min(
        model.max_hp,
        max(
            24,
            int(model.max_hp * 0.50) if model.ascension >= 18 else 0,
            beam_damage - assumed_block + 1 + prebeam_chip,
        ),
    )
    shortfall = max(0, required_hp - end_effective_hp)
    if shortfall <= 0:
        return 0
    # Crossing this line changes the next beam from survivable to lethal, so it
    # needs a threshold cost as well as a per-HP cost. A merely linear price let
    # a first-Orb kill trade the final two points of beam reserve away.
    return 240 + shortfall * 20


def _imminent_enemy_risk(monster):
    if _imminent_exploder(monster):
        return 35
    if monster.monster_id == "TheCollector" and "DEBUFF" in monster.intent:
        # The Collector's strong debuff is commonly followed by a large
        # attack. Weak applied now protects that next turn even though the
        # current intent has no damage for the simulator to reduce directly.
        weak = max(0, _power_amount(monster.powers, "Weakened"))
        return max(0, 24 - weak * 8)
    return 0


def _time_eater_haste_risk(model):
    if not model.time_eater_haste_guard:
        return 0
    if model.initial_hp * 2 < model.max_hp and model.incoming <= 0:
        # At low HP, a quiet turn is the right time to force Haste. The heal
        # wastes damage, but Haste replaces Time Eater's next attack and buys
        # a full draw. Holding above half here made the logged A3 run pass a
        # 17-Strength Heavy Blade, then die to the following 75-damage turn.
        return 0
    for monster in model.monsters:
        if monster.monster_id != "TimeEater" or not monster.alive:
            continue
        threshold = monster.max_hp // 2
        if monster.hp <= threshold:
            living = [candidate for candidate in model.monsters if candidate.alive]
            start_hp = model.initial_enemy_hp if len(living) == 1 else monster.hp
            near_threshold = 0 < start_hp - threshold <= max(
                8,
                int(monster.max_hp * 0.03),
            )
            if near_threshold:
                # With only a sliver above half, delaying damage throws away a
                # whole hand but cannot preserve a meaningful burst window.
                # The A5 log did this at 234/456 and took 27 unblocked damage.
                return 0
            # Haste restores Time Eater to half HP and clears its debuffs. Hold
            # above the threshold until a later hand can cross decisively.
            return 60 + threshold - monster.hp
    return 0


def _slime_split_risk(model):
    if model.slime_split_hp <= 0:
        return 0
    splitting_slime = next(
        (
            monster
            for monster in model.monsters
            if monster.monster_id in SPLIT_SLIME_IDS
            and monster.alive
            and monster.hp <= monster.max_hp // 2
        ),
        None,
    )
    if splitting_slime is None:
        return 0
    good_split_hp = max(1, int(splitting_slime.max_hp * 0.4))
    return max(0, model.slime_split_hp - good_split_hp) * 4


def _affordable_attack_damage_ceiling(model, target):
    """Return a conservative current-hand damage ceiling for one target."""
    energy = max(0, model.energy)
    best = [0] * (energy + 1)
    vulnerable = bool(_power_amount(target.powers, "Vulnerable"))
    vulnerable_multiplier = 1.75 if model.paper_frog else 1.5
    for card in model.hand:
        if (
            card.card_type != "ATTACK"
            or not card.is_playable
            or card.card_id == "Fiend Fire"
        ):
            continue
        options = []
        if card.card_id == "Whirlwind":
            minimum_spend = 0 if model.chemical_x else 1
            for spent in range(minimum_spend, energy + 1):
                base, hits, strength_multiplier = _base_attack(
                    card, model, energy_spent=spent
                )
                options.append((
                    spent,
                    adjusted_attack(
                        base,
                        model.strength,
                        model.weak,
                        vulnerable,
                        strength_multiplier,
                        vulnerable_multiplier,
                    ) * hits,
                ))
        else:
            cost = _card_cost(card, model)
            if cost > energy:
                continue
            base, hits, strength_multiplier = _base_attack(card, model)
            options.append((
                cost,
                adjusted_attack(
                    base,
                    model.strength,
                    model.weak,
                    vulnerable,
                    strength_multiplier,
                    vulnerable_multiplier,
                ) * hits,
            ))
        previous = list(best)
        for cost, damage in options:
            for spent in range(cost, energy + 1):
                best[spent] = max(
                    best[spent], previous[spent - cost] + damage
                )
    return max(best, default=0)


def _champ_hold_is_untenable(model):
    champ = next(
        (
            monster
            for monster in model.monsters
            if monster.monster_id == "Champ" and monster.alive
        ),
        None,
    )
    quiet_threshold_release = False
    if (
        champ is not None
        and champ.hp > champ.max_hp // 2
        and champ.hp - champ.max_hp // 2
        <= max(4, int(champ.max_hp * 0.01))
        and "ATTACK" not in champ.intent
        and model.incoming <= model.block
        and model.hp <= int(model.max_hp * 0.35)
    ):
        required_damage = champ.hp - champ.max_hp // 2 + champ.block
        weak = _power_amount(model.player_powers, "Weakened") > 0
        vulnerable = _power_amount(champ.powers, "Vulnerable") > 0
        for card in model.hand:
            cost = _card_cost(card, model)
            if (
                card.card_type != "ATTACK"
                or not card.is_playable
                or cost > model.energy
            ):
                continue
            attack_model = model
            if card.card_id == "Fiend Fire":
                attack_model = replace(
                    model,
                    hand=[candidate for candidate in model.hand if candidate.uuid != card.uuid],
                )
            base, hits, strength_multiplier = _base_attack(
                card,
                attack_model,
                energy_spent=cost,
            )
            damage = adjusted_attack(
                base,
                model.strength,
                weak,
                vulnerable,
                strength_multiplier,
                1.75 if model.paper_frog else 1.5,
            ) * hits
            if damage >= required_damage:
                # The logged A13 Champ was four HP above phase at 21 life on a
                # DEFEND_BUFF turn. Holding spent the hand on temporary Block
                # and exposed the bot to the unchanged first-phase attack.
                quiet_threshold_release = True
                break

    debuff_window_release = False
    if (
        champ is not None
        and model.turn >= 5
        and "DEBUFF" in champ.intent
        and "ATTACK" not in champ.intent
        and champ.hp > champ.max_hp // 2
        and champ.hp - champ.max_hp // 2
        <= max(12, int(champ.max_hp * 0.08))
        and champ.block >= 9
        and model.incoming <= model.block
        and sum(
            card.card_type == "ATTACK"
            and card.is_playable
            and _card_cost(card, model) <= model.energy
            for card in model.hand
        ) >= 2
    ):
        required_damage = (
            champ.hp - champ.max_hp // 2 + champ.block
        )
        # Crossing during Champ's late debuff replaces its next attack with
        # Anger. Waiting one more cycle spent Impervious in the logged A17
        # fight, then crossed on the following buff turn with the same depth.
        debuff_window_release = (
            _affordable_attack_damage_ceiling(model, champ)
            >= required_damage
        )

    playable_block_cards = [
        card
        for card in model.hand
        if (
            card.card_id in BLOCK_VALUE
            or (
                card.card_id == "Second Wind"
                and any(
                    other.uuid != card.uuid and other.card_type != "ATTACK"
                    for other in model.hand
                )
            )
        )
        and card.is_playable
        and _card_cost(card, model) <= model.energy
    ]
    playable_block = bool(playable_block_cards)
    hold_hp_loss = max(0, model.incoming - model.block)
    projected_hp = model.hp - hold_hp_loss
    phase_distance = (
        max(0, champ.hp - champ.max_hp // 2)
        if champ is not None
        else 0
    )
    near_phase_release = bool(
        champ is not None
        and phase_distance <= max(18, int(champ.max_hp * 0.06))
    )
    critical_reserve_release = projected_hp <= max(
        10, int(model.max_hp * 0.20)
    )
    energy_left = model.energy
    affordable_block_plays = 0
    for card in sorted(
        playable_block_cards,
        key=lambda candidate: _card_cost(candidate, model),
    ):
        cost = _card_cost(card, model)
        if cost <= energy_left:
            energy_left -= cost
            affordable_block_plays += 1
    juggernaut = max(0, _power_amount(model.player_powers, "Juggernaut"))
    juggernaut_defensive_release = bool(
        playable_block
        and juggernaut > 0
        and critical_reserve_release
        and phase_distance <= juggernaut * affordable_block_plays
    )
    forced_release = (
        champ is not None
        and hold_hp_loss >= max(12, int(model.max_hp * 0.18))
        and projected_hp <= int(model.max_hp * 0.40)
        and (near_phase_release or critical_reserve_release)
        and (not playable_block or juggernaut_defensive_release)
    )
    return (
        forced_release
        or quiet_threshold_release
        or debuff_window_release
    )


def _champ_shallow_phase_risk(model):
    if model.champ_race:
        return 0
    champ = next((monster for monster in model.monsters if monster.monster_id == "Champ" and monster.alive), None)
    if champ is None:
        return 0
    phase_hp = champ.max_hp // 2
    fire_breathing = max(
        0, _power_amount(model.player_powers, "Fire Breathing")
    )
    # Preserve the warning buffer while approaching it, but do not count Fire
    # Breathing a second time after the current hand's Status/Curse draws have
    # already put Champ inside that buffer. The latter made every line look as
    # though it would cross, so the logged bot attacked through half health.
    automatic_damage = (
        fire_breathing
        if champ.initial_hp > phase_hp + fire_breathing
        else 0
    )
    if "ATTACK" in champ.intent:
        thorns_damage = (
            max(0, _power_amount(model.player_powers, "Thorns"))
            * max(1, champ.hits)
        )
        # Enemy Block absorbs Thorns. Counting the full retaliation made a
        # covered 222/440 Champ look as though it would cross half health even
        # while its seven Block remained intact.
        automatic_damage += max(0, thorns_damage - champ.block)
    if champ.hp > phase_hp + automatic_damage:
        return 0
    if model.champ_forced_release:
        # Holding at half HP only helps if the current draw can survive the
        # wait. The logged A8 Champ hand contained five attacks and no block;
        # refusing to cross at 211 HP spent 48 life before the next burst.
        return 0
    safe_phase_hp = int(champ.max_hp * 0.38)
    risk_hp = min(champ.hp, phase_hp)
    risk = 25 + max(0, risk_hp - safe_phase_hp) * 3
    if model.ascension >= 18:
        projected_block = _projected_end_turn_block(model)
        regeneration = max(
            0, _power_amount(model.player_powers, "Regeneration")
        )
        projected_hp = min(model.max_hp, model.hp + regeneration) - max(
            0, model.incoming - projected_block
        )
        phase_reserve = max(24, int(model.max_hp * 0.45))
        # Execute follows Anger immediately at high ascension. Crossing shallow
        # while ending the current attack at low HP is substantially worse than
        # spending a covered turn on block and letting scaling mature.
        risk += max(0, phase_reserve - projected_hp) * 5
    return risk


def _champ_known_next_turn_phase_credit(model):
    """Value setting Champ inside an exact next-hand phase-crossing window."""
    if model.champ_race or model.turn < 5 or model.known_next_attack_damage <= 0:
        return 0
    champ = next(
        (
            monster for monster in model.monsters
            if monster.monster_id == "Champ" and monster.alive
        ),
        None,
    )
    if champ is None:
        return 0
    if model.initial_hp <= int(model.max_hp * 0.35):
        # This credit represents future tempo, not actual Block. At low life the
        # next first-phase attack can land before Champ enters Anger, as in the
        # logged A13 fight at 21/80 HP. Preserve a quiet setup turn instead of
        # treating a merely known crossing hand as dozens of points of health.
        return 0
    distance = champ.hp - champ.max_hp // 2
    if distance <= 0 or distance > model.known_next_attack_damage:
        return 0
    # A known crossing on the next draw prevents another first-phase attack
    # cycle. Quiet setup turns receive the full value; attacking turns retain a
    # smaller credit because current survival still comes first.
    base = 52 if "ATTACK" not in champ.intent else 28
    # Crossing by a wider margin is materially safer than merely touching the
    # threshold: Champ cleanses Vulnerable/Weak during Anger, so damage planned
    # before that cleanse should receive credit now.
    return base + min(40, model.known_next_attack_damage - distance)


def _guardian_curl_aggression(model, alive, end_hp):
    """Allow healthy Ironclad decks to push damage through Sharp Hide.

    The Guardian's curled state normally causes the planner to overvalue every
    point of thorns damage and stop attacking.  v5 makes damage progress the
    priority while the player starts healthy and still retains a meaningful
    projected HP reserve after incoming damage and thorns.
    """
    curled = any(
        monster.monster_id == "TheGuardian"
        and _power_amount(monster.powers, "Sharp Hide") > 0
        for monster in alive
    )
    healthy_start = model.initial_hp >= max(30, int(model.max_hp * 0.45))
    # Every candidate from the same turn must remain in this branch. Tying the
    # branch to projected end HP let reckless attack lines escape HP pricing
    # exactly when they crossed below the reserve threshold.
    return curled and healthy_start


def _guardian_desperation_window(model, alive, end_hp):
    """Push a reachable curled Guardian without spending the final HP buffer."""
    curled = any(
        monster.monster_id == "TheGuardian"
        and _power_amount(monster.powers, "Sharp Hide") > 0
        for monster in alive
    )
    low_health = model.initial_hp < max(30, int(model.max_hp * 0.45))
    boss_in_range = model.initial_enemy_hp <= 55
    can_pay_current_hit = model.initial_hp > model.incoming
    return curled and low_health and boss_in_range and can_pay_current_hit and end_hp > 0


def _guardian_known_next_turn_shift_control(model, guardian):
    """Value charge-turn progress against the exact visible next draw."""
    if (
        model.ascension < 18
        or model.initial_hp > int(model.max_hp * 0.70)
        or guardian is None
    ):
        return 0
    remaining = max(0, _power_amount(guardian.powers, "Mode Shift"))
    if remaining <= 0:
        return 48
    known_damage = _known_next_turn_attack_damage(
        model, target=guardian, require_full=False
    )
    if known_damage <= 0:
        return 0
    # Charging Up leaves nine Block in the observed A19 cycle. When a shuffle is
    # pending, use only the attacks whose order is still known and reward reducing
    # the unresolved gap; unknown cards may help, but are never counted as damage.
    known_hp_damage = max(0, known_damage - 9)
    gap = max(0, remaining - known_hp_damage)
    return max(0, 48 - gap * 4)


def _known_draw_outlook(model, hand_size=5):
    """Score the exact top cards expected in the next natural draw."""
    if not model.draw_pile or hand_size <= 0:
        return 0
    cards = tuple(reversed(model.draw_pile[-hand_size:]))
    vulnerable = any(
        monster.alive and _power_amount(monster.powers, "Vulnerable") > 1
        for monster in model.monsters
    )
    hp_ratio = model.hp / max(1, model.max_hp)
    score = 0
    for card in cards:
        if card.card_type in {"STATUS", "CURSE"}:
            if (
                _power_amount(model.player_powers, "Evolve")
                or _power_amount(model.player_powers, "Fire Breathing")
            ):
                score += 2
            else:
                score -= 5
            continue
        card_score = 0
        if card.card_type == "ATTACK":
            base, hits, strength_multiplier = _base_attack(
                card,
                model,
                energy_spent=3 if card.card_id == "Whirlwind" else None,
            )
            damage = (base + max(0, model.strength) * strength_multiplier) * hits
            if vulnerable:
                damage = int(
                    damage * (1.75 if model.paper_frog else 1.5)
                )
            card_score += min(32, damage)
        elif card.card_id in BLOCK_VALUE:
            base, upgrade = BLOCK_VALUE[card.card_id]
            block = adjusted_block(
                base + upgrade * min(card.upgrades, 1),
                model.dexterity,
                model.frail,
            )
            card_score += min(30, block) * (2 if hp_ratio < 0.45 else 1)
        elif card.card_type == "POWER":
            card_score += SAFE_POWER_VALUES.get(card.card_id, 5)
        else:
            card_score += 5
        if card.card_id in DRAW_VALUES:
            card_score += 4
        if card.cost > 3:
            card_score //= 2
        score += card_score
    return score // 4


def _evaluate(model):
    direct_victory = not any(monster.alive for monster in model.monsters)
    if model.stone_calendar_ready and not direct_victory:
        model = _trigger_relic_aoe(
            replace(model, stone_calendar_ready=False), 52
        )
    combust_damage = max(0, _power_amount(model.player_powers, "Combust"))
    if combust_damage:
        for index in range(len(model.monsters)):
            before = model.monsters[index]
            if not before.alive:
                continue
            after, _ = _damage_monster(before, combust_damage)
            model, after = _apply_damage_transition(model, before, after)
            projected_monsters = list(model.monsters)
            projected_monsters[index] = after
            model = replace(model, monsters=tuple(projected_monsters))
    alive = [monster for monster in model.monsters if monster.alive]
    transient_race = any(monster.monster_id == "Transient" for monster in alive)
    incoming_packets = _incoming_damage_packets_after_block(model)
    incoming = sum(incoming_packets)
    # Combat ends immediately on lethal, before Constricted or hand statuses
    # can deal their end-of-turn damage.
    if direct_victory:
        end_damage = 0
    elif alive:
        end_damage = _end_turn_damage(model)
    else:
        # Combust dealt the lethal damage during end-of-turn resolution, so
        # its own HP cost still applies before combat ends.
        end_damage = max(0, model.combust_hp_loss)
    # Regeneration resolves at end of the player's turn, before monsters act.
    # This ordering can make an otherwise lethal block line genuinely survive.
    pre_enemy_hp = model.hp
    if alive:
        pre_enemy_hp = min(
            model.max_hp,
            pre_enemy_hp
            + max(0, _power_amount(model.player_powers, "Regeneration")),
        )
    regeneration_gain = max(0, pre_enemy_hp - model.hp)
    end_hp = pre_enemy_hp
    end_revive_hp = model.revive_hp
    for packet in incoming_packets:
        end_hp, end_revive_hp, _, _ = _apply_hp_damage_with_revive(
            end_hp, end_revive_hp, packet
        )
        if end_hp <= 0:
            break
    if end_damage and end_hp > 0:
        end_hp, end_revive_hp, _, _ = _apply_hp_damage_with_revive(
            end_hp, end_revive_hp, end_damage
        )
    initial_effective_hp = model.initial_hp + model.initial_revive_hp
    end_effective_hp = end_hp + end_revive_hp
    # Regeneration may establish survival, but it is finite recovery rather
    # than a discount for taking avoidable damage this turn.
    hp_loss = max(
        0,
        initial_effective_hp - end_effective_hp + regeneration_gain,
    )
    revive_reserve_spent = max(0, model.initial_revive_hp - end_revive_hp)
    revive_spend_penalty = revive_reserve_spent * 3
    victory = not alive and end_hp > 0
    survives = end_hp > 0
    hp_damage_dealt = model.initial_enemy_hp - sum(monster.hp for monster in alive)
    persistent_block_left = sum(
        monster.block
        for monster in alive
        if (
            _power_amount(monster.powers, "Barricade")
            or _power_amount(monster.powers, "Plated Armor")
        )
    )
    guardian_curl_block_left = sum(
        monster.block
        for monster in alive
        if monster.monster_id == "TheGuardian" and _power_amount(monster.powers, "Sharp Hide")
    )
    guardian_curl_block_broken = max(
        0, model.initial_guardian_curl_block - guardian_curl_block_left
    )
    flame_barrier = max(0, _power_amount(model.player_powers, "Flame Barrier"))
    projected_retaliation = sum(
        min(monster.hp, flame_barrier * max(1, monster.hits))
        for monster in alive
        if flame_barrier and "ATTACK" in monster.intent
    )
    damage_dealt = (
        hp_damage_dealt
        + model.initial_persistent_block
        - persistent_block_left
        + projected_retaliation
    )
    guardian_curl_progress = hp_damage_dealt + guardian_curl_block_broken
    projected_block = _projected_end_turn_block(model)
    danger_alive = sum(_strategic_threat(monster) for monster in alive) + max(
        0,
        model.incoming - projected_block,
    )
    priority_hp = sum(monster.hp * (20 + _target_threat(monster)) for monster in alive)
    sentries = [monster for monster in model.monsters if monster.monster_id == "Sentry"]
    sentry_kills = sum(not monster.alive for monster in sentries) if len(sentries) >= 2 else 0
    sentry_cleanup_control = sum(
        70 + _target_threat(monster)
        for monster in sentries
        if not monster.alive
    )
    attacking_sentry_cleanup_control = sum(
        70 + _target_threat(monster)
        for monster in sentries
        if not monster.alive and "ATTACK" in monster.intent
    )
    living_sentry_hp = [monster.hp for monster in sentries if monster.alive]
    sentry_focus = -min(living_sentry_hp) if len(sentries) >= 2 and living_sentry_hp else 0
    sentry_outer_progress = (
        sum(
            max(0, monster.max_hp - monster.hp)
            for monster in sentries
            if monster.original_index != 1
        )
        if len(sentries) >= 2
        else 0
    )
    imminent_enemy_risk = sum(_imminent_enemy_risk(monster) for monster in alive)
    junk_cleanup = model.junk_exhausted if alive else 0
    slime_split_risk = _slime_split_risk(model)
    net_health = (
        end_effective_hp
        - initial_effective_hp
        - regeneration_gain
        - revive_spend_penalty
        - model.future_risk
        - imminent_enemy_risk
        - slime_split_risk
        - _champ_shallow_phase_risk(model)
        - _time_eater_haste_risk(model)
        + _champ_known_next_turn_phase_credit(model)
        + model.risky_power_credit
    )
    fighting_hexaghost = any(monster.monster_id == "Hexaghost" for monster in alive)
    hexaghost = next(
        (monster for monster in alive if monster.monster_id == "Hexaghost"),
        None,
    )
    fighting_slime_boss = any(monster.monster_id == "SlimeBoss" for monster in alive)
    sleeping_lagavulin = next(
        (
            monster
            for monster in alive
            if monster.monster_id == "Lagavulin"
            and monster.intent in {"SLEEP", "DEBUG"}
        ),
        None,
    )
    fighting_collector = any(monster.monster_id == "TheCollector" for monster in alive)
    collector = next(
        (monster for monster in alive if monster.monster_id == "TheCollector"),
        None,
    )
    collector_finish_window = bool(
        collector
        and model.turn >= 5
        and collector.initial_hp <= max(90, int(collector.max_hp * 0.35))
    )
    collector_opening_aggression = bool(
        collector
        and model.turn <= 3
        and model.initial_hp >= int(model.max_hp * 0.70)
    )
    collector_scaling_setup_window = bool(
        collector
        and model.turn <= 3
        and model.initial_hp >= max(42, int(model.max_hp * 0.52))
        and max(0, model.initial_incoming - model.initial_block)
        <= max(36, int(model.max_hp * 0.42))
    )
    collector_recovery_setup_window = bool(
        collector
        and model.turn <= 3
        and model.initial_hp >= max(38, int(model.max_hp * 0.45))
        and max(0, model.initial_incoming - model.initial_block)
        <= max(36, int(model.max_hp * 0.42))
        and any(card.card_id == "Reaper" for card in model.draw_pile[-5:])
    )
    collector_exhaust_setup_window = bool(
        collector
        and model.turn <= 5
        and collector.hp > max(120, int(collector.max_hp * 0.45))
        and "ATTACK" not in collector.intent
        and model.exhaust_power_ready
        and model.exhaust_power_scaling > 0
        and end_effective_hp >= max(24, int(model.max_hp * 0.30))
    )
    collector_boss_race_window = bool(
        collector_opening_aggression
        and model.turn == 2
        and collector is not None
        and "ATTACK" in collector.intent
        and any(
            monster.monster_id == "TorchHead" and monster.alive
            for monster in model.monsters
        )
    )
    collector_swarm_pressure = (
        sum(
            monster.monster_id == "TorchHead"
            for monster in model.monsters
        ) >= 2
        and (
            max(0, model.initial_incoming - model.initial_block) >= max(
                24, int(model.max_hp * 0.30)
            )
            or (
                model.initial_incoming >= max(35, int(model.max_hp * 0.45))
                and max(0, model.initial_incoming - model.initial_block)
                >= max(18, int(model.max_hp * 0.22))
            )
        )
        and model.initial_hp - max(
            0, model.initial_incoming - model.initial_block
        )
        < int(model.max_hp * 0.66)
    )
    collector_blocked_swarm_replan = bool(
        collector
        and model.turn == 2
        and 0 < model.initial_block <= 10
        and "ATTACK" in collector.intent
        and sum(
            monster.monster_id == "TorchHead" and monster.alive
            for monster in model.monsters
        ) >= 2
        and model.initial_incoming >= max(24, int(model.max_hp * 0.30))
        and max(0, model.initial_incoming - model.initial_block)
        >= max(18, int(model.max_hp * 0.22))
        and model.initial_hp - max(
            0, model.initial_incoming - model.initial_block
        ) < int(model.max_hp * 0.66)
    )
    collector_swarm_pressure = (
        collector_swarm_pressure or collector_blocked_swarm_replan
    )
    collector_early_dual_torch_pressure = bool(
        collector
        and model.turn <= 2
        and sum(
            monster.monster_id == "TorchHead"
            for monster in alive
        ) >= 2
        and model.initial_block == 0
        and max(0, model.initial_incoming - model.initial_block) >= 10
    )
    collector_critical_reserve = bool(
        collector
        and model.initial_hp < max(28, int(model.max_hp * 0.40))
    )
    collector_opening_heavy_hit_guard = bool(
        collector
        and model.turn <= 3
        and sum(
            monster.monster_id == "TorchHead" and monster.alive
            for monster in model.monsters
        ) == 1
        and max(0, model.initial_incoming - model.initial_block)
        >= max(24, int(model.max_hp * 0.30))
        and model.initial_hp
        - max(0, model.initial_incoming - model.initial_block)
        < max(30, int(model.max_hp * 0.40))
    )
    fighting_bronze_automaton = any(
        monster.monster_id == "BronzeAutomaton" for monster in alive
    )
    spire_growth = next(
        (monster for monster in alive if monster.monster_id == "Serpent"),
        None,
    )
    serpent_constrict_window = bool(
        spire_growth
        and "STRONG_DEBUFF" in spire_growth.intent
        and _power_amount(model.player_powers, "Constricted") == 0
    )
    snake_plant = next(
        (monster for monster in alive if monster.monster_id == "SnakePlant"),
        None,
    )
    critical_snake_plant_burst = bool(
        snake_plant
        and "ATTACK" not in snake_plant.initial_intent
        and model.initial_hp <= max(18, int(model.max_hp * 0.30))
    )
    snake_plant_followup_commit = bool(
        snake_plant
        and "ATTACK" in snake_plant.initial_intent
        and model.initial_incoming >= max(18, int(model.max_hp * 0.24))
        and model.initial_hp
        - max(0, model.initial_incoming - model.initial_block)
        <= max(14, int(model.max_hp * 0.20))
        and snake_plant.initial_hp <= int(snake_plant.max_hp * 0.65)
        and _known_next_turn_attack_damage(
            model, target=snake_plant, require_full=False
        ) > 0
    )
    reptomancer_encounter = any(
        monster.monster_id == "Reptomancer" for monster in model.monsters
    )
    donu_deca_encounter = (
        any(monster.monster_id == "Donu" for monster in model.monsters)
        and any(monster.monster_id == "Deca" for monster in model.monsters)
    )
    gremlin_leader_encounter = any(
        monster.monster_id == "GremlinLeader" for monster in model.monsters
    )
    red_slaver_encounter = (
        any(monster.monster_id == "SlaverBoss" for monster in model.monsters)
        and any(monster.monster_id == "SlaverRed" for monster in model.monsters)
    )
    triple_slaver_encounter = red_slaver_encounter and any(
        monster.monster_id == "SlaverBlue" for monster in model.monsters
    )
    colosseum_slaver_pair = (
        any(monster.monster_id == "SlaverRed" for monster in model.monsters)
        and any(monster.monster_id == "SlaverBlue" for monster in model.monsters)
        and not any(
            monster.monster_id == "SlaverBoss" for monster in model.monsters
        )
    )
    slaver_cleanup_encounter = (
        any(monster.monster_id == "SlaverBoss" for monster in model.monsters)
        and any(monster.monster_id == "SlaverBlue" for monster in model.monsters)
        and not any(monster.monster_id == "SlaverRed" for monster in model.monsters)
    )
    awakened_one_encounter = any(
        monster.monster_id == "AwakenedOne" for monster in model.monsters
    )
    time_eater = next(
        (monster for monster in alive if monster.monster_id == "TimeEater"),
        None,
    )
    support_encounter = model.support_cleanup_encounter or (
        len(model.monsters) >= 2
        and any(
            monster.monster_id in {"Healer", "Mystic"}
            for monster in model.monsters
        )
    )
    support_alive = [
        monster for monster in model.monsters
        if monster.monster_id in {"Healer", "Mystic"} and monster.alive
    ]
    support_heal_window = any(
        monster.initial_intent == "BUFF"
        and any(
            candidate.alive and candidate.initial_hp < candidate.max_hp
            for candidate in model.monsters
        )
        for monster in support_alive
    )
    shielded_support_heal_window = support_heal_window and any(
        monster.initial_block >= 12 for monster in support_alive
    )
    support_is_sole_attacker = (
        any("ATTACK" in monster.intent for monster in support_alive)
        and not any(
            monster.alive
            and monster.monster_id not in {"Healer", "Mystic"}
            and "ATTACK" in monster.intent
            for monster in model.monsters
        )
    )
    initial_large_slime_count = sum(
        monster.monster_id in {"AcidSlime_L", "SpikeSlime_L"}
        for monster in model.monsters
    )
    post_boss_slime_wave = (
        initial_large_slime_count >= 2
        or (
            initial_large_slime_count >= 1
            and any(
                monster.monster_id in {
                    "AcidSlime_M", "AcidSlime_S",
                    "SpikeSlime_M", "SpikeSlime_S",
                }
                for monster in model.monsters
            )
        )
    )
    if fighting_hexaghost and model.turn <= 4:
        net_health += model.scaling
    late_hexaghost_race = model.turn >= 3 and fighting_hexaghost
    early_hexaghost_setup_window = bool(
        hexaghost
        and model.turn <= 4
        and hexaghost.hp > int(hexaghost.max_hp * 0.55)
        and max(0, model.initial_incoming - model.initial_block) <= 8
    )
    short_swarm_race = (
        len(model.monsters) >= 3
        and sum(monster.hp + monster.block for monster in alive) <= 120
        and sum(monster.monster_id == "Darkling" for monster in model.monsters) < 2
    )
    jaw_worm = next(
        (monster for monster in alive if monster.monster_id == "JawWorm"),
        None,
    )
    jaw_worm_scaling_race = bool(
        jaw_worm
        and len(alive) == 1
        and (
            jaw_worm.intent == "DEFEND_BUFF"
            or _power_amount(jaw_worm.powers, "Strength") >= 5
        )
    )
    orb_walker_scaling_race = bool(
        model.ascension >= 18
        and any(
            monster.monster_id in {"OrbWalker", "Orb Walker"}
            for monster in alive
        )
    )
    giant_head = next(
        (monster for monster in alive if monster.monster_id == "GiantHead"),
        None,
    )
    giant_head_setup_window = bool(giant_head) and (
        model.turn <= 3
        and model.initial_hp >= max(30, int(model.max_hp * 0.45))
        and model.incoming <= 20
    )
    giant_head_recovery_window = bool(
        giant_head
        and model.turn >= 3
        and model.initial_hp <= max(32, int(model.max_hp * 0.40))
        and max(0, model.initial_incoming - model.initial_block) <= 12
    )
    swarm_kill_control = sum(
        45 + _target_threat(monster)
        for monster in model.monsters
        if not monster.alive
    )
    charging_wizard_progress = sum(
        max(
            0,
            monster.initial_hp + monster.initial_block
            - monster.hp - monster.block,
        )
        for monster in model.monsters
        if (
            monster.monster_id == "GremlinWizard"
            and monster.alive
            and "ATTACK" not in monster.initial_intent
        )
    )
    imminent_wizard_burst = any(
        monster.monster_id == "GremlinWizard"
        and monster.alive
        and "ATTACK" in monster.initial_intent
        and max(0, monster.initial_damage) * max(1, monster.initial_hits) >= 25
        for monster in model.monsters
    )
    charging_wizard_finish_control = max(
        (
            80
            + min(
                20,
                _known_next_turn_attack_damage(
                    model,
                    target=monster,
                    require_full=False,
                )
                - monster.hp
                - monster.block,
            )
            for monster in model.monsters
            if (
                monster.monster_id == "GremlinWizard"
                and monster.alive
                and "ATTACK" not in monster.initial_intent
                and _known_next_turn_attack_damage(
                    model,
                    target=monster,
                    require_full=False,
                )
                >= monster.hp + monster.block
            )
        ),
        default=0,
    )
    collector_torch_kill_control = sum(
        45 + _target_threat(monster)
        for monster in model.monsters
        if monster.monster_id == "TorchHead" and not monster.alive
    )
    collector_torch_progress = sum(
        max(0, monster.initial_hp - monster.hp)
        for monster in model.monsters
        if monster.monster_id == "TorchHead" and monster.alive
    )
    collector_torch_focus_progress = max(
        (
            max(0, monster.max_hp - monster.hp)
            for monster in model.monsters
            if monster.monster_id == "TorchHead" and monster.alive
        ),
        default=0,
    )
    collector_quiet_swarm_window = bool(
        collector
        and "ATTACK" not in collector.intent
        and sum(
            monster.monster_id == "TorchHead" and monster.alive
            for monster in model.monsters
        ) >= 2
    )
    collector_quiet_engine_replan = bool(
        collector_quiet_swarm_window
        and model.turn <= 3
        and collector.intent == "DEFEND_BUFF"
        and model.initial_hp <= int(model.max_hp * 0.60)
        and _power_amount(model.player_powers, "Feel No Pain") > 0
    )
    collector_pocketwatch_known_block = (
        _known_next_turn_block_capacity(
            model,
            natural_draw=8,
            require_full=False,
            follow_draw=False,
        )
        if (
            collector
            and model.turn >= 5
            and collector.initial_intent == "DEFEND_BUFF"
            and model.initial_incoming <= model.initial_block
            and model.pocketwatch_counter >= 0
        )
        else None
    )
    collector_pocketwatch_bridge_window = bool(
        collector
        and model.initial_hp <= int(model.max_hp * 0.60)
        and collector.initial_hp > max(90, int(collector.max_hp * 0.35))
        and 0 <= model.pocketwatch_counter - len(model.commands) <= 3
        and collector_pocketwatch_known_block is not None
        and collector_pocketwatch_known_block <= 5
    )
    collector_boss_progress = sum(
        max(0, monster.initial_hp - monster.hp)
        for monster in model.monsters
        if monster.monster_id == "TheCollector"
    )
    collector_boss_exposed = bool(
        collector and _power_amount(collector.powers, "Vulnerable") > 0
    )
    killed_reptomancer_daggers = [
        monster
        for monster in model.monsters
        if monster.monster_id == "Dagger" and not monster.alive
    ]
    killed_dagger_incoming = sum(
        max(0, monster.damage) * max(1, monster.hits)
        for monster in killed_reptomancer_daggers
        if "ATTACK" in monster.intent
    )
    prevented_unblocked_dagger_damage = (
        max(0, model.incoming + killed_dagger_incoming - model.block)
        - max(0, model.incoming - model.block)
    )
    reptomancer_control = (
        len(killed_reptomancer_daggers) * 35
        + prevented_unblocked_dagger_damage * 6
    ) + sum(
        240
        for monster in model.monsters
        if monster.monster_id == "Reptomancer" and not monster.alive
    )
    reptomancer_dagger_progress = sum(
        min(72, max(0, monster.initial_hp - monster.hp) * 4)
        + (
            10
            if monster.hp <= 9 and monster.hp < monster.initial_hp
            else 0
        )
        for monster in model.monsters
        if monster.monster_id == "Dagger" and monster.alive
    )
    donu_kill_control = sum(
        220
        for monster in model.monsters
        if monster.monster_id == "Donu" and not monster.alive
    )
    initial_bronze_orbs = sum(
        monster.monster_id == "BronzeOrb" and monster.initial_hp > 0
        for monster in model.monsters
    )
    bronze_orb_focus_progress = max(
        (
            max(0, monster.initial_hp - monster.hp)
            for monster in model.monsters
            if monster.monster_id == "BronzeOrb" and monster.alive
        ),
        default=0,
    )
    bronze_orb_control = sum(
        0
        if _bronze_delayed_stasis_recovery(monster, model)
        else 95 + _bronze_stasis_priority(monster) * 30
        for monster in model.monsters
        if monster.monster_id == "BronzeOrb" and not monster.alive
    )
    bronze_pre_stasis_attack_control = sum(
        30
        for monster in model.monsters
        if monster.monster_id == "BronzeOrb"
        and not monster.alive
        and "ATTACK" in monster.initial_intent
        and monster.stasis_card is None
        and model.turn <= 3
    )
    bronze_prebeam_stasis_control = sum(
        180
        for monster in model.monsters
        if not monster.alive
        and _bronze_imminent_prebeam_stasis(monster, model)
    )
    cycle_turn = (max(1, model.turn) - 1) % 6 + 1

    def bronze_stasis_progress_value(monster):
        critical_prebeam_release = bool(
            cycle_turn in {4, 5}
            and monster.stasis_card is not None
            and monster.stasis_card.card_id in BRONZE_PREBEAM_RELEASE_CARDS
        )
        if (
            initial_bronze_orbs <= 1
            and monster.alive
            and monster.stasis_card is not None
            and not critical_prebeam_release
        ):
            # Once one Orb is gone, ordinary chip on the survivor must not
            # beat the three-times-weighted Automaton race. A lone Orb still
            # receives its full kill/cleanup credit, and the explicit
            # pre-Hyper-Beam release cards retain their preparation window.
            return 0
        if (
            monster.alive
            and cycle_turn == 3
            and model.initial_incoming <= model.initial_block
            and (
                monster.stasis_card is None
                or monster.stasis_card.card_id
                not in BRONZE_PREBEAM_RELEASE_CARDS
            )
        ):
            # Turn three is the last clean damage window of the opening cycle.
            # Staging an ordinary card for a later Orb kill spent the complete
            # logged hand on Reaper, left Automaton untouched, and recovered
            # the card only into a turn where its block made the heal trivial.
            # Keep nonlethal setup only for cards with an established beam
            # payoff; a same-turn kill is still scored separately below.
            return 0
        if (
            _bronze_delayed_stasis_progress(monster, model)
            and not (monster.alive and critical_prebeam_release)
        ):
            return 0
        progress = (
            min(16, max(0, monster.initial_hp - monster.hp))
            if not monster.alive
            else max(0, monster.initial_hp - monster.hp)
        )
        if (
            monster.alive
            and cycle_turn <= 3
            and model.initial_incoming > model.initial_block
            and not critical_prebeam_release
        ):
            # Before Hyper Beam preparation, reducing a key-card Orb from ten
            # HP to one is not additional control: either value the kill or
            # preserve HP for the boss cycle. This also lets a post-Boomerang
            # replan block when the observed random hits missed the finisher.
            cleanup_reserve = max(10, int(monster.max_hp * 0.18))
            progress = min(
                progress,
                max(0, monster.initial_hp - cleanup_reserve),
            )
        priority = _bronze_stasis_priority(monster)
        multiplier = 2 + priority
        if critical_prebeam_release:
            # Damage on the Disarm Orb during turn four made it killable on
            # turn five with energy left to play the returned card. Counting
            # only same-turn kills instead sent that attack into a 3-HP Orb
            # holding Juggernaut and left Hyper Beam at full Strength.
            multiplier = 18 + priority * 4
        return progress * multiplier

    bronze_stasis_focus_progress = max(
        (
            bronze_stasis_progress_value(monster)
            for monster in model.monsters
            if monster.monster_id == "BronzeOrb"
            and _power_amount(monster.powers, "Stasis") != 0
        ),
        default=0,
    )
    gremlin_minions = [
        monster for monster in model.monsters
        if monster.monster_id != "GremlinLeader"
    ] if gremlin_leader_encounter else []
    gremlin_minion_control = sum(
        130 + _target_threat(monster)
        for monster in gremlin_minions
        if not monster.alive
    )
    gremlin_minion_progress = sum(
        max(0, monster.max_hp - monster.hp)
        for monster in gremlin_minions
        if monster.alive
    )
    gremlin_warrior_enrage_risk = sum(
        max(0, monster.damage - monster.initial_damage) * max(1, monster.hits)
        for monster in gremlin_minions
        if monster.alive
        and monster.monster_id == "GremlinWarrior"
        and _power_amount(monster.powers, "Angry") > 0
    )
    gremlin_leader_kill_control = sum(
        520
        for monster in model.monsters
        if monster.monster_id == "GremlinLeader" and not monster.alive
    )
    automaton_boss_progress = sum(
        max(0, monster.initial_hp - monster.hp)
        for monster in model.monsters
        if monster.monster_id == "BronzeAutomaton"
    )
    automaton_artifact_break_control = (
        sum(
            max(
                0,
                monster.initial_artifact
                - max(0, _power_amount(monster.powers, "Artifact")),
            ) * 22
            for monster in model.monsters
            if monster.monster_id == "BronzeAutomaton" and monster.alive
        )
        if model.initial_incoming <= model.initial_block
        else 0
    )
    fighting_byrds = any(monster.monster_id == "Byrd" for monster in model.monsters)
    mixed_byrd_encounter = fighting_byrds and any(
        monster.monster_id != "Byrd" and monster.alive
        for monster in model.monsters
    )
    cultist_encounter = any(
        monster.monster_id == "Cultist" for monster in model.monsters
    )
    chosen_hex_encounter = (
        any(monster.monster_id == "Chosen" and monster.alive for monster in model.monsters)
        and _power_amount(model.player_powers, "Hex") != 0
    )
    thieves = [
        monster
        for monster in model.monsters
        if monster.monster_id in {"Looter", "Mugger"}
    ]
    thief_pair_encounter = len(thieves) >= 2
    thief_kill_control = sum(
        180 + _target_threat(monster)
        for monster in thieves
        if not monster.alive
    )
    cultist_control = sum(
        125
        for monster in model.monsters
        if monster.monster_id == "Cultist" and not monster.alive
    )
    cultists = [
        monster for monster in model.monsters
        if monster.monster_id == "Cultist"
    ]
    cultist_damage_this_turn = sum(
        max(0, monster.initial_hp - monster.hp)
        for monster in cultists
    )
    cultist_attackers = sum(
        monster.alive and "ATTACK" in monster.intent
        for monster in cultists
    )
    cultist_encounter_attackers = sum(
        monster.alive and "ATTACK" in monster.intent
        for monster in model.monsters
    )
    cultist_focus_control = 0
    if len(cultists) >= 2:
        lowest_start_hp = min(monster.initial_hp for monster in cultists)
        damage_this_turn = [
            max(0, monster.initial_hp - monster.hp)
            for monster in cultists
        ]
        lowest_target_damage = max(
            (
                max(0, monster.initial_hp - monster.hp)
                for monster in cultists
                if monster.initial_hp == lowest_start_hp
            ),
            default=0,
        )
        cultist_focus_control = min(
            100,
            max(damage_this_turn, default=0) * 3 + lowest_target_damage * 2,
        )
    red_slaver = next(
        (
            monster for monster in model.monsters
            if monster.monster_id == "SlaverRed"
        ),
        None,
    )
    red_slaver_damage = (
        max(0, red_slaver.initial_hp - red_slaver.hp)
        if red_slaver is not None
        else 0
    )
    red_slaver_kill_control = (
        300 if red_slaver is not None and not red_slaver.alive else 0
    )
    slaver_weak_control = sum(
        max(0, monster.initial_damage - monster.damage)
        * max(1, monster.hits)
        * 2
        for monster in model.monsters
        if monster.alive
        and monster.monster_id in {"SlaverBlue", "SlaverBoss", "SlaverRed"}
        and "ATTACK" in monster.intent
        and _power_amount(monster.powers, "Weakened") > 0
    )
    slaver_cleanup_control = sum(
        260 + _target_threat(monster)
        for monster in model.monsters
        if monster.monster_id in {"SlaverBlue", "SlaverBoss"}
        and not monster.alive
    )
    cleanup_slavers = [
        monster for monster in model.monsters
        if monster.alive and monster.monster_id in {"SlaverBlue", "SlaverBoss"}
    ]
    slaver_cleanup_focus_damage = 0
    if len(cleanup_slavers) >= 2:
        # After Red Slaver dies, finishing one attacker is worth much more than
        # spreading equal raw damage. Lock this plan on the currently lowest-HP
        # survivor so the next draw can actually remove an incoming packet.
        cleanup_focus = min(
            cleanup_slavers,
            key=lambda monster: (monster.initial_hp, -_target_threat(monster)),
        )
        slaver_cleanup_focus_damage = max(
            0, cleanup_focus.initial_hp - cleanup_focus.hp
        )
    support_kill_control = sum(
        280 + _target_threat(monster)
        for monster in model.monsters
        if monster.monster_id in {"Healer", "Mystic"} and not monster.alive
    )
    support_damage_this_turn = max(
        0,
        model.initial_support_hp
        - sum(monster.hp for monster in support_alive),
    )
    expected_support_heal = 20 if model.ascension >= 17 else 16
    support_progress = sum(
        max(
            0,
            monster.max_hp
            - min(
                monster.max_hp,
                monster.hp
                + (
                    expected_support_heal
                    if monster.monster_id in {"Healer", "Mystic"}
                    and monster.intent == "BUFF"
                    else 0
                ),
            ),
        )
        for monster in support_alive
    )
    support_finish_penalty = sum(
        190
        for monster in support_alive
        if monster.hp <= max(12, int(monster.max_hp * 0.25))
        and (
            monster.initial_hp <= max(12, int(monster.max_hp * 0.25))
            or (
                monster.initial_intent == "BUFF"
                and model.initial_strength > 0
                and any(
                    card.card_id == "Limit Break"
                    and card.is_playable
                    and _card_cost(card, model) > model.energy
                    for card in model.hand
                )
            )
        )
    )
    support_max_hp = sum(
        monster.max_hp
        for monster in model.monsters
        if monster.monster_id in {"Healer", "Mystic"}
    )
    support_focus_locked = (
        model.turn >= 2
        or model.initial_hp / max(1, model.max_hp) < 0.45
        or model.initial_support_hp <= int(max(1, support_max_hp) * 0.80)
        or not model.initial_support_block_available
        # A quiet opening is the safest window to damage the support before
        # it heals or gains Centurion's Block. Iron Wave being available does
        # not justify leaving the other three energy unused on that window.
        or model.initial_incoming <= model.initial_block
    )
    slime_child_ids = {
        "AcidSlime_M", "AcidSlime_S", "SpikeSlime_M", "SpikeSlime_S"
    }
    large_slime_ids = {"AcidSlime_L", "SpikeSlime_L"}
    slime_child_control = sum(
        150 + _target_threat(monster)
        for monster in model.monsters
        if monster.monster_id in slime_child_ids and not monster.alive
    )
    slime_child_progress = sum(
        max(0, monster.max_hp - monster.hp)
        for monster in model.monsters
        if monster.monster_id in slime_child_ids and monster.alive
    )
    large_slime_kill_control = sum(
        320
        for monster in model.monsters
        if monster.monster_id in large_slime_ids and not monster.alive
    )
    large_slime_split_pressure = sum(
        180
        for monster in model.monsters
        if (
            monster.monster_id in large_slime_ids
            and monster.alive
            and monster.hp <= monster.max_hp // 2
        )
    )
    new_attacking_large_splits = [
        monster
        for monster in model.monsters
        if (
            monster.monster_id in large_slime_ids
            and monster.alive
            and monster.initial_hp > monster.max_hp // 2 >= monster.hp
            and "ATTACK" in monster.initial_intent
        )
    ]
    large_slime_split_attack_control = sum(
        max(0, monster.initial_damage) * max(1, monster.initial_hits)
        for monster in new_attacking_large_splits
    )
    fighting_spikers = any(monster.monster_id == "Spiker" for monster in model.monsters)
    fighting_plated_armor = any(
        monster.alive and _power_amount(monster.powers, "Plated Armor")
        for monster in model.monsters
    )
    fungi_scaling_kill_control = sum(
        max(0, _power_amount(monster.powers, "Strength")) * 8
        + (28 if "BUFF" in monster.initial_intent else 0)
        for monster in model.monsters
        if monster.monster_id == "FungiBeast" and not monster.alive
    )
    spiker_kill_control = sum(
        90 + _target_threat(monster)
        for monster in model.monsters
        if monster.monster_id == "Spiker" and not monster.alive
    )
    byrd_control = sum(
        (
            180
            if (
                monster.alive
                and monster.initial_flight > 0
                and _power_amount(monster.powers, "Flight") <= 0
            )
            else 100
        )
        + max(0, monster.initial_damage) * max(1, monster.initial_hits)
        for monster in model.monsters
        if monster.monster_id == "Byrd"
        and (
            # Flight is 3 on lower ascensions and 4 from A17 onward.  Reward
            # only candidates that remove the live amount completely; partial
            # hits do not cancel the attack and must still compete with Block.
            monster.initial_flight > 0
            and (
                not monster.alive
                or _power_amount(monster.powers, "Flight") <= 0
            )
            or (
                not monster.alive
                and (
                    "ATTACK" in monster.initial_intent
                    or mixed_byrd_encounter
                )
            )
        )
    )
    byrd_caw_weak_control = sum(
        min(3, max(0, _power_amount(monster.powers, "Weakened"))) * 6
        for monster in model.monsters
        if monster.monster_id == "Byrd"
        and monster.alive
        and monster.initial_flight > 0
        and "BUFF" in monster.initial_intent
    )
    mixed_byrd_combust_credit = 0
    if (
        model.turn <= 2
        and model.initial_hp >= int(model.max_hp * 0.45)
        and any(monster.monster_id == "Byrd" and monster.alive for monster in model.monsters)
        and any(monster.monster_id == "Chosen" and monster.alive for monster in model.monsters)
    ):
        # Combust turns the otherwise long Chosen cleanup into a bounded race.
        # In the logged A13 opener, full blocking beat a four-HP Combust line;
        # the run then died with Chosen at five HP after eight scaling turns.
        combust = max(0, _power_amount(model.player_powers, "Combust"))
        mixed_byrd_combust_credit = min(160, combust * 30)
    elite_damage_race = any(
        monster.monster_id in {"BookOfStabbing", "GiantHead", "GremlinNob"}
        or (
            monster.monster_id == "Lagavulin"
            and monster.intent not in {"SLEEP", "STUN", "DEBUG"}
        )
        for monster in alive
    )
    gremlin_nob = next(
        (
            monster for monster in alive
            if monster.monster_id == "GremlinNob"
        ),
        None,
    )
    nob_opening_scaling_window = bool(
        gremlin_nob
        and model.turn == 1
        and "ATTACK" not in gremlin_nob.initial_intent
        and model.initial_incoming <= model.initial_block
        and model.initial_hp >= max(30, int(model.max_hp * 0.55))
        and gremlin_nob.hp > int(gremlin_nob.max_hp * 0.60)
    )
    champ = next(
        (monster for monster in alive if monster.monster_id == "Champ"),
        None,
    )
    champ_crossed_this_turn = bool(
        champ
        and champ.initial_hp > champ.max_hp // 2
        and champ.hp <= champ.max_hp // 2
    )
    champ_known_deep_followthrough = bool(
        champ_crossed_this_turn
        and "ATTACK" in champ.initial_intent
        and model.known_next_attack_damage > 0
        and champ.hp - model.known_next_attack_damage
        <= int(champ.max_hp * 0.34)
        and model.resource_risk == 0
    )
    champ_first_phase_weak_control = (
        min(4, max(0, _power_amount(champ.powers, "Weakened"))) * 8
        if (
            champ
            and not model.champ_race
            and champ.hp > champ.max_hp // 2
            and model.initial_hp <= int(model.max_hp * 0.75)
        )
        else 0
    )
    guardian_curl_push = _guardian_curl_aggression(model, alive, end_effective_hp)
    guardian_desperation = _guardian_desperation_window(model, alive, end_effective_hp)
    guardian_curled = any(
        monster.monster_id == "TheGuardian"
        and _power_amount(monster.powers, "Sharp Hide") > 0
        for monster in alive
    )
    guardian_charge_window = (
        model.initial_incoming == 0
        and any(
            monster.monster_id == "TheGuardian"
            and (
                (
                    monster.intent == "DEFEND"
                    and _power_amount(monster.powers, "Mode Shift") > 0
                )
                or (
                    model.initial_guardian_curl_block == 0
                    and _power_amount(monster.powers, "Sharp Hide") > 0
                )
            )
            for monster in alive
        )
    )
    if sleeping_lagavulin is not None:
        # Use the free sleep turns to find setup or a real burst. The logged
        # opener spent Pummel, Headbutt, and Strike for only 15 HP damage,
        # waking Lagavulin two turns before Bash and the upgraded hand arrived.
        setup_progress = model.scaling + model.offensive_scaling + model.draw_value
        wake_start_block = max(
            sleeping_lagavulin.initial_block,
            max(
                0,
                _power_amount(sleeping_lagavulin.powers, "Metallicize"),
            ),
        )
        wake_progress = max(
            0,
            sleeping_lagavulin.initial_hp
            + wake_start_block
            - sleeping_lagavulin.hp
            - sleeping_lagavulin.block,
        )
        weak_wake_threshold = max(24, int(sleeping_lagavulin.max_hp * 0.22))
        early_weak_wake_credit = (
            min(
                2,
                max(
                    0,
                    _power_amount(sleeping_lagavulin.powers, "Weakened"),
                ),
            )
            * 10
            if model.turn == 2
            else 0
        )
        if (
            model.turn < 3
            and wake_progress > 0
            and wake_progress + early_weak_wake_credit < weak_wake_threshold
        ):
            urgent_damage = -100 + wake_progress
        else:
            # The second sleep turn is the final chance to carry Weak into
            # Lagavulin's first 20-damage attack without surrendering two full
            # setup draws. A complete Uppercut/Clothesline opener can therefore
            # beat a visibly weaker third hand even when raw HP damage is just
            # below the ordinary wake threshold.
            urgent_damage = (
                wake_progress * 3
                + setup_progress
                + early_weak_wake_credit
            )
    elif transient_race:
        # The encounter ends by surviving Fading, not by chewing through 999
        # HP. Shifting makes damage another form of block, so preserve the next
        # draw first and use real damage to break equal-health ties. Known draws
        # are already simulated card by card; abstract draw credit must not make
        # an unaffordable Exhume target look like extra mitigation.
        transient = next(
            monster for monster in alive if monster.monster_id == "Transient"
        )
        protected_setup_credit = 0
        if (
            model.turn <= 2
            and _power_amount(model.player_powers, "Buffer") > 0
            and _power_amount(transient.powers, "Fading") >= 4
        ):
            # Buffer makes this attack packet free regardless of how much damage
            # Shifting removes. Spend that protected early window on a Strength
            # engine that improves every larger attack still to come.
            protected_setup_credit = model.offensive_scaling * 2
        transient_loss_pressure = model.self_damage + incoming + end_damage
        healing_gain = max(0, model.hp - model.initial_hp)
        recovery_weight = (
            4
            if model.initial_hp < int(model.max_hp * 0.45)
            else 1
        )
        urgent_damage = (
            damage_dealt
            + protected_setup_credit
            + healing_gain * recovery_weight
            - transient_loss_pressure * 10
            - len(model.commands)
            - model.resource_risk
        )
    elif guardian_charge_window:
        # Charging Up has no incoming damage, so ordinary Block expires before
        # Guardian's next heavy hit. Spend this hand on real mode-shift progress
        # while preserving the exact known defensive draw for that attack.
        hp_price = 3 if model.initial_hp < int(model.max_hp * 0.45) else 1
        healing_gain = max(0, model.hp - model.initial_hp)
        recovery_weight = (
            3
            if model.initial_hp < int(model.max_hp * 0.55)
            else 1
        )
        guardian = next(
            (
                monster for monster in alive
                if monster.monster_id == "TheGuardian"
            ),
            None,
        )
        next_shift_control = _guardian_known_next_turn_shift_control(
            model, guardian
        )
        urgent_damage = (
            damage_dealt
            + next_shift_control
            + _known_draw_outlook(model)
            + model.scaling
            + model.offensive_scaling * 2
            + healing_gain * recovery_weight
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif guardian_curl_push:
        # Sharp Hide progress matters, but every attack also spends real HP.
        # Price that recoil and current incoming once so the planner combines
        # one efficient hit with block instead of converting an otherwise
        # survivable defensive cycle into a 16-HP damage race.
        guardian = next(
            monster for monster in alive if monster.monster_id == "TheGuardian"
        )
        high_boss_hp = model.initial_enemy_hp > int(guardian.max_hp * 0.55)
        reserve_is_thin = model.initial_hp < int(model.max_hp * 0.65)
        hp_price = (
            3
            if (
                reserve_is_thin and hp_loss > 0
                or high_boss_hp and hp_loss > 3
            )
            else 1
        )
        urgent_damage = guardian_curl_progress - hp_loss * hp_price
    elif guardian_desperation:
        # Ending with a full hand of attacks loses the same race a turn later,
        # but spending every last HP on Sharp Hide leaves no room for the next
        # multi-hit. Advance the kill while preserving a small tactical buffer.
        reserve_hp = max(4, int(model.max_hp * 0.05))
        reserve_penalty = max(0, reserve_hp - end_hp) * 20
        urgent_damage = guardian_curl_progress - hp_loss - reserve_penalty
    elif guardian_curled:
        # Low-health, out-of-range Guardian turns still need explicit recoil
        # pricing. Otherwise they fall through to generic damage scoring and
        # can spend the final reserve on Sharp Hide chip.
        reserve_hp = max(8, int(model.max_hp * 0.15))
        reserve_penalty = max(0, reserve_hp - end_effective_hp) * 12
        hp_price = 5 if model.initial_incoming >= 16 else 3
        urgent_damage = (
            guardian_curl_progress
            - hp_loss * hp_price
            - reserve_penalty
            - model.resource_risk
        )
    elif fighting_slime_boss:
        # Slime Boss offers only a few draws before Slam and the split. Generic
        # setup scoring spent the logged quiet turn on Shrug, Armaments, and
        # Disarm while a Perfected Strike sat in hand. Price real boss progress
        # before generic setup, retain credit for offensive scaling/draw, and
        # keep the existing strong penalty for a high-health split.
        # At the high-ascension 150-HP breakpoint, crossing the split line also
        # cancels a 38-damage Slam. Count that cancellation as immediate control
        # while retaining the split-HP penalty, so the search still drives the
        # children as low as the current hand permits. The logged A11 turn could
        # reach 70 only by playing Armaments+ before Strike; ignoring the cancel
        # made it block for 13, take 22, and die to the children instead.
        emergency_split_control = max(
            (
                max(0, model.initial_incoming - model.initial_block)
                for monster in alive
                if monster.monster_id == "SlimeBoss"
                and monster.max_hp >= 150
                and monster.initial_hp > monster.max_hp // 2 >= monster.hp
            ),
            default=0,
        )
        deep_emergency_split_control = max(
            (
                max(0, model.initial_incoming - model.initial_block)
                for monster in alive
                if monster.monster_id == "SlimeBoss"
                and monster.max_hp >= 150
                and monster.initial_hp > monster.max_hp // 2 >= monster.hp
                and monster.hp <= int(monster.max_hp * 0.48)
                and (
                    model.known_next_attack_damage <= 0
                    or monster.initial_hp - model.known_next_attack_damage
                    > int(monster.max_hp * 0.40)
                )
                and not any(
                    card.card_id in {
                        "Flame Barrier", "Impervious", "Power Through",
                    }
                    for card in model.hand
                )
            ),
            default=0,
        )
        known_next_split_control = 0
        if model.initial_incoming == 0 and model.known_next_attack_damage > 0:
            slime_boss = next(
                (
                    monster
                    for monster in alive
                    if monster.monster_id == "SlimeBoss"
                ),
                None,
            )
            if (
                slime_boss is not None
                and slime_boss.hp > slime_boss.max_hp // 2
                and slime_boss.hp - model.known_next_attack_damage
                <= int(slime_boss.max_hp * 0.40)
            ):
                # Wait only when the exact next hand reaches a genuinely low
                # split. Merely crossing half HP made the logged A19 boss pass a
                # current 40-damage hand for a known six-damage Strike, producing
                # much healthier children after the following Slam.
                known_next_split_control = 55
        delayed_deep_split_control = 0
        if (
            model.initial_incoming >= max(30, int(model.max_hp * 0.45))
            and model.known_next_attack_damage > 0
        ):
            slime_boss = next(
                (
                    monster
                    for monster in alive
                    if monster.monster_id == "SlimeBoss"
                ),
                None,
            )
            if slime_boss is not None:
                split_threshold = slime_boss.max_hp // 2
                good_split_hp = max(1, int(slime_boss.max_hp * 0.40))
                projected_split_hp = max(
                    0, slime_boss.hp - model.known_next_attack_damage
                )
                if (
                    slime_boss.initial_hp > split_threshold
                    and slime_boss.hp > split_threshold
                    and projected_split_hp <= good_split_hp
                    and end_effective_hp
                    >= max(18, int(model.max_hp * 0.35))
                ):
                    # The logged A17 hand could cancel Slam by splitting at 67,
                    # but two Defends left 29 HP and the exact next hand dealt
                    # 57 during Slime Boss's free debuff turn. Reward taking the
                    # bounded hit now to create roughly 19-HP children instead
                    # of four near-full medium Slimes over the following turns.
                    split_improvement = good_split_hp - projected_split_hp
                    delayed_deep_split_control = 48 + min(
                        24, split_improvement // 2
                    )
        bounded_slam_delay_control = 0
        slime_boss = next(
            (
                monster
                for monster in alive
                if monster.monster_id == "SlimeBoss"
            ),
            None,
        )
        if (
            slime_boss is not None
            and model.initial_incoming >= max(30, int(model.max_hp * 0.45))
            and slime_boss.initial_hp > slime_boss.max_hp // 2
            and slime_boss.hp > slime_boss.max_hp // 2
            and end_effective_hp >= max(24, int(model.max_hp * 0.32))
            and model.attack_cards >= 5
        ):
            split_threshold = slime_boss.max_hp // 2
            split_distance = slime_boss.hp - split_threshold
            near_split_window = max(12, int(slime_boss.max_hp * 0.08))
            if 0 < split_distance <= near_split_window:
                # When a defended Slam still leaves a real reserve, stopping a
                # few points above the threshold buys Slime Boss's following
                # debuff turn for a much deeper split. The logged A17 line
                # instead cancelled Slam at 74 HP and created nearly full
                # children; Twin Strike + Strike + Defend reached 84 HP and
                # safely kept that quiet follow-up window.
                bounded_slam_delay_control = 36 + min(
                    18, max(0, damage_dealt - split_distance)
                )
        covered_slam_delay_control = 0
        if (
            slime_boss is not None
            and model.initial_incoming >= max(30, int(model.max_hp * 0.45))
            and slime_boss.initial_hp > slime_boss.max_hp // 2
            and slime_boss.hp > slime_boss.max_hp // 2
            and hp_loss <= max(6, int(model.max_hp * 0.09))
            and end_effective_hp >= max(24, int(model.max_hp * 0.72))
            and model.attack_cards >= 4
        ):
            split_threshold = slime_boss.max_hp // 2
            split_distance = slime_boss.hp - split_threshold
            deep_setup_window = max(24, int(slime_boss.max_hp * 0.18))
            if 0 < split_distance <= deep_setup_window:
                # The A19 boss was safely blockable at 97/150. Spending Pen Nib
                # on Blood for Blood split it at 61 merely to cancel Slam;
                # Impervious plus Defend could absorb the hit and preserve the
                # following debuff turn for a much lower split instead.
                covered_slam_delay_control = 120 + min(18, split_distance)
        early_exhaust_engine_credit = 0
        if (
            model.ascension >= 17
            and model.turn <= 2
            and model.initial_incoming <= model.initial_block
            and slime_boss is not None
            and slime_boss.initial_hp >= int(slime_boss.max_hp * 0.75)
            and model.exhaust_power_ready
            and sum(
                card.card_type == "SKILL"
                for card in model.hand + model.draw_pile + model.exhaust_pile
            ) >= 5
            and (
                _power_amount(model.player_powers, "Corruption") > 0
                or _power_amount(model.player_powers, "Feel No Pain") > 0
                or _power_amount(model.player_powers, "Dark Embrace") > 0
            )
        ):
            # Slime Boss's first two debuff turns are the safe window for a
            # paired exhaust engine. Treat newly deployed Corruption/FNP as
            # boss progress; otherwise a few points of chip damage consume the
            # window and the engine never protects the post-split hands.
            early_exhaust_engine_credit = model.exhaust_power_scaling * 5
        hp_price = 2 if model.incoming > 0 or model.initial_hp * 2 < model.max_hp else 1
        urgent_damage = (
            damage_dealt
            + emergency_split_control * 2
            + deep_emergency_split_control
            + known_next_split_control
            + delayed_deep_split_control
            + bounded_slam_delay_control
            + covered_slam_delay_control
            + model.offensive_scaling
            + early_exhaust_engine_credit
            + model.draw_value * 2
            - hp_loss * hp_price
            - slime_split_risk * 2
        )
    elif post_boss_slime_wave:
        # Start controlling the second split as soon as Slime Boss produces its
        # two large children. Waiting for the first medium child made the rule
        # one action too late in both A17 batch-17 boss fights. Clear existing
        # children, or spread damage above both large split thresholds, unless
        # a large Slime itself can be killed.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 4 if hp_ratio < 0.45 else 2
        heavy_visible_split_turn = (
            max(0, model.initial_incoming - model.initial_block)
            >= max(24, int(model.max_hp * 0.30))
        )
        emergency_split_escape = bool(
            large_slime_split_attack_control
            and end_effective_hp > 0
            and (hp_ratio < 0.40 or heavy_visible_split_turn)
        )
        split_pressure = large_slime_split_pressure
        split_escape_credit = 0
        if emergency_split_escape:
            # Crossing an attacking large Slime's threshold cancels that hit.
            # This is worth creating children at critical HP, and also on a
            # heavy multi-attacker turn before the reserve becomes critical.
            split_pressure = max(
                0,
                split_pressure - 180 * len(new_attacking_large_splits),
            )
            split_escape_credit = large_slime_split_attack_control * 8
        urgent_damage = (
            large_slime_kill_control
            + slime_child_control
            + slime_child_progress * 4
            + damage_dealt // 4
            # Newly deployed Combust is damage on every remaining slime wave,
            # not optional setup equivalent to clearing one more Slimed card.
            + model.offensive_scaling
            + split_escape_credit
            - split_pressure
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif critical_snake_plant_burst:
        # Snake Plant's debuff turn is the only free damage window before its
        # three-hit pressure resumes. At critical HP, convert that window into
        # immediate burst instead of preserving ordinary attacks for a future
        # draw the player is unlikely to survive. Fiend Fire keeps a small
        # explicit resource price from simulate_card so it still needs to deal
        # materially more damage than the cheap alternatives.
        known_exhaust_block = (
            max(0, _power_amount(model.player_powers, "Feel No Pain"))
            * min(
                4,
                sum(
                    card.exhausts or card.ethereal
                    for card in model.draw_pile[-10:]
                ),
            )
        )
        urgent_damage = (
            damage_dealt * 3
            + model.offensive_scaling
            + model.scaling
            + known_exhaust_block
            - hp_loss * 4
            - model.resource_risk
        )
    elif snake_plant_followup_commit:
        # A heavy three-hit leaves only one draw at this reserve.  Use the exact
        # exposed draw order to recognize a same-turn Rupture/Hemokinesis setup
        # that turns that next hand into a real finish.  Reserve a small damage
        # margin for Malleable instead of treating raw forecast damage as lethal.
        known_next_damage = _known_next_turn_attack_damage(
            model, target=snake_plant, require_full=False
        )
        known_followup_finish = 0
        if snake_plant.hp <= max(0, known_next_damage - 8):
            known_followup_finish = 120 + min(
                40, known_next_damage - 8 - snake_plant.hp
            )
        urgent_damage = (
            damage_dealt * 3
            + model.offensive_scaling
            + model.scaling
            + known_followup_finish
            - hp_loss * 4
            - model.resource_risk
        )
    elif fighting_collector and (
        model.incoming == 0
        or model.initial_hp < max(28, int(model.max_hp * 0.45))
        or collector_finish_window
        or collector_opening_aggression
        or collector_scaling_setup_window
        or collector_recovery_setup_window
        or collector_exhaust_setup_window
        or collector_swarm_pressure
        or collector_quiet_engine_replan
    ):
        # Collector alternates summons, a three-turn debuff, and large attack
        # turns. Treat permanent setup, boss progress, and removing Torch Heads
        # as race progress, but price HP and exhausted core cards so the bot
        # still blocks efficiently. This prevents a low-HP quiet turn from
        # choosing slow setup over a reachable burst window.
        if collector_critical_reserve:
            hp_price = 5
        elif collector_swarm_pressure or collector_early_dual_torch_pressure:
            # Two early Torch Heads already represent a recurring 14-point tax.
            # Price that life before it grows into the later swarm threshold.
            hp_price = 4
        elif collector_opening_heavy_hit_guard:
            # Once one Torch Head is gone, nonlethal minion progress must not
            # make a healthy-looking opener spend most of the remaining bar.
            # The exact next hand can finish a nearly dead minion on Collector's
            # debuff turn; keep enough life to reach that hand.
            hp_price = 3
        elif model.initial_hp < max(28, int(model.max_hp * 0.45)):
            hp_price = 3
        else:
            hp_price = 1
        collector_demon_form_deployed = bool(
            (collector_scaling_setup_window or collector_recovery_setup_window)
            and _power_amount(model.player_powers, "Demon Form") > 0
            and model.offensive_scaling >= SAFE_POWER_VALUES["Demon Form"]
        )
        collector_reserve_penalty = (
            max(
                0,
                max(24, int(model.max_hp * 0.30)) - end_effective_hp,
            )
            * 6
            if (
                collector_swarm_pressure
                and model.turn <= 3
                and model.initial_block == 0
                and not collector_demon_form_deployed
            )
            else 0
        )
        debuff_control = sum(
            min(
                3,
                max(0, _power_amount(monster.powers, "Weakened")),
                max(0, _power_amount(monster.powers, "Vulnerable")),
            )
            * 2
            for monster in alive
        )
        # A healthy opener may spend some reserve before the debuff cycle, while
        # a Collector inside one good hand of lethal no longer gives setup enough
        # turns to repay itself. The logged A7 turn played Evolve instead of
        # Strike at 81 boss HP and finished only ten HP short.
        scaling_credit = 0 if collector_finish_window else model.scaling
        collector_offensive_setup_credit = 0
        if (
            collector_scaling_setup_window
            and end_effective_hp >= max(18, int(model.max_hp * 0.22))
        ):
            # The third turn is often the last affordable Demon Form window.
            # The logged A13 fight entered at medium HP, fell outside both the
            # healthy and critical branches, and never deployed its only boss
            # scaling before Collector's debuff cycle closed the fight.
            collector_offensive_setup_credit = model.offensive_scaling * 2
        elif (
            collector_recovery_setup_window
            and end_effective_hp >= max(10, int(model.max_hp * 0.15))
        ):
            # The A17 energy-potion hand could establish Demon Form, survive the
            # swarm, then draw Reaper immediately with the new Strength online.
            # Treat that known recovery hand as part of the setup window without
            # extending the same low-reserve license to an unknown next draw.
            collector_offensive_setup_credit = model.offensive_scaling
        temporary_control = collector_torch_kill_control
        if (
            collector
            and model.turn <= 5
            and "ATTACK" not in collector.intent
            and max(0, model.initial_incoming - model.initial_block) <= 3
        ):
            # A nearly dead Torch Head whose current hit is already covered is
            # cleanup, not a full minion removal. The A17 planner gave its last
            # three HP more value than deploying both long-fight engines.
            trivial_cleanup_discount = sum(
                max(0, 45 + _target_threat(monster) - 8)
                for monster in model.monsters
                if (
                    monster.monster_id == "TorchHead"
                    and not monster.alive
                    and monster.initial_hp <= 8
                )
            )
            temporary_control = max(
                0, temporary_control - trivial_cleanup_discount
            )
        collector_exhaust_setup_credit = 0
        collector_quiet_engine_credit = 0
        if collector_exhaust_setup_window:
            collector_exhaust_setup_credit = model.exhaust_power_scaling * 3
            collector_quiet_engine_credit = model.offensive_scaling * 2
        corruption_engine_control = 0
        if _power_amount(model.player_powers, "Corruption"):
            if _power_amount(model.player_powers, "Feel No Pain"):
                corruption_engine_control += 24
            if _power_amount(model.player_powers, "Dark Embrace"):
                corruption_engine_control += 18
        boss_progress_weight = 1
        if collector_quiet_swarm_window:
            torch_progress_weight = 2
        elif collector_swarm_pressure and collector_boss_exposed:
            torch_progress_weight = 1
        else:
            torch_progress_weight = 0
        if collector_finish_window:
            temporary_control //= 4
            boss_progress_weight = 5
            torch_progress_weight = 0
        elif (
            collector_boss_race_window
            and not collector_swarm_pressure
            and not collector_opening_heavy_hit_guard
        ):
            temporary_control //= 3
            boss_progress_weight = 4
            torch_progress_weight = 0
        elif collector_swarm_pressure:
            # Killing one Torch Head already removes its current attack from
            # hp_loss, and Collector can summon it again. Keep that temporary
            # control valuable without counting the same attack three different
            # ways. Partial focus still matters here: putting one Torch Head in
            # next-draw lethal range prevents repeated three-enemy attack turns.
            # The pressure flag is tied to the opening board, so a candidate
            # cannot lower its own HP price by killing a minion.
            temporary_control //= 2
        collector_strength_debuff_credit = (
            model.strength_debuff_scaling * 3
            if collector_swarm_pressure and model.initial_block == 0
            else 0
        )
        collector_replan_focus_weight = (
            2 if collector_quiet_engine_replan
            else 1 if collector_blocked_swarm_replan
            else 0
        )
        collector_pocketwatch_control = (
            40
            if (
                collector_pocketwatch_bridge_window
                and 0 <= model.pocketwatch_counter <= 3
            )
            else 0
        )
        urgent_damage = (
            temporary_control
            + damage_dealt
            + collector_torch_progress * torch_progress_weight
            + collector_torch_focus_progress * collector_replan_focus_weight
            + collector_boss_progress * (boss_progress_weight - 1)
            + scaling_credit
            + collector_offensive_setup_credit
            + collector_exhaust_setup_credit
            + collector_quiet_engine_credit
            + corruption_engine_control
            + debuff_control * 4
            + collector_strength_debuff_credit
            + collector_pocketwatch_control
            - hp_loss * hp_price
            - collector_reserve_penalty
            - model.future_risk
            - model.resource_risk
        )
    elif reptomancer_encounter:
        # Reptomancer compresses the fight into a few extremely dangerous
        # draws. At 61 HP the logged deck held Offering, killed both daggers,
        # but declined to draw for block and then lost 30. Paying six HP to
        # expose three real cards is immediate control while a reserve exists.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        draw_credit = 8 if hp_ratio >= 0.35 else 4
        hp_price = 2 if hp_ratio >= 0.45 else 3
        urgent_damage = (
            reptomancer_control
            + reptomancer_dagger_progress
            + damage_dealt
            + model.draw_value * draw_credit
            + model.offensive_scaling
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif awakened_one_encounter:
        # A healthy opener may establish one supported engine, but every later
        # Power must pay the full permanent Curiosity cost. This keeps the v68
        # supported-Corruption fix while avoiding the v77 low-HP sequence that
        # stacked Evolve, Fire Breathing, Feel No Pain, and Inflame.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 4 if hp_ratio < 0.30 else 2
        curiosity_risk_price = 2 if hp_ratio < 0.30 else 1
        setup_credit = model.awakened_key_power_credit * 2
        urgent_damage = (
            cultist_control
            + cultist_focus_control
            + damage_dealt
            + setup_credit
            + model.offensive_scaling * 2
            + model.draw_value * 3
            - hp_loss * hp_price
            - model.resource_risk
            - (
                model.future_risk + model.awakened_curiosity_risk
            ) * curiosity_risk_price
        )
    elif donu_deca_encounter:
        # The Shapes are a damage race from turn one: every delayed Donu kill
        # adds Strength to both attackers. Still preserve setup that repays
        # inside the opening cycle, especially Shockwave through Artifact.
        # The logged A15 opener saved six HP but gave up 26 Donu progress and
        # consequently took one additional 36-damage attack before the kill.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 3 if hp_ratio < 0.40 else 2
        opening_setup_weight = 6 if model.turn <= 2 else 0
        urgent_damage = (
            donu_kill_control
            + damage_dealt
            + model.offensive_scaling * 2
            + model.scaling * opening_setup_weight
            + model.draw_value * 5
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif time_eater is not None:
        # Time Eater is both a damage race and a card-efficiency check. Generic
        # health scoring spent the logged second turn on four block/setup cards,
        # leaving Shockwave unused, then paid three energy for Corruption while
        # an upgraded Heavy Blade could pair with block on the 32-damage turn.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        candidate_below_reserve = end_effective_hp < max(
            10, int(model.max_hp * 0.30)
        )
        if candidate_below_reserve or hp_ratio < 0.30:
            hp_price = 6
        elif hp_ratio < 0.56:
            hp_price = 4
        else:
            hp_price = 2
        pocketwatch_control = (
            40
            if 0 <= model.pocketwatch_counter <= 3
            else 0
        )
        weak_turns = max(0, _power_amount(time_eater.powers, "Weakened"))
        vulnerable_turns = max(0, _power_amount(time_eater.powers, "Vulnerable"))
        debuff_control = (
            min(5, weak_turns) * 6
            + min(5, vulnerable_turns) * 4
        )
        ending_time_warp = max(
            0, _power_amount(time_eater.powers, "Time Warp")
        )
        time_warp_control = 0
        if (
            ending_time_warp >= 11
            and model.initial_time_warp < 11
            and survives
        ):
            # Carrying eleven into the next hand makes its first card end the
            # turn. Charge that lost tactical card now, while still allowing a
            # genuinely life-saving block play to overcome the bounded price.
            time_warp_control -= 24
        if model.initial_incoming <= 0 and model.initial_time_warp >= 10:
            if ending_time_warp == 0 and model.commands:
                # At ten or eleven, a quiet turn is the clean opportunity to
                # reset the clock. The logged A19 line played only one Strike
                # from ten and carried eleven into a 36-damage turn, where its
                # first Defend immediately ended the hand.
                time_warp_control += 52
            elif ending_time_warp == 11:
                time_warp_control -= 56
            elif ending_time_warp == 10:
                time_warp_control -= 20
        if (
            model.initial_incoming > 0
            and model.initial_time_warp >= 11
            and ending_time_warp == 0
            and survives
            and end_effective_hp >= max(8, int(model.max_hp * 0.12))
            and model.commands
            and not (0 <= model.pocketwatch_counter <= 3)
        ):
            # The bot executes a plan one card at a time and replans after every
            # observation. In the logged A17 Time Eater fight the full plan
            # correctly reached twelve, but the final replan started at eleven
            # and ended instead. Pay the small current Strength increase while
            # it is survivable so the next hand is not limited to one card.
            time_warp_control += 28
        if (
            model.initial_incoming <= 0
            and model.initial_hp < max(30, int(model.max_hp * 0.45))
            and model.initial_time_warp >= 7
        ):
            if ending_time_warp == 0 and model.commands:
                # Spend the quiet turn closing a high counter. The logged A13
                # run stopped at ten, so the next attack turn lost its hand as
                # soon as the second card triggered Time Warp.
                time_warp_control = max(time_warp_control, 32)
            elif ending_time_warp >= 10:
                time_warp_control -= (ending_time_warp - 9) * 14
        urgent_damage = (
            damage_dealt
            + model.offensive_scaling * 2
            + model.scaling // 2
            + model.draw_value * 3
            + debuff_control
            + pocketwatch_control
            + time_warp_control
            - hp_loss * hp_price
            - _time_eater_haste_risk(model) * 2
            - model.future_risk
            - model.resource_risk
        )
    elif fighting_bronze_automaton:
        # Hyper Beam makes this a timed damage race from the opening cycle. If
        # an orb is killable, its control bonus still wins; if this hand can
        # only leave a healthy orb alive, convert the damage into boss progress
        # instead of repeating the logged 48-damage non-kill while Automaton
        # remained at 295 HP.
        automaton = next(
            monster for monster in alive if monster.monster_id == "BronzeAutomaton"
        )
        living_bronze_orbs = sum(
            monster.monster_id == "BronzeOrb" and monster.alive
            for monster in model.monsters
        )
        boss_finish_window = automaton.hp <= max(
            72, int(automaton.max_hp * 0.24)
        )
        early_setup_window = (
            model.turn <= 3
            and automaton.hp > int(automaton.max_hp * 0.55)
            and max(0, model.initial_incoming - model.initial_block) <= 8
        )
        survivable_midfight_demon_form = bool(
            4 <= model.turn <= 9
            and automaton.hp > max(90, int(automaton.max_hp * 0.35))
            and _power_amount(model.player_powers, "Demon Form") > 0
            and model.offensive_scaling >= SAFE_POWER_VALUES["Demon Form"]
            and survives
            and end_effective_hp >= max(10, int(model.max_hp * 0.12))
        )
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        opening_pressure = max(
            0, model.initial_incoming - model.initial_block
        )
        critical_raw_hp = model.initial_hp <= max(
            14, int(model.max_hp * 0.20)
        )
        unresolved_key_orb_pressure = bool(
            living_bronze_orbs >= 2
            and any(
                monster.monster_id == "BronzeOrb"
                and monster.alive
                and "ATTACK" in monster.intent
                and _bronze_stasis_priority(monster) >= 3
                for monster in model.monsters
            )
        )
        if critical_raw_hp and not boss_finish_window:
            # At critical raw HP, one point can be the difference between
            # surviving the next exact attack and dying.  The logged A16 fight
            # traded five avoidable HP for 23 nonlethal damage at 12 HP.
            hp_price = 16
        elif (
            hp_ratio < 0.60
            and unresolved_key_orb_pressure
            and not boss_finish_window
        ):
            # When random hits fail to finish the attacking Stasis Orb, keep
            # enough life for the Automaton cycle instead of buying ordinary
            # boss chip with all remaining block energy. Killing the Orb still
            # removes this branch and receives its full control reward.
            hp_price = 7
        elif (
            hp_ratio < 0.50
            or (
                model.turn <= 3
                and opening_pressure >= max(18, int(model.max_hp * 0.22))
            )
        ) and not boss_finish_window:
            # At 39/80 with the boss still at 154, spending 34 HP on two
            # Immolates only moved the loss one turn closer. Preserve enough
            # life to reach the next draw unless this hand can finish the boss.
            # The same price applies to a healthy opening hand taking 24 while
            # its known Pommel -> Shrug -> Defend line loses only eight.
            hp_price = 4
        else:
            hp_price = 3 if model.turn <= 6 else 2
        # Killing the first orb is valuable because it returns a Stasis card.
        # Once only one orb remains, do not spend repeated turns chipping it:
        # either finish it immediately or convert spare damage into boss race
        # progress. Boss damage is therefore weighted more heavily, while the
        # second-orb kill bonus is reduced unless it is actually completed.
        # Count the first kill when the turn began with both Orbs. The old test
        # used the post-plan living count, which made every first-orb kill worth
        # zero and favored leaving a 2- or 3-HP Stasis Orb alive.
        orb_control_value = (
            bronze_orb_control
            if initial_bronze_orbs >= 2
            else 0
        )
        pre_stasis_attack_control = (
            bronze_pre_stasis_attack_control
            if initial_bronze_orbs >= 2
            else 0
        )
        boss_progress_weight = (
            3
            if living_bronze_orbs == 1 or model.bronze_orb_cleanup_credit
            else 1
        )
        healthy_two_orb_setup = (
            initial_bronze_orbs >= 2
            and living_bronze_orbs >= 2
            and model.turn <= 3
            and hp_ratio >= 0.65
            and model.initial_incoming < 20
        )
        bronze_orb_setup_progress = (
            bronze_orb_focus_progress * 2 if healthy_two_orb_setup else 0
        )
        # The opening Shockwave in the logged A10 fight looked like zero
        # damage, but stripping Artifact let the second copy land and cover
        # the entire first cycle. Once the Orbs spawn, Weak/Vulnerable on three
        # targets is still worth more than a pair of ordinary attacks.
        debuff_setup_weight = (
            20
            if model.turn == 1 and living_bronze_orbs == 0
            else 3
            if model.turn <= 3
            else 1
        )
        cycle_turn = (max(1, model.turn) - 1) % 6 + 1
        automaton_setup_scaling = model.scaling
        prebeam_buffer_preservation_credit = 0
        if (
            cycle_turn in {2, 3, 4, 5}
            and automaton.hp > max(72, int(automaton.max_hp * 0.24))
            and _power_amount(model.player_powers, "Buffer") > 0
            and model.initial_incoming > model.initial_block
            and model.incoming > 0
            and model.incoming <= _projected_end_turn_block(model)
        ):
            # Buffer turns one entire damage packet into zero. Spending Helix on
            # Automaton's small double hit left the logged A19 run defenseless
            # against the known 58-damage Hyper Beam four turns later.
            beam_damage = (
                54 + max(0, _power_amount(automaton.powers, "Strength"))
            )
            prebeam_buffer_preservation_credit = max(240, beam_damage * 5)
        unsupported_delayed_corruption = bool(
            model.delay_corruption
            and _power_amount(model.player_powers, "Corruption")
            and not any(
                _power_amount(model.player_powers, power_id)
                for power_id in {"Dark Embrace", "Feel No Pain"}
            )
        )
        if unsupported_delayed_corruption:
            # Turn-one Artifact stripping receives a large Automaton-specific
            # multiplier. Corruption's generic setup value is not debuff setup;
            # multiplying it by twenty made a payoff-free copy beat Uppercut
            # plus Iron Wave in the logged A19 fight.
            automaton_setup_scaling = max(
                0,
                automaton_setup_scaling - model.exhaust_power_scaling,
            )
        pre_beam_exhaust_setup_credit = 0
        if (
            cycle_turn == 5
            and "ATTACK" not in automaton.intent
            and model.exhaust_power_ready
            and _power_amount(model.player_powers, "Corruption")
            and any(
                _power_amount(model.player_powers, power_id)
                for power_id in {"Dark Embrace", "Feel No Pain"}
            )
        ):
            # Turn five is the last free setup window before Hyper Beam. In the
            # logged A16 fight, an upgraded Corruption backed by two Dark
            # Embraces lost to one Immolate here, then arrived on turn six with
            # four block/exhaust skills still costing energy. Establishing the
            # supported engine now converts that known beam hand into free
            # block and draw, so value it as immediate survival preparation.
            pre_beam_exhaust_setup_credit = SAFE_POWER_VALUES["Corruption"] * 5
        urgent_damage = (
            damage_dealt
            + orb_control_value
            + pre_stasis_attack_control
            + bronze_prebeam_stasis_control
            + bronze_stasis_focus_progress
            + bronze_orb_setup_progress
            + model.bronze_orb_cleanup_credit
            + automaton_boss_progress * boss_progress_weight
            # Artifact removal is real setup: once all three charges are gone,
            # Bash/Uppercut can carry Vulnerable or Weak through Hyper Beam and
            # the post-stun double hit. Two A19 losses left all three charges
            # untouched because only landed debuffs had previously been valued.
            + automaton_artifact_break_control
            + model.offensive_scaling * (
                3
                if early_setup_window or survivable_midfight_demon_form
                else 1
            )
            + automaton_setup_scaling * debuff_setup_weight
            + pre_beam_exhaust_setup_credit
            + prebeam_buffer_preservation_credit
            - hp_loss * hp_price
            - _automaton_hyper_beam_reserve_risk(model, end_effective_hp)
            - model.future_risk
            - model.resource_risk
        )
    elif serpent_constrict_window:
        # Spire Growth's debuff is a delayed ten damage every turn. Treat the
        # last unconstricted hand as a short burst window: current damage and
        # the visible next draw are worth more than slow powers which will not
        # repay their energy before Constricted starts draining the reserve.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 4 if hp_ratio < 0.45 else 2
        urgent_damage = (
            damage_dealt * 3
            + _known_draw_outlook(model)
            + model.offensive_scaling
            + model.scaling
            - hp_loss * hp_price
            - model.future_risk
            - model.resource_risk
        )
    elif (
        champ is not None
        and not model.champ_race
        and (
            champ.initial_hp >= int(champ.max_hp * 0.70)
            or model.initial_hp >= int(model.max_hp * 0.35)
        )
    ):
        # Champ's first phase is preparation, but real boss progress still has
        # to beat spending a quiet turn at four energy. The logged A10 opener
        # skipped 33 free damage and later died with Champ at 26 HP. Keep the
        # existing phase-crossing guard: once a candidate crosses half HP,
        # simulate_card marks champ_race and the stricter branch below scores it.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        projected_unblocked_hp = model.initial_hp - max(
            0, model.initial_incoming - model.initial_block
        )
        if projected_unblocked_hp < max(18, int(model.max_hp * 0.25)):
            # At critical reserve, a controlled True Grit exhaust can still
            # carry a real long-term cost. Price this turn's life high enough
            # that preserving six HP beats one extra chip attack.
            hp_price = 6
        elif (
            hp_ratio < 0.40
            or projected_unblocked_hp < int(model.max_hp * 0.45)
        ):
            hp_price = 3
        elif (
            model.ascension >= 18
            and model.turn <= 2
            and model.initial_incoming >= 14
        ):
            # A18 Champ gives ample first-phase setup time but punishes a thin
            # reserve with a 56-damage Execute. The logged full-health opener
            # spent both Defends for three attacks, then repeated that trade on
            # turn two and lost the life bar before Corruption arrived.
            hp_price = 4 if hp_ratio < 0.90 else 3
        elif (
            model.initial_incoming >= max(20, int(model.max_hp * 0.22))
            and projected_unblocked_hp < int(model.max_hp * 0.55)
        ):
            # In Champ's first phase, a medium reserve still has to survive the
            # execute cycle. The logged A17 turn valued seven immediate HP at
            # only one point each and skipped a free True Grit; a modest second
            # price tier selects that efficient block without prematurely
            # spending Impervious.
            hp_price = 2
        elif (
            model.initial_incoming >= 10
            and hp_ratio < 0.90
            and projected_unblocked_hp < int(model.max_hp * 0.70)
        ):
            # A18 Champ still has a long first phase and a 56-damage Execute
            # after the cleanse. The logged turn spent eleven HP for extra chip
            # despite holding Power Through+, then died exactly one hit short.
            # Once the reserve has already fallen, price that avoidable medium
            # hit above pre-transition damage without forcing burst block at full
            # health or on the later damage-race phase.
            hp_price = 3
        else:
            hp_price = 1
        charons_corruption_setup_credit = (
            model.exhaust_power_scaling
            if (
                model.charons_ashes
                and _power_amount(model.player_powers, "Corruption")
                and model.initial_incoming <= model.initial_block
            )
            else 0
        )
        champ_quiet_exhaust_setup_credit = (
            model.exhaust_power_scaling * 4
            if (
                model.ascension >= 18
                and model.turn <= 6
                and hp_ratio < 0.40
                and champ.initial_hp > champ.max_hp // 2
                and "ATTACK" not in champ.initial_intent
                and model.initial_incoming <= model.initial_block
                and model.exhaust_power_ready
                and _power_amount(model.player_powers, "Dark Embrace") > 0
            )
            else 0
        )
        critical_champ_combust_risk = (
            model.combust_hp_loss * 12
            if (
                min(projected_unblocked_hp, end_effective_hp)
                <= max(18, int(model.max_hp * 0.25))
                and champ.initial_hp >= int(champ.max_hp * 0.70)
            )
            else 0
        )
        urgent_damage = (
            damage_dealt
            + model.scaling
            + model.offensive_scaling * 2
            + model.draw_value * 2
            + champ_first_phase_weak_control
            # On a covered Champ setup turn, Corruption turns the remaining
            # skills into both free defense and Charon's Ashes damage.
            + charons_corruption_setup_credit
            # At low reserve, a quiet first-phase hand is the window to deploy
            # a supported Dark Embrace. Waiting until Champ attacks can force
            # Second Wind to consume the block cards needed for that hit.
            + champ_quiet_exhaust_setup_credit
            - hp_loss * hp_price
            # At critical reserve in early phase one, a newly played Combust
            # spends life every remaining cycle. The logged A19 opener valued
            # that slow scaling above Bash plus Carnage and entered the next
            # attack one HP lower with twenty less immediate boss damage.
            - critical_champ_combust_risk
            - model.future_risk
            - model.resource_risk
            - _champ_shallow_phase_risk(model)
        )
    elif fighting_plated_armor:
        # Plated Armor rebuilds every turn and shrinks only after real HP
        # damage. Treat breaking the current shell as race progress so a
        # hallway hand does not spend all its energy on slow setup while a
        # Perfected Strike or another efficient hit is available.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = (
            10
            if hp_ratio < 0.25
            else 7
            if hp_ratio < 0.40
            else 4
            if hp_ratio < 0.60
            else 2
        )
        shelled_early_attrition_guard = bool(
            model.turn <= 2
            and model.initial_incoming >= 10
            and _power_amount(model.player_powers, "Frail") > 0
            and any(
                monster.alive
                and monster.monster_id in {
                    "Shelled Parasite", "Shell Parasite",
                }
                and _power_amount(monster.powers, "Plated Armor") > 0
                for monster in model.monsters
            )
        )
        if shelled_early_attrition_guard:
            # Keep the attrition price after an earlier action strips the
            # visible Block. Plated Armor still identifies the same dangerous
            # opening, so a same-turn replan must not discard promised defense.
            hp_price = max(hp_price, 5)
        a18_shelled_pressure_guard = bool(
            model.ascension >= 18
            and model.turn <= 2
            and model.initial_incoming >= 20
            and hp_ratio < 0.80
            and any(
                monster.monster_id == "Shelled Parasite"
                for monster in model.monsters
            )
        )
        if a18_shelled_pressure_guard:
            # Spending the opening hand entirely on the intact shell can turn
            # a healthy-looking A18 reserve into two forced lethal hallways.
            # Keep this price after the first attack strips visible Block: the
            # Plated Armor power still identifies the same attrition turn, and
            # same-turn replanning must not replace a promised Defend with one
            # more attack merely because the shell is now nearly broken.
            hp_price = max(hp_price, 5)
        projected_unblocked_hp = model.initial_hp - max(
            0, model.initial_incoming - model.initial_block
        )
        if (
            model.ascension >= 18
            and projected_unblocked_hp
            < max(24, int(model.max_hp * 0.35))
            and any(
                monster.monster_id == "Shelled Parasite"
                for monster in model.monsters
            )
        ):
            # At A18, taking the full debuff hit can consume the reserve before
            # Plated Armor is broken. Keep enough life for the known next draw.
            hp_price = max(hp_price, 8)
        reserve_hp = max(18, int(model.max_hp * 0.25))
        reserve_shortfall = (
            max(0, reserve_hp - end_effective_hp)
            if hp_ratio < 0.50
            else 0
        )
        plated_block_progress = max(
            0, model.initial_persistent_block - persistent_block_left
        )
        plated_race_progress = (
            damage_dealt
            if hp_damage_dealt > 0
            else plated_block_progress // 4
        )
        exhaust_engine_powers = {
            "Corruption", "Dark Embrace", "Feel No Pain"
        }
        status_engine_powers = {"Evolve", "Fire Breathing"}
        exhaust_setup_multiplier = (
            3 if model.turn <= 2 and hp_ratio < 0.50 else 2
        )
        plated_engine_setup_credit = sum(
            SAFE_POWER_VALUES[power_id] * exhaust_setup_multiplier
            for power_id in exhaust_engine_powers
            if model.exhaust_power_ready
            and _power_amount(model.player_powers, power_id)
        ) + sum(
            SAFE_POWER_VALUES[power_id]
            for power_id in status_engine_powers
            if model.status_power_ready
            and _power_amount(model.player_powers, power_id)
        )
        plated_debuff_duration_cap = 5 if hp_ratio >= 0.50 else 3
        plated_debuff_turn_value = 8 if hp_ratio >= 0.50 else 3
        plated_debuff_control = sum(
            min(
                plated_debuff_duration_cap,
                max(0, _power_amount(monster.powers, "Weakened")),
                max(0, _power_amount(monster.powers, "Vulnerable")),
            )
            * plated_debuff_turn_value
            for monster in alive
        )
        shelled_early_demon_form_window = bool(
            model.act == 2
            and model.turn <= 2
            and hp_ratio >= 0.50
            and model.initial_enemy_hp >= 75
            and model.initial_incoming <= max(18, int(model.max_hp * 0.23))
            and projected_unblocked_hp >= max(24, int(model.max_hp * 0.35))
            and _power_amount(model.player_powers, "Demon Form") > 0
            and model.offensive_scaling >= SAFE_POWER_VALUES["Demon Form"]
        )
        plated_scaling_multiplier = 4 if shelled_early_demon_form_window else 2
        urgent_damage = (
            plated_race_progress * 2
            + fungi_scaling_kill_control
            + model.offensive_scaling * plated_scaling_multiplier
            + plated_engine_setup_credit
            + plated_debuff_control
            + model.strength_debuff_scaling * 3
            + model.draw_value * 2
            + model.risky_power_credit
            - hp_loss * hp_price
            - reserve_shortfall * 8
            - model.future_risk
            - model.resource_risk
        )
    elif model.persistent_block_race:
        # A retained-block enemy is a long damage race. Immediate chip still
        # matters, but ignoring setup powers made the planner spend spare turns
        # on Strikes and deploy Fire Breathing only when already dead.
        # Spheric Guardian's retained block must not hide a one-HP attacking
        # Sentry. Removing that attacker is immediate race progress even though
        # the final hit has poor raw damage efficiency.
        # Only an attacking Sentry earns the large cleanup bonus. Damaging a
        # debuffing Sentry while Spheric Guardian deals 22 is not immediate
        # control; at critical HP, discount that progress so one more draw is
        # worth more than leaving the Sentry at three. Persistent-block chip
        # also pays a real HP price whenever no attacker was removed.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        critical_retained_block = (
            hp_ratio < 0.30 and not attacking_sentry_cleanup_control
        )
        if attacking_sentry_cleanup_control:
            # Killing the Sentry removes its hit, but Spheric Guardian can
            # still connect. At low reserve, do not make that remaining damage
            # free merely because the first attacker died this turn.
            hp_price = 4 if hp_ratio < 0.50 else 0
        elif critical_retained_block:
            hp_price = 6
        elif model.incoming <= 10 and model.initial_hp >= model.incoming * 4:
            # A small hit is an acceptable price for breaking retained block;
            # otherwise one Defend can stall forever against 80 Barricade.
            hp_price = 1
        else:
            hp_price = 4 if hp_ratio < 0.50 else 3
        known_next_block = _known_next_turn_block_capacity(
            model, require_full=False, follow_draw=False
        )
        if (
            hp_ratio < 0.45
            and any(
                monster.alive
                and monster.monster_id == "SphericGuardian"
                and monster.initial_intent == "ATTACK_DEFEND"
                for monster in model.monsters
            )
            and (known_next_block or 0) <= 5
        ):
            # Harden is followed by the double-hit Slam. If the exposed next
            # hand has almost no Block, preserve HP now instead of spending a
            # Defend on retained-Block chip and dying to the known follow-up.
            hp_price = max(hp_price, 5)
        nonattacking_sentry_progress_discount = 0
        if (
            hp_ratio < 0.50
            and hp_loss > 0
            and any("ATTACK" not in monster.intent for monster in sentries)
        ):
            nonattacking_sentry_progress_discount = min(20, damage_dealt)
        retained_block_progress = max(
            0, model.initial_persistent_block - persistent_block_left
        )
        known_next_retained_finish_control = 0
        if critical_retained_block and survives and len(alive) == 1:
            target = alive[0]
            remaining_life = target.hp + target.block
            known_next_damage = _known_next_turn_attack_damage(model)
            if known_next_damage >= remaining_life:
                # CommunicationMod exposes the exact next five-card draw. At
                # critical HP, breaking retained Block into that known damage
                # window is immediate control, not speculative chip. This
                # distinguishes the logged Immolate setup from spending the
                # same energy on Fire Breathing and leaving the shell intact.
                known_next_retained_finish_control = 100 + min(
                    60, (known_next_damage - remaining_life) * 3
                )
        persistent_race_damage = damage_dealt
        if critical_retained_block:
            # Chip that cannot reach HP this turn is not worth replacing a
            # life-saving Defend. The logged Spheric Guardian line spent one
            # energy on Strike into 54 retained Block and fell to two HP.
            persistent_race_damage = (
                hp_damage_dealt
                + projected_retaliation
                + retained_block_progress // 4
            )
        urgent_damage = (
            persistent_race_damage
            + model.scaling * 2
            + attacking_sentry_cleanup_control
            + known_next_retained_finish_control
            - hp_loss * hp_price
            - nonattacking_sentry_progress_discount
        )
    elif fighting_spikers:
        # Thorns grow every buff cycle, so preserving one extra HP this turn is
        # not enough reason to leave a 3-HP attacker alive indefinitely. Reward
        # a surviving kill, while heavily pricing recoil and finite block spent
        # merely to make nonlethal progress on a quiet turn.
        covered_attacking_spiker_cleanup_discount = sum(
            30
            for monster in model.monsters
            if monster.monster_id == "Spiker"
            and not monster.alive
            and "ATTACK" in monster.initial_intent
            and model.initial_block >= model.initial_incoming
            and any(
                other.initial_hp > 0
                and other.monster_id in {"Exploder", "Repulsor"}
                for other in model.monsters
            )
        )
        urgent_damage = (
            spiker_kill_control
            - covered_attacking_spiker_cleanup_discount
            + damage_dealt
            - hp_loss * 6
            - model.future_risk
        )
    elif fighting_byrds:
        # Partial hits normally do not prevent this turn's damage. First
        # maximize actual knockdowns/kills; the narrow mixed-fight setup credit
        # above also preserves useful quiet-turn progress toward a next-turn
        # knockdown. Once reserve falls, block, Weak, and Strength loss take over.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        initial_pressure = max(
            0, model.initial_incoming - model.initial_block
        )
        if hp_ratio < 0.35:
            hp_price = 32
        elif hp_ratio < 0.55:
            hp_price = 28
        elif initial_pressure <= max(8, int(model.max_hp * 0.12)):
            hp_price = 1
        else:
            hp_price = 3
        strength_setup_credit = 0
        if hp_ratio >= 0.55 and end_effective_hp >= model.max_hp * 0.40:
            strength_setup_credit = min(60, model.offensive_scaling * 2)
        urgent_damage = (
            byrd_control
            + mixed_byrd_combust_credit
            # A cawing A17+ Byrd attacks six times on its next turn. Weak on it
            # is future block even though the current intent displays no damage.
            + byrd_caw_weak_control
            + strength_setup_credit
            + model.status_aoe_setup_credit * 2
            + damage_dealt
            - hp_loss * hp_price
        )
    elif gremlin_leader_encounter:
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 4 if hp_ratio < 0.35 else 2
        leader = next(
            (
                monster for monster in model.monsters
                if monster.monster_id == "GremlinLeader" and monster.alive
            ),
            None,
        )
        known_next_leader_finish_control = 0
        if leader is not None and "ATTACK" not in leader.intent:
            known_next_damage = _known_next_turn_attack_damage(
                model,
                target=leader,
                require_full=False,
            )
            leader_life = leader.hp + leader.block
            if (
                known_next_damage >= leader_life
                and end_effective_hp >= max(12, int(model.max_hp * 0.18))
            ):
                # CommunicationMod exposes the exact next draw. On the logged
                # quiet turn, Inflame changed five known attacks from 45 damage
                # into a Leader kill, but static current-turn minion progress
                # hid that payoff. Target the Leader explicitly so Vulnerable on
                # a minion cannot manufacture a false finish, and accept a short
                # draw pile because every remaining card is still guaranteed.
                known_next_leader_finish_control = 180 + min(
                    60, (known_next_damage - leader_life) * 3
                )
        leader_multihit_crisis = bool(
            leader
            and "ATTACK" in leader.intent
            and leader.hits >= 2
            and max(0, model.initial_incoming - model.initial_block)
            >= max(24, int(model.max_hp * 0.30))
        )
        if leader_multihit_crisis:
            hp_price = max(hp_price, 4)
        early_demon_form_commitment = bool(
            leader_multihit_crisis
            and model.turn <= 2
            and model.initial_hp >= int(model.max_hp * 0.70)
            and end_effective_hp >= max(24, int(model.max_hp * 0.35))
            and _power_amount(model.player_powers, "Demon Form") > 0
            and model.offensive_scaling >= SAFE_POWER_VALUES["Demon Form"]
        )
        quiet_leader_scaling_setup = 0
        if (
            leader is not None
            and "ATTACK" not in leader.initial_intent
            and leader.hp > max(45, int(leader.max_hp * 0.30))
            and model.initial_incoming <= max(12, int(model.max_hp * 0.20))
            and end_effective_hp >= max(24, int(model.max_hp * 0.35))
            and not any(
                minion.alive and "ATTACK" in minion.intent
                for minion in gremlin_minions
            )
        ):
            # After the active adds are cleared, a quiet Leader turn is the
            # scarce window for permanent Strength. The logged A17 fight kept
            # Demon Form+ in hand on turn nine, took four low-value attacks,
            # and then faced a 22x3 Leader with no scaling online.
            quiet_leader_scaling_setup = min(
                80, model.offensive_scaling * 2
            )
        if gremlin_minions:
            # Gremlin Leader's safe turns end as soon as two minions are alive.
            # The v67 log repeatedly hit the Leader while a Warrior/Fat Gremlin
            # survived, allowing another summon-and-attack cycle. Give removing
            # minions immediate control value; killing the nearly-dead Leader
            # still wins outright through the much larger kill bonus.
            if leader_multihit_crisis:
                # A minion kill is useful, but paying most of the current life
                # bar for it while Leader attacks three times is not control.
                # Permanent Strength loss and Weak cover every later summon
                # cycle, so keep their setup value visible in this crisis. Base
                # this branch on minions present at turn start: a candidate that
                # barely clears the last add must not switch to the full-credit
                # no-minion branch and hide a catastrophic HP trade.
                urgent_damage = (
                    gremlin_leader_kill_control
                    + known_next_leader_finish_control
                    + gremlin_minion_control // 3
                    + gremlin_minion_progress // 2
                    + damage_dealt // 3
                    + model.scaling * 2
                    + (
                        model.offensive_scaling
                        if early_demon_form_commitment
                        else 0
                    )
                    - hp_loss * hp_price
                    - model.resource_risk
                )
            else:
                urgent_damage = (
                    gremlin_leader_kill_control
                    + known_next_leader_finish_control
                    + gremlin_minion_control
                    + gremlin_minion_progress * 2
                    + damage_dealt // 3
                    + model.strength_debuff_scaling
                    + quiet_leader_scaling_setup
                    - gremlin_warrior_enrage_risk * 16
                    - hp_loss * hp_price
                    - model.resource_risk
                )
        else:
            urgent_damage = (
                gremlin_leader_kill_control
                + known_next_leader_finish_control
                + gremlin_minion_control
                + damage_dealt
                + model.offensive_scaling
                + quiet_leader_scaling_setup
                - hp_loss * hp_price
            )
    elif len(sentries) >= 2:
        # Finish a low-HP Sentry even when overkill lowers raw damage. Efficient
        # block also buys the draw cycles needed to escape Dazed-heavy hands.
        # At high HP, paying a small amount to accelerate an attacking outer
        # Sentry can prevent a full extra ten-damage cycle on the next draw.
        sentry_hp_price = (
            1
            if model.initial_hp >= int(model.max_hp * 0.65)
            and any(
                monster.alive and "ATTACK" in monster.intent
                for monster in sentries
            )
            else 2
        )
        urgent_damage = (
            sentry_kills * 100 + damage_dealt - hp_loss * sentry_hp_price
        )
    elif red_slaver_encounter or colosseum_slaver_pair:
        # Red Slaver's Entangle can blank the next attack hand. Concentrate the
        # opener on it instead of drifting toward Blue Slaver's current attack;
        # once it dies, normal multi-enemy scoring resumes on the next state.
        # The Colosseum's Red/Blue pair has no Taskmaster, but needs the same
        # immediate focus. It is a short fight, so do not let slow Power setup
        # outrank damage that makes Red killable before its larger follow-up.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = (
            7 if colosseum_slaver_pair and hp_ratio < 0.45
            else 5 if colosseum_slaver_pair
            else 6 if hp_ratio < 0.45
            else 3
        )
        if (
            triple_slaver_encounter
            and red_slaver is not None
            and red_slaver.alive
            and model.initial_incoming - model.initial_block
            >= max(18, int(model.max_hp * 0.22))
        ):
            # If the opener cannot kill Red Slaver, partial focus damage is not
            # worth a third of the run. Flame Barrier also retaliates against
            # all three attackers while preserving the next draw cycle.
            hp_price = max(hp_price, 7)
        durable_setup = model.offensive_scaling if red_slaver_encounter else 0
        urgent_damage = (
            red_slaver_kill_control
            + slaver_weak_control
            + red_slaver_damage * 3
            + damage_dealt
            + durable_setup
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif slaver_cleanup_encounter:
        # Once Red Slaver is gone, two attackers remain and the fight is too
        # short for low-life speculative scaling. The logged A13 turn had
        # Power Through, Twin Strike and four energy at 15 HP, but spent three
        # energy on Demon Form and died before its first useful Strength tick.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 6 if hp_ratio < 0.30 else 4 if hp_ratio < 0.50 else 2
        durable_setup = model.offensive_scaling if hp_ratio >= 0.45 else 0
        urgent_damage = (
            slaver_cleanup_control
            + damage_dealt * 2
            + slaver_cleanup_focus_damage * 3
            + durable_setup
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif support_encounter and support_focus_locked:
        # The support target must stay locked until it is dead.  Communication
        # Mod does not always expose a reliable turn counter, so the old
        # ``turn >= 3`` gate often never activated.  Worse, cumulative progress
        # made a Healer at 2-8 HP look "already handled", letting overkill-
        # efficient attacks switch to Centurion while the Healer restored both
        # enemies. Reward only support damage made this turn and heavily price
        # ending the turn with a finishable Healer/Mystic still alive. Keep
        # this branch after the support dies so its kill credit is not lost.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        if hp_ratio < 0.30:
            # At true critical reserve, another five Block is the difference
            # between keeping a follow-up turn and dying to Centurion's next
            # attack. Nonlethal support damage no longer buys that HP cheaply.
            hp_price = 16
            support_damage_weight = 3
        elif hp_ratio < 0.45:
            # At 33/85 against Centurion plus Mystic, five block was worth a
            # complete extra turn. The old linear price still traded it for a
            # third support-target attack, leaving the player at two HP before
            # Centurion's multi-hit. Near critical reserve, preserve that turn.
            hp_price = 12
            support_damage_weight = 4
        elif hp_ratio < 0.55:
            # Do not let same-turn replanning forget the HP budget after an
            # opening attack. The logged line correctly planned Wild Strike
            # into Flame Barrier, then re-evaluated and replaced the block with
            # Clothesline, falling from 38 to 18 HP.
            hp_price = 8
            support_damage_weight = 4
        else:
            hp_price = 3
            support_damage_weight = 9
        if support_is_sole_attacker:
            # When Centurion is defending and the Healer is the only attacker,
            # racing the support is unnecessary. Preserve HP and take durable
            # Spot Weakness scaling unless an attack can actually kill it.
            hp_price = max(hp_price, 12)
            support_damage_weight = 4
        if shielded_support_heal_window:
            # Below half HP, a buff-intent Mystic is using its large heal.  When
            # Centurion has also supplied Block, chip attacks are mostly erased;
            # keep kill credit high but prefer durable setup and useful defense.
            support_damage_weight = min(support_damage_weight, 3)
        support_shield_spend = (
            sum(
                max(0, monster.initial_block - monster.block)
                for monster in support_alive
            )
            if shielded_support_heal_window
            else 0
        )
        frontliner_damage = (
            max(0, damage_dealt - support_damage_this_turn)
            if support_alive
            else 0
        )
        support_cleanup_damage = (
            damage_dealt if model.support_cleanup_encounter else 0
        )
        support_cleanup_weight = 5 if hp_ratio < 0.30 else 3
        heavy_centurion_cleanup = bool(
            model.support_cleanup_encounter
            and hp_ratio < 0.70
            and any(
                monster.monster_id == "Centurion"
                and monster.alive
                and "ATTACK" in monster.intent
                and max(0, monster.damage) * max(1, monster.hits) >= 18
                for monster in model.monsters
            )
        )
        if heavy_centurion_cleanup:
            # Preserve the next boss reserve instead of paying a full multi-hit
            # merely to remove Centurion one draw sooner.
            hp_price = max(hp_price, 5)
        healing_gain = max(0, model.hp - model.initial_hp)
        critical_recovery = (
            healing_gain * 12 if hp_ratio < 0.25 else 0
        )
        critical_frontliner_weak_control = (
            sum(
                min(
                    3,
                    max(0, _power_amount(monster.powers, "Weakened")),
                )
                * 4
                for monster in alive
                if monster.monster_id == "Centurion"
            )
            if hp_ratio < 0.30
            else 0
        )
        quiet_demon_form_setup = (
            model.offensive_scaling * 3
            if (
                # At critical reserve, pressure on the support target plus the
                # known next defensive draw must precede three-energy scaling.
                hp_ratio >= 0.25
                and model.initial_incoming <= model.initial_block
                and support_alive
                and _power_amount(model.player_powers, "Demon Form") > 0
                and model.offensive_scaling >= SAFE_POWER_VALUES["Demon Form"]
            )
            else 0
        )
        post_support_disarm_control = (
            model.strength_debuff_scaling
            * (5 if hp_ratio < 0.30 else 3)
            if (
                model.strength_debuff_scaling > 0
                and not support_alive
                and any(
                    monster.monster_id == "Centurion" and monster.alive
                    for monster in model.monsters
                )
            )
            else 0
        )
        quiet_support_defensive_setup = (
            max(
                0,
                model.scaling
                - model.offensive_scaling
                - model.exhaust_power_scaling,
            )
            * 4
            if (
                model.initial_incoming <= model.initial_block
                and support_alive
            )
            else 0
        )
        quiet_shielded_support_setup = 0
        if (
            shielded_support_heal_window
            and model.initial_incoming <= model.initial_block
            and hp_ratio < 0.40
        ):
            # A low-life turn where Centurion defends and the support heals is
            # the best chance to establish Strength scaling and multi-turn
            # Weak. Do not trade that window for chip which the heal erases.
            durable_debuff_control = sum(
                min(3, max(0, _power_amount(monster.powers, "Weakened"))) * 7
                + min(3, max(0, _power_amount(monster.powers, "Vulnerable"))) * 3
                for monster in alive
            )
            quiet_shielded_support_setup = (
                model.offensive_scaling * 5 + durable_debuff_control
            )
        urgent_damage = (
            support_kill_control * 2
            + support_damage_this_turn * support_damage_weight
            + support_progress
            + model.offensive_scaling
            + quiet_demon_form_setup
            + critical_recovery
            + critical_frontliner_weak_control
            + support_cleanup_damage * support_cleanup_weight
            + post_support_disarm_control
            + quiet_support_defensive_setup
            + quiet_shielded_support_setup
            + (
                model.strength_debuff_scaling * 5
                if hp_ratio < 0.30 and support_alive
                else 0
            )
            # Damage that also reached the support target is not a targeting
            # mistake. The logged A17 Cleave plus Immolate line dealt two less
            # to the blocked Healer but eight more to Centurion than Twin Strike
            # plus Immolate; subtracting that free AoE damage selected the
            # strictly worse total result.
            + frontliner_damage
            - support_finish_penalty
            - support_shield_spend * 2
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif thief_pair_encounter:
        # The thieves escape quickly, so immediate damage is useful even when it
        # is the fourth card and disables Pocketwatch. Preserve HP first, then
        # break equal-loss ties with real progress instead of ending at full
        # Block while Sword Boomerang is still affordable.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 7 if hp_ratio < 0.45 else 4 if hp_ratio < 0.65 else 3
        urgent_damage = (
            thief_kill_control
            + damage_dealt * 2
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif cultist_encounter:
        # In a two-enemy hallway, fully blocking while a Cultist grows turns a
        # quiet opener into an unwinnable damage race. Price HP, but make real
        # progress and removing the scaling enemy visible to the first-turn
        # planner instead of treating all damage as strategically neutral.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        if cultist_attackers >= 2:
            hp_price = (
                10
                if hp_ratio < 0.25
                else 5
                if hp_ratio < 0.45
                else 3
            )
            focus_control = cultist_focus_control // 4
            cultist_progress_weight = 0
        else:
            hp_price = (
                14
                if hp_ratio < 0.25 and cultist_encounter_attackers >= 2
                else 8
                if hp_ratio < 0.45
                else 7
                if model.initial_incoming >= 10
                else 2
            )
            projected_raw_hp = model.initial_hp - model.initial_incoming
            if (
                len(cultists) == 1
                and cultist_attackers == 1
                and model.initial_incoming >= 20
                and projected_raw_hp
                < max(18, int(model.max_hp * 0.25))
            ):
                # A lone Cultist is still accelerating. The logged A19 line
                # spent its last energy on Double Tap, failed to kill by 11 HP,
                # and paid the full 26 damage despite holding Defend. Price the
                # post-hit reserve, not just the healthier bar at turn start.
                hp_price = max(hp_price, 8)
            focus_control = cultist_focus_control
            cultist_progress_weight = 3
        status_setup_weight = 2 if cultist_attackers == 0 else 1
        quiet_three_cultist_demon_form = (
            len(cultists) >= 3
            and cultist_attackers == 0
            and model.turn <= 2
            and model.initial_hp >= int(model.max_hp * 0.55)
            and _power_amount(model.player_powers, "Demon Form") > 0
            and model.offensive_scaling >= SAFE_POWER_VALUES["Demon Form"]
        )
        demon_form_setup_credit = 180 if quiet_three_cultist_demon_form else 0
        remaining_skill_payload = sum(
            card.card_type == "SKILL"
            for pile in (
                model.hand,
                model.draw_pile,
                model.exhaust_pile,
            )
            for card in pile
        )
        quiet_three_cultist_corruption = (
            len(cultists) >= 3
            and cultist_attackers == 0
            and model.turn <= 2
            and model.initial_hp >= int(model.max_hp * 0.55)
            and remaining_skill_payload >= 5
            and model.exhaust_power_ready
            and _power_amount(model.player_powers, "Corruption") > 0
            and model.exhaust_power_scaling >= SAFE_POWER_VALUES["Corruption"]
        )
        corruption_setup_credit = (
            180 if quiet_three_cultist_corruption else 0
        )
        quiet_single_cultist_setup = (
            model.scaling * 3
            if (
                len(cultists) == 1
                and cultist_attackers == 0
                and (
                    model.future_risk == 0
                    or model.risky_power_credit > 0
                )
            )
            else 0
        )
        healing_gain = max(0, model.hp - model.initial_hp)
        healing_weight = 4 if hp_ratio < 0.45 else 2
        urgent_damage = (
            cultist_control
            + focus_control
            + cultist_damage_this_turn * cultist_progress_weight
            + damage_dealt
            + healing_gain * healing_weight
            + model.offensive_scaling
            + demon_form_setup_credit
            + corruption_setup_credit
            + quiet_single_cultist_setup
            + model.status_aoe_setup_credit * status_setup_weight
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif chosen_hex_encounter:
        # Hex's Dazed cost matters, but it cannot be valued above damage that
        # lands immediately. Batch 19 skipped Shockwave plus Defend for 12 raw
        # damage, then repeated the same trade on the next two attack turns.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        hp_price = 6 if hp_ratio < 0.35 else 4 if hp_ratio < 0.55 else 3
        heavy_attack = max(
            0,
            model.initial_incoming - model.initial_block,
        ) >= max(12, int(model.max_hp * 0.18))
        if heavy_attack:
            hp_price = max(hp_price, 4)
        defensive_draw_credit = min(16, model.draw_value * 4) if heavy_attack else 0
        guaranteed_next_block = 0
        if hp_ratio < 0.45:
            known_block = _known_next_turn_block_capacity(
                model, require_full=False, follow_draw=False
            )
            guaranteed_next_block = max(0, known_block or 0) * 2
        chosen = next(
            (
                monster
                for monster in alive
                if monster.monster_id == "Chosen"
            ),
            None,
        )
        chosen_near_finish_credit = 0
        if chosen is not None:
            finish_threshold = max(8, int(chosen.max_hp * 0.08))
            if (
                0 < chosen.hp <= finish_threshold
                and chosen.initial_hp > finish_threshold
                and "ATTACK" in chosen.initial_intent
                and damage_dealt > 0
                and end_effective_hp >= max(10, int(model.max_hp * 0.20))
            ):
                # Hex makes slow setup increasingly expensive. When a current
                # attack leaves Chosen one ordinary hit from death without
                # spending the player's reserve, value that concrete finish
                # window above a three-energy power that deals nothing now.
                chosen_near_finish_credit = 18 + min(
                    8,
                    finish_threshold - chosen.hp,
                )
        known_next_lethal_credit = 0
        if (
            chosen is not None
            and model.known_next_attack_damage > 0
            and chosen.hp <= model.known_next_attack_damage
            and model.statuses_added == 0
        ):
            # CommunicationMod exposes the exact next natural hand. The A17
            # Chosen loss could spend seven HP to leave 31 HP for a known
            # 35-damage hand, but the one-turn HP price instead chose ten
            # block and left 50 HP. Credit only a fully known, unclogged
            # next-turn lethal so ordinary speculative aggression is unchanged.
            known_next_lethal_credit = 24 + min(
                16,
                model.known_next_attack_damage - chosen.hp,
            )
        urgent_damage = (
            damage_dealt
            + model.scaling
            + model.offensive_scaling
            + defensive_draw_credit
            + guaranteed_next_block
            + chosen_near_finish_credit
            + known_next_lethal_credit
            - hp_loss * hp_price
            - model.future_risk
            - model.resource_risk
        )
    elif jaw_worm_scaling_race:
        # A lone Jaw Worm that has started Bellowing is a scaling damage race.
        # Treating it as an ordinary hallway made every nonlethal attack worth
        # zero strategic progress, so the bot saved Hemokinesis's two HP while
        # allowing five more Strength and paying entire later attacks instead.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        damage_weight = 2 if hp_ratio >= 0.45 else 1
        hp_price = 8 if hp_ratio < 0.35 else 4 if hp_ratio < 0.50 else 1
        urgent_damage = (
            damage_dealt * damage_weight
            + model.offensive_scaling
            - hp_loss * hp_price
            - model.resource_risk
        )
    elif orb_walker_scaling_race:
        # A18+ Orb Walkers gain five Strength every turn. A generic one-turn
        # health score can therefore overblock the first three small attacks
        # and turn a 96-HP hallway into an unwinnable 30+ damage loop. Convert
        # efficient early damage and permanent setup into race progress, while
        # raising the HP price as the remaining reserve becomes fragile.
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        projected_reserve = end_effective_hp / max(1, model.max_hp)
        damage_weight = 3 if model.turn <= 3 else 2
        hp_price = (
            8
            if projected_reserve < 0.25
            else 5
            if projected_reserve < 0.40
            else 2
            if hp_ratio < 0.65
            else 1
        )
        orb_kill_control = sum(
            180
            for monster in model.monsters
            if monster.monster_id in {"OrbWalker", "Orb Walker"}
            and not monster.alive
        )
        orb_strength = max(
            (
                max(0, _power_amount(monster.powers, "Strength"))
                for monster in alive
                if monster.monster_id in {"OrbWalker", "Orb Walker"}
            ),
            default=0,
        )
        scaling_pressure = min(30, orb_strength * 2 + model.turn * 3)
        urgent_damage = (
            orb_kill_control
            + damage_dealt * damage_weight
            + model.offensive_scaling * 2
            + model.strength_debuff_scaling * 4
            + scaling_pressure
            - hp_loss * hp_price
            - model.future_risk
            - model.resource_risk
        )
    elif short_swarm_race:
        # In short multi-enemy hallway fights, damage now makes the next draw
        # lethal sooner even when this hand cannot quite remove a target. Do
        # not spend the whole opener on Demon Form while five enemies attack.
        urgent_damage = (
            swarm_kill_control
            + damage_dealt
            + charging_wizard_progress * 2
            + charging_wizard_finish_control
            + model.status_aoe_setup_credit
            - model.resource_risk
        )
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        candidate_below_reserve = end_effective_hp < max(
            10, int(model.max_hp * 0.25)
        )
        if imminent_wizard_burst:
            # A charged Wizard's 30-point hit is the encounter's decisive
            # packet. Preserve the following draw instead of spending almost
            # the same life to remove a five-damage support gremlin.
            urgent_damage -= hp_loss * 15
        elif (
            model.ascension >= 18
            and model.turn <= 2
            and hp_ratio >= 0.55
            and model.initial_incoming >= max(
                20, int(model.max_hp * 0.30)
            )
            and hp_loss >= max(10, int(model.max_hp * 0.14))
            and model.initial_burst_block_available
            and any(
                card.card_id in OPENING_BURST_BLOCK_CARDS
                for card in model.hand
            )
        ):
            # A19 Gremlin Gang offered Impervious against 25 opening damage.
            # Spending all three energy on attacks saved only ten HP and then
            # left the following elite with no reserve. A full-turn burst block
            # is allowed to trade one attack for the entire dangerous opener.
            urgent_damage -= hp_loss * 5
        elif hp_ratio < 0.45 or candidate_below_reserve:
            # Once HP is low, preserving the next draw is more important than
            # a few extra points spread across the swarm. Apply the same rule
            # when only the candidate line crosses the reserve: the logged
            # Berserk line made a 45-HP Jaw Worm turn end at eight HP because
            # its inflated enemy threat falsely increased kill-control score.
            urgent_damage -= hp_loss * (4 if candidate_below_reserve else 3)
        elif model.initial_incoming >= max(18, int(model.max_hp * 0.22)):
            # Three A17 Louses represented 24 immediate damage, but the generic
            # short-swarm branch valued only chip progress and spent no energy
            # on Defend or Disarm before a forced elite. Preserve a meaningful
            # reserve whenever a healthy-looking opener is already a heavy hit.
            urgent_damage -= hp_loss * 2
    elif late_hexaghost_race:
        # At low HP, efficient block buys another full draw against Hexaghost.
        # Pure lexicographic damage made the bot spend 5 HP for 9 damage several
        # turns in a row, then die with the boss one hand away from lethal.
        weak_turns = max(0, _power_amount(hexaghost.powers, "Weakened"))
        vulnerable_turns = max(
            0, _power_amount(hexaghost.powers, "Vulnerable")
        )
        durable_debuff_control = 0
        if weak_turns >= 3 and vulnerable_turns >= 3:
            durable_debuff_control = (
                max(0, min(5, weak_turns) - 1) * 6
                + max(0, min(5, vulnerable_turns) - 1) * 4
            )
        elif (
            model.initial_hp / max(1, model.max_hp) < 0.35
            and weak_turns >= 2
        ):
            # At critical reserve, the one Weak turn left after the current
            # attack protects an entire additional Hexaghost draw. The logged
            # A19 line valued only the immediate six HP prevented, so Bludgeon
            # beat Clothesline plus Strike by three points and left three HP.
            durable_debuff_control = (
                max(0, min(5, weak_turns) - 1) * 6
            )
        # One remaining turn is already represented by the current adjusted
        # intent and attack damage. Two or more further turns protect future
        # Hexaghost cycles and amplify later attacks, so even base Shockwave must
        # not lose to chip damage when the HP reserve is already threatened.
        urgent_damage = (
            damage_dealt
            + durable_debuff_control
            + model.strength_debuff_scaling
            - model.resource_risk
        )
        fire_breathing_damage = max(
            0, _power_amount(model.player_powers, "Fire Breathing")
        )
        if (
            fire_breathing_damage
            and model.status_power_ready
            and hexaghost is not None
            and hexaghost.hp > max(30, int(hexaghost.max_hp * 0.20))
            and max(0, model.initial_incoming - model.initial_block) <= 8
        ):
            # Hexaghost supplies Burns and the deck may add Dazed/Wounds of its
            # own. In a genuinely quiet window, deploying a fueled Fire
            # Breathing is immediate race progress rather than optional setup.
            urgent_damage += fire_breathing_damage
        evolve_draw = max(0, _power_amount(model.player_powers, "Evolve"))
        known_statuses = sum(
            card.card_type == "STATUS"
            for card in model.hand + model.draw_pile
        ) + max(0, model.statuses_added)
        if (
            evolve_draw
            and model.status_power_ready
            and known_statuses >= 2
            and hexaghost is not None
            and hexaghost.hp > max(30, int(hexaghost.max_hp * 0.20))
            and max(0, model.initial_incoming - model.initial_block) <= 8
        ):
            # Hexaghost keeps adding Burns after Inferno. In a safe window, a
            # fueled Evolve turns the exact known status queue into real future
            # cards; valuing only this turn's damage left it unplayed for an
            # entire logged A16 fight.
            urgent_damage += min(
                32,
                evolve_draw * (8 + 5 * min(4, known_statuses)),
            )
        if early_hexaghost_setup_window:
            # The logged A10 turn had only four incoming damage and Hexaghost
            # above 85% HP, yet nine Pommel Strike damage outranked Demon Form.
            # Price permanent Strength as three future attack draws while this
            # genuinely safe setup window remains open.
            urgent_damage += model.offensive_scaling * 3
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        projected_unblocked_hp = initial_effective_hp - max(
            0, model.initial_incoming - model.initial_block
        )
        reserve_hp = max(14, int(model.max_hp * 0.42))
        critical_reserve = hp_ratio < 0.45
        early_reserve_pressure = model.turn <= 6 and hp_ratio < 0.50
        projected_reserve_pressure = (
            hp_ratio < 0.65 and projected_unblocked_hp < reserve_hp
        )
        late_cycle_pressure = bool(
            model.turn >= 8
            and model.initial_incoming >= max(12, int(model.max_hp * 0.16))
            and hp_loss >= max(8, int(model.max_hp * 0.10))
        )
        mid_cycle_pressure = bool(
            4 <= model.turn <= 7
            and model.initial_incoming >= max(10, int(model.max_hp * 0.11))
            and hp_ratio <= 0.70
            and _power_amount(model.player_powers, "Strength") >= 2
            and hexaghost.hp > max(70, int(hexaghost.max_hp * 0.30))
            and hp_loss >= 5
        )
        high_ascension_cycle_pressure = bool(
            model.ascension >= 18
            and 3 <= model.turn <= 8
            and model.initial_incoming >= 6
            and hp_ratio <= 0.70
            and hexaghost.hp > max(50, int(hexaghost.max_hp * 0.20))
            and hp_loss >= 5
        )
        if (
            critical_reserve
            or early_reserve_pressure
            or projected_reserve_pressure
            or late_cycle_pressure
            or mid_cycle_pressure
            or high_ascension_cycle_pressure
        ):
            # Price the HP this attack is about to consume, not only the bar at
            # turn start. The logged A13 turn began at 37/80, ignored Feel No
            # Pain plus Defend, and fell to 25 before the next six-hit cycle.
            hp_price = (
                3
                if hp_ratio < 0.50
                and min(projected_unblocked_hp, end_effective_hp) < reserve_hp
                else 2
                if hp_ratio < 0.50
                or mid_cycle_pressure
                or high_ascension_cycle_pressure
                else 1
            )
            urgent_damage -= hp_loss * hp_price
            if (
                model.exhaust_power_ready
                and _power_amount(model.player_powers, "Feel No Pain") > 0
            ):
                # Hexaghost itself supplies Burns while Shockwave/True Grit
                # turn Feel No Pain into block on later pressure hands. At a
                # threatened reserve, establishing it outranks one extra Strike.
                urgent_damage += model.scaling
    elif elite_damage_race or model.champ_race:
        urgent_damage = damage_dealt
        if nob_opening_scaling_window:
            # Nob's Bellow opener is the one turn where a supported Strength
            # power costs no life or Enrage. The logged deck's Demon Form turns
            # its next Pummel and basic attacks into a four-turn kill, whereas
            # two opening Strikes left Nob alive for a sixth lethal attack.
            urgent_damage += model.offensive_scaling * 2
        if champ_crossed_this_turn and model.champ_forced_release:
            # Removing the hold penalty is not enough when a quiet hand can
            # farm setup score instead. Once survival has declared the hold
            # untenable, crossing now replaces Champ's next first-phase move
            # with the scripted transition and is immediate encounter control.
            urgent_damage += 60 - model.self_damage * 3
        if champ_known_deep_followthrough:
            # The current attack still lands, but the following known burst
            # reaches a safe second-phase depth before Execute. Preserve some
            # HP without charging the shallow-transition penalty that made the
            # logged line wait through Champ's debuff.
            urgent_damage -= hp_loss * 2
        elif champ_crossed_this_turn and not model.champ_forced_release:
            # Do not manufacture a "forced" transition by first spending the
            # energy and block cards that made holding safe. The logged A9 run
            # used Fiend Fire at 28 HP, burned Power Through, crossed Champ at
            # 237 HP, and entered Execute range with only three life.
            reserve_hp = max(8, int(model.max_hp * 0.15))
            initial_reserve_gap = max(0, reserve_hp - initial_effective_hp)
            reserve_penalty = max(
                0,
                max(0, reserve_hp - end_effective_hp) - initial_reserve_gap,
            ) * 8
            urgent_damage -= (
                hp_loss * 4
                + model.resource_risk
                + reserve_penalty
            )
        champ_execute_phase = bool(
            champ
            and model.champ_race
            and _power_amount(champ.powers, "Strength") >= 6
        )
        if champ_execute_phase:
            # Anger has finished cleansing the first-phase debuffs. Permanent
            # Strength loss now protects Execute and every later attack, so it
            # is race progress rather than optional setup.
            hp_ratio = model.initial_hp / max(1, model.max_hp)
            urgent_damage += model.strength_debuff_scaling * 3
            urgent_damage -= hp_loss * (3 if hp_ratio < 0.50 else 1)
        book = next(
            (
                monster for monster in alive
                if monster.monster_id == "BookOfStabbing"
            ),
            None,
        )
        if book is not None:
            # Book scales its number of hits every turn. Permanent Strength
            # reduction and durable setup are race progress, not lost tempo.
            # At low HP, however, damage that consumes the next draw is false
            # progress. The logged opener paid 14 of 31 HP despite holding two
            # Defends, then died with Book at 26 HP.
            weak_turns = max(
                0, _power_amount(book.powers, "Weakened")
            )
            multihit_weak_control = (
                min(3, weak_turns)
                * max(4, min(12, max(1, book.hits) * 3))
            )
            early_book_scaling_credit = 0
            if (
                model.turn <= 3
                and book.initial_hp >= int(book.max_hp * 0.65)
                and end_effective_hp >= max(24, int(model.max_hp * 0.45))
            ):
                # Book's hit count rises every turn. A safe early Demon Form or
                # another permanent Strength source must be priced across the
                # remaining race, not as though it had only one future attack.
                # The logged A19 turn-three Demon Form converts the otherwise
                # lethal eighth-hit turn into a kill before Book can attack.
                early_book_scaling_credit = model.offensive_scaling
            urgent_damage += (
                model.scaling
                + multihit_weak_control
                + early_book_scaling_credit
            )
            # Book is a damage race, but deleting Fire Breathing, Bash and
            # the remaining attack package is not free damage.  Keep Fiend
            # Fire's explicit resource cost in the race score.
            if model.turn >= 3 or model.reaper_scaling_reserve:
                urgent_damage -= model.resource_risk
            hp_ratio = model.initial_hp / max(1, model.max_hp)
            projected_unblocked_hp = model.initial_hp - max(
                0, model.initial_incoming - model.initial_block
            )
            book_pressure = book.hits >= 2 or model.initial_incoming >= 20
            if hp_ratio < 0.45:
                book_hp_price = 5
            elif projected_unblocked_hp < max(24, int(model.max_hp * 0.50)):
                # Price the reserve the current multi-hit is about to consume,
                # not only the HP visible before it lands. The logged A10 turn
                # started at 45/85, declined Shrug, and fell straight to 24.
                # Batch 10 repeated the pattern at 60/92 by spending 18 while
                # Flame Barrier was in hand, one turn before the hit count rose.
                book_hp_price = 3 if book_pressure else 2
            elif book_pressure:
                book_hp_price = 2
            else:
                book_hp_price = 0
            urgent_damage -= hp_loss * book_hp_price
        if giant_head_setup_window:
            # Slow makes setup-before-attacks efficient this turn, while early
            # permanent Strength is worth several later Giant Head draws. HP
            # is still a race resource, so do not trade a full hit for chip.
            urgent_damage += model.offensive_scaling * 4
            setup_hp_price = (
                6
                if model.initial_hp < int(model.max_hp * 0.60)
                else 3
            )
            urgent_damage -= hp_loss * setup_hp_price
        elif giant_head and model.initial_incoming >= 35:
            # Giant Head becomes a damage race, but damage that spends the next
            # draw's entire life bar is false progress. Batch 20 twice ignored
            # Power Through/Impervious on 40- and 45-damage turns, then died one
            # turn later with the boss still alive. Preserve a modest reserve;
            # lethal still wins through the leading victory tuple.
            projected_unblocked_hp = initial_effective_hp - max(
                0, model.initial_incoming - model.initial_block
            )
            reserve_hp = max(24, int(model.max_hp * 0.35))
            hp_price = (
                2
                if model.turn >= 6 or projected_unblocked_hp < reserve_hp
                else 1
            )
            urgent_damage -= hp_loss * hp_price
        if giant_head:
            # Giant Head is a six-turn resource race, not a target dummy for
            # early Fiend Fire. Its burst must pay for the attacks and defense
            # it permanently removes; true finish windows already discount
            # that cost inside simulate_card.
            urgent_damage -= model.resource_risk + model.future_risk
            if giant_head_recovery_window:
                # On the logged quiet turn at 23 HP, Reaper was the defensive
                # play: its heal survived the next 40-damage hit. Raw Slow-
                # boosted damage instead spent Impervious while nothing attacked.
                healing_gain = max(0, model.hp - model.initial_hp)
                urgent_damage += healing_gain * 6
        lagavulin_alive = any(monster.monster_id == "Lagavulin" for monster in alive)
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        if lagavulin_alive and model.initial_incoming >= 12:
            # Spot Weakness is real race progress after Lagavulin starts
            # attacking, particularly once its debuffs have erased Strength.
            urgent_damage += min(18, model.offensive_scaling)
            # Lagavulin's debuffs make damage urgent, but paying a full attack
            # for a little extra Strike damage compounds across its later turns.
            # Start pricing the reserve on the first heavy hit, even at full HP.
            if hp_ratio >= 0.90:
                # At a full reserve, Flame Barrier plus one attack is the
                # balance point: absorb most of the hit without extending the
                # fight by over-blocking during Lagavulin's damage race.
                hp_reserve_penalty = (
                    hp_loss * 2
                    if model.ascension >= 18
                    else hp_loss * 3 // 2
                )
            else:
                hp_reserve_penalty = hp_loss * (3 if hp_ratio < 0.50 else 2)
            urgent_damage -= hp_reserve_penalty
        if (
            any(monster.monster_id == "GremlinNob" for monster in alive)
            and hp_ratio < 0.50
        ):
            # Once the reserve is low, skills that still block more than the
            # Enrage they trigger can preserve the next draw without abandoning
            # the race. Raw damage alone previously spent 27 HP for two Strikes.
            urgent_damage -= hp_loss * 2
    else:
        urgent_damage = 0
    if model.double_boss_reserve and survives:
        # At A20 the first Act 3 boss is only half of the final gauntlet. The
        # logged run beat Time Eater after taking an avoidable 24 damage on a
        # setup turn, then entered Awakened One at 15 HP. Price current HP twice:
        # once for this fight's branch and once for the boss waiting behind it.
        urgent_damage -= hp_loss * 2
    if alive and model.limit_break_timing_credit:
        # Several encounter-specific race branches intentionally count only
        # immediate damage. Keep a timely Act 2 Strength double visible there so
        # one more basic attack does not automatically postpone it for a cycle.
        urgent_damage += model.limit_break_timing_credit
    calipers_block_credit = _calipers_retained_block_credit(model)
    if alive and calipers_block_credit:
        urgent_damage += calipers_block_credit
    if alive and model.mummified_hand_credit:
        # The target is random when several positive-cost cards remain, but
        # every live action is followed by a fresh state and replan. Price the
        # expected one-turn energy swing strongly while refusing to let that
        # speculative value excuse a large current hit.
        mummified_credit = model.mummified_hand_credit
        hp_price = 8 if model.initial_hp * 2 < model.max_hp else 5
        mummified_credit = max(0, mummified_credit - hp_loss * hp_price)
        if _awakened_curiosity_live(model):
            mummified_credit //= 2
        urgent_damage += mummified_credit
    future_intangible_stacks = max(
        0,
        _power_amount(model.player_powers, "IntangiblePlayer") - 1,
    )
    if alive and future_intangible_stacks:
        hp_ratio = model.initial_hp / max(1, model.max_hp)
        # The current stack handles this enemy turn; every additional stack is
        # a whole future protected turn. This is especially valuable when
        # multiple Ethereal Apparitions would otherwise disappear together.
        urgent_damage += future_intangible_stacks * (
            36 if hp_ratio < 0.50 else 18
        )
    # A Fairy in a Bottle or unused Lizard Tail is a future life, not ordinary
    # effective HP.  Preserve it when a defensive line can do so, while keeping
    # immediate victory lexicographically ahead of this resource price.
    urgent_damage -= revive_spend_penalty
    pocketwatch_draw = (
        3
        if 0 <= model.pocketwatch_counter <= 3 and alive
        else 0
    )
    relic_future_credit = 0
    ice_cream_bank_credit = 0
    art_of_war_bank_credit = 0
    if alive and survives:
        extra_energy = max(
            0, _projected_next_turn_energy(model) - model.next_turn_energy
        )
        stored_energy = max(0, model.energy) if model.ice_cream else 0
        conditional_art_energy = int(
            model.art_of_war and model.attacks_played == 0
        )
        relic_future_credit += max(
            0, extra_energy - stored_energy - conditional_art_energy
        ) * 6
        # Ice Cream stores real energy, but banking it is an alternative use of
        # this turn's resource rather than a free relic proc. Keep it beside
        # damage and known-draw progress so a quiet enemy no longer makes
        # unused energy lexicographically beat every playable attack.
        ice_cream_bank_credit = stored_energy * 4
        art_of_war_bank_credit = _art_of_war_future_credit(model)
        relic_future_credit += min(24, model.self_forming_clay_block)
        if (
            model.incense_burner_counter >= 0
            and model.incense_burner_counter % 6 == 5
        ):
            relic_future_credit += (
                30 if model.initial_hp * 2 < model.max_hp else 18
            )
        relic_future_credit += model.random_card_credit
    known_draw_progress = (
        damage_dealt
        + _known_draw_outlook(model, hand_size=8 if pocketwatch_draw else 5)
        + ice_cream_bank_credit
        + art_of_war_bank_credit
    )
    score = (
        int(survives),
        int(victory),
        urgent_damage,
        net_health,
        sentry_kills,
        sentry_focus,
        sentry_outer_progress,
        -danger_alive,
        model.scaling + model.draw_value + pocketwatch_draw
        + relic_future_credit,
        known_draw_progress,
        -priority_hp,
        damage_dealt,
        junk_cleanup,
        -model.self_damage,
        -model.statuses_added,
        -len(model.commands),
        0,
    )
    return TurnPlan(model.commands + ("END",), hp_loss, score)


def _state_key(model):
    return (
        model.hp,
        model.max_hp,
        model.revive_hp,
        model.block,
        model.energy,
        model.drawable_cards,
        model.pocketwatch_counter,
        model.velvet_choker_counter,
        model.initial_strength,
        model.runic_cube,
        model.has_boot,
        model.paper_frog,
        model.chemical_x,
        model.player_powers,
        tuple((m.hp, m.block, m.intent, m.damage, m.hits, m.powers) for m in model.monsters),
        tuple((c.uuid, c.cost, c.upgrades) for c in model.hand),
        tuple((c.uuid, c.cost, c.upgrades) for c in model.draw_pile),
        tuple((c.uuid, c.cost, c.upgrades) for c in model.exhaust_pile),
        model.scaling,
        model.exhaust_power_scaling,
        model.statuses_added,
        model.future_risk,
        model.slime_split_hp,
        model.slime_debuff_scaling,
        model.strength_debuff_scaling,
        model.junk_exhausted,
        model.risky_power_credit,
        model.champ_race,
        model.champ_forced_release,
        model.conserve_exhaust_defense,
        model.strike_cards,
        model.attack_cards,
        model.exhaust_power_ready,
        model.barricade_support,
        model.offensive_scaling,
        model.limit_break_timing_credit,
        model.status_aoe_setup_credit,
        model.resource_risk,
        model.feed_max_hp_gain,
        model.reaper_scaling_reserve,
        model.time_eater_haste_guard,
        model.status_power_ready,
        model.self_damage_power_ready,
        model.awakened_key_power_credit,
        model.awakened_curiosity_risk,
        model.bronze_orb_cleanup_credit,
        model.initial_support_hp,
        model.initial_support_block_available,
        model.support_cleanup_encounter,
        model.next_turn_energy,
        model.act,
        model.ascension,
        model.double_boss_reserve,
        model.initial_time_warp,
        model.known_next_attack_damage,
        model.calipers,
        model.charons_ashes,
        model.pen_nib_counter,
        model.pen_nib_ready,
        model.brimstone_race,
        model.combust_hp_loss,
        model.mummified_hand,
        model.mummified_hand_credit,
        model.attacks_played,
        model.centennial_puzzle_available,
        model.happy_flower_counter,
        model.incense_burner_counter,
        model.ink_bottle_counter,
        model.kunai_counter,
        model.letter_opener_counter,
        model.necronomicon_available,
        model.nunchaku_counter,
        model.orange_pellets_mask,
        model.ornamental_fan_counter,
        model.random_card_credit,
        model.self_forming_clay_block,
        model.shuriken_counter,
        model.stone_calendar_ready,
        model.sundial_counter,
    )


def plan_turn(combat, gs=None, max_actions=8, node_budget=25000):
    initial = build_model(combat, gs)
    best = _evaluate(initial)
    stack = [(initial, 0)]
    seen = {}
    nodes = 0
    while stack and nodes < node_budget:
        model, depth = stack.pop()
        nodes += 1
        candidate = _evaluate(model)
        if candidate.score > best.score:
            best = candidate
        if depth >= max_actions or not model.hand:
            continue
        key = _state_key(model)
        previous = seen.get(key)
        if previous is not None and previous >= model.draw_value:
            continue
        seen[key] = model.draw_value
        for hand_index, hand_card in enumerate(model.hand):
            if not hand_card.is_playable or _card_cost(hand_card, model) > model.energy:
                continue
            if hand_card.card_id == "Limit Break" and model.strength <= 0:
                continue
            if hand_card.card_id == "Rupture" and not model.self_damage_power_ready:
                continue
            if (
                hand_card.card_id == "Second Wind"
                and (model.velvet_choker_counter < 0 or model.velvet_choker_counter <= 4)
                and not any(
                    _power_amount(monster.powers, "Time Warp") >= 11
                    for monster in model.monsters if monster.alive
                )
                and any(
                    other_index != hand_index
                    and other.card_id == "Power Through"
                    and other.is_playable
                    and _card_cost(other, model) <= model.energy
                    and (
                        _card_cost(hand_card, model) + _card_cost(other, model)
                        <= model.energy
                        or (
                            not _power_amount(model.player_powers, "No Block")
                            and max(
                                0,
                                model.incoming
                                - model.block
                                - adjusted_block(
                                    BLOCK_VALUE["Power Through"][0]
                                    + BLOCK_VALUE["Power Through"][1]
                                    * min(other.upgrades, 1),
                                    model.dexterity,
                                    model.frail,
                                ),
                            ) < model.hp + model.revive_hp
                        )
                    )
                    for other_index, other in enumerate(model.hand)
                )
            ):
                # Power Through creates two extra Second Wind targets while
                # moving the reusable block card safely to discard. The logged
                # A19 Book line reversed that order and permanently deleted its
                # strongest repeatable defense before the hit count scaled.
                continue
            if (
                hand_card.card_id == "True Grit"
                and hand_card.upgrades <= 0
                and model.incoming > model.block
                and any(
                    other_index != hand_index
                    and other.card_id != "True Grit"
                    and other.card_id in BLOCK_VALUE
                    and other.is_playable
                    and not other.exhausts
                    and _card_cost(hand_card, model) + _card_cost(other, model)
                    <= model.energy
                    for other_index, other in enumerate(model.hand)
                )
            ):
                # Base True Grit exhausts a random remaining card in the live
                # game. Spend affordable block cards first on an attack turn so
                # the random roll cannot erase defense the plan still relies on.
                continue
            targets = range(len(model.monsters)) if hand_card.has_target else (None,)
            for target_index in targets:
                if target_index is not None and not model.monsters[target_index].alive:
                    continue
                try:
                    next_model = simulate_card(model, hand_index, target_index)
                except ValueError:
                    continue
                stack.append((next_model, depth + 1))
    if best.commands == ("END",):
        # A random generated attack is an observation boundary: play the
        # generator, then replan from the real card instead of inventing it.
        entangled = _power_amount(initial.player_powers, "Entangled") > 0
        choker_full_next = any(
            relic.get("id") == "Velvet Choker"
            and int(relic.get("counter", 0) or 0) >= 5
            for relic in (gs or {}).get("relics", [])
        )
        time_warp_full_next = any(
            _power_amount(monster.powers, "Time Warp") >= 11
            for monster in initial.monsters if monster.alive
        )
        if not (entangled or choker_full_next or time_warp_full_next):
            for index, card in enumerate(initial.hand):
                if card.card_id != "Infernal Blade" or not card.is_playable:
                    continue
                try:
                    generated = simulate_card(initial, index, None)
                except ValueError:
                    continue
                candidate = _evaluate(generated)
                if (
                    candidate.score[0] >= best.score[0]
                    and candidate.hp_loss <= best.hp_loss
                    and any(monster.alive for monster in generated.monsters)
                ):
                    return candidate
    return best
