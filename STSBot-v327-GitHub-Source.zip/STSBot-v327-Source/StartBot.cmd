@echo off
title Slay the Spire Ironclad Bot
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0outputs\start_sts_autoplay.ps1"
set "BOT_EXIT=%ERRORLEVEL%"
if not "%BOT_EXIT%"=="0" echo.
if not "%BOT_EXIT%"=="0" echo Start failed. Run CheckEnvironment.cmd and read the usage guide.
pause
exit /b %BOT_EXIT%
