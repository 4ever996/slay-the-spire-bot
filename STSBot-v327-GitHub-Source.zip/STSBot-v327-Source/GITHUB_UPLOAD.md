# STSBot v327：GitHub 上传说明

## 检查结果（本次实际读取 ZIP 目录和文件统计）

- 原压缩包：`STSBot-v327-Portable.zip`
- ZIP 大小：34,068,510 字节（32.49 MiB）。
- 解压后的文件总大小：63,008,890 字节（60.09 MiB）；共 2,088 个文件。
- `runtime/python/`：40.10 MiB。
- `runtime/mods/`：17.41 MiB。
- 两类附带运行环境合计：57.51 MiB，占解压文件总大小的 95.7%。
- 从原包原样保留到源码包的文件：15 个，合计 1.22 MiB（不含新增说明等文件）。
- 原 ZIP SHA-256：`d4f69aeecc67e8607ffc93ee925ab0b5bc6c87ecf65c3de22fbacd10d51c7151`。

本次源码包不包含运行环境、Python 缓存、本机 `portable_config.json` 和原便携包的
`SHA256SUMS.txt`。原校验文件不适用于精简后的源码分发，因此另生成 `SHA256SUMS.source.txt`。
原始完整 ZIP 未修改。所有保留的原文件均已逐字节/校验值核对。

## 推荐步骤：源码和完整便携包分别上传

### 1. 上传源码

1. 解压 `STSBot-v327-GitHub-Source.zip`，进入其中的 `STSBot-v327-Source` 文件夹。
2. 在 GitHub 仓库打开 Add file → Upload files。
3. 上传该文件夹里面的文件及子文件夹，让 README.md、work/、outputs/ 位于仓库根目录。
4. 填写“首次上传 STSBot v327 源码”，检查更改并提交。
5. 不要只把源码 ZIP 当一个文件上传；源码应当展开，便于查看和维护。

网页上传每个文件上限为 25 MiB，一次最多 100 个文件。此源码包的文件数和单文件大小
均在这两个限制以内。[1]

### 2. 上传完整便携包

1. 仓库至少需要一次提交；完成上面的源码提交即可。
2. 打开仓库 Releases → Draft a new release。
3. 新建版本标签，例如 `v327`，Target 选择实际保存源码的分支（通常为 main）。
4. 标题可用 `STSBot v327 Portable`，说明中写清支持的系统、依赖和使用方法。
5. 将原完整 `STSBot-v327-Portable.zip` 拖到发布页面的附件/二进制文件上传区域，
   而不是普通 Add file → Upload files 页面或仅用于正文图片的区域。
6. 附件上传完成后，检查访问范围和内容，再点击 Publish release。[2]

Releases 专项文档规定每个附件小于 2 GiB；这个约 32.49 MiB 的 ZIP 在该范围内。[3]
下载者应选择你手工上传的 Portable.zip，而不是 GitHub 自动生成的 Source code (zip)。[3]

原完整包中存在本机游戏目录配置。公开分发前可在自己的发布副本中移除
`portable_config.json` 后重新压缩；不要直接删除仍在使用的本地工作副本。
原包的说明和启动脚本表明，启动器可以重新定位并写入该配置。本次没有改动原完整包。

## 另一条路径：通过 Git 上传完整内容

普通 Git 推送的单文件硬限制为 100 MiB，不是网页上传的 25 MiB。
本次原 ZIP 小于 100 MiB，解压后的每一个文件也都小于 100 MiB，
因此不必仅为了本次体积使用 Git LFS。[4]

VS Code 的 Source Control 可发布到 GitHub，也可以向已经关联的远程仓库推送提交。[5]
若仓库已在网页创建，不要重复使用“新建发布仓库”来建立第二个同名仓库；应先克隆现有仓库，
复制文件到该工作副本，再提交和推送。

但为保持历史清晰，建议普通仓库仅跟踪源码，完整分发包仍放 Releases。

## .gitignore 的作用边界

`.gitignore` 作用于本地 Git 的文件跟踪/提交选择；它不是 ZIP 压缩器，也不会删除你在
资源管理器里看到的文件。往一个已有 ZIP 里添加 `.gitignore` 不会让 ZIP 自动变小。
网页拖拽上传和手工压缩时，应自行选择文件，不要依赖它自动剔除内容。
已经被 Git 跟踪的文件，需要另行取消跟踪；仅补一条规则不会自动清理历史。[6]

此项目的 `outputs/` 保存启动和停止 PowerShell 脚本，不能因目录名称像“输出目录”
就整个忽略。实际本机通信与日志目录为 `work/sts-comm/`。

## 官方依据（核对日期：2026-09-18）

[1] GitHub — Adding a file to a repository:
https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository

[2] GitHub — Managing releases in a repository:
https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository

[3] GitHub — About releases:
https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases

[4] GitHub — About large files on GitHub:
https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github

[5] VS Code — Working with repositories and remotes:
https://code.visualstudio.com/docs/sourcecontrol/repos-remotes

[6] GitHub — Ignoring files:
https://docs.github.com/en/get-started/git-basics/ignoring-files
