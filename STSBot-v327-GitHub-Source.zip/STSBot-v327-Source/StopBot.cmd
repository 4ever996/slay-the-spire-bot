@echo off
title Stop Slay the Spire Ironclad Bot
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0outputs\stop_sts_autoplay.ps1"
pause
