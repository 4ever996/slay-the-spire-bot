@echo off
title Check Slay the Spire Bot Package
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0outputs\start_sts_autoplay.ps1" -CheckOnly
set "BOT_EXIT=%ERRORLEVEL%"
echo.
if "%BOT_EXIT%"=="0" echo Check passed. You can run StartBot.cmd.
if not "%BOT_EXIT%"=="0" echo Check failed. Read the usage guide and the message above.
pause
exit /b %BOT_EXIT%
