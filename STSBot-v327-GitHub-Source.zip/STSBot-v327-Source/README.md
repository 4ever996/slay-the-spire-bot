# STSBot v327 — 源码版

《杀戮尖塔》战士自动打牌机器人项目的源码整理包。

**本目录不是完整便携运行包。** 未附带 `runtime/python/` 和 `runtime/mods/`，
因此不能把它当作“无需安装依赖，解压即用”的完整版本。
直接使用请保留原来的 `STSBot-v327-Portable.zip`；项目维护者可以将完整包作为 GitHub Release 附件发布。

## 目录

```text
work/                           Python 策略、通信桥、界面和评分数据
outputs/start_sts_autoplay.ps1   启动与环境检查脚本（必须保留）
outputs/stop_sts_autoplay.ps1    停止脚本（必须保留）
StartBot.cmd                    Windows 启动入口
CheckEnvironment.cmd            Windows 环境检查入口
StopBot.cmd                     Windows 停止入口
使用说明.txt                    原便携包说明，阅读时注意其便携包前提
.gitignore                      源码仓库忽略规则
portable_config.example.json    不含本机路径的配置格式示例
GITHUB_UPLOAD.md                 上传步骤与本次整理范围
SHA256SUMS.source.txt            本次源码文件校验清单
```

原说明中提到的中文命令文件，在本次收到的压缩包中未找到对应文件。
请以本目录实际存在的 `StartBot.cmd`、`CheckEnvironment.cmd`、`StopBot.cmd` 为准。

## 使用源码进行开发

最直接的依赖准备方法：从对应版本的完整便携包中，把整个 `runtime/` 文件夹复制到
本目录，保持 `runtime/python/` 和 `runtime/mods/` 的内部结构。运行仍然需要游戏本体
及原说明要求的系统环境。本目录下的 `.gitignore` 会让本地 Git 默认不提交这个运行环境。
也可以自行配置 Python 和 Mod，但这不属于本次上传整理或运行验证的范围。

`portable_config.json` 是启动器写入的本机配置；通常不必手工创建。
示例文件只说明格式，不必为了启动而重命名它。

## GitHub 发布安排

源码文件放仓库的 Code 区域；完整便携 ZIP 放 Releases 的附件区。
上传到网页时，先解压源码 ZIP，再上传内部的文件和文件夹，不要只上传源码 ZIP 本身。
GitHub 自动生成的 Source code (zip) 是仓库源码快照，不会自动包含单独上传的完整便携附件。

第三方组件的来源已在原 `使用说明.txt` 中列出。本次整理未新增或替项目选择开源许可证。
对外发布前，请检查待发布内容、第三方组件许可说明及本机配置。

## 本次处理范围

原始 Python、PowerShell、CMD 和 CSV 文件保持字节不变；仅整理打包范围并新增说明、
忽略规则、配置示例和校验清单。未运行上传包中的脚本或 Windows 游戏，未进行完整安全审计。
详见 `GITHUB_UPLOAD.md`。
